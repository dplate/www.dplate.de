# Microsoft Developer Studio Project File - Name="ScapeMaker" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** NICHT BEARBEITEN **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=ScapeMaker - Win32 Debug
!MESSAGE Dies ist kein g�ltiges Makefile. Zum Erstellen dieses Projekts mit NMAKE
!MESSAGE verwenden Sie den Befehl "Makefile exportieren" und f�hren Sie den Befehl
!MESSAGE 
!MESSAGE NMAKE /f "ScapeMaker.mak".
!MESSAGE 
!MESSAGE Sie k�nnen beim Ausf�hren von NMAKE eine Konfiguration angeben
!MESSAGE durch Definieren des Makros CFG in der Befehlszeile. Zum Beispiel:
!MESSAGE 
!MESSAGE NMAKE /f "ScapeMaker.mak" CFG="ScapeMaker - Win32 Debug"
!MESSAGE 
!MESSAGE F�r die Konfiguration stehen zur Auswahl:
!MESSAGE 
!MESSAGE "ScapeMaker - Win32 Release" (basierend auf  "Win32 (x86) Application")
!MESSAGE "ScapeMaker - Win32 Debug" (basierend auf  "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MD /W2 /GX /O2 /Ob2 /I "$(QTDIR)\include" /I ".\thirdparty\includes" /I ".\thirdparty\ziparchive" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "QT_DLL" /D "QT_THREAD_SUPPORT" /FAcs /YX /FD /c
# SUBTRACT CPP /Fr
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG"
# ADD RSC /l 0x407 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /machine:I386
# ADD LINK32 version.lib dxguid.lib dinput8.lib kernel32.lib winmm.lib user32.lib cximage.lib jbig.lib Jpeg.lib png.lib Tiff.lib zlib.lib jasper.lib j2k.lib ZipArchive_STL.lib d3dx9dt.lib d3d9.lib dxerr9.lib gdi32.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib imm32.lib wsock32.lib $(QTDIR)\lib\qt-mt230nc.lib $(QTDIR)\lib\qtmain.lib /nologo /subsystem:windows /machine:I386 /out:"ScapeMaker.exe" /libpath:"./thirdparty/libs/"
# SUBTRACT LINK32 /pdb:none /debug

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /GZ /c
# ADD CPP /nologo /MD /W3 /Gm /GX /Zi /Od /I "$(QTDIR)\include" /I ".\thirdparty\includes" /I ".\thirdparty\ziparchive" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "QT_DLL" /D "QT_THREAD_SUPPORT" /D "D3D_DEBUG_INFO" /FAcs /FR /YX /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "_DEBUG"
# ADD RSC /l 0x407 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 version.lib dxguid.lib dinput8.lib kernel32.lib winmm.lib user32.lib cximage.lib jbig.lib Jpeg.lib png.lib Tiff.lib zlib.lib jasper.lib j2k.lib ZipArchive_STL.lib d3dx9dt.lib d3d9.lib dxerr9.lib gdi32.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib imm32.lib wsock32.lib $(QTDIR)\lib\qt-mt230nc.lib $(QTDIR)\lib\qtmain.lib /nologo /subsystem:windows /incremental:no /map /debug /debugtype:both /machine:I386 /out:"ScapeMaker.exe" /pdbtype:sept /libpath:"./thirdparty/libs/"
# SUBTRACT LINK32 /pdb:none

!ENDIF 

# Begin Target

# Name "ScapeMaker - Win32 Release"
# Name "ScapeMaker - Win32 Debug"
# Begin Group "Quellcodedateien"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat;for;f90"
# Begin Source File

SOURCE=.\source\engine\common\AABB.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\bitmapnav.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\bitmapnavbase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\camera.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\clouds\cloud.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\clouds\cloudlayer.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\clouds\clouds.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsgen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\config.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\config\configgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\config\configguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\console\console.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\coolslider.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\postprocessing\depth.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\directxfont.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\dxframework.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\dxutil.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\dynamicterrainobject.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\engine.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\enginehelpers.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\enviromentgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\enviromentguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\guihelpers.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\postprocessing\heightbasedfog.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\heightmap.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\hud\hud.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\info\infoguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\input\input.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\justplaying.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\input\keyboard.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\keys3dmode.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\lensflare.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\lightmap.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\load\loadgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\load\loadguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\logger\logger.cpp
# End Source File
# Begin Source File

SOURCE=.\source\main.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\maskimportgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\maskimportguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\hud\minimap.cpp
# End Source File
# Begin Source File

SOURCE=.\source\common\minixml.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_bitmapnav.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_bitmapnavbase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\moc_cloudsgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\moc_cloudsguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\config\moc_configgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\config\moc_configguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_coolslider.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\moc_enviromentgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\moc_enviromentguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_guihelpers.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\info\moc_infoguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\moc_keys3dmode.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\load\moc_loadgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\load\moc_loadguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_maskimportgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_maskimportguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\moc_objectsgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\moc_objectsguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\moc_previewfullscreenbase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\moc_previewgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\moc_previewguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\moc_scapemakerdialog.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\moc_scapemakerdialogbase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_textureexportgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\moc_textureexportguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\moc_texturegui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\moc_textureguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\moc_topografiegui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\moc_topografieguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\moc_watergui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\moc_waterguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\module.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\moon.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\input\mouse.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\object.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectgen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\objects.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectsgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectsguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\particles\particles.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\particles\particlesource.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\particles\particletype.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewfullscreenbase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\rivers.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\riversgen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\riversmap.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\riverstile.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\scapemakerdialog.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\scapemakerdialogbase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\screenshot.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\scripts\scripts.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\sea.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\seagen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\seatile.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\shadowgen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\sky.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\stars.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\staticterrainobject.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\hud\statusline.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\submesh.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\submeshes.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\sun.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\terrain.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\terraintile.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\textureexportgui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\textureexportguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\texturegen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\texturegui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\textureguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\tilecheck.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\time.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topogen.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topografiegui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topografieguibase.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\viewfrustum.cpp
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\water.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\watergui.cpp
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\waterguibase.cpp
# End Source File
# End Group
# Begin Group "Header-Dateien"

# PROP Default_Filter "h;hpp;hxx;hm;inl;fi;fd"
# Begin Source File

SOURCE=.\source\engine\common\aabb.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\bitmapnav.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\bitmapnav.h
InputName=bitmapnav

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\bitmapnav.h
InputName=bitmapnav

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\common\bitmapnavbase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\camera.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\clouds\cloud.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\clouds\cloudlayer.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\clouds\clouds.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsgen.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\clouds
InputPath=.\source\gui\clouds\cloudsgui.h
InputName=cloudsgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\clouds
InputPath=.\source\gui\clouds\cloudsgui.h
InputName=cloudsgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\scripts\commands.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\config.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\config\configgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\config
InputPath=.\source\gui\config\configgui.h
InputName=configgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\config
InputPath=.\source\gui\config\configgui.h
InputName=configgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\config\configguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\console\console.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\coolslider.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\coolslider.h
InputName=coolslider

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\coolslider.h
InputName=coolslider

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\engine\postprocessing\depth.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\directxfont.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\dxframework.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\dxutil.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\dynamicterrainobject.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\engine.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\enginehelpers.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\enviromentgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\environment
InputPath=.\source\gui\environment\enviromentgui.h
InputName=enviromentgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\environment
InputPath=.\source\gui\environment\enviromentgui.h
InputName=enviromentgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\enviromentguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\guihelpers.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\guihelpers.h
InputName=guihelpers

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\guihelpers.h
InputName=guihelpers

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\engine\postprocessing\heightbasedfog.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\heightmap.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\hud\hud.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\info\infoguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\input\input.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\justplaying.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\input\keyboard.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\keys3dmode.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\lensflare.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\lightmap.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\load\loadgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\load
InputPath=.\source\gui\load\loadgui.h
InputName=loadgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\load
InputPath=.\source\gui\load\loadgui.h
InputName=loadgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\load\loadguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\logger\logger.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\maskimportgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\maskimportgui.h
InputName=maskimportgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\maskimportgui.h
InputName=maskimportgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\common\maskimportguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\hud\minimap.h
# End Source File
# Begin Source File

SOURCE=.\source\common\minixml.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\module.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\moon.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\input\mouse.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\object.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectgen.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\objects.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectsgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\objects
InputPath=.\source\gui\objects\objectsgui.h
InputName=objectsgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\objects
InputPath=.\source\gui\objects\objectsgui.h
InputName=objectsgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectsguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\particles\particles.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\particles\particlesource.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\particles\particletype.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewfullscreenbase.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\preview
InputPath=.\source\gui\preview\previewgui.h
InputName=previewgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\preview
InputPath=.\source\gui\preview\previewgui.h
InputName=previewgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\resource.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\rivers.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\riversgen.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\riversmap.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\riverstile.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\scapemakerdialog.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui
InputPath=.\source\gui\scapemakerdialog.h
InputName=scapemakerdialog

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui
InputPath=.\source\gui\scapemakerdialog.h
InputName=scapemakerdialog

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\scapemakerdialogbase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\screenshot.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\scripts\scripts.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\sea.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\seagen.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\seatile.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\shaderconsts.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\shadowgen.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\sky.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\stars.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\objects\staticterrainobject.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\hud\statusline.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\submesh.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\submeshes.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\sky\sun.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\terrain.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\terrain\terraintile.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\common\textureexportgui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\textureexportgui.h
InputName=textureexportgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\textureexportgui.h
InputName=textureexportgui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\common\textureexportguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\texturegen.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\texturegui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\texture
InputPath=.\source\gui\texture\texturegui.h
InputName=texturegui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\texture
InputPath=.\source\gui\texture\texturegui.h
InputName=texturegui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\textureguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\tilecheck.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\common\time.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topogen.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topografiegui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\topography
InputPath=.\source\gui\topography\topografiegui.h
InputName=topografiegui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\topography
InputPath=.\source\gui\topography\topografiegui.h
InputName=topografiegui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topografieguibase.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\camera\viewfrustum.h
# End Source File
# Begin Source File

SOURCE=.\source\engine\water\water.h
# End Source File
# Begin Source File

SOURCE=.\source\gui\water\watergui.h

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\water
InputPath=.\source\gui\water\watergui.h
InputName=watergui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Moc'ing $(InputName).h ...
InputDir=.\source\gui\water
InputPath=.\source\gui\water\watergui.h
InputName=watergui

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\water\waterguibase.h
# End Source File
# End Group
# Begin Group "Ressourcendateien"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;cnt;rtf;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\GUIBmps\scapemaker.ico
# End Source File
# Begin Source File

SOURCE=.\GUIBmps\scapemaker.rc
# End Source File
# End Group
# Begin Group "Shaders"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\enginefiles\shaders\depth.psh
# End Source File
# Begin Source File

SOURCE=.\enginefiles\shaders\depth.vsh
# End Source File
# Begin Source File

SOURCE=.\enginefiles\shaders\heightBasedFogBack.psh
# End Source File
# Begin Source File

SOURCE=.\enginefiles\shaders\heightBasedFogFinal.psh
# End Source File
# Begin Source File

SOURCE=.\enginefiles\shaders\water.psh
# End Source File
# Begin Source File

SOURCE=.\enginefiles\shaders\water.vsh
# End Source File
# End Group
# Begin Source File

SOURCE=.\source\gui\common\bitmapnavbase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\bitmapnavbase.ui
InputName=bitmapnavbase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\bitmapnavbase.ui
InputName=bitmapnavbase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\clouds\cloudsguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\clouds
InputPath=.\source\gui\clouds\cloudsguibase.ui
InputName=cloudsguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\clouds
InputPath=.\source\gui\clouds\cloudsguibase.ui
InputName=cloudsguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\config\configguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\config
InputPath=.\source\gui\config\configguibase.ui
InputName=configguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\config
InputPath=.\source\gui\config\configguibase.ui
InputName=configguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\environment\enviromentguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\environment
InputPath=.\source\gui\environment\enviromentguibase.ui
InputName=enviromentguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\environment
InputPath=.\source\gui\environment\enviromentguibase.ui
InputName=enviromentguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\info\infoguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\info
InputPath=.\source\gui\info\infoguibase.ui
InputName=infoguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\info
InputPath=.\source\gui\info\infoguibase.ui
InputName=infoguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\keys3dmode.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui
InputPath=.\source\gui\keys3dmode.ui
InputName=keys3dmode

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui
InputPath=.\source\gui\keys3dmode.ui
InputName=keys3dmode

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\load\loadguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\load
InputPath=.\source\gui\load\loadguibase.ui
InputName=loadguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\load
InputPath=.\source\gui\load\loadguibase.ui
InputName=loadguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\common\maskimportguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\maskimportguibase.ui
InputName=maskimportguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\maskimportguibase.ui
InputName=maskimportguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\objects\objectsguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\objects
InputPath=.\source\gui\objects\objectsguibase.ui
InputName=objectsguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\objects
InputPath=.\source\gui\objects\objectsguibase.ui
InputName=objectsguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewfullscreenbase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\preview
InputPath=.\source\gui\preview\previewfullscreenbase.ui
InputName=previewfullscreenbase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\preview
InputPath=.\source\gui\preview\previewfullscreenbase.ui
InputName=previewfullscreenbase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\preview\previewguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\preview
InputPath=.\source\gui\preview\previewguibase.ui
InputName=previewguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\preview
InputPath=.\source\gui\preview\previewguibase.ui
InputName=previewguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\scapemakerdialogbase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui
InputPath=.\source\gui\scapemakerdialogbase.ui
InputName=scapemakerdialogbase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui
InputPath=.\source\gui\scapemakerdialogbase.ui
InputName=scapemakerdialogbase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\common\textureexportguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\textureexportguibase.ui
InputName=textureexportguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\common
InputPath=.\source\gui\common\textureexportguibase.ui
InputName=textureexportguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\texture\textureguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\texture
InputPath=.\source\gui\texture\textureguibase.ui
InputName=textureguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\texture
InputPath=.\source\gui\texture\textureguibase.ui
InputName=textureguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\topography\topografieguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\topography
InputPath=.\source\gui\topography\topografieguibase.ui
InputName=topografieguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\topography
InputPath=.\source\gui\topography\topografieguibase.ui
InputName=topografieguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\source\gui\water\waterguibase.ui

!IF  "$(CFG)" == "ScapeMaker - Win32 Release"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\water
InputPath=.\source\gui\water\waterguibase.ui
InputName=waterguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "ScapeMaker - Win32 Debug"

# PROP Ignore_Default_Tool 1
# Begin Custom Build - Uic'ing $(InputName).ui ...
InputDir=.\source\gui\water
InputPath=.\source\gui\water\waterguibase.ui
InputName=waterguibase

BuildCmds= \
	%qtdir%\bin\uic.exe $(InputPath) -o $(InputDir)\$(InputName).h \
	%qtdir%\bin\uic.exe $(InputPath) -i $(InputName).h -o $(InputDir)\$(InputName).cpp \
	%qtdir%\bin\moc.exe $(InputDir)\$(InputName).h -o $(InputDir)\moc_$(InputName).cpp \
	

"$(InputDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

"$(InputDir)\moc_$(InputName).cpp" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# End Target
# End Project
