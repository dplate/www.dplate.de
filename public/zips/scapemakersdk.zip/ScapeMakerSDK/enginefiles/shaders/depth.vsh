vs.1.1

dcl_position v0
dcl_texcoord v1

; Transform position to clip space and output it
dp4 oPos.x, v0, c0
dp4 oPos.y, v0, c1
dp4 oPos.z, v0, c2
dp4 oPos.w, v0, c3

; calculate depth
dp4 r1.x, v0, c2

; scale down
mul r1.x, r1.x, c22.w

; set value to other coordinates
mov r1.y, r1.x
mov r1.z, r1.x

; calculate look up table coordinates for depth
mul r0.xyz, r1.xyz, c22.xyz

; output as texture coordinate for red, green and blue ramp texture
mov oT1.xy, r0.x
mov oT2.xy, r0.y
mov oT3.xy, r0.z

; output alpha texture coordinate
mov oT0, v1