vs.1.1										

dcl_position v0
dcl_color v5
dcl_texcoord0 v7
dcl_texcoord1 v8
dcl_texcoord2 v9
dcl_texcoord3 v10

; Transform point to projection space
; m4x4	oPos, v0,  c0	
dp4 oPos.x, v0, c0
dp4 oPos.y, v0, c1
dp4 oPos.z, v0, c2
dp4 oPos.w, v0, c3

; move diffuse color
mov oD0, v5

; move texture coordinate of normal map and put in t0
add oT0.xy, v7.xy,  c30.xy	

; rotate tangent space transformation matrix around y axis
mul r1.x, v8.x, c31.y		; multiply with cos(a)
mul r1.z, v8.z, c31.x		; multiply with sin(a)
sub oT1.x, r1.x, r1.z
mov oT1.y, v8.y
mul r1.x, v8.x, c31.x		; multiply with sin(a)
mul r1.z, v8.z, c31.y		; multiply with cos(a)
add oT1.z, r1.x, r1.z

mul r1.x, v9.x, c31.y		; multiply with cos(a)
mul r1.z, v9.z, c31.x		; multiply with sin(a)
sub oT2.x, r1.x, r1.z
mov oT2.y, v9.y
mul r1.x, v9.x, c31.x		; multiply with sin(a)
mul r1.z, v9.z, c31.y		; multiply with cos(a)
add oT2.z, r1.x, r1.z

mul r1.x, v10.x, c31.y		; multiply with cos(a)
mul r1.z, v10.z, c31.x		; multiply with sin(a)
sub oT3.x, r1.x, r1.z
mov oT3.y, v10.y
mul r1.x, v10.x, c31.x		; multiply with sin(a)
mul r1.z, v10.z, c31.y		; multiply with cos(a)
add oT3.z, r1.x, r1.z

; get view/point vector
m4x4 r0,v0, c4			; Transform point to world space
add r0,-r0, c10			; Get a vector toward the camera position,
mov oT1.w, r0.x			; put vector as w-coordinate in t1-t3
mov oT2.w, r0.y
mov oT3.w, r0.z
