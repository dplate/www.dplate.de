!include "MUI.nsh"

;--------------------------------
;Configuration

  ;General
  !define PRODUCT "ScapeMaker"
  !define VERSION "1.3"
  Name "${PRODUCT}"
  OutFile "ScapeMakerSetup_1_3.exe"

  ;Folder selection page
  InstallDir "$PROGRAMFILES\${PRODUCT}"
  
  ;Remember install folder
  InstallDirRegKey HKCU "Software\${PRODUCT}" ""
  
  ;Remember the Start Menu Folder
  !define MUI_STARTMENUPAGE_REGISTRY_ROOT "HKCU" 
  !define MUI_STARTMENUPAGE_REGISTRY_KEY "Software\${PRODUCT}" 
  !define MUI_STARTMENUPAGE_REGISTRY_VALUENAME "Start Menu Folder"
  
;--------------------------------
;Modern UI Configuration

  !define MUI_DIRECTORYPAGE
  !define MUI_STARTMENUPAGE
 
  !define MUI_ABORTWARNING
 
  !define MUI_UNINSTALLER
  !define MUI_UNCONFIRMPAGE
  
;--------------------------------
;Variables

  Var MUI_TEMP
  Var STARTMENU_FOLDER
  
;--------------------------------
;Pages

  !insertmacro MUI_PAGE_DIRECTORY
  !insertmacro MUI_PAGE_STARTMENU Application $STARTMENU_FOLDER
  !insertmacro MUI_PAGE_INSTFILES
  !insertmacro MUI_PAGE_FINISH
  
  !insertmacro MUI_UNPAGE_CONFIRM
  !insertmacro MUI_UNPAGE_INSTFILES  
  !insertmacro MUI_UNPAGE_FINISH
  
;--------------------------------
;Languages
 
  !insertmacro MUI_LANGUAGE "English"
  
;--------------------------------
;Installer Sections

Section "scapemaker.exe" SecCopyUI


  SetOutPath "$INSTDIR"
  File "scapemaker.exe"
  File "qt-mt230nc.dll"
  File "scapemaker_de.qm"
  File "manual.html"
  File "manual_e.html"
  File "tutorial.html"
  File "tutorial_e.html"
  File "readme.txt"
  SetOutPath "$INSTDIR\detailmaps"
  File /r "detailmaps\*.*"
  SetOutPath "$INSTDIR\groundtextures"
  File /r "groundtextures\*.*"
  SetOutPath "$INSTDIR\objects"
  File /r "objects\*.*"
  SetOutPath "$INSTDIR\wavetextures"
  File /r "wavetextures\*.*"
  SetOutPath "$INSTDIR\guifiles"
  File "guifiles\sky.txt"
  File /r "guifiles\*.bmp"
  File /r "guifiles\*.png"
  SetOutPath "$INSTDIR\enginefiles"
  File /r "enginefiles\*.dds"
  File /r "enginefiles\*.png"
  File /r "enginefiles\*.jpg"
  File /r "enginefiles\*.x"
  File "enginefiles\stars.txt"
  SetOutPath "$INSTDIR\enginefiles\scripts"
  File /r "enginefiles\scripts\*.*"
  SetOutPath "$INSTDIR\enginefiles\shaders"
  File /r "enginefiles\shaders\*.*"
  SetOutPath "$INSTDIR\landscapes"
  SetOutPath "$INSTDIR\screenshots"
  SetOutPath "$INSTDIR"
 
  ;Store install folder
  WriteRegStr HKLM "Software\${PRODUCT}" "" $INSTDIR
  
  ;Create start menu entries
  !insertmacro MUI_STARTMENU_WRITE_BEGIN Application
    
    ;Create shortcuts
    CreateDirectory "$SMPROGRAMS\$STARTMENU_FOLDER"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\ScapeMaker.lnk" "$INSTDIR\scapemaker.exe"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\Manual (English).lnk" "$INSTDIR\manual_e.html"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\Handbuch (Deutsch).lnk" "$INSTDIR\manual.html"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\Tutorial (English).lnk" "$INSTDIR\tutorial_e.html"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\Tutorial (Deutsch).lnk" "$INSTDIR\tutorial.html"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\Screenshots.lnk" "$INSTDIR\screenshots"
    CreateShortCut "$SMPROGRAMS\$STARTMENU_FOLDER\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
  
  !insertmacro MUI_STARTMENU_WRITE_END
  
  ;Create uninstaller
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  
  ;set windows uninstaller reg key
  WriteRegExpandStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\ScapeMaker" "UninstallString" "$INSTDIR\Uninstall.exe"
  WriteRegExpandStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\ScapeMaker" "InstallLocation" "$INSTDIR"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\ScapeMaker" "DisplayName" "ScapeMaker"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\ScapeMaker" "DisplayVersion" "${VERSION}"
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\ScapeMaker" "NoModify" "1"
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\ScapeMaker" "NoRepair" "1"

SectionEnd

;--------------------------------
;Uninstaller Section

Section "Uninstall"

  Delete "$INSTDIR\scapemaker.exe"
  Delete "$INSTDIR\qt-mt230nc.dll"
  Delete "$INSTDIR\scapemaker_de.qm"
  Delete "$INSTDIR\uninstall.exe"
  Delete "$INSTDIR\scapemaker.log"
  Delete "$INSTDIR\manual.html"
  Delete "$INSTDIR\manual_e.html"
  Delete "$INSTDIR\tutorial.html"
  Delete "$INSTDIR\tutorial_e.html"
  Delete "$INSTDIR\readme.txt"
  RMDir /r "$INSTDIR\enginefiles"

  MessageBox MB_YESNO|MB_ICONQUESTION "Would you like to remove all detail maps?" IDNO NoDetailMapsDelete
    RMDir /r "$INSTDIR\detailmaps"
  NoDetailMapsDelete:
  
  MessageBox MB_YESNO|MB_ICONQUESTION "Would you like to remove all ground textures?" IDNO NoGroundTexturesDelete
    RMDir /r "$INSTDIR\groundtextures"
  NoGroundTexturesDelete:
  
  RMDir /r "$INSTDIR\guifiles"
  
  MessageBox MB_YESNO|MB_ICONQUESTION "Would you like to remove all objects?" IDNO NoObjectsDelete
    RMDir /r "$INSTDIR\objects"
  NoObjectsDelete:
  
  MessageBox MB_YESNO|MB_ICONQUESTION "Would you like to remove all wave textures?" IDNO NoWaveTexturesDelete
    RMDir /r "$INSTDIR\wavetextures"
  NoWaveTexturesDelete: 
    
  MessageBox MB_YESNO|MB_ICONQUESTION "Would you like to remove your landscapes?" IDNO NoLandscapeDelete
    RMDir /r "$INSTDIR\landscapes"
  NoLandscapeDelete:
  
  MessageBox MB_YESNO|MB_ICONQUESTION "Would you like to remove your screenshots?" IDNO NoScreenshotsDelete
    RMDir /r "$INSTDIR\screenshots"
  NoScreenshotsDelete:
  
  RMDir "$INSTDIR"
  
  ;Remove shortcut
  !insertmacro MUI_STARTMENU_GETFOLDER Application $MUI_TEMP
 
  Delete "$SMPROGRAMS\$MUI_TEMP\ScapeMaker.lnk"
  Delete "$SMPROGRAMS\$MUI_TEMP\Manual (English).lnk"
  Delete "$SMPROGRAMS\$MUI_TEMP\Handbuch (Deutsch).lnk"
  Delete "$SMPROGRAMS\$MUI_TEMP\Tutorial (English).lnk"
  Delete "$SMPROGRAMS\$MUI_TEMP\Tutorial (Deutsch).lnk"
  Delete "$SMPROGRAMS\$MUI_TEMP\Screenshots.lnk"
  Delete "$SMPROGRAMS\$MUI_TEMP\Uninstall.lnk"
  RMDir "$SMPROGRAMS\$MUI_TEMP" ;Only if empty, so it won't delete other shortcuts
    
  ;Delete registry keys
  DeleteRegKey HKLM "Software\${PRODUCT}"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\${PRODUCT}"
  
SectionEnd