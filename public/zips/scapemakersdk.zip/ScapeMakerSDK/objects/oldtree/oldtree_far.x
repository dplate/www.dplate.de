xof 0303txt 0032
template XSkinMeshHeader {
 <3cf169ce-ff7c-44ab-93c0-f78f62d172e2>
 WORD nMaxSkinWeightsPerVertex;
 WORD nMaxSkinWeightsPerFace;
 WORD nBones;
}

template VertexDuplicationIndices {
<b8d65549-d7c9-4995-89cf-53a9a8b031e3>
 DWORD nIndices;
 DWORD nOriginalVertices;
 array DWORD indices[nIndices];
}

template SkinWeights {
 <6f0d123b-bad2-4167-a0d0-80224f25fabb>
 STRING transformNodeName;
 DWORD nWeights;
 array DWORD vertexIndices[nWeights];
 array FLOAT weights[nWeights];
 Matrix4x4 matrixOffset;
}


Frame Scene_Root {


 FrameTransformMatrix {
  1.000000, 0.000000, 0.000000, 0.000000,
  0.000000, 1.000000, 0.000000, 0.000000,
  0.000000, 0.000000, 1.000000, 0.000000,
  0.000000, 0.000000, 0.000000, 1.000000;;
 }

  Frame Regroup02 {

   FrameTransformMatrix {
    1.000000, 0.000000, 0.000000, 0.000000,
    0.000000, 1.000000, 0.000000, 0.000000,
    0.000000, 0.000000, 1.000000, 0.000000,
    0.000000, 0.000000, 0.000000, 1.000000;;
   }

   Mesh {
    4;
    -0.919469;2.665373;0.000000;,
    1.400531;-0.199400;0.000000;,
    1.390531;2.665373;0.000000;,
    -0.929469;-0.199400;0.000000;;
    2;
    3;0,2,1;,
    3;0,1,3;;

    MeshNormals {
     4;
     0.000000;0.000000;0.000000;,
     0.000000;0.000000;0.000000;,
     0.000000;0.000000;0.000000;,
     0.000000;0.000000;0.000000;;
     2;
     3;0,2,1;,
     3;0,1,3;;
    }

    MeshTextureCoords {
     4;
     0.004292;-0.000000;,
     0.490234;0.998047;,
     0.485943;0.001519;,
     0.000000;1.000000;;
    }

    VertexDuplicationIndices {
     4;
     4;
     0,
     1,
     2,
     3;
    }

    MeshMaterialList {
     1;
     2;
     0,
     0;

     Material Flat {
      0.800000;0.800000;0.800000;1.000000;;
      0.000000;
      0.000000;0.000000;0.000000;;
      0.000000;0.000000;0.000000;;
      TextureFilename {
       "flat.dds";
      }
     }
    }

   }
 }
}
