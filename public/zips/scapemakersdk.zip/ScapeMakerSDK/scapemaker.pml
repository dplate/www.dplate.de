<?xml version="1.0" encoding="UTF-8" ?>
<PADGEN_PML>
	<AppVerInfo>PADGen 2.0.1.22</AppVerInfo>
	<CompanyName />
	<Program_Info>
		<Program_Name>ScapeMaker</Program_Name>
		<Program_Version>1.3</Program_Version>
		<Program_Release_Month>02</Program_Release_Month>
		<Program_Release_Day>13</Program_Release_Day>
		<Program_Release_Year>2005</Program_Release_Year>
		<Program_Cost_Dollars>0</Program_Cost_Dollars>
		<Program_Cost_Other_Code />
		<Program_Cost_Other />
		<Program_Type>Freeware</Program_Type>
		<Program_Release_Status>Major Update</Program_Release_Status>
		<Program_Install_Support>Install and Uninstall</Program_Install_Support>
		<Program_OS_Support>Win98,WinME,Windows2000,WinXP,Windows2003</Program_OS_Support>
		<Program_Language>English,German</Program_Language>
		<Program_Change_Info />
		<Program_Specific_Category>Graphics</Program_Specific_Category>
		<Program_Category_Class>Graphic Apps::Other</Program_Category_Class>
		<Program_Categories>Graphics, 3D</Program_Categories>
		<Program_System_Requirements>Directx 9.0c</Program_System_Requirements>
		<Includes_JAVA_VM>N</Includes_JAVA_VM>
		<Includes_VB_Runtime>N</Includes_VB_Runtime>
		<Includes_DirectX>N</Includes_DirectX>
		<File_Info>
			<Filename_Versioned>scape13.exe</Filename_Versioned>
			<Filename_Previous>scape13.exe</Filename_Previous>
			<Filename_Generic>scape13.exe</Filename_Generic>
			<Filename_Long>ScapeMakerSetup_1_3.exe</Filename_Long>
			<File_Size_Bytes>4634885</File_Size_Bytes>
			<File_Size_K>4526</File_Size_K>
			<File_Size_MB>4.42</File_Size_MB>
		</File_Info>
		<Expire_Info>
			<Has_Expire_Info>N</Has_Expire_Info>
			<Expire_Count />
			<Expire_Based_On>Days</Expire_Based_On>
			<Expire_Other_Info />
			<Expire_Month />
			<Expire_Day />
			<Expire_Year />
		</Expire_Info>
	</Program_Info>
	<Program_Descriptions>
		<English>
			<Keywords>terrain generator texture sky box 3d</Keywords>
			<Char_Desc_45>ScapeMaker, a powerful terrain generator</Char_Desc_45>
			<Char_Desc_80>ScapeMaker, a powerful terrain generator</Char_Desc_80>
			<Char_Desc_250>ScapeMaker is an easy to handle but powerful landscape generator. Using a user-friendly interface, realistic height profiles with varying textures can be created by setting only a few parameters.</Char_Desc_250>
			<Char_Desc_450>ScapeMaker is an easy to handle but powerful landscape generator. Using a user-friendly interface, realistic height profiles with varying textures can be created by setting only a few parameters. On this landscape objects contained within ScapeMaker (e.g. trees and grass) can be allocated. Furthermore special effects like realistic height-depending fog, daytimes, clouds and sea are configurable.</Char_Desc_450>
			<Char_Desc_2000>ScapeMaker is an easy to handle but powerful landscape generator. Using a user-friendly interface, realistic height profiles with varying textures can be created by setting only a few parameters. On this landscape objects contained within ScapeMaker (e.g. trees and grass) can be allocated. Furthermore special effects like realistic height-depending fog, daytimes, clouds and sea are configurable. This generated landscape can be shown in a powerful 3d-engine in real-time afterwards, where screen shots can be made.
As the target-group we see all computer users interested in graphics, which on the one hand are professionals, who want to create raw materials for their own projects (websites, games, applications) and on the other hand normal users, who want to generate their own landscapes according to own wishes and then take screen shots, to use for example as background images for their desktops.</Char_Desc_2000>
		</English>
		<German>
			<Keywords>Landschaftsgenerator Texturgenerator Skybox Textures</Keywords>
			<Char_Desc_45>ScapeMaker, ein Landschaftsgenerator</Char_Desc_45>
			<Char_Desc_80>ScapeMaker ist ein einfach bedienbarer Landschaftsgenerator</Char_Desc_80>
			<Char_Desc_250>ScapeMaker ist ein einfach bedienbarer, aber leistungsfähiger, Landschaftsgenerator. Über eine benutzerfreundliche Oberfläche lassen sich mittels weniger Parameter realistische Höhenprofile und abwechslungsreiche Bodentexturen erzeugen.</Char_Desc_250>
			<Char_Desc_450>ScapeMaker ist ein einfach bedienbarer, aber leistungsfähiger, Landschaftsgenerator. Über eine benutzerfreundliche Oberfläche lassen sich mittels weniger Parameter realistische Höhenprofile und abwechslungsreiche Bodentexturen erzeugen. Diese generierte Landschaft kann anschließend in einer leistungsfähigen 3D-Engine in Echtzeit besichtigt und Screenshots angefertigt werden.</Char_Desc_450>
			<Char_Desc_2000>ScapeMaker ist ein einfach bedienbarer, aber leistungsfähiger, Landschaftsgenerator. Über eine benutzerfreundliche Oberfläche lassen sich mittels weniger Parameter realistische Höhenprofile und abwechslungsreiche Bodentexturen erzeugen. Auf diese Landschaft können mitgelieferte Objekte (z.B. Bäume und Gras) verteilt werden. Außerdem sind Spezialeffekte wie realistischer höhenbasierter Nebel, Tageszeiten, Wolken und Meer konfigurierbar. Diese generierte Landschaft kann anschließend in einer leistungsfähigen 3D-Engine in Echtzeit besichtigt und Screenshots angefertigt werden.
Als Zielgruppe sehen wir alle grafikinteressierten Computernutzer. Dazu gehören einerseits Profis, die mit ScapeMaker Rohmaterial für ihre eigenen Projekte (Webseiten, Spiele, Programme) erzeugen können, anderseits aber auch normale Benutzer, die mit dem Progamm eigene Landschaften nach ihren individuellen Vorstellungen generieren und dann Screenshots aus der Engine als Hintergrundbild in Windows verwenden können.</Char_Desc_2000>
		</German>
	</Program_Descriptions>
	<Web_Info>
		<Application_URLs>
			<Application_Info_URL>http://www.scapemaker.de.vu</Application_Info_URL>
			<Application_Order_URL>http://www.scapemaker.de.vu</Application_Order_URL>
			<Application_Screenshot_URL>http://www.dplate.de/scapemaker/screenshots/engine8.jpg</Application_Screenshot_URL>
			<Application_Icon_URL>http://www.dplate.de/scapemaker/images/icon.jpg</Application_Icon_URL>
			<Application_XML_File_URL>http://www.dplate.de/scapemaker/scapemaker.xml</Application_XML_File_URL>
		</Application_URLs>
		<Download_URLs>
			<Primary_Download_URL>http://www.heikoplate.de/dP-Software/zips/ScapeMakerSetup_1_3.exe</Primary_Download_URL>
			<Secondary_Download_URL>http://www.shedeki.net/scapemaker/ScapeMakerSetup_1_3.exe</Secondary_Download_URL>
			<Additional_Download_URL_1 />
			<Additional_Download_URL_2 />
		</Download_URLs>
	</Web_Info>
	<Permissions>
		<Distribution_Permissions />
		<EULA />
	</Permissions>
	<ASP>
		<ASP_FORM>Y</ASP_FORM>
		<ASP_Member>N</ASP_Member>
		<ASP_Member_Number />
	</ASP>
</PADGEN_PML>
