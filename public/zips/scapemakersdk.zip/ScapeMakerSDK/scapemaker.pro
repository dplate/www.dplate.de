HEADERS         = ./source/gui/scapemakerdialog.h \
		  ./source/gui/scapemakerdialogbase.h \
		  ./source/gui/keys3dmode.h \
		  ./source/gui/config/configgui.h \
		  ./source/gui/config/configguibase.h \
		  ./source/gui/info/infoguibase.h \
		  ./source/gui/load/loadgui.h \
		  ./source/gui/load/loadguibase.h \
		  ./source/gui/topography/topografiegui.h \
		  ./source/gui/topography/topografieguibase.h\
		  ./source/gui/texture/texturegui.h \ 
		  ./source/gui/texture/textureguibase.h \
		  ./source/gui/objects/objectsgui.h \
		  ./source/gui/objects/objectsguibase.h \
		  ./source/gui/water/watergui.h \
		  ./source/gui/water/waterguibase.h \
		  ./source/gui/clouds/cloudsgui.h \
		  ./source/gui/clouds/cloudsguibase.h \
		  ./source/gui/environment/enviromentgui.h \
		  ./source/gui/environment/enviromentguibase.h \
		  ./source/gui/preview/previewgui.h \
		  ./source/gui/preview/previewguibase.h \
		  ./source/gui/preview/loadingengine.h \
		  ./source/gui/preview/loadingenginebase.h \
		  ./source/gui/common/bitmapnav.h \
		  ./source/gui/common/bitmapnavbase.h \
		  ./source/gui/common/textureexportgui.h \
		  ./source/gui/common/textureexportguibase.h \
		  ./source/gui/common/maskimportgui.h \
		  ./source/gui/common/maskimportguibase.h \		  
		  ./source/gui/common/coolslider.h \
		  ./source/gui/common/guihelpers.h

SOURCES         = ./source/gui/scapemakerdialog.cpp \
		  ./source/gui/scapemakerdialogbase.cpp \
		  ./source/gui/keys3dmode.cpp \
		  ./source/gui/config/configgui.cpp \
		  ./source/gui/config/configguibase.cpp \
		  ./source/gui/info/infoguibase.cpp \
		  ./source/gui/load/loadgui.cpp \
		  ./source/gui/load/loadguibase.cpp \
		  ./source/gui/topography/topografiegui.cpp \
		  ./source/gui/topography/topografieguibase.cpp\
		  ./source/gui/texture/texturegui.cpp \ 
		  ./source/gui/texture/textureguibase.cpp \
		  ./source/gui/objects/objectsgui.cpp \
		  ./source/gui/objects/objectsguibase.cpp \
		  ./source/gui/water/watergui.cpp \
		  ./source/gui/water/waterguibase.cpp \
		  ./source/gui/clouds/cloudsgui.cpp \
		  ./source/gui/clouds/cloudsguibase.cpp \
		  ./source/gui/environment/enviromentgui.cpp \
		  ./source/gui/environment/enviromentguibase.cpp \
		  ./source/gui/preview/previewgui.cpp \
		  ./source/gui/preview/previewguibase.cpp \
		  ./source/gui/preview/loadingengine.cpp \
		  ./source/gui/preview/loadingenginebase.cpp \
		  ./source/gui/common/bitmapnav.cpp \
		  ./source/gui/common/bitmapnavbase.cpp \
		  ./source/gui/common/textureexportgui.cpp \
		  ./source/gui/common/textureexportguibase.cpp \
		  ./source/gui/common/maskimportgui.cpp \
		  ./source/gui/common/maskimportguibase.cpp \		  
		  ./source/gui/common/coolslider.cpp \
		  ./source/gui/common/guihelpers.cpp

TRANSLATIONS    = scapemaker_de.ts
