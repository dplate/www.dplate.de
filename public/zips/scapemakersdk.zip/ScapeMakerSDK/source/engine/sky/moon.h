/****************************************************************************
** Moon
**
** moon rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(MOON_H)
#define MOON_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "../common/dxutil.h"
#include <Dxerr9.h>
#include "../common/enginehelpers.h"
#include "../../common/minixml.h"

class Moon
{
public:
	Moon();
	~Moon();

	HRESULT update();
	HRESULT render();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, float skyRadius, D3DXVECTOR3 position, int time);
	HRESULT	destroyGeometry();

private:
	LPDIRECT3DDEVICE9		pD3DDevice;
	bool					visible;

	//sun variables
	LPDIRECT3DVERTEXBUFFER9 pVB;			//the vertex buffer with moon vertices
	LPDIRECT3DTEXTURE9		pTexture;		//the texture
	D3DXMATRIX				transformation;

	LPDIRECT3DSTATEBLOCK9	pStateBlock;		//used state block for rendering sun
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;//saved old state block for rendering sun
};

#endif