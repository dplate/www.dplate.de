/****************************************************************************
** CloudsGUI meta object code from reading C++ file 'cloudsgui.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_CloudsGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "cloudsgui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *CloudsGUI::className() const
{
    return "CloudsGUI";
}

QMetaObject *CloudsGUI::metaObj = 0;

void CloudsGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(CloudsGUIBase::className(), "CloudsGUIBase") != 0 )
	badSuperclassWarning("CloudsGUI","CloudsGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString CloudsGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("CloudsGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* CloudsGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) CloudsGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(CloudsGUI::*m1_t0)();
    typedef void(CloudsGUI::*m1_t1)();
    typedef void(CloudsGUI::*m1_t2)();
    m1_t0 v1_0 = Q_AMPERSAND CloudsGUI::valuesChanged;
    m1_t1 v1_1 = Q_AMPERSAND CloudsGUI::generateClicked;
    m1_t2 v1_2 = Q_AMPERSAND CloudsGUI::cancelClicked;
    QMetaData *slot_tbl = QMetaObject::new_metadata(3);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(3);
    slot_tbl[0].name = "valuesChanged()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "generateClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "cancelClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"CloudsGUI", "CloudsGUIBase",
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
