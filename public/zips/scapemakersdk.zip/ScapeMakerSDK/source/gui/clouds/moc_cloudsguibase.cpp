/****************************************************************************
** CloudsGUIBase meta object code from reading C++ file 'cloudsguibase.h'
**
** Created: Sun Feb 13 15:03:33 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_CloudsGUIBase
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "cloudsguibase.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *CloudsGUIBase::className() const
{
    return "CloudsGUIBase";
}

QMetaObject *CloudsGUIBase::metaObj = 0;

void CloudsGUIBase::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("CloudsGUIBase","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString CloudsGUIBase::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("CloudsGUIBase",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* CloudsGUIBase::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(CloudsGUIBase::*m1_t0)();
    typedef void(CloudsGUIBase::*m1_t1)();
    typedef void(CloudsGUIBase::*m1_t2)();
    m1_t0 v1_0 = Q_AMPERSAND CloudsGUIBase::cancelClicked;
    m1_t1 v1_1 = Q_AMPERSAND CloudsGUIBase::generateClicked;
    m1_t2 v1_2 = Q_AMPERSAND CloudsGUIBase::valuesChanged;
    QMetaData *slot_tbl = QMetaObject::new_metadata(3);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(3);
    slot_tbl[0].name = "cancelClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "generateClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "valuesChanged()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"CloudsGUIBase", "QWidget",
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
