/****************************************************************************
** MaskImportGUI meta object code from reading C++ file 'maskimportgui.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_MaskImportGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "maskimportgui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *MaskImportGUI::className() const
{
    return "MaskImportGUI";
}

QMetaObject *MaskImportGUI::metaObj = 0;

void MaskImportGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(MaskImportGUIBase::className(), "MaskImportGUIBase") != 0 )
	badSuperclassWarning("MaskImportGUI","MaskImportGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString MaskImportGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("MaskImportGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* MaskImportGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) MaskImportGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(MaskImportGUI::*m1_t0)();
    typedef void(MaskImportGUI::*m1_t1)();
    typedef void(MaskImportGUI::*m1_t2)();
    typedef void(MaskImportGUI::*m1_t3)();
    typedef void(MaskImportGUI::*m1_t4)();
    typedef void(MaskImportGUI::*m1_t5)();
    typedef void(MaskImportGUI::*m1_t6)();
    typedef void(MaskImportGUI::*m1_t7)();
    typedef void(MaskImportGUI::*m1_t8)();
    m1_t0 v1_0 = Q_AMPERSAND MaskImportGUI::source1ImportClicked;
    m1_t1 v1_1 = Q_AMPERSAND MaskImportGUI::source2ImportClicked;
    m1_t2 v1_2 = Q_AMPERSAND MaskImportGUI::source1InvertClicked;
    m1_t3 v1_3 = Q_AMPERSAND MaskImportGUI::source2InvertClicked;
    m1_t4 v1_4 = Q_AMPERSAND MaskImportGUI::source1ResetClicked;
    m1_t5 v1_5 = Q_AMPERSAND MaskImportGUI::source2ResetClicked;
    m1_t6 v1_6 = Q_AMPERSAND MaskImportGUI::sourcesChanged;
    m1_t7 v1_7 = Q_AMPERSAND MaskImportGUI::okClicked;
    m1_t8 v1_8 = Q_AMPERSAND MaskImportGUI::cancelClicked;
    QMetaData *slot_tbl = QMetaObject::new_metadata(9);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(9);
    slot_tbl[0].name = "source1ImportClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "source2ImportClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "source1InvertClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "source2InvertClicked()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "source1ResetClicked()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "source2ResetClicked()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "sourcesChanged()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "okClicked()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "cancelClicked()";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"MaskImportGUI", "MaskImportGUIBase",
	slot_tbl, 9,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
