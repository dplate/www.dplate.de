/****************************************************************************
** TextureExportGUI meta object code from reading C++ file 'textureexportgui.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_TextureExportGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "textureexportgui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *TextureExportGUI::className() const
{
    return "TextureExportGUI";
}

QMetaObject *TextureExportGUI::metaObj = 0;

void TextureExportGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(TextureExportGUIBase::className(), "TextureExportGUIBase") != 0 )
	badSuperclassWarning("TextureExportGUI","TextureExportGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString TextureExportGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("TextureExportGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* TextureExportGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) TextureExportGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(TextureExportGUI::*m1_t0)();
    m1_t0 v1_0 = Q_AMPERSAND TextureExportGUI::exportClicked;
    QMetaData *slot_tbl = QMetaObject::new_metadata(1);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(1);
    slot_tbl[0].name = "exportClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"TextureExportGUI", "TextureExportGUIBase",
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
