/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\config\configguibase.ui'
**
** Created: Sun Feb 13 15:03:30 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "configguibase.h"

#include <qbuttongroup.h>
#include <qcheckbox.h>
#include <qcombobox.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"32 32 254 2",
"bf c #080808",
"bA c #090909",
"aR c #0a0a0a",
"aX c #0b0b0b",
"#X c #0c0c0c",
"bH c #0d0d0d",
"#r c #0e0e0e",
".J c #101010",
"## c #111111",
".9 c #121212",
".N c #131313",
".O c #141414",
"#Y c #151515",
".j c #161616",
"a0 c #171717",
"av c #181818",
"ax c #191919",
".7 c #1a1a1a",
"a# c #1b1b1b",
"#1 c #1c1c1c",
"bo c #1d1d1d",
"bk c #1e1e1e",
".k c #1f1f1f",
"#. c #202020",
"be c #212121",
"bS c #222222",
"bi c #232323",
"#U c #242424",
"a1 c #252525",
".6 c #262626",
"#J c #282828",
"bE c #292929",
"am c #2a2a2a",
"ba c #2b2b2b",
"a9 c #2c2c2c",
"bj c #2d2d2d",
"aZ c #2e2e2e",
".8 c #2f2f2f",
"#q c #303030",
"#s c #313131",
"#H c #323232",
"aJ c #333333",
"#7 c #343434",
"bm c #353535",
"#K c #363636",
"#a c #363637",
"#T c #373737",
"#V c #383838",
".M c #383839",
"aw c #393939",
"aY c #3a3a3a",
"ab c #3b3b3b",
"#0 c #3c3c3c",
".P c #3d3d3d",
".K c #3e3e3e",
"#L c #404040",
"aI c #414141",
"bg c #424242",
"bl c #434343",
"az c #444444",
".I c #464646",
"#8 c #474747",
"bX c #484848",
"br c #494949",
"#p c #4a4a4a",
"ar c #4b4b4b",
"bq c #4c4c4c",
"aa c #4d4d4d",
"bp c #4e4e4e",
"a5 c #4f4f4f",
"#Z c #505050",
"bd c #515151",
"aj c #525252",
"#E c #535353",
"aS c #545453",
"aA c #545454",
"bn c #555555",
"a4 c #565656",
"bs c #575757",
"bt c #585858",
"#2 c #585859",
"aH c #595959",
"#I c #5a5a5a",
"#M c #5b5b5b",
"bu c #5c5c5c",
".p c #5d5d5d",
".i c #5e5e5e",
".o c #5f5f5f",
"ay c #606060",
".l c #616161",
"#F c #636362",
"#D c #636363",
"bB c #646464",
"#9 c #656565",
"an c #666666",
".L c #676767",
"bc c #686868",
"aT c #696969",
"#S c #6a6a6a",
"a. c #6b6b6b",
"#W c #6c6c6c",
"bO c #6d6d6c",
"al c #6d6d6d",
"ac c #6e6e6e",
"as c #6f6f6f",
"aG c #707070",
".q c #717171",
".n c #727271",
"ak c #737373",
"#o c #747474",
"#j c #757575",
"aF c #767676",
"bh c #767677",
"#6 c #777776",
"a7 c #777777",
"ad c #787878",
"bw c #797978",
"#N c #797979",
"bv c #7a7a79",
"#i c #7a7a7a",
"aq c #7b7b7b",
"#t c #7c7c7c",
"#u c #7d7d7d",
"bF c #7e7e7d",
".H c #7e7e7e",
"au c #7f7f7f",
"b# c #80807f",
"ai c #808080",
".Q c #818181",
"bz c #828282",
"ae c #838383",
"ap c #848484",
"#n c #858584",
"#w c #858585",
".r c #868686",
"a8 c #878786",
"aO c #878787",
"#G c #888888",
"bb c #898988",
"ao c #898989",
"bZ c #8a8a89",
".m c #8a8a8a",
"by c #8b8b8a",
"#C c #8b8b8b",
"#k c #8c8c8c",
"#v c #8d8d8d",
".0 c #8e8e8d",
"ah c #8e8e8e",
"aC c #8f8f8f",
"a6 c #919190",
".Z c #919191",
"bG c #929291",
"bx c #929292",
"bV c #939393",
"#l c #949493",
"ag c #949494",
"aP c #959595",
"aB c #969696",
"#x c #979797",
"af c #989898",
"#R c #999998",
"aW c #999999",
"aN c #9a9a9a",
"#h c #9b9b9b",
"bI c #9b9b9c",
".Y c #9c9c9c",
"#m c #9d9d9d",
"#4 c #9e9e9e",
"bY c #9f9f9f",
"#5 c #a0a0a0",
"aQ c #a1a1a1",
".3 c #a2a2a2",
"#O c #a3a3a2",
"#B c #a3a3a3",
"#d c #a4a4a4",
"bC c #a5a5a5",
".B c #a6a6a6",
"b0 c #a7a7a6",
".1 c #a7a7a7",
"aE c #a8a8a8",
".C c #a9a9a9",
"#3 c #a9a9aa",
"b. c #aaaaa9",
"#b c #aaaaaa",
"bD c #ababaa",
".2 c #ababab",
".s c #acacac",
".X c #adadad",
"b1 c #adadae",
".A c #aeaeae",
"at c #afafaf",
".4 c #b0b0b0",
".S c #b1b1b1",
"aK c #b2b2b2",
"#Q c #b3b3b2",
"#A c #b3b3b3",
".D c #b4b4b4",
"#c c #b5b5b5",
".G c #b6b6b6",
".z c #b7b7b7",
".h c #b8b8b8",
"#g c #b9b9b9",
".a c #bababa",
"aD c #bababb",
".y c #bbbbbb",
".T c #bcbcbc",
".E c #bdbdbd",
"bJ c #bebebe",
"#y c #bfbfbf",
"#e c #c0c0c0",
".F c #c1c1c1",
".b c #c2c2c2",
"Qt c #c3c3c3",
"#z c #c4c4c4",
"bT c #c5c5c5",
".5 c #c6c6c6",
".R c #c7c7c7",
".c c #c8c8c8",
".U c #c9c9c9",
".# c #cacaca",
"aV c #cbcbcb",
".v c #cccccc",
".f c #cdcdcd",
"aM c #cecece",
".V c #cfcfcf",
".e c #d0d0d0",
".w c #d1d1d1",
"#P c #d2d2d2",
".W c #d3d3d3",
"bU c #d4d4d4",
"#f c #d5d5d5",
".d c #d6d6d6",
".x c #d7d7d7",
"aL c #d8d8d8",
"bW c #d9d9d9",
".t c #dadada",
"bK c #dbdbdb",
".g c #dddddd",
"bN c #dfdfdf",
"bR c #e0e0e0",
"bM c #e1e1e1",
".u c #e2e2e2",
"bQ c #e3e3e3",
"a2 c #e5e5e5",
"a3 c #e6e6e6",
"bL c #e9e9e9",
"b2 c #ebebeb",
"aU c #ededed",
"b5 c #f0f0f0",
"b3 c #f1f1f1",
"b4 c #f3f3f3",
"bP c #f6f6f6",
"b7 c #f8f8f8",
"b6 c #fafafa",
"Qt.#Qt.a.b.c.#.d.e.f.g.h.i.j.k.l.m.n.o.p.q.r.s.t.u.v.b.#.w.w.w.x",
".y.z.A.B.C.D.E.F.D.yQt.G.H.I.J.K.L.M.N.O.P.Q.z.R.eQt.S.T.c.U.V.W",
".T.X.Y.Z.0.1.2.3.4.5.4.1.B.q.6.7.8.9#.###a.0#b.C#c#d.4.R.R#e.U#f",
"#g#c#h#i#j#k#k#l.B.4.E#m#n#o#p#####q.P#r#s#t#u#v#w#x#y#z#A.z#y.v",
"Qt#e#B#C#D#E#F.q.Q.B.R.z#G#E#q.J#H#I#J.N.P#K#L#M#N#OQt.F.1#g.##P",
"#P.b#Q#R#S#T#U#V#W.3.4.A.3.o.N#X#Y#Z#0##.k.9#1#K#2#G#d#3#4#d.z.v",
".v.z#5#w#6#M#7.9#8#S#9.L#Na.#Ta##Yaa#D#0.6.Pab#qab#Macadaeaf.GQt",
"Qt#bag.Zahai.L.k.7a#.9.kajakalam.J.6an.m#Caoapaq.laras.mag.A.y#y",
".T.A.s#bat.Cau#Vavamawaxav#Tayaza###aA.B.U.#.b.S#4aBaC.4#zaDaE.E",
"#y.E#e.5.yaEaF.i#SaGaH#1.9##aIaJ#r.k#paCaK.W.uaL.f#g#d.C.D#m.Y.4",
".U#z.vaM.TaNaOaPaQ#t#saR.8am#Y.k.9aSaT#N#d#eaUaUaV.AaW#G.H.n.maP",
".v.T.b#y#e.D#A.Aao#Wa#aXaYaAaZa0a1.o#x.2.FaVa2a3.e#y#A#ka4#8aG.Y",
".w.h.z.4aE.h#g.C.ra5.6#X#1.Lac.i#9aGa6#A#d#g.E.V.WaV.y.raI#Ha7aK",
".f.A#B#4a8#kaN#Gad.P.Ja0a9.qae#E#VaraF#Na7aB.C#z.4#cb.b#ba#q.H.S",
".c#BbbahaqaH#Ebcbdbebfaw#pbg.K#1#r#Yam#L.Laoaf#h.r#5#bbh#7bi#SaP",
"#yaQapaT.objav#Hbk.7axava0#Y.9a#bl#V.9#J.oac#I#8#pae.2#ubmavbnap",
".a#AaNay#qambm.Jbobpbq.k.7br.lbs#oaqaZ.Jbi.k#Y#r#U#Sagak#qaX#Hbt",
"#zQt#h.oazbu#S#EbsbvbwbnaHa7#4aNbxbyaA#7.6.6a9###U#ubz#8a#bA##.J",
".T.C.rbB.Hbx#4.Y.mbx#hafaW.X.ybC.naT.q.HacbB#E.NawadaGbaaXbj.P#U",
".c#d.H#v#baK.D#c#x.Q.ZbD#bat#m.rajbeaYan#M#sbE##.kaw#U.Ja9.LbFas",
".##b#4#AaM.5.s#5bGad#D#ua8aN.m.p#sbA#XbjbEbHaX#1a###.J.NaZ.LbI#d",
".TbJ.T#gbK.x.4#x.3apbpaIbtal#Saa.9a1bE.O#Xa9bl#Z.pa5bgbqaj#pad.X",
".f.w.RQt.W.W.y.a.4aWa7#Z#T.8#1av#YaAas#p#Y#Jan#N#v.Z#GaO#v#ja7.A",
"bLa2bM.t.tbNaM.D#b.s#vbO#T#rbe#1aYan.raT#7#rbi#0#D#4#z.z.D.saW.s",
"bPbQ#fbRbR.d.R#5aO.m#WaY##a9aH#8bd#uaPae.l#0bSbHaz#x.X.s.y.c.v.f",
"bR#fbTbU#f.b.CbVaF.i#7.Ja9.oaiad#M#S.Y.Cahas#s.Oa5bc.i#u#5.baMbW",
".x#e.hbT.G.3ahaGbl.6.Jam#MapaQaNap.HaC.AaN#N#Va#aZam#Ja4ah.3at.v",
"aL.TbCaN.ZaFbs#La9#J#s.i#taCaE#5#4bCaNb..B.H.laY#H.PbXbladaB.2#e",
"aM.a.1#wa.bsajbd.l#o#Sacafat.Sat.a.T.S.2#xahai#i#G#G#obu#SbY.y.R",
"#zaKafbZ.H#6#C#x#l.1.B#vahbJ.dbT.F.cQt#z.z.zb0#h.4b1bG#G#tbV.zaM",
".aaE.3.2aQ.YaK.z.4at.R.E#dQtb2bK.e.V.tbMbN.x.v#c#c#e.A#m#m#4#b.5",
".E#A#g.5.b#y.5.v.V#z.VaL#e.Rb2b3b4b2b5b6b7aU.gaMaMaMQt#g.4#c.SbT"};


/* 
 *  Constructs a ConfigGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
ConfigGUIBase::ConfigGUIBase( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    if ( !name )
	setName( "ConfigGUIBase" );
    resize( 490, 330 ); 
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 490, 330 ) );
    setCaption( tr( "ScapeMaker | Config" ) );
    setIcon( image0 );

    performanceGroup = new QGroupBox( this, "performanceGroup" );
    performanceGroup->setGeometry( QRect( 10, 10, 230, 315 ) ); 
    performanceGroup->setTitle( tr( "Performance" ) );

    detailTexture = new QCheckBox( performanceGroup, "detailTexture" );
    detailTexture->setGeometry( QRect( 10, 20, 130, 21 ) ); 
    detailTexture->setText( tr( "Terrain detail texture" ) );
    QToolTip::add(  detailTexture, tr( "" ) );
    QWhatsThis::add(  detailTexture, tr( "Switches the detail texture on/off. When the detail texture is switched on, a high-resolution structure is laid over the whole landscape, which makes the landscape textures look less blury. Needs much system resources and should be switched off with slow graphic cards." ) );

    terrainLODGroup = new QButtonGroup( performanceGroup, "terrainLODGroup" );
    terrainLODGroup->setGeometry( QRect( 10, 45, 210, 105 ) ); 
    terrainLODGroup->setTitle( tr( "Terrain geometry" ) );
    QToolTip::add(  terrainLODGroup, tr( "" ) );
    QWhatsThis::add(  terrainLODGroup, tr( "Defines the detail of the landscapes geometry. This only affects the mesh, not the landscape textures. A low level of detail can have a very positive affect on the frame rate, if an old graphic card is used." ) );

    terrainLODHigh = new QRadioButton( terrainLODGroup, "terrainLODHigh" );
    terrainLODHigh->setGeometry( QRect( 10, 60, 120, 21 ) ); 
    terrainLODHigh->setText( tr( "High detail" ) );
    terrainLODGroup->insert( terrainLODHigh, 2 );

    terrainLODMiddle = new QRadioButton( terrainLODGroup, "terrainLODMiddle" );
    terrainLODMiddle->setGeometry( QRect( 10, 40, 120, 21 ) ); 
    terrainLODMiddle->setText( tr( "Middle detail" ) );
    terrainLODGroup->insert( terrainLODMiddle, 1 );

    terrainLODLow = new QRadioButton( terrainLODGroup, "terrainLODLow" );
    terrainLODLow->setGeometry( QRect( 10, 20, 120, 21 ) ); 
    terrainLODLow->setText( tr( "Low detail" ) );
    terrainLODGroup->insert( terrainLODLow, 0 );

    terrainLODFull = new QRadioButton( terrainLODGroup, "terrainLODFull" );
    terrainLODFull->setGeometry( QRect( 10, 80, 120, 21 ) ); 
    terrainLODFull->setText( tr( "Full detail" ) );
    terrainLODGroup->insert( terrainLODFull, 3 );

    cloudShading = new QCheckBox( performanceGroup, "cloudShading" );
    cloudShading->setGeometry( QRect( 10, 175, 205, 21 ) ); 
    cloudShading->setText( tr( "Cloud shading" ) );
    QToolTip::add(  cloudShading, tr( "" ) );
    QWhatsThis::add(  cloudShading, tr( "Switches cloud shading on/off for all landscapes. Not shaded  clouds need less memory, but this option is only available  at better graphic cards." ) );

    waterReflection = new QCheckBox( performanceGroup, "waterReflection" );
    waterReflection->setGeometry( QRect( 10, 195, 205, 21 ) ); 
    waterReflection->setText( tr( "Water reflection" ) );
    QToolTip::add(  waterReflection, tr( "" ) );
    QWhatsThis::add(  waterReflection, tr( "De-/activates the reflexion of water for all landscapes. Like with height based fog, this is only available for users with vertex-/pixelshader support." ) );

    seaReflectionGroup = new QButtonGroup( performanceGroup, "seaReflectionGroup" );
    seaReflectionGroup->setGeometry( QRect( 10, 220, 211, 85 ) ); 
    seaReflectionGroup->setTitle( tr( "Sea reflection" ) );
    QWhatsThis::add(  seaReflectionGroup, tr( "Defines the type of reflection. You get better performance if less elements are visible in reflection." ) );

    reflectionSkyTerrainSubMeshes = new QRadioButton( seaReflectionGroup, "reflectionSkyTerrainSubMeshes" );
    reflectionSkyTerrainSubMeshes->setGeometry( QRect( 10, 60, 195, 16 ) ); 
    reflectionSkyTerrainSubMeshes->setText( tr( "Sky, terrain, clouds and objects" ) );
    seaReflectionGroup->insert( reflectionSkyTerrainSubMeshes, 2 );

    reflectionSky = new QRadioButton( seaReflectionGroup, "reflectionSky" );
    reflectionSky->setGeometry( QRect( 10, 20, 190, 16 ) ); 
    reflectionSky->setText( tr( "Sky" ) );
    seaReflectionGroup->insert( reflectionSky, 0 );

    reflectionSkyTerrain = new QRadioButton( seaReflectionGroup, "reflectionSkyTerrain" );
    reflectionSkyTerrain->setGeometry( QRect( 10, 40, 190, 16 ) ); 
    reflectionSkyTerrain->setText( tr( "Sky and terrain" ) );
    seaReflectionGroup->insert( reflectionSkyTerrain, 1 );

    fog = new QCheckBox( performanceGroup, "fog" );
    fog->setGeometry( QRect( 10, 155, 205, 21 ) ); 
    fog->setText( tr( "Height based fog" ) );
    QToolTip::add(  fog, tr( "" ) );
    QWhatsThis::add(  fog, tr( "Switches height based fog on/off for all landscapes. Should be switched off if the graphic card has problems with the used vertex-/pixelshaders. If the graphic card does not support vertex-/pixelshaders, this option is not available." ) );

    cancelButton = new QPushButton( this, "cancelButton" );
    cancelButton->setGeometry( QRect( 310, 295, 81, 25 ) ); 
    cancelButton->setText( tr( "Cancel" ) );

    okButton = new QPushButton( this, "okButton" );
    okButton->setGeometry( QRect( 400, 295, 81, 25 ) ); 
    okButton->setText( tr( "OK" ) );
    okButton->setDefault( TRUE );

    hardwareGroup = new QGroupBox( this, "hardwareGroup" );
    hardwareGroup->setGeometry( QRect( 250, 10, 231, 100 ) ); 
    hardwareGroup->setTitle( tr( "Hardware" ) );

    typeLabel = new QLabel( hardwareGroup, "typeLabel" );
    typeLabel->setGeometry( QRect( 10, 20, 61, 21 ) ); 
    typeLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, typeLabel->sizePolicy().hasHeightForWidth() ) );
    typeLabel->setText( tr( "Type:" ) );
    typeLabel->setScaledContents( FALSE );

    antialiasingLabel = new QLabel( hardwareGroup, "antialiasingLabel" );
    antialiasingLabel->setGeometry( QRect( 10, 65, 65, 20 ) ); 
    antialiasingLabel->setText( tr( "Antialiasing:" ) );

    type = new QLabel( hardwareGroup, "type" );
    type->setGeometry( QRect( 76, 20, 145, 21 ) ); 
    type->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, type->sizePolicy().hasHeightForWidth() ) );
    type->setText( tr( "?" ) );
    type->setScaledContents( FALSE );

    resolutionLabel = new QLabel( hardwareGroup, "resolutionLabel" );
    resolutionLabel->setGeometry( QRect( 10, 40, 60, 21 ) ); 
    resolutionLabel->setText( tr( "Resolution:" ) );

    resolution = new QComboBox( FALSE, hardwareGroup, "resolution" );
    resolution->setGeometry( QRect( 75, 40, 145, 21 ) ); 
    resolution->setCurrentItem( -1 );
    QWhatsThis::add(  resolution, tr( "Switches resolution, color depth and frequence of the graphic card. Choose only values your graphic card and monitor can handle. Height based fog will only be visible at 32 bit color depth." ) );

    antialiasing = new QComboBox( FALSE, hardwareGroup, "antialiasing" );
    antialiasing->setGeometry( QRect( 75, 65, 145, 21 ) ); 
    antialiasing->setCurrentItem( -1 );
    QWhatsThis::add(  antialiasing, tr( "Sets intensity of antialiasing in fullscreen mode. Switch it off for better performance." ) );

    infoGroup = new QGroupBox( this, "infoGroup" );
    infoGroup->setGeometry( QRect( 250, 190, 230, 100 ) ); 
    infoGroup->setTitle( tr( "Information" ) );

    infoText = new QLabel( infoGroup, "infoText" );
    infoText->setGeometry( QRect( 10, 20, 210, 65 ) ); 
    infoText->setText( tr( "Height based fog needs vertex- and pixel-shader 2.0 hardware.\nWater reflection needs vertex- and pixel-shader 1.1 hardware with environment bump mapping support." ) );
    infoText->setTextFormat( QLabel::AutoText );
    infoText->setAlignment( int( QLabel::WordBreak | QLabel::AlignTop | QLabel::AlignLeft ) );

    GuiGroup = new QGroupBox( this, "GuiGroup" );
    GuiGroup->setGeometry( QRect( 250, 115, 230, 70 ) ); 
    GuiGroup->setTitle( tr( "User interface" ) );

    languageLabel = new QLabel( GuiGroup, "languageLabel" );
    languageLabel->setGeometry( QRect( 10, 20, 60, 16 ) ); 
    languageLabel->setText( tr( "Language:" ) );

    language = new QComboBox( FALSE, GuiGroup, "language" );
    language->insertItem( tr( "English" ) );
    language->insertItem( tr( "German" ) );
    language->setGeometry( QRect( 75, 15, 145, 22 ) ); 
    language->setCurrentItem( 0 );
    QWhatsThis::add(  language, tr( "Switches language of gui." ) );

    expert = new QCheckBox( GuiGroup, "expert" );
    expert->setGeometry( QRect( 10, 45, 205, 17 ) ); 
    expert->setText( tr( "Expert mode: Shows all functions" ) );
    QWhatsThis::add(  expert, tr( "Set this flag to unhide all function. If you're a beginner, let this option turned off." ) );

    // signals and slots connections
    connect( okButton, SIGNAL( clicked() ), this, SLOT( okClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( waterReflection, SIGNAL( toggled(bool) ), seaReflectionGroup, SLOT( setEnabled(bool) ) );
    connect( resolution, SIGNAL( activated(int) ), this, SLOT( resolutionChanged(int) ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ConfigGUIBase::~ConfigGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

void ConfigGUIBase::cancelClicked()
{
    qWarning( "ConfigGUIBase::cancelClicked(): Not implemented yet!" );
}

void ConfigGUIBase::resolutionChanged(int)
{
    qWarning( "ConfigGUIBase::resolutionChanged(int): Not implemented yet!" );
}

void ConfigGUIBase::okClicked()
{
    qWarning( "ConfigGUIBase::okClicked(): Not implemented yet!" );
}

