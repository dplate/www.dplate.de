/****************************************************************************
** EnviromentGUI meta object code from reading C++ file 'enviromentgui.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_EnviromentGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "enviromentgui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *EnviromentGUI::className() const
{
    return "EnviromentGUI";
}

QMetaObject *EnviromentGUI::metaObj = 0;

void EnviromentGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(EnviromentGUIBase::className(), "EnviromentGUIBase") != 0 )
	badSuperclassWarning("EnviromentGUI","EnviromentGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString EnviromentGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("EnviromentGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* EnviromentGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) EnviromentGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(EnviromentGUI::*m1_t0)();
    typedef void(EnviromentGUI::*m1_t1)();
    typedef void(EnviromentGUI::*m1_t2)();
    typedef void(EnviromentGUI::*m1_t3)();
    typedef void(EnviromentGUI::*m1_t4)();
    typedef void(EnviromentGUI::*m1_t5)();
    typedef void(EnviromentGUI::*m1_t6)();
    typedef void(EnviromentGUI::*m1_t7)();
    typedef void(EnviromentGUI::*m1_t8)(int);
    typedef void(EnviromentGUI::*m1_t9)(int);
    typedef void(EnviromentGUI::*m1_t10)();
    m1_t0 v1_0 = Q_AMPERSAND EnviromentGUI::shadowValuesChanged;
    m1_t1 v1_1 = Q_AMPERSAND EnviromentGUI::generateClicked;
    m1_t2 v1_2 = Q_AMPERSAND EnviromentGUI::cancelClicked;
    m1_t3 v1_3 = Q_AMPERSAND EnviromentGUI::timeValueChanged;
    m1_t4 v1_4 = Q_AMPERSAND EnviromentGUI::colorFromClicked;
    m1_t5 v1_5 = Q_AMPERSAND EnviromentGUI::colorToClicked;
    m1_t6 v1_6 = Q_AMPERSAND EnviromentGUI::colorAmbientClicked;
    m1_t7 v1_7 = Q_AMPERSAND EnviromentGUI::colorDiffuseClicked;
    m1_t8 v1_8 = Q_AMPERSAND EnviromentGUI::segmentBeginChanged;
    m1_t9 v1_9 = Q_AMPERSAND EnviromentGUI::segmentEndChanged;
    m1_t10 v1_10 = Q_AMPERSAND EnviromentGUI::exportClicked;
    QMetaData *slot_tbl = QMetaObject::new_metadata(11);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(11);
    slot_tbl[0].name = "shadowValuesChanged()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "generateClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "cancelClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "timeValueChanged()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "colorFromClicked()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "colorToClicked()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "colorAmbientClicked()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "colorDiffuseClicked()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "segmentBeginChanged(int)";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Public;
    slot_tbl[9].name = "segmentEndChanged(int)";
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl_access[9] = QMetaData::Public;
    slot_tbl[10].name = "exportClicked()";
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl_access[10] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"EnviromentGUI", "EnviromentGUIBase",
	slot_tbl, 11,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
