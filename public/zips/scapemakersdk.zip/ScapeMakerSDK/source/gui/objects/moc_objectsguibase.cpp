/****************************************************************************
** ObjectsGUIBase meta object code from reading C++ file 'objectsguibase.h'
**
** Created: Sun Feb 13 15:03:32 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_ObjectsGUIBase
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "objectsguibase.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *ObjectsGUIBase::className() const
{
    return "ObjectsGUIBase";
}

QMetaObject *ObjectsGUIBase::metaObj = 0;

void ObjectsGUIBase::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("ObjectsGUIBase","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString ObjectsGUIBase::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("ObjectsGUIBase",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* ObjectsGUIBase::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(ObjectsGUIBase::*m1_t0)();
    typedef void(ObjectsGUIBase::*m1_t1)();
    typedef void(ObjectsGUIBase::*m1_t2)();
    typedef void(ObjectsGUIBase::*m1_t3)();
    typedef void(ObjectsGUIBase::*m1_t4)();
    typedef void(ObjectsGUIBase::*m1_t5)();
    typedef void(ObjectsGUIBase::*m1_t6)();
    typedef void(ObjectsGUIBase::*m1_t7)();
    typedef void(ObjectsGUIBase::*m1_t8)();
    typedef void(ObjectsGUIBase::*m1_t9)();
    typedef void(ObjectsGUIBase::*m1_t10)();
    typedef void(ObjectsGUIBase::*m1_t11)();
    m1_t0 v1_0 = Q_AMPERSAND ObjectsGUIBase::addClicked;
    m1_t1 v1_1 = Q_AMPERSAND ObjectsGUIBase::cancelClicked;
    m1_t2 v1_2 = Q_AMPERSAND ObjectsGUIBase::clearClicked;
    m1_t3 v1_3 = Q_AMPERSAND ObjectsGUIBase::editClicked;
    m1_t4 v1_4 = Q_AMPERSAND ObjectsGUIBase::generateClicked;
    m1_t5 v1_5 = Q_AMPERSAND ObjectsGUIBase::importMaskClicked;
    m1_t6 v1_6 = Q_AMPERSAND ObjectsGUIBase::importObjectClicked;
    m1_t7 v1_7 = Q_AMPERSAND ObjectsGUIBase::objectSelected;
    m1_t8 v1_8 = Q_AMPERSAND ObjectsGUIBase::removeClicked;
    m1_t9 v1_9 = Q_AMPERSAND ObjectsGUIBase::renameClicked;
    m1_t10 v1_10 = Q_AMPERSAND ObjectsGUIBase::resetMaskClicked;
    m1_t11 v1_11 = Q_AMPERSAND ObjectsGUIBase::valuesChanged;
    QMetaData *slot_tbl = QMetaObject::new_metadata(12);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(12);
    slot_tbl[0].name = "addClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "cancelClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "clearClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "editClicked()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "generateClicked()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "importMaskClicked()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "importObjectClicked()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "objectSelected()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "removeClicked()";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Public;
    slot_tbl[9].name = "renameClicked()";
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl_access[9] = QMetaData::Public;
    slot_tbl[10].name = "resetMaskClicked()";
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl_access[10] = QMetaData::Public;
    slot_tbl[11].name = "valuesChanged()";
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl_access[11] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"ObjectsGUIBase", "QWidget",
	slot_tbl, 12,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
