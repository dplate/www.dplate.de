/****************************************************************************
** TopografieGUI meta object code from reading C++ file 'topografiegui.h'
**
** Created: Sun Feb 13 15:03:33 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_TopografieGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "topografiegui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *TopografieGUI::className() const
{
    return "TopografieGUI";
}

QMetaObject *TopografieGUI::metaObj = 0;

void TopografieGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(TopografieGUIBase::className(), "TopografieGUIBase") != 0 )
	badSuperclassWarning("TopografieGUI","TopografieGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString TopografieGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("TopografieGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* TopografieGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) TopografieGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(TopografieGUI::*m1_t0)();
    typedef void(TopografieGUI::*m1_t1)();
    typedef void(TopografieGUI::*m1_t2)();
    typedef void(TopografieGUI::*m1_t3)();
    typedef void(TopografieGUI::*m1_t4)();
    m1_t0 v1_0 = Q_AMPERSAND TopografieGUI::cancelClicked;
    m1_t1 v1_1 = Q_AMPERSAND TopografieGUI::exportClicked;
    m1_t2 v1_2 = Q_AMPERSAND TopografieGUI::generateClicked;
    m1_t3 v1_3 = Q_AMPERSAND TopografieGUI::importClicked;
    m1_t4 v1_4 = Q_AMPERSAND TopografieGUI::resetValues;
    QMetaData *slot_tbl = QMetaObject::new_metadata(5);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(5);
    slot_tbl[0].name = "cancelClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "exportClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "generateClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "importClicked()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "resetValues()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"TopografieGUI", "TopografieGUIBase",
	slot_tbl, 5,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
