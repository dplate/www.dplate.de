/****************************************************************************
** WaterGUI meta object code from reading C++ file 'watergui.h'
**
** Created: Sun Feb 13 15:03:33 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_WaterGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "watergui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *WaterGUI::className() const
{
    return "WaterGUI";
}

QMetaObject *WaterGUI::metaObj = 0;

void WaterGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(WaterGUIBase::className(), "WaterGUIBase") != 0 )
	badSuperclassWarning("WaterGUI","WaterGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString WaterGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("WaterGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* WaterGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) WaterGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(WaterGUI::*m1_t0)();
    typedef void(WaterGUI::*m1_t1)();
    typedef void(WaterGUI::*m1_t2)();
    typedef void(WaterGUI::*m1_t3)();
    typedef void(WaterGUI::*m1_t4)();
    typedef void(WaterGUI::*m1_t5)();
    typedef void(WaterGUI::*m1_t6)();
    typedef void(WaterGUI::*m1_t7)();
    typedef void(WaterGUI::*m1_t8)(QPoint);
    typedef void(WaterGUI::*m1_t9)(QPoint);
    typedef void(WaterGUI::*m1_t10)();
    typedef void(WaterGUI::*m1_t11)();
    typedef void(WaterGUI::*m1_t12)();
    m1_t0 v1_0 = Q_AMPERSAND WaterGUI::seaValuesChanged;
    m1_t1 v1_1 = Q_AMPERSAND WaterGUI::riversValuesChanged;
    m1_t2 v1_2 = Q_AMPERSAND WaterGUI::colorClicked;
    m1_t3 v1_3 = Q_AMPERSAND WaterGUI::importClicked;
    m1_t4 v1_4 = Q_AMPERSAND WaterGUI::removeClicked;
    m1_t5 v1_5 = Q_AMPERSAND WaterGUI::renameClicked;
    m1_t6 v1_6 = Q_AMPERSAND WaterGUI::resetClicked;
    m1_t7 v1_7 = Q_AMPERSAND WaterGUI::exportMaskClicked;
    m1_t8 v1_8 = Q_AMPERSAND WaterGUI::newSource;
    m1_t9 v1_9 = Q_AMPERSAND WaterGUI::deleteSource;
    m1_t10 v1_10 = Q_AMPERSAND WaterGUI::generateClicked;
    m1_t11 v1_11 = Q_AMPERSAND WaterGUI::cancelClicked;
    m1_t12 v1_12 = Q_AMPERSAND WaterGUI::sourceSelected;
    QMetaData *slot_tbl = QMetaObject::new_metadata(13);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(13);
    slot_tbl[0].name = "seaValuesChanged()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "riversValuesChanged()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "colorClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "importClicked()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "removeClicked()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "renameClicked()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "resetClicked()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "exportMaskClicked()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "newSource(QPoint)";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Public;
    slot_tbl[9].name = "deleteSource(QPoint)";
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl_access[9] = QMetaData::Public;
    slot_tbl[10].name = "generateClicked()";
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl_access[10] = QMetaData::Public;
    slot_tbl[11].name = "cancelClicked()";
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl_access[11] = QMetaData::Public;
    slot_tbl[12].name = "sourceSelected()";
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl_access[12] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"WaterGUI", "WaterGUIBase",
	slot_tbl, 13,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
