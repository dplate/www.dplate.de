ScapeMaker

Copyright:
  Matthias Buchetics
  Dirk Plate

More information:
  manual_e.html    (English manual of ScapeMaker)
  manual.html      (Deutsches Handbuch von ScapeMaker)
  tutorial_e.html  (English tutorial for your first steps)
  tutorial.html    (Deutsches Tutorial fuer die ersten Schritte)
  
Click on 'scapemaker.exe' to start the program.
  
Please visit our web site:
  http://www.scapemaker.de.vu

  
ChangeLog:

v.1.3

  English:
    Sea without Environment-Bump-Mapping possible.
    Better performance with many objects.
    Better blending between different object LODs.
    Rivers.
    Pause, accelerate and slow down of engine possible.
    Night with moon and stars.
    Formulas and constants in Script-System.
    Shaded cirrus clouds.
    Scrolling in console.
    Detail map customizable.
    Minimap.
    Textures are saved compressed.
    Water with real transparency.
    Terrain textures with 64x64 and 128x128 resolution.
    Ex- and import of images in many different formats.
    Antialiasing in fullscreen enabled.
    Better loading of engine.
    Better screenshot names.
    Better sky box generation (no graphic tool required).
    Hiding the border of terrain by repeating terrain and new haze.
    Generated height maps are tilable.
    Better height based fog.
    Position of sun and moon in preview visible.
    Beginner mode with less setting sliders.
    Automaticaly restart of ScapeMaker after changing language.
    Sun with real lensflare effect.
    Height maps with better size (256x256 instead of 257x257)
    Shadow calculation considers the fog.
    Better shadow on water.
    Tutorials are only online now.
    Help by context sensitive 'questionmark'-function.
    Combination of different masks possible.
  
  Deutsch:
    Meer auch ohne Environment-Bump-Mapping m�glich.
    Performance-Verbesserung bei vielen Objekten.
    Verbesserte �berblendung zwischen verschiedenen Detailstufen der Objekte.
    Fl�sse.
    Pausieren, Beschleunigen und Verlangsamen der Engine m�glich.
    Nacht mit Mond und Sternen.
    Formeln und Konstanten im Script-System.
    Schattierte Zirruswolken.
    Scrollen in Konsole m�glich.
    Detailtextur vom Benutzer w�hlbar.
    Minimap.
    Texturen komprimiert gespeichert.
    Wasser mit echter Transparenz.
    Terraintexturen auch mit 64x64er und 128x128er Aufl�sung.
    Ex- und Import von Bildern in verschiedenen Formaten m�glich.
    Antialiasing f�r Vollbildmodus w�hlbar.
    Ladevorgang der Engine verbessert.
    Aussagekr�ftige Screenshotnamen.
    Skybox-Generierung ben�tigt keine Nachbearbeitung mehr.
    Verstecken des Landschaftsrands durch Wiederholung der Landschaft und Dunst.
    Generierte Heightmaps sind tileable (wiederholbar).
    Verbesserter h�henbasierter Nebel (keine Zacken mehr).
    Position von Sonne und Mond wird im Preview angezeigt.
    Anf�ngermodus, bei dem komplizierte Einstellungen ausgeblendet sind.
    Automatischer Neustart von ScapeMaker beim �ndern der Sprache.
    Sonne mit richtigem Lensflare-Effekt.
    Heightmaps besitzen eine Standardgr��e (256x256 statt 257x257).
    Beim Schattenberechnen wird der Nebel ber�cksichtigt.
    Schatten auf Wasser korrigiert.
    Tutorials ins Internet ausgelagert.
    Hilfe �ber kontextsensitive 'Fragezeichen'-Funktion.
    Kombination von verschiedenen Masken m�glich.
 
 
v.1.2:

  English:
    Z-Sorting of all semi transparent meshes.
    Console.
    Script-System.
    Slope dependent terrain shadows.
    Sky box creation script.
    Pseudo transparent water.
    Preview of shadow calculation improved.
    Faster loading of numerousness objects.
    New water with realtime reflection of terrain and objects.
    Corona around sun.
    New sun texture.
    New detail terrain texture.
    Faster shadow calculation on terrains with much water.
    Customizable water normal map.
    Animated cirrus clouds on a new cloud layer.
    Task switch without crash.
    More information in log file.
    Minimizing without crash.
    Resume of shadow calculation possible.
    Export of generated terrain textures.
    New cumulus cloud texture.
    Z-Writing for all semi transparent meshes disabled (no more z-buffer errors).
    Height calculation for dynamic objects fixed.
    Decreased gui crashes.
    Improved terrain textures.
    Import of 8bit heightmaps possible.
    
  Deutsch:
    Z-Sortierung aller halbtransparenter Objekte.
    Konsole.
    Script-System.
    Neigungsabh�ngige Landschaftsschatten.
    Script zur Erzeugung von Sky-Boxen.
    Pseudotransparentes Wasser.
    Vorschau der Schattenberechnung verbessert.
    Gro�e Anzahl von Objekten werden schneller geladen.
    Neues Wasser mit Echtzeitreflektion der Landschaft und der Objekte.
    Korona um die Sonne.
    Neue Sonnentextur.
    Neue Landschaftsdetailtextur.
    Beschleunigte Berechnung der Schatten bei Landschaften mit viel Wasser.
    Normalmap der Wasser vom Benutzer w�hlbar.
    Animierte Zirruswolken auf einer neuen Wolkenschicht.
    Taskwechsel ohne Absturz.
    Mehr Informationen in der Log-Datei.
    Minimieren ohne Absturz.
    Wiederaufnahme der Schattenberechnung m�glich.
    Export von generierten Landschaftstexturen.
    Neue Kumuluswolkentextur.
    Halbtransparente Objekte werden nicht in den Z-Buffer geschrieben (keine Z-Buffer Fehler mehr).
    H�henberechnung der dynamischen Objekte korrigiert.
    Abst�rze der Benutzeroberfl�che verringert.
    Verbesserte Landschaftstexturen.
    Import von 8Bit Heightmaps m�glich.


v.1.1:

  English:
    Rotation of objects corrected. 
    Resolution affects 3D mode. 
    Enhanced features for topography generation. Possibility to improve old heightmaps. 
    More position informations in debug display of 3D mode. 
    Landscape dialog shows a preview image. 
    Hourglass while duplicating a landscape. 
    User defined masks with textures possible. 
    User defined masks with objects possible. 
    Opening 'settings.txt' from object panel possible. 
    16bit color depth available. 
    Textures are mapped without scaling. 
    Language selector included (english or german). 
    Possibility to place objects manually. 
    Manuals and tutorials are compatible to mozilla now.  
  
  Deutsch:
    Rotation von Objekten korrigiert. 
    Bildschirmaufl�sung wird korrekt ber�cksichtigt. 
    Zus�tzliche Option zu Topografiegenerierung. Erm�glicht Nachbearbeitung bestehender Heightmaps. 
    Zus�tzliche Positonsangaben in den Debugausgaben im 3D-Modus. 
    Landschaftsverwaltungsfenster zeigt zus�tzlich eine Vorschau der Landschaft. 
    Sanduhr beim Duplizieren von Landschaften. 
    Benutzerdefinierte Maske bei Texturen m�glich. 
    Benutzerdefinierte Maske bei Objekten m�glich. 
    �ffnen der 'settings.txt' eines Objekts vom Objekte-Bereich aus m�glich. 
    16bit Farbtiefe kann nun ebenfalls ausgew�hlt werden. 
    Texturen werden nicht mehr skaliert, sondern in der Originalgr��e �bernommen. 
    Sprachauswahl f�r GUI eingef�gt (Deutsch oder Englisch m�glich). 
    Objekte k�nnen manuell innerhalb der GUI plaziert und gel�scht werden. 
    �ffnen der Handb�cher und Tutorials auch mit Mozilla m�glich.