public class Gameapplet extends java.applet.Applet	//Notwendige Klassenkopfzeile, damit es ein Applet ist
{
	Game appGame;				//das Objekt des eigentlichen Spiels
	static Gameapplet applet;	//Ein Pointer auf sich selbst (um vom Hauptprogramm auf das hier zugreifen zu k�nnen)

	public void init()			//Wird automatisch beim starten des Applets aufgerufen
	{
		applet = this;			//applet bist du selber
		appGame  = new Game();	//Ein Objekt der Hauptklasse des Spiels machen
	}

	public void stop()			//Wird vom windowslistener in der Klasse Game aufgerufen
	{
		appGame.dispose();		//Fenster schliessen
	}
}