import java.awt.*;

public class Gegner extends Component implements Runnable
{
	Image [] bild = new Image[2]; 	//Die Bilder des Gegners
	int [] pos = new int[2];		//an dieser befindet sich der Gegner
	int [] posP = new int[2];		//die Position in Pixeln
	int pixelMove;					//soviele Pixel von der NormalPosition verschoben
	Karte pKarte;					//Pointer auf das Kartenobjekt
	Spieler pSpieler;				//Pointer auf den Spieler
	Thread gegnerThread;			//zeigt auf den Thread, der den Gegner steuert
	int richtung;					//in diese Richtung l�uft er gerade
	int animation;					//Diese Animationsstufe wird gerade angezeigt

	public Gegner(Karte newKarte,Spieler newSpieler) 	//Konstruktor
	{
		bild[0] = Helps.loadImage("gegner1.gif",this);	//Animationsstufe 1 laden
		bild[1] = Helps.loadImage("gegner2.gif",this);	//Animationsstufe 2 laden

		pKarte = newKarte;					//Pointer zu Karte kopieren
		pSpieler = newSpieler;				//Pointer zu Spieler kopieren

		pos[0] = pKarte.hort[0];			//Gegner auf Hort setzen
		pos[1] = pKarte.hort[1];
	}

	public void init()						//initialisiert den Gegner
	{
		pos[0] = pKarte.hort[0];			//Gegner auf Hort setzen
		pos[1] = pKarte.hort[1];
		pixelMove = 0;						//Am Anfang in der Mitte der Kachel
		richtung = pKarte.getRichtung(pos,(int)(Math.random()*pKarte.getWays(pos))); //Zuf�llig eine Startrichtung
		Helps.calcPixelKoord(pKarte,pos[0],pos[1],richtung,pixelMove,posP); //die Koordinate in Pixel umrechnen
		gegnerThread = new Thread(this);	//neuen Thread f�r diesen Gegner erzeugen
		gegnerThread.start();				//Thread starten (weiter gehts dann in run())
	}

	public void run()						//wird von thread.start aufgerufen
	{
		boolean moved = false;				//schon zur n�chsten Kachel bewegt?

		Helps.wait((int)(Math.random()*Konst.normTime)); //Am Beginn eine zuf�llige Zeit lang warten
		Thread thisThread = Thread.currentThread(); //den Namen des aktuellen Threads speichern
		while(gegnerThread == thisThread)			//solange wiederholen, bis Thread nicht mehr vorhanden
		{
			Helps.wait(Konst.fpsTime);				//Eine halbe Sekunde warten

			checkKoll();							//Ist hier was?
			pixelMove += (pKarte.breite*Konst.fpsTime)/Konst.normTime; //Weite berechnen
			if (pixelMove > pKarte.breite/2)		//n�chste Kachel erreicht
			{
				pixelMove = pixelMove-pKarte.breite;//relativen Wert f�r die n�chste Kachel einstellen
				pos = pKarte.walk(pos,richtung);	//entg�ltig dorthin gehen
				moved = true;						//zur Kachel bewegt
				animation++;						//n�chste Animationphase
				if (animation > 1) animation = 0;	//Letzte Animation erreicht, dann wieder die erste
				checkKoll();						//Hier zur Sicherheit nochmal �berpr�fen
			}
			Helps.calcPixelKoord(pKarte,pos[0],pos[1],richtung,pixelMove,posP); //die Koordinate in Pixel umrechnen

			if ((pixelMove >= 0) && (moved)) 		//neue ZielPosition berechnen
			{
				boolean check = false;				//true, wenn Weg gefunden

				moved = false;
				int [] wRichtungen = getSpielerRichtungen();		//Die Wunschrichtungen ermitteln
				if (wRichtungen[0] != -1)							//Wenn Spieler in Reichweite
				{
					richtung = wRichtungen[(int)(Math.random()*2)]; 	//Eine von diesen Richtungen zuf�llig w�hlen
					if (pKarte.check(pKarte.walk(pos,richtung))) check = true;	  //Diese Richtung probieren
					else 												//sonst
					{
						if (wRichtungen[0] == richtung) richtung = wRichtungen[1];//Die andere Richtung nehmen
						else richtung = wRichtungen[0];
						if (pKarte.check(pKarte.walk(pos,richtung))) check = true;//Diese Richtung probieren
					}
				}
				if (!check) richtung = pKarte.getRichtung(pos,(int)(Math.random()*pKarte.getWays(pos))); //Zuf�llig einen Weg w�hlen
			}
		}
	}

	public int [] getSpielerRichtungen()		//Ermittelt die beiden Richtungen, die zum Spieler f�hren
	{
		int [] richtungen = new int[2];			//Dort werden die ermittelten Richtungen reingespeichert

		richtungen[0] = -1;						//Damit ich am Schluss feststellen kann, ob sich was getan hat
		richtungen[1] = -1;

		if ((Math.abs(pSpieler.pos[0]-pos[0]) > Konst.lookRange) ||
			(Math.abs(pSpieler.pos[1]-pos[1]) > Konst.lookRange)) return richtungen;	//au�er Reichweite

		if (pSpieler.pos[0] > pos[0]) richtungen[0] = 1;	//Spieler befindet sich rechts
		if (pSpieler.pos[0] < pos[0]) richtungen[0] = 3;	//Spieler befindet sich links
		if (pSpieler.pos[1] > pos[1]) richtungen[1] = 2;	//Spieler befindet sich unten
		if (pSpieler.pos[1] < pos[1]) richtungen[1] = 0;	//Spieler befindet sich oben

		if (richtungen[0] == -1) richtungen[0] = richtungen[1]; //Richtung ist eindeutig
		if (richtungen[1] == -1) richtungen[1] = richtungen[0]; //Richtung ist eindeutig

		if (pSpieler.turbo > 0)		//Wenn Spieler turbo hat ->fl�chten
		{
			for (int i=0;i<2;i++)	//Beide Richtungen durchgehen
			{
				richtungen[i]+=2;						//Gegengesetze Richtung
				if (richtungen[i]>=4) richtungen[i]-=4; //Wieder in den richtigen Ma�stab setzen
			}
		}
		return richtungen;
	}

	public void checkKoll()						//�berpr�ft, ob an dieser Stelle etwas ist
	{
		if ((pos[0] == pSpieler.pos[0]) && (pos[1] == pSpieler.pos[1])) //Kollision mit Gegner
		{
			if (pSpieler.turbo == 0) 									//Wenn kein Turbo aktiv
			{
				if(!pSpieler.geschafft) pSpieler.killed = true;			//Und Spieler noch nicht gewonnen
			}
			else														//sonst
			{
				pos[0] = pKarte.hort[0];		//Gegner wieder ins Hort setzen
				pos[1] = pKarte.hort[1];
			}
		}
	}

	public void display(Graphics screen)
	{
		screen.drawImage(bild[animation],posP[0],posP[1],this);	//den Gegner malen
	}
}