import java.awt.*;

public class Helps extends Component	//Hilfsfunktionen
{
	public Helps()						//Konstruktor
	{
	}

	static Image loadImage(String fileName, Component object) //L�dt ein Bild
	{
		Image bild = null;

		try
		{
			if (Gameapplet.applet == null)		//Wenn nicht als Applet gestartet
			{
				bild = Toolkit.getDefaultToolkit().getImage(fileName);	//Bild laden
			}
			else 								//Wenn als Applet gestartet
			{
				bild = Gameapplet.applet.getImage(Gameapplet.applet.getCodeBase(),fileName);//Bild laden
			}
			MediaTracker tracker = new MediaTracker(object);	//Mediatracker erstellen
			// Bilder zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.addImage(bild, 0);
			tracker.waitForAll();				//Warten bis fertig geladen

		}
		catch(java.lang.InterruptedException ie)//falls Fehler beim laden
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes"); //Fehlermeldung
		}
		return bild;							//Bild zur�ckliefern
	}

	static void wait(int dauer)				//wartet eine bestimmte Zeit (in ms)
	{
		try
		{
			Thread.sleep(dauer);			//Pause machen
		}
		catch(InterruptedException ie)		//Wenn Fehler bei Pause
		{
			System.out.println("Irgendein Sleep Fehler"); //Fehlermeldung
		}
	}

	//Rechnet Kachelkoordinaten (mit Verschiebung) in absolute Pixelkoordinaten um
	static void calcPixelKoord(Karte pKarte, int kachelX, int kachelY, int richtung, int move, int [] pos)
	{
		pos[0] = Konst.feldX+kachelX*pKarte.breite;		//absolute Pixelposition berechnen
		pos[1] = Konst.feldY+kachelY*pKarte.hoehe;
		switch(richtung)		//Die Verschiebung in eine bestimmte Richtung
		{
		case 0:					//nach oben
			pos[1] -= move;
			break;
		case 1:					//nach rechts
			pos[0] += move;
			break;
		case 2:					//nach unten
			pos[1] += move;
			break;
		case 3:					//nach links
			pos[0] -= move;
			break;

		}
	}
}