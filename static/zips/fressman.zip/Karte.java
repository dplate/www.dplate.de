import java.awt.*;

public class Karte extends Component
{
	int breite,hoehe;				//Breite und H�he der Kacheln
	Image [] bilder = new Image[Levels.maxKacheln]; 		//Die Bilder der verschiedenen Kacheln
	int [][] aktKarte = new int[Levels.maxX][Levels.maxY];	//Hier wird die aktuelle Karte gespeichert
	int [] hort = new int[2];		//an dieser Stelle kommen die Gegner raus
	int [] home = new int[2];		//dort beginnt der Spieler
	int anzGold;					//wieviele Goldst�cke liegen noch rum?

	public Karte() 									//Konstruktor
	{
		bilder[0] = Helps.loadImage("0.gif",this);	//Mauer laden
		bilder[1] = Helps.loadImage("1.gif",this);	//Weg laden
		bilder[2] = Helps.loadImage("2.gif",this);	//Weg mit Perle laden
		bilder[3] = Helps.loadImage("3.gif",this);	//Weg mit Hort laden
		bilder[4] = Helps.loadImage("1.gif",this);	//Weg laden (home ist durchsichtig)
		bilder[5] = Helps.loadImage("5.gif",this);	//Weg mit Turbo laden

		breite = bilder[0].getWidth(this);	//Die Breite der Kacheln speichern
		hoehe = bilder[0].getHeight(this);	//Die H�he der Kacheln speichern
	}

	public void init(int level)				//L�dt ein Level
	{
		int x,y;

		anzGold = 0;						//bei 0 Goldst�cken anfangen
		for (x=0;x<Levels.maxX;x++)			//alle X-Koordinaten durchgehen
			for (y=0;y<Levels.maxY;y++)		//alle Y-Koordinaten durchgehen
			{
				aktKarte[x][y] = Levels.level[level][x][y]; //eine Kopie der aktuellen Karte anfertigen
				if (aktKarte[x][y] == 2) anzGold++;			//Wenn Gold dann Goldz�hler hochz�hlen
				if (aktKarte[x][y] == 3)		//An dieser Stelle ist der Gegnerhort
				{
					hort[0] = x;				//Position speichern
					hort[1] = y;
				}
				if (aktKarte[x][y] == 4)		//An dieser Stelle beginnt der Spieler
				{
					home[0] = x;				//Position speichern
					home[1] = y;
				}
			}
	}

	public boolean check(int [] check)			//Pr�ft, ob ein Teil begehbar ist
	{
		if (aktKarte[check[0]][check[1]] > 0) return true;	//alles roger
		else return false;								//Wand
	}

	public int getWays(int [] check)					//Liefert die Anzahl von Wegen zur�ck
	{
		int anz = 4;									//Von 4 freien Wegen ausgehen
		if (aktKarte[check[0]][check[1]-1] == 0) anz--;		//Wand, also ein Weg weniger
		if (aktKarte[check[0]+1][check[1]] == 0) anz--;		//Wand, also ein Weg weniger
		if (aktKarte[check[0]][check[1]+1] == 0) anz--;		//Wand, also ein Weg weniger
		if (aktKarte[check[0]-1][check[1]] == 0) anz--;		//Wand, also ein Weg weniger
		return anz;
	}

	public int getRichtung(int [] check, int nr)		//Liefert die Richtung eines Weges von getWays
	{
		int i = 0;
		if (aktKarte[check[0]][check[1]-1] != 0)
		{
			if (i==nr) return 0;				//Richtung ist oben
			i++;
		}
		if (aktKarte[check[0]+1][check[1]] != 0)
		{
			if (i==nr) return 1;				//Richtung ist rechts
			i++;
		}
		if (aktKarte[check[0]][check[1]+1] != 0)
		{
			if (i==nr) return 2;				//Richtung ist unten
			i++;
		}
		if (aktKarte[check[0]-1][check[1]] != 0)
		{
			if (i==nr) return 3;				//Richtung ist links
		}
		return -1;
	}

	public int [] walk(int [] pos, int richtung)		//Bewegt die Position in die Richtung
	{
		int [] newPos = new int[2];

		newPos[0] = pos[0];		//Die Position umkopieren
		newPos[1] = pos[1];

		switch(richtung)
		{
		case 0:			//nach oben
			newPos[1]--;
			break;
		case 1:			//nach rechts
			newPos[0]++;
			break;
		case 2:			//nach unten
			newPos[1]++;
			break;
		case 3:			//nach links
			newPos[0]--;
			break;
		}
		return newPos;
	}

	public void display(Graphics screen)
	{
		int x,y;

		for (x=0;x<Levels.maxX;x++)		//alle X-Koordinaten durchgehen
			for (y=0;y<Levels.maxY;y++)	//alle Y-Koordinaten durchgehen
				screen.drawImage(bilder[aktKarte[x][y]],
					Konst.feldX+x*breite,
					Konst.feldY+y*hoehe,
					this);	//jede Kachel malen
	}
}