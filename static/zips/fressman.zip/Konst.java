import java.awt.*;

public class Konst extends Component		//Hier sind alle Konstanten drin
{
	static float pi = (float)3.1415926535897932384626433832795; //pi: was hast du gedacht, was das sein soll?

	static int maxX = 261;		//Fensterbreite
	static int maxY = 280;		//Fensterh�he

	static int korrX = 3;		//Die Breite des Fensterrandes
	static int korrY = 22;		//Die H�he der Titelleiste (gibts vielleicht auch einen Befehl)

	static int feldX = korrX+15;//Die linke/obere Ecke des Spielfeldes
	static int feldY = korrY+15;

	static int normTime = 300;	//Wielange braucht ein Vieh von einer Kachel zur n�chsten (in ms)
	static int fpsTime = 50;	//Wieviele mspf (milliseconds per frame)

	static int maxGegner = 4;	//Wieviele Gegner gibt es
	static int lookRange = 5;	//Wie weit k�nnen die Gegner sehen

	static Color braun = new Color(128,64,0);						//die Farbe braun
	static Font schrift = new Font("TimesRoman", Font.PLAIN, 14);	//die Standardschrift
}