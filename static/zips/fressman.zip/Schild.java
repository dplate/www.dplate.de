import java.awt.*;
import java.awt.Font;

public class Schild extends Component implements Runnable
{
	int breite,hoehe;				//Breite und H�he des Bitmaps
	Image bild; 					//Das Bild des Schilds
	int posX,posY;					//an dieser befindet sich das Schild
	Thread schildThread;			//zeigt auf den Thread
	boolean hoch;					//Das Schild wird hochgezogen
	boolean fertig;					//Zeigt an, ob mit Animation fertig
	String zeile1,zeile2;			//Die Schrift, die auf dem Schild steht
	int zeile1X,zeile1Y;			//Die relative Position der 1. Zeile
	int zeile2X,zeile2Y;			//Die relative Position der 2. Zeile

	public Schild() 								//Konstruktor
	{
		bild = Helps.loadImage("schild.gif",this);	//Das Schildbild laden

		breite = bild.getWidth(this);				//Die Breite des Schilds speichern
		hoehe = bild.getHeight(this);				//Die H�he des Schilds speichern
	}

	public void init(String newZeile1, String newZeile2)	//neues Schild mit neuer Beschriftung
	{
		FontMetrics fm = getFontMetrics(Konst.schrift);		//Um die Gr��e eines Strings zu ermitteln

		posX = (Konst.maxX-breite)/2;						//Schild zentrieren
		posY = -hoehe+Konst.korrY;							//Gerade oberhalb des sichtbaren Bereichs

		hoch = false;										//f�hrt nicht hoch
		fertig = false;										//und ist noch nicht fertig

		zeile1 = newZeile1;									//1.Zeile speichern
		zeile2 = newZeile2;									//2.Zeile speichern

		zeile1X = (breite-fm.stringWidth(zeile1))/2;		//1.Zeile zentrieren
		zeile1Y = 90;										//oben im Schild
		zeile2X = (breite-fm.stringWidth(zeile2))/2;		//2.Zeile zentrieren
		zeile2Y = 115;										//unten im Schild

		schildThread = new Thread(this);					//neuen Thread f�r diesen Gegner erzeugen
		schildThread.start();								//Thread starten (weiter gehts dann in run())
	}

	public void run()								//wird von thread.start aufgerufen
	{
		Thread thisThread = Thread.currentThread(); //den namen des aktuellen Threads speichern
		while(schildThread == thisThread)			//solange wiederholen, bis Thread nicht mehr vorhanden
		{
			Helps.wait(Konst.fpsTime);				//warten
			if (hoch) posY -= 4;					//mit 4 Pixeln nach oben bewegen
			else if (posY < Konst.korrY) posY += 2;	//mit 2 Pixeln nach unten bewegen
			if ((posY < -hoehe) && (hoch))			//wenn beim hochbewegen oben angelangt
			{
				fertig = true;						//dann fertig
				schildThread = null;				//thread beenden
			}
		}
	}

	public void display(Graphics screen)
	{
		screen.drawImage(bild,posX,posY, this);					//das Schild malen
		screen.setColor(Konst.braun);							//Farbe auf braun setzen
		screen.drawString(zeile1,posX+zeile1X,posY+zeile1Y);	//Erste Zeile hinschreiben
		screen.drawString(zeile2,posX+zeile2X,posY+zeile2Y);	//Zweite Zeile hinschreiben
	}
}