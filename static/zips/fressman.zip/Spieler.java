import java.awt.*;

public class Spieler extends Component implements Runnable
{
	Image [] bild1 = new Image[8];	//Die Bilder des Spielers (im Normalzustand)
	Image [] bild2 = new Image[8];	//Die Bilder des Spielers (im Turbozustand)
	Image bild3;					//Bild vom totem Spieler
	Image bild4;					//Bild vom gl�cklichen Spieler
	int [] pos = new int[2];		//an dieser Stelle befindet sich der Spieler
	int [] posP = new int[2];		//die Position in Pixeln
	int pixelMove;					//soviele Pixel von der NormalPosition verschoben
	Karte pKarte;					//Pointer auf das Kartenobjekt
	Thread spielerThread;			//zeigt auf den Thread, der den Spieler aktualisiert
	int richtung;					//in diese Richtung l�uft er gerade
	int wunschRichtung;				//dorthin will der Spieler als n�chstes laufen
	boolean taste;					//wurde eine Taste neu gedr�ckt
	int turbo;						//Turbomodus (wieviele Frames noch aktiv)
	int animation;					//zeigt die aktuelle Animationstufe an
	boolean killed;					//Ist der Spieler gestorben?
	boolean geschafft;				//Ist das Level geschafft?
	boolean walk;					//Kollision mit Wand -> nicht weiterlaufen

	public Spieler(Karte newKarte) 	//Konstruktor
	{
		bild1[0] = Helps.loadImage("spieler10.gif",this); //nicht Turbo nach oben
		bild1[1] = Helps.loadImage("spieler11.gif",this);
		bild1[2] = Helps.loadImage("spieler12.gif",this); //nicht Turbo nach rechts
		bild1[3] = Helps.loadImage("spieler13.gif",this);
		bild1[4] = Helps.loadImage("spieler14.gif",this); //nicht Turbo nach unten
		bild1[5] = Helps.loadImage("spieler15.gif",this);
		bild1[6] = Helps.loadImage("spieler16.gif",this); //nicht Turbo nach links
		bild1[7] = Helps.loadImage("spieler17.gif",this);
		bild2[0] = Helps.loadImage("spieler20.gif",this); //Turbo nach oben
		bild2[1] = Helps.loadImage("spieler21.gif",this);
		bild2[2] = Helps.loadImage("spieler22.gif",this); //Turbo nach rechts
		bild2[3] = Helps.loadImage("spieler23.gif",this);
		bild2[4] = Helps.loadImage("spieler24.gif",this); //Turbo nach unten
		bild2[5] = Helps.loadImage("spieler25.gif",this);
		bild2[6] = Helps.loadImage("spieler26.gif",this); //Turbo nach links
		bild2[7] = Helps.loadImage("spieler27.gif",this);
		bild3 	 = Helps.loadImage("spieler30.gif",this); //toter Pacman
		bild4    = Helps.loadImage("spieler40.gif",this); //froher Pacman

		pKarte = newKarte;					//Pointer auf die Karte

		pos[0] = pKarte.home[0];			//Beginne zuhause
		pos[1] = pKarte.home[1];
	}

	public void init()
	{
		pos[0] = pKarte.home[0];			//Beginne zuhause
		pos[1] = pKarte.home[1];

		richtung = 0;						//Richtung egal
		wunschRichtung = -1;				//Wunschrichtung schon gar nicht
		killed = false;						//noch nicht tot
		geschafft = false;					//und noch nicht geschafft
		walk = false;						//Am Anfang stehen
		pixelMove = 0;						//Am Anfang in der Mitte der Kachel
		turbo = 0;							//Turbo ausschalten

		Helps.calcPixelKoord(pKarte,pos[0],pos[1],richtung,pixelMove,posP); //die Koordinate in Pixel umrechnen*/

		spielerThread = new Thread(this);	//neuen Thread f�r den Spieler erzeugen
		spielerThread.start();				//Thread starten (weiter gehts dann in run())
	}

	public void run()						//wird von thread.start aufgerufen
	{
		boolean moved = false;				//schon zur n�chsten Kachel bewegt?

		Thread thisThread = Thread.currentThread(); //den namen des aktuellen Threads speichern
		while(spielerThread == thisThread)			//solange wiederholen, bis Thread nicht mehr vorhanden
		{
			Helps.wait(Konst.fpsTime);				//Pause machen

			if ((killed) || (geschafft)) continue;	//Wenn Tod oder Fertig, dann nichts mehr berechnen
			if (turbo > 0) turbo--;					//den Turbo abziehen
			checkKoll();							//Ist etwas auf dieser Position?
			if (walk)
			{
				if (turbo > 0) pixelMove += (1.5*pKarte.breite*Konst.fpsTime)/Konst.normTime; //Bei Turbo schneller
				else pixelMove += (pKarte.breite*Konst.fpsTime)/Konst.normTime; //Weite berechnen
				if (pixelMove > pKarte.breite/2)		//n�chste Kachel erreicht
				{
					pixelMove = pixelMove-pKarte.breite;//relativen Wert f�r die n�chste Kachel einstellen
					pos = pKarte.walk(pos,richtung);	//entg�ltig dorthin gehen
					moved = true;						//zur Kachel bewegt
					animation = 1;						//Mund auf
				}
				Helps.calcPixelKoord(pKarte,pos[0],pos[1],richtung,pixelMove,posP); //die Koordinate in Pixel umrechnen
			}

			if (((pixelMove >= 0) && (moved)) || (!walk))//neue ZielPosition berechnen
			{
				boolean check = false;					//Noch kein Weg gefunden

				moved = false;							//Normalzustand einstellen
				if (wunschRichtung != -1)				//Wenn Richtung durch Tastendruck vorgegeben
				{
					if (pKarte.check(pKarte.walk(pos,wunschRichtung))) //Wenn dies neue Stelle frei
					{
						richtung = wunschRichtung;		//und die Wunschrichtung ist jetzt die offizielle Richtung
						check = true;					//Weg gefunden
						walk = true;					//gehen wieder aktivieren
					}
				}
				if (!check)	if (!pKarte.check(pKarte.walk(pos,richtung))) walk = false;//wenn neue Position besetzt

				if (taste) taste = false;				//Taste nicht aktuell gedr�ckt
				else wunschRichtung = -1;				//Wenn keine Taste gedr�ckt, wunschRichtung wieder l�schen

				animation = 0;							//Mund zu
			}
		}
	}

	public void checkKoll()							//�berpr�ft, ob an dieser Stelle etwas ist
	{
		if (pKarte.aktKarte[pos[0]][pos[1]] == 2)	//Gold gefunden
		{
			pKarte.aktKarte[pos[0]][pos[1]] = 1;	//Gold l�schen
			pKarte.anzGold--;						//Ein Goldst�ck weniger auf der Karte
			if (pKarte.anzGold == 0) geschafft = true; //Wenn kein Goldst�ck mehr da, dann fertig
		}

		if (pKarte.aktKarte[pos[0]][pos[1]] == 5)	//Turbo gefunden
		{
			pKarte.aktKarte[pos[0]][pos[1]] = 1;	//Turbo entfernen
			turbo = 50;								//und Turbo spendieren
		}
	}

	public void display(Graphics screen)
	{
		if (geschafft) screen.drawImage(bild4,posP[0],posP[1],this);			//Geschafft-Pacman malen
		else if (killed) screen.drawImage(bild3,posP[0],posP[1],this);			//Toten-Pacman malen
		else if (turbo == 0)
			screen.drawImage(bild1[2*richtung+animation],posP[0],posP[1],this);	//den nicht Turbo-Pacman mit passender Animationsphase und Richtung malen
		else screen.drawImage(bild2[2*richtung+animation],posP[0],posP[1],this);//den Turbo-Pacman mit passender Animationsphase und Richtung malen
	}
}

