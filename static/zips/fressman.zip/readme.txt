"Fressman"
von/by dP-Software

If you can't speak german, scroll down to the english version.


Starten des Spiels:

Es gibt bei Java zwei M�glichkeiten, entweder das Spiel als Applet zu starten oder als Programm.

Als Applet (nicht optimal):
Mit dem "Netscape Navigator", dem "Microsoft Internet Explorer", dem "Applet-Viewer" oder einem anderen Java-Applet-f�higen Browser die Datei "index.htm" �ffnen. Dann sollte das Spiel automatisch starten.

Als Programm (optimal):
Daf�r muss Java auf dem Rechner installiert sein. Das Spiel kann dann mit diesem Befehl in der DOS-Eingabeauforderung im Spielverzeichnis gestartet werden: "java -jar fressman.jar"


Anleitung:

Die Aufgabe ist es, mit der gelben Spielfigur durch ein Labyrinth zu laufen und alle Goldst�cke einzusammeln. Da das Ganze so etwas einfach w�re, irren auch noch ein paar gef�hrliche Monster herum. Mit diesen sollte man jeden Kontakt vermeiden. Zus�tzlich zu den Goldst�cken gibt es auch noch Turboperlen. Sammelt man sie ein, verwandelt sich die Spielfigur selbst in ein Monster und man kann f�r kurze Zeit die Gegner fressen. Hat man alle Goldst�cke gefunden, landet man im n�chsten Level. Das Ziel ist es, alle Level zu schaffen (es gibt 5 St�ck).


Anmerkungen:

Die *.java Dateien im Spielverzeichnis sind nicht zum Spielen notwendig. Sie enthalten f�r Interessierte den Quellcode des Spiels. In der Datei Levels.java sind die Level gespeichert. Hier k�nnen leicht weitere erstellt werden.
Auf �lteren Browsern kann es sein, dass das Spiel nicht startet, da diese noch nicht vollst�ndig Java unterst�tzt haben.
Unter dem "Internet Explorer 4.0" und dem "Netscape Navigator 4.0" l�uft es fehlerfrei, allerdings reagieren die Tasten beim Navigator etwas sp�t, so dass das Spielen etwas schwieriger wird. Da die Javaunterst�tzung der Browser nicht optimal ist, ruckelt das Spiel auch etwas, wenn es als Applet gestartet wird.


Werbung:

Noch mehr gratis Spiele von dP-Software gibt es unter: http://dP-Software.home.pages.de/
Bei Fragen Email an mich: dP-Software@gmx.de


------------------------------------------------------------
English-Version:


Starting:

You have the choice: start the game as applet in your browser ("Internet Explorer 4.0" or "Netscape Navigator 4.0" or better) or (if you have installed Java on your computer) start it with java. If you want to play it as applet load the "index.htm" with your browser else write "java -jar fressman.jar" at the command-line (be sure you're in the "Fressman"-folder). The game should start now.


Description:

You are a small yellow ball in a labyrinth. Your goal is to collect all gold-pieces at the floor. But there are some monsters too, don't touch them! If you see blue perls lying around, get them and you can eat the monsters for a short moment.
After you got all gold-pieces you will transfered to the next level. Try to complete all 5 levels.


Comments:

There are some *.java-files in the "Fressman"-folder. You don't need them to play the game, it's "only" the source-code. Feel free to edit them, especialy "Levels.java". In this file I have saved the levels. You easily can change them or build new ones. The comments in the source-code are only in german, sorry.
If you try to start the game with an old browser it could happen that the game don't start,  because old browsers aren't Java-compatible.


Commercial:

Get more freeware-games at: "http://dP-Software.home.pages.de/"
Questions? Write a email to "dP-Software@gmx.de"


Dirk Plate 
am 03.01.2001