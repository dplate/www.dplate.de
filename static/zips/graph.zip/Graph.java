import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.Font;


public class Graph extends JFrame
	implements Runnable,AdjustmentListener,FocusListener,ActionListener,
				MouseListener,MouseMotionListener
{
	Image offscreenImage;	//die Ebene f�r den Graphen
	Graphics offscreen;		//wird in diese Speicherbereich gemalt

	Thread updateThread;	//zeigt auf den Thread

	JPanel pane;			//Die Hauptebene
	JPanel gPane;			//Die Ebene mit der Grafik
	JPanel ePane;			//Die Ebene f�r die Formel
	JScrollBar zoomLeiste;	//Die Zoomleiste
	JTextField [] input = new JTextField[Konst.anzParam];			//Die Felder in denen die Parameter eingetragen werden
	float [][] param = new float[Konst.anzParam+1][Konst.anzParam];	//die Werte vor dem x hoch 4 usw.
	int [] y = new int[Konst.maxX];	//die y-Werte zu den x-Werten
	int zoom = 50;					//welcher zoom-Faktor ist gerade eingestellt
	int midX,midY;					//speichert die Mitte der gPane
	float aktPoint;					//Welcher Punkt wird gerade n�her angeschaut (die x-Bildschirmkoordinate)
	float aktX,aktY;				//Der richtigen Koodinaten des aktuellen Punkts
	float aktSteigung;				//Die Steigung am aktuellen Punkt
	float aktKruemmung;				//Die Kr�mmung am aktuellen Punkt
	float aktNormSteigung;			//Die Steigung der Normalen am aktuellen Punkt

	public Graph()					//Konstruktor
    {
		super("Graph");				//Titelleiste benennen

		int i;

		setResizable(false);			//Fenster soll nicht in der Gr��e ver�nderbar sein
		setSize(Konst.maxX,Konst.maxY);	//Fenster auf die richtige Gr��e bringen

		try								//Aussehen der Benutzeroberfl�che festlegen
		{
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		}
		catch (Exception e)
	    {
			System.err.println("Kann nicht auf die Standardbenutzeroberfl�che umschalten" + e);
		}

		WindowListener l = new WindowAdapter()		//Den Zustand des Fensters �berwachen
		{
			public void windowClosing(WindowEvent e)//Wenn das Fenster geschlossen wird
			{
				System.exit(0); 					//und tsch�ss
			}
		};
		addWindowListener(l);						//Den Listener zum Fenster hinzuf�gen

		//Die Kn�pfe usw. einf�gen
		pane = new JPanel();						//die Hauptebene erzeugen
		GridBagLayout gridbag = new GridBagLayout();//Das GridBagLayout erzeugen
		pane.setLayout(gridbag);					//und der Hauptebene zuweisen

		ePane = new JPanel();						//Die Eingabeebene erzeugen
		GridBagConstraints constraints = new GridBagConstraints(); //Ein Positionsobjekt erzeugen
		buildConstraints(constraints, 0, 0, 1, 1, 20, 5,GridBagConstraints.HORIZONTAL,GridBagConstraints.WEST);
		gridbag.setConstraints(ePane, constraints);	//Die Position der Eingabeebene zuweisen
		//die ePane-Ebene belegen
		ePane.setLayout(new FlowLayout(FlowLayout.LEFT)); //Die Schaltfl�chenanordnung auf der Eingabeebene einstellen
		for (i=Konst.anzParam-1;i>=0;i--)			//F�r jeden Paramete
		{
			input[i] = new JTextField("0",3);		//ein Eingabefeld erzeugen
			input[i].addFocusListener(this);		//Soll reagieren, wenn sich der Focus �ndert
         	input[i].addActionListener(this);		//und wenn etwas eingegeben wurde
			ePane.add(input[i]);					//Das Eingabefeld zuweisen
			JLabel text;							//Ein neues Textelement erzeugen
			if (i > 1)	text = new JLabel("x^"+String.valueOf(i)+"+"); //Das "x hoch" schreiben
			else if (i > 0) text = new JLabel("x+");//je nach Position unterschiedliche
			else text = new JLabel("=f(x)");		//Sachen schreiben
			ePane.add(text);						//den Texutr zu Eingabeebene zuweisen
		}
		pane.add(ePane);							//Die Eingabeebene der Hauptebene zuweisen

		zoomLeiste = new JScrollBar(SwingConstants.HORIZONTAL, 50, 10, 1, 500);	//die zoom-Leiste erzeugen
		zoomLeiste.addAdjustmentListener(this);		//Die Aktionen von dieser Leiste abfragen
		zoomLeiste.setSize(200,50);					//Leiste soll 200 Einteilungen haben und Schieber soll 50 gro� sein
		buildConstraints(constraints, 1, 0, 1, 1, 80, 5,GridBagConstraints.HORIZONTAL,GridBagConstraints.EAST);
		gridbag.setConstraints(zoomLeiste, constraints); //Die Position der zoomLeiste zuweisen
		pane.add(zoomLeiste);						//Den ZoomLeiste hinzuf�gen

		gPane = new JPanel();						//Eine neue Ebene f�r die Grafik erzeugen
		gPane.addMouseListener(this);				//Ebene soll auf Mausdr�cker
		gPane.addMouseMotionListener(this);			//und -bewegungen reagieren
		buildConstraints(constraints, 0, 1, 2, 1, 100, 95,GridBagConstraints.BOTH,GridBagConstraints.CENTER);
		gridbag.setConstraints(gPane, constraints); //die Position der Grafikebene hinzuf�gen
		pane.add(gPane);							//Grafikebene in die andere Ebene einf�gen
		setContentPane(pane);						//die Ebene dem Fenster zurordnen
		setVisible(true);							//Das Fenster anzeigen

		offscreenImage = createImage(gPane.getWidth(),gPane.getHeight());	//Ein imagin�res Bild im Speicher erstellen
		offscreen = offscreenImage.getGraphics();	//Den Handle von dem Bild offscreen hinzuf�gen

		midX = gPane.getWidth()/2;					//Die Mitte der Grafikebene errechnen
		midY = gPane.getHeight()/2;
		aktPoint = midX;							//Der aktuelle Punkt ist zum Beginn in der Mitte

		calculate();								//Standard berechnen

		updateThread = new Thread(this);			//den Update-Thread erzeugen
		updateThread.start();						//den Update-Thread starten
	}

	public void run()								//wird von thread.start aufgerufen
	{
		Thread thisThread = Thread.currentThread(); //den namen des aktuellen Threads speichern
		while(updateThread == thisThread)			//solange wiederholen, bis Thread nicht mehr vorhanden
		{
			try
			{
				Thread.sleep(50);					//eine 20tel Sekunde Pause machen (ergibt ca. 20 Bilder/sek)
			}
			catch(InterruptedException ie)
			{
				System.out.println("Irgendein Sleep Fehler");
			}
			repaint();								//jedes Mal das Bild neu malen
		}
	}

	public void update(Graphics screen) 	//wird von repaint aufgerufen
	{
		paint(screen);						//Bildschirm nicht l�schen, sondern einfach wieder Paint
	}

	public void paint(Graphics screen)		//wird von update aufgerufen
	{
		int i;
		int posX = gPane.getX()+Konst.korrX;//die linke/obere Ecke der Grafikebene ermitteln
		int posY = gPane.getY()+Konst.korrY;

		ePane.repaint();					//die Eingabeebene neu malen
		zoomLeiste.repaint();				//die zoomLeiste neu malen
		zeichne();							//den Graphen neu malen
		screen.drawImage(offscreenImage, posX, posY, this); //offscreen auf screen malen
	}

	public void zeichneLinie(float steigung)	//Zeichnet eine Linie mit einer bestimmten Steigung durch den aktuellen Punkt
	{
		float point0x,point0y,point1x,point1y;	//Die 2 Koordinaten der Geraden
		float faktor;							//Die notwendige L�nge der Geraden

		if (((aktY*zoom) > midY) || ((aktY*zoom) < -midY)) return; 	//Wenn der aktuelle Punkt nich auf dem Bild ist -> raus

		if (Math.abs(steigung) < (float)midY/midX) 					//bei flachen Geraden
			faktor = (float)gPane.getWidth()/zoom;					//betr�gt die L�nge die Bildschirmbreite
		else faktor = 1f/steigung*(float)gPane.getHeight()/zoom;	//bei steilen Geraden ist die L�nge an die Steigung angepasst

		point0x = aktX+faktor;				//die erste Koordinate berechnen
		point0y = aktY+faktor*steigung;
		point1x = aktX-faktor;				//die zweite Koordinate berechnen
		point1y = aktY-faktor*steigung;

		offscreen.drawLine(midX+(int)(point0x*zoom),midY-(int)(point0y*zoom),	//die Gerade malen
							midX+(int)(point1x*zoom),midY-(int)(point1y*zoom));
	}

	public void calculate()					//F�hrt alle den Graphen betreffenden Berechnungen durch
	{
		int x,i,j;
		float erg;

		//die Ableitungen berechnen
		for (i=1;i<Konst.anzParam+1;i++)			//alle Ableitungen durchgehen
		{
			for (j=0;j<Konst.anzParam-i;j++) 		//alle Parameter durchgehen
				param[i][j] = param[i-1][j+1]*(j+1);//den Parameter aus dem Parameter der vorherigen Ableitung berechnen
		}

		//die y-Werte berechnen
		for (x=0;x<Konst.maxX;x++)						//Jede Bildschirmkoordinate durchgehen
		{
			erg = getErg((float)(x-midX)/zoom,param[0]);//die passende y-Koordinate berechnen
			erg *= zoom;								//die Koordinate an die Zoomstufe anpassen
			erg = Math.round(erg);						//die Koordinate auf eine ganze Zahl runden
			y[x] = (int)erg;							//die y-Koordinate speichern

			if (y[x] > midY) y[x] = midY+1;				//Wenn die Koordinate auserhalb der Bildschirm ist
			if (y[x] < -midY) y[x] = -midY-1;			//dann einen Wert gerade auserhalb des Bildschirms nehmen
		}

		aktX = (float)(aktPoint-midX)/zoom;				//die x-Koordinate des aktuellen Punkts berechnen
		aktY = getErg(aktX,param[0]);					//die y-Koordinate durch Einsetzen der X-Koordinate in die Formel berechnen
		aktSteigung = getErg(aktX,param[1]);			//die Steigung durch Einsetzen in die 1. Ableitung berechnen
		aktKruemmung = getErg(aktX,param[2]);			//die Kr�mmung durch Einsetzen in die 2. Ableitung berechnen
		if (aktSteigung == 0) aktNormSteigung = 10000;	//Wenn die Steigung 0 ist, dann ist die Normalensteigung "unendlich"
		else aktNormSteigung = -1f/aktSteigung;			//sonst Normalensteigung 'normal' berechnen
	}

	public float getErg(float x, float [] formel)		//berechnet einen Wert durch Einsetzen in Formel
	{
		int i;
		float erg = 0;		//da kommt das Ergebnis rein
		for (i=0;i<Konst.anzParam;i++) erg += formel[i]*Math.pow((double)x,(double)i); //jeden Parameter dazuaddieren
		return erg;			//Ergebnis zur�ckliefern
	}

	public float roundFloat(float zahl, int stellen)	//rundet ein Zahl auf eine bestimmte Anzahl von Stellen
	{
		int faktor;
		if (stellen == -1)faktor = Math.round((float)zoom/100)+2; //wenn nichts angegeben wurde, die Zoomstufe als Anzahl der Stellen nehmen
		else faktor = stellen;							//sonst den angegebenen Wert
		faktor = (int)Math.pow(10,faktor);				//den Faktor berechnen

		return (float)Math.round(zahl*faktor)/faktor;	//zahl mit Faktor malnehmen, dann auf ganze Zahl runden und wieder durch den Faktor teilen
	}

	public void zeichne()					//Zeichnet den Graphen
	{
		int x,i,j;
		String formel;						//dort wieder die Formel in Text gespeichert

		//Hintergrund malen
		offscreen.setColor(Color.black);
		offscreen.fillRect(0,0,gPane.getWidth(),gPane.getHeight());

		//die Koordinatenachsen malen
		offscreen.setColor(Color.gray);
		offscreen.drawLine(midX,0,midX,gPane.getHeight());
		offscreen.drawLine(0,midY,gPane.getWidth(),midY);
		//Die Einheiteneinteilung malen
		offscreen.drawLine(midX+zoom,midY-5,midX+zoom,midY+5);
		offscreen.drawLine(midX-zoom,midY-5,midX-zoom,midY+5);
		offscreen.drawLine(midX-5,midY-zoom,midX+5,midY-zoom);
		offscreen.drawLine(midX-5,midY+zoom,midX+5,midY+zoom);
		//Die Einheiten schreiben
		offscreen.setFont(Konst.schrift);
		offscreen.drawString("1",midX+zoom-3,midY+20);
		offscreen.drawString("-1",midX-zoom-6,midY+20);
		offscreen.drawString("1",midX+10,midY-zoom+5);
		offscreen.drawString("-1",midX+10,midY+zoom+5);
		//den Graphen malen
		offscreen.setColor(Color.white);
		for (x=0;x<Konst.maxX-1;x++)
		{
			offscreen.drawLine(x,midY-y[x],x+1,midY-y[x+1]);
		}
		//Die Tangente und Normale malen
		offscreen.setColor(Color.yellow);
		zeichneLinie(aktSteigung);
		offscreen.setColor(Color.red);
		zeichneLinie(aktNormSteigung);
		//Die Formel und die Ableitungen ausschreiben
		offscreen.setColor(Color.green);
		for (i=0;i<Konst.anzParam+1;i++)		//jede Ableitung durchgehen
		{
			formel = "";						//formel-Variable l�schen
			for (j=Konst.anzParam-1;j>=0;j--)	//jeden Parameter von hinten her durchgehen
			{
				if (param[i][j] == 0) continue; //wenn Parameter 0, dann mit n�chstem weitermachen
				if ((formel.length() != 0) && (param[i][j] >= 0)) formel+= "+"; //bei Positiven und nicht beim ersten ein "+" davorschreiben
				if ((param[i][j] != 1) || (j==0)) formel += getString(roundFloat(param[i][j],3)); //bei allen Zahlen au�er 1 den Parameter hinschreiben
				if (j>1) formel += "x^"+String.valueOf(j);	//bei allen Parametern, au�er x^1 und x^0, das x hoch hinschreiben
				else if (j==1) formel += "x";				//bei x^1 nur x hinschreiben
			}
			if (formel.length() == 0) break;				//wenn keine Formel vorhanden, raus
			formel += "=f";									//sonst "=f" hinschreiben
			for (j=0;j<i;j++) formel+="'";					//passende Anzahl von hochkomma anh�ngen
			formel += "(x)";								//und noch das "(x)" ranbauen
			offscreen.drawString(formel,10,20+i*20);		//die Formel ins Bild pinseln
		}
		//Die Eigenschaften des aktuellen Punktes ausgeben
		offscreen.drawString("Koordinaten= ("+String.valueOf(roundFloat(aktX,-1))+";"+String.valueOf(roundFloat(aktY,-1))+")",10,gPane.getHeight()-50);
		offscreen.drawString("Steigung= "+String.valueOf(roundFloat(aktSteigung,-1)),10,gPane.getHeight()-30);
		offscreen.drawString("Kr�mmung= "+String.valueOf(roundFloat(aktKruemmung,-1)),10,gPane.getHeight()-10);

	}

	void checkInput()					//pr�ft und �bernimmt die Eingaben im Eingabefeld
	{
		int i;

		for (i=0;i<Konst.anzParam;i++)	//jedes Eingabefeld durchgehen
		{
			try							//nur probieren
			{
				param[0][i] = Float.parseFloat(input[i].getText()); //ob Eingabewert in Zahl umgewandelt werden kann
			}
			catch (Exception e)			//Wenns nicht geklappt hat
	    	{
										//nichts machen
			}
		}
	}

	String getString(float zahl)		//Liefert den String einer Zahl zur�ck
	{
		if (zahl%1 == 0) return String.valueOf((int)zahl); 	//wenn keine Kommazahl, dann erst in Int-Umwandeln (dann schreibt er nicht immer .0)
		else return String.valueOf(zahl);					//sonst ganz normal umwandeln
	}

	void buildConstraints(GridBagConstraints gbc, int gx, int gy, int gw, int gh,
				int wx, int wy,int f, int a)	//die Positionen f�r die Schaltfl�chen einstellen
	{
		gbc.gridx = gx;			//in welcher Kachel ist die linke/obere Ecke
		gbc.gridy = gy;
		gbc.gridwidth = gw;		//wieviele Kacheln belegt dieses Element
		gbc.gridheight = gh;
		gbc.weightx = wx;		//wieviel % der gesamten Breite nimmt das Element ein
		gbc.weighty = wy;
		gbc.fill = f;			//f�llt das Element den gesamten Bereich aus?
		gbc.anchor = a;			//die Ausrichtung in der Kachel
	}

	public void adjustmentValueChanged(AdjustmentEvent evt)	//wenn der zoomLeistenwert verstellt wird
	{
		float tmp;

		tmp = (float)(aktPoint-midX)/zoom;		//die richtige Koordinate des aktuellen Punktes ermitteln
		zoom = evt.getValue();					//die neue Zoomeinstellung abfragen
		aktPoint = tmp*zoom+midX;				//den aktuellen Punkt wieder zur�ckermitteln
		calculate();							//den Graphen neu errechnen
	}

	public void actionPerformed(ActionEvent evt)//es wurde eine Eingabe gemacht
	{
		checkInput();							//die Eingabe testen
		calculate();							//und Graphen neu berechnen
	}

	public void focusLost(FocusEvent evt)		//Ein Eingabefeld hat den Fokus verloren
	{
		checkInput();							//die Eingabe testen
		calculate();							//und den Graphen neu berechnen
	}

	public void focusGained(FocusEvent evt) { }	//diese Funktionen m�ssen �berschrieben werden (benutze ich aber nicht)

	public void mouseClicked(MouseEvent evt) { }

	public void mouseEntered(MouseEvent evt) { }

	public void mouseExited(MouseEvent evt) { }

	public void mousePressed(MouseEvent evt)	//Maustaste gedr�ckt
	{
		aktPoint = (float)evt.getX();			//der aktuelle Punkt ist die X-Koordinate des Mauscursors
		calculate();							//Graphen neu berechnen
	}

	public void mouseReleased(MouseEvent evt) { }

	public void mouseDragged(MouseEvent evt)	//Maus mit gedr�ckter Maustaste bewegt
	{
		aktPoint = (float)evt.getX();			//der aktuelle Punkt ist die X-Koordinate des Mauscursors
		calculate();							//Graphen neu berechnen
	}

	public void mouseMoved(MouseEvent evt)	{ }


	public static void main(String[] args)		//Hauptprogramm
	{
		Graph frame = new Graph();			//das Haupt-Objekt erzeugen (zieht alles andere nach sich)
	}
}
