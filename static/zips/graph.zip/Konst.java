import java.awt.*;

public class Konst extends Component		//Hier sind alle Konstanten drin
{
	static int maxX = 600;	//Fensterbreite
	static int maxY = 600;	//Fensterh�he

	static int korrX = 3;	//Die Breite des Fensterrandes
	static int korrY = 22;	//Die H�he der Titelleiste (gibts vielleicht auch einen Befehl)

	static int anzParam = 5;//Wieviele Parameter gibts bei der Formel (bis zu welchem Grad)

	static Font schrift = new Font("TimesRoman", Font.PLAIN, 14); //die Standardschrift
}