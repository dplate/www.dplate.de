//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

class Application : public CD3DApplication
{
public:
    Application();
private:
	// Transform matrices
    D3DXMATRIX              m_matWorld;
    D3DXMATRIX              m_matView;
    D3DXMATRIX              m_matProj;
	D3DXVECTOR3				vEyePt;      
    D3DXVECTOR3				vLookatPt;   
    D3DXVECTOR3				vUpVec;
	D3DXVECTOR3				vCam1;
	D3DXVECTOR3				vMoveCam;
    D3DLIGHT8				d3dLight; 

	KollisionList testKollisionList;
	Karte		testKarte;
	Objekte		testObjekte;
	Auto		testAuto[MAXAUTOS];

protected:
    HRESULT OneTimeSceneInit();
    HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
    HRESULT FrameMove();
    HRESULT FinalCleanup();
	LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};