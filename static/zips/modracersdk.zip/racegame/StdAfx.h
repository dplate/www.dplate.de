// stdafx.h : Include-Datei f�r Standard-System-Include-Dateien,
//  oder projektspezifische Include-Dateien, die h�ufig benutzt, aber
//      in unregelm��igen Abst�nden ge�ndert werden.
//

#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)

#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Selten benutzte Teile der Windows-Header nicht einbinden

// Windows-Header-Dateien:
#include <windows.h>

// Header-Dateien der C-Laufzeit
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <commdlg.h>
#include <tchar.h>
#include <D3DX8.h>

#define INITGUID
#include <basetsd.h>
#include <dinput.h>

// Lokale Header-Dateien
#include <fstream>
#include <math.h>
#include <time.h>
#include <float.h>
#include <direct.h>
#include "D3DApp.h"
#include "D3DUtil.h"
#include "DXUtil.h"
#include "Dxerr8.h"

#include "fmod.h"
#include "fmod_errors.h"


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt zus�tzliche Deklarationen unmittelbar vor der vorherigen Zeile ein.

#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
