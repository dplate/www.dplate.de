//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "auto.h"
#include "helpfunctions.h"


Auto::Auto(D3DXMATRIX      *matWorldSet,
		   D3DXVECTOR3	   *vEyePtSet,
		   D3DXVECTOR3	   *vLookatPtSet,
		   FLOAT           *fElapsedTimeSet,
		   Textures		   *texturesSet,
		   char			   *homeDirSet,
		   TestText		   *testTextSet,
		   TestLine		   *testLineSet,
		   Smoke		   *smokeSet,
		   int			   *raceStatusSet,
		   int			   *refPosSet,
		   bool			   menueSet,
		   int			   startNrSet,
		   int			   indexNrSet,
		   KollisionList   *kL, 
		   Auto			   **allA, 
		   Karte		   *streckeSet, 
		   bool			   comp,
		   int			   art,
		   int			   anzRundenSet,
		   D3DVIEWPORT8	   *viewPort,
		   char			   *nameSet,
		   bool			   *debugSet,
		   CViewFrustum	   *viewFrustumSet)
{
	int i;
	XYFloat tmp0,tmp1,tmp2,tmp3;
	char buffer[MAXSTRING];
	char radXFile[MAXSTRING];
	char camFile[MAXSTRING];
	char motorSoundFile[MAXSTRING];
	float radHaftung;
	float radius;
	std::ifstream file;
	bool enableSound;

	matWorld		= matWorldSet;
	vEyePt			= vEyePtSet;
	vLookatPt		= vLookatPtSet;
	fElapsedTime	= fElapsedTimeSet;
	textures		= texturesSet;
	homeDir			= homeDirSet;
	testText		= testTextSet;
	testLine		= testLineSet;
	strecke			= streckeSet;
	menue			= menueSet;
	raceStatus		= raceStatusSet;
	refPos			= refPosSet;
	anzRunden		= anzRundenSet;
	name			= nameSet;
	debug			= debugSet;
	viewFrustum		= viewFrustumSet;	

	mesh		= NULL;
	anzMat		= 0;
	materials	= NULL;
	texNr		= NULL;

	startNr = startNrSet;
	indexNr	= indexNrSet;
	computer = comp;

	//change in the home-directory
	if (_chdir(homeDir) == -1) 
	{
		MessageBox(NULL,homeDir,NULL,NULL);
		return;
	}

	file.open("autos.txt",std::ios::in);
	if (!file.is_open())
	{
		MessageBox(NULL,"Can't open file autos.txt",NULL,NULL);
		return;
	}
	for (i=0;i<ANZCARLINES*art;i++) file.getline(buffer,MAXSTRING);
	file.getline(buffer,MAXSTRING);
	file.getline(xFile,MAXSTRING);	//Den x-File Name
	file >> laenge; file.get();		//Die L�nge und die Breite des Auto
	file >>	breite; file.getline(buffer,MAXSTRING);
	file.getline(radXFile,MAXSTRING);	//Den x-File Namen des Rades
	file >>	radius; file.getline(buffer,MAXSTRING); //Den Radius des Rades
	file >> radAbstLaenge; file.get();	//Die L�nge und die Breite des Auto
	file >>	radAbstBreite; file.getline(buffer,MAXSTRING);
	file >> power; file.get();		//the power of the car
	file >> brakePower; file.get();	//the brake power of the car
	file >> airPower; file.get();	//the air power of the car
	file >> radHaftung; file.getline(buffer,MAXSTRING); //die Haftung der R�der
	file.getline(camFile,MAXSTRING);//the camera-file-name
	file.getline(motorSoundFile,MAXSTRING);//the motorSound-file-name
	file.close();

	if (indexNr == 0) enableSound = true;	//Play only the sound for the first player
	else enableSound = false;
	if ((!computer) && (!menue))
		cockpit = new Cockpit(matWorld,textures,homeDir,testText,fElapsedTime,
							camFile,&position,&richtung,raceStatus,vEyePt,vLookatPt,		
							&clock,&lastStartZielZeit,&lastRundenZeit,&bestRundenZeit,
							&runde,&anzRunden,refPos,&indexNr,viewPort,enableSound,name,
							viewFrustum);
	else cockpit = NULL;

	for (i=0;i<4;i++) autoRad[i] = new Rad(matWorld,
		fElapsedTime,textures,homeDir,testText,smokeSet,raceStatus,radXFile,
		radius,radHaftung,airPower,menue,viewFrustum);

	geschwindigkeit.x = 0;
	geschwindigkeit.y = 0;
	
	gasPedal   = 0;
	bremsPedal = 0;
	wunschGasPedal = 0;
	wunschBremsPedal = 0;
	reverse = false;

	if (menue)
	{
		position.x = 0.0f;
		position.y = 0.0f;
		
		richtung.x = (float)1;
		richtung.y = (float)0;
		lenkRichtung.x = (float)0;
		lenkRichtung.y = (float)1;
		wunschLenkRichtung.x = (float)0;
		wunschLenkRichtung.y = (float)1;
		
		for (i=0;i<4;i++) autoRad[i]->setzeRichtung(richtung);
		
		tmp0 = position;
		tmp0.x += radAbstLaenge;
		tmp0.y -= radAbstBreite;
		autoRad[0]->setzePosition(tmp0,false);
		tmp1 = position;
		tmp1.x += radAbstLaenge;
		tmp1.y += radAbstBreite;
		autoRad[1]->setzePosition(tmp1,false);
		tmp2 = position;
		tmp2.x -= radAbstLaenge;
		tmp2.y += radAbstBreite;
		autoRad[2]->setzePosition(tmp2,false);
		tmp3 = position;
		tmp3.x -= radAbstLaenge;
		tmp3.y -= radAbstBreite;
		autoRad[3]->setzePosition(tmp3,false);
	}

	//calc. the position on the track
	if (!menue)
	{
		streckenPos = strecke->startZiel;
		for (i=0;i<strecke->anzRouteNodes-startNr;i++) streckenPos = streckenPos->next;
		reset();
		tmp0.x = 0;
		tmp0.y = 0;
		kList = kL;
		kollisionsNr[0] = kList->newObject(tmp0,tmp0);
		kollisionsNr[1] = kList->newObject(tmp0,tmp0);
		kollisionsNr[2] = kList->newObject(tmp0,tmp0);
		kollisionsNr[3] = kList->newObject(tmp0,tmp0);
	}

	//change in the sound-directory
	if (!menue)
	{
		strcpy_s(buffer,homeDir);
		strcat_s(buffer,SOUNDDIR);
		if (_chdir(buffer) == -1) MessageBox(NULL,buffer,NULL,NULL);
		motorSoundSample = FSOUND_Sample_Load(FSOUND_FREE, motorSoundFile, FSOUND_HW3D | FSOUND_LOOP_NORMAL, 0, 0);
		motorSoundBuffer = FSOUND_PlaySoundEx(FSOUND_FREE, motorSoundSample, NULL, true);
		FSOUND_SetPriority(motorSoundBuffer,255);
		motorSoundFrequency = FSOUND_GetFrequency(motorSoundBuffer);
		
		bremsSoundSample = FSOUND_Sample_Load(FSOUND_FREE, "brems.wav", FSOUND_HW3D | FSOUND_LOOP_NORMAL, 0, 0);
		bremsSoundBuffer = -1;

		crashSoundSample = FSOUND_Sample_Load(FSOUND_FREE, "crash.wav", FSOUND_HW3D | FSOUND_LOOP_OFF, 0, 0);
		crashSoundBuffer = -1;
	}

	clock = 0.0f;
	allAutos = allA;
	lastOnRoad = clock;
	lastRundenZeit = 0.0f;
	bestRundenZeit = 3600.0f;
	lastStartZielZeit = lastOnRoad;
	startZielFlag = false;
	runde = 0;
	backOverStartZiel = false;
	beforeFirstStartZiel = true;
	imZiel = false;

	menueRotation = 0;

	timer = 0;
	
}

Auto::~Auto()
{
	int i;

	for (i=0;i<4;i++) delete autoRad[i];
	if ((!computer) && (!menue)) delete cockpit;

	if (!menue) 
	{
		FSOUND_StopSound(motorSoundBuffer);
		FSOUND_StopSound(bremsSoundBuffer);
		FSOUND_StopSound(crashSoundBuffer);
	}

}

bool Auto::FrameMove()
{
	int i;
	XYFloat tmp0,tmp1,tmp2,tmp3,tmp4,tmp5,tmpRichtung;
	float tmpWinkel1,tmpWinkel2;
	float tmpBetrag;
	XYFloat neuRadPos[4];
	float addBrake;
	float oldUps[4];
	D3DXMATRIX  mat1;
	float upsSchnitt;
	bool rutscht;
	
	//calculate the transformation matrices
	//the enviroment mapping
	D3DXMatrixInverse(&matEnv,NULL,matWorld);
	D3DXMatrixRotationZ(&mat1,-(float)atan2(richtung.x,richtung.y));
	D3DXMatrixMultiply(&matEnv,&matEnv,&mat1);
	D3DXMatrixTranslation(&mat1,-position.x*0.1f, -position.y*0.1f,0.0f);
	D3DXMatrixMultiply(&matEnv,&matEnv,&mat1);
	D3DXMatrixScaling(&mat1,3.0f, 3.0f, 1.0f);
	D3DXMatrixMultiply(&matEnv,&matEnv,&mat1);
	
	if (menue) 
	{
		menueRotation += (*fElapsedTime)/2;
		D3DXMatrixTranslation( &mat1, position.x, 0.0f, position.y );
		D3DXMatrixMultiply( &mat1, matWorld, &mat1 );
		D3DXMatrixRotationY( &mat, menueRotation); 
		D3DXMatrixMultiply( &mat, &mat, &mat1 );
		
		//position der R�der updaten
		for (i=0;i<4;i++) autoRad[i]->FrameMove(0,false);
		
		return true;
	}
	if (*raceStatus != RSPAUSE)
	{
		//Lenkrichtung angleichen
		if (wunschLenkRichtung.x == 0)
		{
			lenkRichtung.x -= (lenkRichtung.x-wunschLenkRichtung.x)*(*fElapsedTime)*LENKANPASSUNGZ;
			lenkRichtung.y -= (lenkRichtung.y-wunschLenkRichtung.y)*(*fElapsedTime)*LENKANPASSUNGZ;
		}
		else
		{
			lenkRichtung.x -= (lenkRichtung.x-wunschLenkRichtung.x)*(*fElapsedTime)*LENKANPASSUNG;
			lenkRichtung.y -= (lenkRichtung.y-wunschLenkRichtung.y)*(*fElapsedTime)*LENKANPASSUNG;
		}
		//Gaspedal angleichen
		gasPedal -= (gasPedal-wunschGasPedal)*(*fElapsedTime)*GASANPASSUNG;
		bremsPedal -= (bremsPedal-wunschBremsPedal)*(*fElapsedTime)*GASANPASSUNG;
		
		//GasPedalstellung auf die Vorderr�der �bertragen 
		for (i=0;i<4;i++) oldUps[i] = autoRad[i]->ups;	
		
		if (!imZiel)
		{
			for (i=0;i<2;i++) 
			{
				if ((float)fabs(oldUps[i]) >= 1.0f)
				{
					if (reverse) autoRad[i]->ups -= power/(float)fabs(oldUps[i])*gasPedal*(*fElapsedTime);
					else autoRad[i]->ups += power/(float)fabs(oldUps[i])*gasPedal*(*fElapsedTime);
				}
				else
				{
					if (reverse) autoRad[i]->ups -= power*gasPedal*(*fElapsedTime);
					else autoRad[i]->ups += power*gasPedal*(*fElapsedTime);
				}
			}
		}
		//BremsPedalstellung auf alle R�der �bertragen
		for (i=0;i<4;i++) 
		{
			addBrake =  -brakePower*bremsPedal*(*fElapsedTime);
			autoRad[i]->ups += -(float)_copysign(addBrake,oldUps[i]);
			//Wenn sich das Vorzeichen ge�ndert hat, dann vollbremsung
			if ((bremsPedal != 0) && ((autoRad[i]->ups*oldUps[i]) < 0)) autoRad[i]->ups = 0;
		}
		
		//position der R�der updaten 
		if (((int)position.x >= 0) && ((int)position.x < strecke->anzX) &&
			((int)position.y >= 0) && ((int)position.y < strecke->anzY))
		{
			for (i=0;i<4;i++) 
				autoRad[i]->FrameMove(&(strecke->map[(int)position.x][(int)position.y]->type),
					((indexNr == 0) && (i==0)));
		}
		else
		{
			for (i=0;i<4;i++) 
				autoRad[i]->FrameMove(NULL,((indexNr == 0) && (i==0)));
		}

		//Calculate the middle of the two front ups
		upsSchnitt = (float)fabs((autoRad[0]->ups+autoRad[1]->ups)/2);
		
		//slide a wheel?
		rutscht = false;
		for (i=0;i<4;i++) if (autoRad[i]->rutscht) rutscht = true;
	
		//Richtung des Autos festlegen
		tmp3.x = (autoRad[0]->position.x+autoRad[1]->position.x)/2;
		tmp3.y = (autoRad[0]->position.y+autoRad[1]->position.y)/2;
		tmp4.x = (autoRad[2]->position.x+autoRad[3]->position.x)/2;
		tmp4.y = (autoRad[2]->position.y+autoRad[3]->position.y)/2;
		tmp5.x = tmp3.x-tmp4.x;
		tmp5.y = tmp3.y-tmp4.y;

		tmpBetrag = GetBetrag(tmp5);
		richtung.x = tmp5.x/tmpBetrag;
		richtung.y = tmp5.y/tmpBetrag;
		
		//Mittelposition des Autos errechnen
		tmp5.x = (tmp3.x+tmp4.x)/2;
		tmp5.y = (tmp3.y+tmp4.y)/2;
		position.x = tmp5.x;
		position.y = tmp5.y;
		tmpRichtung.x = richtung.y;
		tmpRichtung.y = -richtung.x;
		neuRadPos[0].x = tmp5.x+richtung.x*radAbstLaenge+tmpRichtung.x*radAbstBreite;
		neuRadPos[0].y = tmp5.y+richtung.y*radAbstLaenge+tmpRichtung.y*radAbstBreite;
		neuRadPos[1].x = tmp5.x+richtung.x*radAbstLaenge-tmpRichtung.x*radAbstBreite;
		neuRadPos[1].y = tmp5.y+richtung.y*radAbstLaenge-tmpRichtung.y*radAbstBreite;
		neuRadPos[2].x = tmp5.x-richtung.x*radAbstLaenge+tmpRichtung.x*radAbstBreite;
		neuRadPos[2].y = tmp5.y-richtung.y*radAbstLaenge+tmpRichtung.y*radAbstBreite;
		neuRadPos[3].x = tmp5.x-richtung.x*radAbstLaenge-tmpRichtung.x*radAbstBreite;
		neuRadPos[3].y = tmp5.y-richtung.y*radAbstLaenge-tmpRichtung.y*radAbstBreite;
		
		//R�der parallelisieren
		if (richtung.y != 0.0f)
		{
			if (richtung.y < 0)
			{
				tmp2.x = 1;	
				tmp2.y = richtung.x/richtung.y;
			}
			else if (richtung.y > 0)
			{
				tmp2.x = -1;	
				tmp2.y = -(richtung.x/richtung.y);	
			}
			tmpBetrag = GetBetrag(tmp2);
			tmp3.x = tmp2.x/tmpBetrag;
			tmp3.y = tmp2.y/tmpBetrag;
		}
		else
		{
			tmp3.x = 0.0f;
			if (richtung.x > 0.0f) tmp3.y = -1.0f;
			else tmp3.y = 1.0f;
		}
		
		if (lenkRichtung.x < 0)
		{
			autoRad[0]->setzePosition(neuRadPos[0],true);
			neuRadPos[1].x = neuRadPos[0].x+tmp3.x*2*radAbstBreite;
			neuRadPos[1].y = neuRadPos[0].y-tmp3.y*2*radAbstBreite;
			autoRad[1]->setzePosition(neuRadPos[1],true);
		}
		else
		{
			autoRad[1]->setzePosition(neuRadPos[1],true);
			neuRadPos[0].x = neuRadPos[1].x-tmp3.x*2*radAbstBreite;
			neuRadPos[0].y = neuRadPos[1].y+tmp3.y*2*radAbstBreite;
			autoRad[0]->setzePosition(neuRadPos[0],true);
		}
		
		//Hinterr�der an die richtige Stelle setzen
		neuRadPos[3].x = neuRadPos[0].x-richtung.x*2*radAbstLaenge;
		neuRadPos[3].y = neuRadPos[0].y-richtung.y*2*radAbstLaenge;
		autoRad[3]->setzePosition(neuRadPos[3],true);
		neuRadPos[2].x = neuRadPos[1].x-richtung.x*2*radAbstLaenge;
		neuRadPos[2].y = neuRadPos[1].y-richtung.y*2*radAbstLaenge;
		autoRad[2]->setzePosition(neuRadPos[2],true);
	
		//Noch mal die Position des Autos ermitteln (damit es mit den R�dern �bereinstimmt)
		tmp1.x = (neuRadPos[0].x+neuRadPos[1].x)/2;
		tmp1.y = (neuRadPos[0].y+neuRadPos[1].y)/2;
		tmp2.x = (neuRadPos[2].x+neuRadPos[3].x)/2;
		tmp2.y = (neuRadPos[2].y+neuRadPos[3].y)/2;
		position.x = (tmp1.x+tmp2.x)/2;
		position.y = (tmp1.y+tmp2.y)/2;

		tmp5.x = tmp1.x-tmp2.x;
		tmp5.y = tmp1.y-tmp2.y;

		tmpBetrag = GetBetrag(tmp5);
		richtung.x = tmp5.x/tmpBetrag;
		richtung.y = tmp5.y/tmpBetrag;
		
		//Hinterr�der in die richtige Richtung setzen
		for (i=2;i<4;i++) autoRad[i]->setzeRichtung(richtung);
		
		//Lenkrichtung auf die Vorderr�der �bertragen
		tmpWinkel1 = (float)atan2(lenkRichtung.x,lenkRichtung.y);
		tmpWinkel2 = (float)atan2(richtung.y,richtung.x);
		tmp1.x = (float)cos(tmpWinkel1+tmpWinkel2);
		tmp1.y = (float)sin(tmpWinkel1+tmpWinkel2);
		for (i=0;i<2;i++) autoRad[i]->setzeRichtung(tmp1);
	
		//Geschwindigkeit des Autos ermitteln
		tmp3.x = (autoRad[0]->geschwindigkeit.x+autoRad[1]->geschwindigkeit.x)/2;
		tmp3.y = (autoRad[0]->geschwindigkeit.y+autoRad[1]->geschwindigkeit.y)/2;
		tmp4.x = (autoRad[2]->geschwindigkeit.x+autoRad[3]->geschwindigkeit.x)/2;
		tmp4.y = (autoRad[2]->geschwindigkeit.y+autoRad[3]->geschwindigkeit.y)/2;
		geschwindigkeit.x = (tmp3.x+tmp4.x)/2;
		geschwindigkeit.y = (tmp3.y+tmp4.y)/2;
		
		//Kollisionsdaten updaten (jede Seite neu in die Liste eintragen)
		tmp1.x = position.x+richtung.x*laenge+tmpRichtung.x*breite;
		tmp1.y = position.y+richtung.y*laenge+tmpRichtung.y*breite;
		tmp0.x = position.x+richtung.x*laenge-tmpRichtung.x*breite;
		tmp0.y = position.y+richtung.y*laenge-tmpRichtung.y*breite;
		tmp2.x = position.x-richtung.x*laenge+tmpRichtung.x*breite;
		tmp2.y = position.y-richtung.y*laenge+tmpRichtung.y*breite;
		tmp3.x = position.x-richtung.x*laenge-tmpRichtung.x*breite;
		tmp3.y = position.y-richtung.y*laenge-tmpRichtung.y*breite;
		
		kList->updateObject(kollisionsNr[0],tmp0,tmp1);
		kList->updateObject(kollisionsNr[1],tmp1,tmp2);
		kList->updateObject(kollisionsNr[2],tmp2,tmp3);
		kList->updateObject(kollisionsNr[3],tmp3,tmp0);
		
		if (*debug && (indexNr == 0)) 
		{
			char buffer[10];
			_gcvt_s(buffer, 9, position.x,  6);
			testText->drawText(2,buffer);
			_gcvt_s(buffer, 9, position.y, 6);
			testText->drawText(3,buffer);
		}

		//draw testlines
		if (*debug)
		{
			testLine->drawLine(kollisionsNr[0],tmp0,tmp1);
			testLine->drawLine(kollisionsNr[1],tmp1,tmp2);
			testLine->drawLine(kollisionsNr[2],tmp2,tmp3);
			testLine->drawLine(kollisionsNr[3],tmp3,tmp0);
		}
		
		//�berpr�fen, ob Auto mit einer Wand (oder anderem Auto) kollidiert
		if ((*raceStatus != RSBEFORESTART) || (!imZiel))
			checkKollision();
		
		//Streckenposition ermitteln
		if ((*raceStatus != RSBEFORESTART) || (!imZiel))
			checkStreckenPos();
		
		//Wenn Computer, dann seine Aktionen berechnen 
		if (computer && (*raceStatus != RSBEFORESTART) && (!imZiel)) 
			driveComputer();
		
		FSOUND_SetFrequency(motorSoundBuffer,(long)(motorSoundFrequency+(40000)*(1-exp(-upsSchnitt/40))));
		FSOUND_SetVolume(motorSoundBuffer,(int)(100+(255-100)*(1-exp(-upsSchnitt))));
	
		float pos[3] = {position.x, 0.05f, position.y};
		float vel[3] = {geschwindigkeit.x, 0.0f, geschwindigkeit.y};
		FSOUND_3D_SetAttributes(motorSoundBuffer,pos,vel);
		
		if (rutscht)
		{
			if ((bremsSoundBuffer == -1) || (!FSOUND_IsPlaying(bremsSoundBuffer)))
			{
				bremsSoundBuffer = FSOUND_PlaySound(FSOUND_FREE, bremsSoundSample);
				FSOUND_SetPriority(bremsSoundBuffer,255);
			}
			if (FSOUND_IsPlaying(bremsSoundBuffer))
				FSOUND_3D_SetAttributes(bremsSoundBuffer,pos,vel);
		}
		else FSOUND_StopSound(bremsSoundBuffer);
		
		//add timer
		timer++;
		if (!beforeFirstStartZiel) clock += *fElapsedTime;
	}

	//make the transformation matrix
	D3DXMatrixTranslation( &mat1, position.x, 0.0f, position.y );
	D3DXMatrixMultiply( &mat1, matWorld, &mat1 );
	D3DXMatrixRotationY( &mat, (float)(atan2(richtung.x,richtung.y)+pi/2)); 
	D3DXMatrixMultiply( &mat, &mat, &mat1 );

	//update the bounding sphere
	bsM = bsMOriginal;
	bsM.x += position.x;
	bsM.z += position.y; 
	
	//update the cockpit
	if (!computer)
	{
		if (!cockpit->FrameMove(&(streckenPos->next->teil->position),upsSchnitt))
		{
			MessageBox(NULL,"Error: cockpit->FrameMove() (Auto::calcCockpit())",NULL,NULL);
			return false;
		}
	}
	return true;
}

bool Auto::Render(int checkValue)
{
	int j;
	bool check;

	if ((viewFrustum == NULL) || (viewFrustum->CullSphere(&bsM,&bsR) != SPHERE_AUSSERHALB))
	{
		d3dDevice->SetRenderState( D3DRS_SPECULARENABLE, TRUE );
		d3dDevice->SetTransform( D3DTS_WORLD, &mat);
		
		// Set diffuse blending for alpha set in vertices.
		d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
		d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
		d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
		d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
		d3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
		d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
		
		if (envTexNr != -1) d3dDevice->SetTexture( 1,textures->getTex(envTexNr));
		d3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR,D3DCOLOR_ARGB(50,0,0,0));
		d3dDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_BLENDFACTORALPHA);
		d3dDevice->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR );
		
		d3dDevice->SetTransform(D3DTS_TEXTURE1, &matEnv);
		d3dDevice->SetTextureStageState(1, D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_COUNT2);
		
		for( DWORD i=0; i<anzMat; i++ )
		{
			d3dDevice->SetMaterial( &materials[i]);
			if (texNr[i] != -1) d3dDevice->SetTexture( 0,textures->getTex(texNr[i]));
			
			if (FAILED(mesh->DrawSubset(i)))
			{
				MessageBox(NULL,"error: mesh->DrawSubset() (Auto::Render)",NULL,NULL);
				return false;
			}
		}
		
		// Restore state
		d3dDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE );
		d3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
		d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
		d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );
	}
	//Die R�der
	check = true;
	for (j=0;j<4;j++) check = check && autoRad[j]->Render();
	if (!check)
	{
		MessageBox(NULL,"error: rad->Render() (Auto::Render)",NULL,NULL);
		return false;
	}
	return true;
}

bool Auto::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	LPD3DXBUFFER pD3DXMtrlBuffer;
	D3DXMATERIAL* d3dxMaterials; 
	DWORD i;
	int j;
	char changeDir[MAXSTRING];
	bool check;
	D3DVERTEX3D2 *pVertices;	//Pointer to the object-vertices
	char buffer[MAXSTRING];
	char buffer2[MAXSTRING];

	//update d3dDevice
	d3dDevice = d3dDeviceSet;
		
	//change in the model-directory
	strcpy_s(changeDir,homeDir);
	strcat_s(changeDir,MODELSDIR);
	if (_chdir(changeDir) == -1) 
	{
		MessageBox(NULL,changeDir,NULL,NULL);
		return false;
	}

	//Jetzt Modell laden
	if (FAILED(D3DXLoadMeshFromX(xFile, D3DXMESH_MANAGED, 
		d3dDevice, NULL, 
		&pD3DXMtrlBuffer, &anzMat, 
		&mesh))) 
	{
		strcpy_s(buffer,"Can't open car model file ");
		strcat_s(buffer,xFile);
		strcat_s(buffer," in the directory ");
		_getcwd(buffer2,MAXSTRING);
		strcat_s(buffer,buffer2);
		MessageBox(NULL,buffer,NULL,NULL);
		return false;
	}
	
	d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	materials = new D3DMATERIAL8[anzMat];
	texNr	  = new int[anzMat];
	
	for(i=0; i<anzMat; i++ )
	{
		materials[i] = d3dxMaterials[i].MatD3D;
		materials[i].Ambient = materials[i].Diffuse;
		texNr[i] = textures->newTex(d3dDevice, d3dxMaterials[i].pTextureFilename);
	}
	SAFE_RELEASE(pD3DXMtrlBuffer);

	check = true;
	for (j=0;j<4;j++) check = check && autoRad[j]->InitDeviceObjects(d3dDevice);
	if (!check)
	{
		MessageBox(NULL,"error: rad->InitDeviceObjects() (Auto::InitDeviceObjects)",NULL,NULL);
		return false;
	}
	
	if ((!computer) && (!menue))
	{
		if (!cockpit->InitDeviceObjects(d3dDevice))
		{
			MessageBox(NULL,"Error: cockpit->InitDeviceObjects() (Auto::InitDeviceObjects)",NULL,NULL);
			return false;
		}
	}

	mesh->LockVertexBuffer(D3DLOCK_READONLY,(BYTE**)&pVertices);
	D3DXComputeBoundingSphere(pVertices,mesh->GetNumVertices(),D3DFVF_D3DVERTEX3D2,&bsMOriginal,&bsR);
	mesh->UnlockVertexBuffer();

	//make the enviroment mapping
	envTexNr = textures->newTex(d3dDevice, "himmel.dds");
	return true;
}

bool Auto::DeleteDeviceObjects()
{
	int i;

	//Auto l�schen
	SAFE_DELETE_ARRAY(materials);
	SAFE_DELETE_ARRAY(texNr);
	SAFE_RELEASE(mesh);
	anzMat = 0;
		
	for (i=0;i<4;i++) autoRad[i]->DeleteDeviceObjects();

	if ((!computer) && (!menue)) 
	{
		if (!cockpit->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: cockpit->DeleteDeviceObjects() (Auto::DeleteDeviceObjects())",NULL,NULL);
			return false;
		}
	}
	return true;
}

bool Auto::InvalidateDeviceObjects()
{
	if ((!computer) && (!menue)) 
	{
		if (!cockpit->InvalidateDeviceObjects())
		{
			MessageBox(NULL,"Error: Cockpit->InvalidateDeviceObjects()",NULL,NULL);
			return false;
		}
	}
	return true;
}

bool Auto::RestoreDeviceObjects()
{
	if ((!computer) && (!menue)) 
	{
		if (!cockpit->RestoreDeviceObjects())
		{
			MessageBox(NULL,"Error: cockpit->RestoreDeviceObjects()",NULL,NULL);
			return false;
		}
	}
	return true;
}

void Auto::setzeLenkRichtung(float Winkel, bool now)
{
	wunschLenkRichtung.y = (float)cos(Winkel);	//Winkel in Vektor mit L�nge=1 umrechnen
	
	if (wunschLenkRichtung.y < 0)
	{
		if (wunschLenkRichtung.x >= 0) wunschLenkRichtung.x = MAXLENKWINKEL;	
		if (wunschLenkRichtung.x < 0) wunschLenkRichtung.x =-MAXLENKWINKEL;
		wunschLenkRichtung.y = (float)sqrt(1-wunschLenkRichtung.x*wunschLenkRichtung.x);
	}
	else
	{
		wunschLenkRichtung.x = (float)sin(Winkel);
		if (wunschLenkRichtung.x > MAXLENKWINKEL) wunschLenkRichtung.x = MAXLENKWINKEL;	
		if (wunschLenkRichtung.x <-MAXLENKWINKEL) wunschLenkRichtung.x =-MAXLENKWINKEL;
		if (fabs(wunschLenkRichtung.x) > MAXLENKWINKEL) 
		{
			if (wunschLenkRichtung.x > 0) wunschLenkRichtung.x = MAXLENKWINKEL;	
			if (wunschLenkRichtung.x < 0) wunschLenkRichtung.x =-MAXLENKWINKEL;
			wunschLenkRichtung.y = (float)sqrt(1-wunschLenkRichtung.x*wunschLenkRichtung.x);
		}
	}
	if (now)
	{
		lenkRichtung.x = wunschLenkRichtung.x;
		lenkRichtung.y = wunschLenkRichtung.y;
	}
}

void Auto::setzeGasPedal(int newGasPedal, bool now)
{
	wunschGasPedal = (float)newGasPedal;
	if (wunschGasPedal > MAXAXIS) wunschGasPedal = MAXAXIS;	//Vollgas
	if (wunschGasPedal < 0) wunschGasPedal = 0;				//Leerlauf	
	if (now) gasPedal = wunschGasPedal;
}

void Auto::setzeBremsPedal(int newBremsPedal, bool now)
{
	wunschBremsPedal = (float)newBremsPedal;
	if (wunschBremsPedal > MAXAXIS) wunschBremsPedal = MAXAXIS;	//Vollbremsung
	if (wunschBremsPedal < 0) wunschBremsPedal = 0;				//bremst nicht
	if (now) bremsPedal = wunschBremsPedal;
}


void Auto::makeKollision(XYFloat stoss,bool relativ,XYFloat stossPos)
{
	int i;
	double entfBetr;
	XYFloat absPos;
	XYFloat entf;
	XYFloat resStoss;
	
	for (i=0;i<4;i++)				//jedes Rad anstossen
	{
		absPos = autoRad[i]->position;		//die Entfernung vom Stosspunkt zu diesem Rad errechnen
		entf.x = stossPos.x - absPos.x;
		entf.y = stossPos.y - absPos.y;
		entfBetr = (float)sqrt(entf.x*entf.x+entf.y*entf.y);
		
		resStoss.x = stoss.x*(float)exp(-entfBetr*10);	//je gr��er die Entfernung, desto kleiner der resultierende Stoss
		resStoss.y = stoss.y*(float)exp(-entfBetr*10);
		
		if (relativ) autoRad[i]->changeGeschwindigkeit(resStoss); //bei relativ zur bestehenden Geschwindkeit hinzuaddieren
		else autoRad[i]->setzeGeschwindigkeit(resStoss);			//sonst komplett die Geschwindigkeit ersetzen
	}
}

void Auto::checkKollision()
{
	int iSeiteEigen, kollNr;
	XYFloat sPunkt,sPunkt2,tmpg1Punkt0,tmpg1Punkt1,tmpg2Punkt0,tmpg2Punkt1,tmpGeschwindigkeit,g2Diff;
	XYFloat tmpg3Punkt0,tmpg3Punkt1,tmpg4Punkt0,tmpg4Punkt1;
	float alpha,beta,beta1,vBetrag,tmpvBetrag;

	if ((geschwindigkeit.x == 0) && (geschwindigkeit.y == 0)) return; //wenn sich das Auto nicht bewegt, dann auch keine Kollisionsabfrage

	tmpg3Punkt0 = position;
	tmpg3Punkt1.x = position.x + 10000*geschwindigkeit.x; //eine 'unendlich' lange Gerade vom Mittelpunkt des aus erzeugen
	tmpg3Punkt1.y = position.y + 10000*geschwindigkeit.y;

	vBetrag = (float)sqrt(geschwindigkeit.x*geschwindigkeit.x+geschwindigkeit.y*geschwindigkeit.y);
	if (vBetrag < 0.5f) vBetrag = 0.5f;

	for (iSeiteEigen=0;iSeiteEigen<=3;iSeiteEigen++)		//Jede Seite des Autos durchgehen und bei jeder Seite nach Kollisionen pr�fen
	{
		kList->getObject(kollisionsNr[iSeiteEigen],&tmpg1Punkt0,&tmpg1Punkt1);
		kList->setCheckLine(tmpg1Punkt0,tmpg1Punkt1);		//set a new test line to test
		kollNr = kList->checkKollision(&tmpg2Punkt0,&tmpg2Punkt1,&sPunkt,kollisionsNr,4,false);
		if (kollNr == -1) continue;			//no collision
	
		g2Diff.x = tmpg2Punkt1.x-tmpg2Punkt0.x;
		g2Diff.y = tmpg2Punkt1.y-tmpg2Punkt0.y;
		
		//Rausfinden, ob Bewegungsrichtung g�ltig zur Wand (wenn sich das Auto gar nicht zur Wand hin bewegt, dann auch keine Kollision)
		tmpg4Punkt0.x = tmpg2Punkt0.x-10000*g2Diff.x;	//eine 'unendlich'-lange Gerade schaffen
		tmpg4Punkt0.y = tmpg2Punkt0.y-10000*g2Diff.y;
		tmpg4Punkt1.x = tmpg2Punkt1.x+10000*g2Diff.x;
		tmpg4Punkt1.y = tmpg2Punkt1.y+10000*g2Diff.y;
		sPunkt2 = Schnittpunkt(tmpg3Punkt0,tmpg3Punkt1,tmpg4Punkt0,tmpg4Punkt1);
		if ((sPunkt2.x == -1) && (sPunkt2.y == -1))	continue;
	
		if ((kollNr/4 >= 1) && (kollNr/4 < MAXAUTOS+1))	//falls anderes Objekt = Auto, dann ansto�en 
		{
			//Differenzgeschwindigkeit der beiden Autos ausrechnen
			tmpGeschwindigkeit.x = -(allAutos[kollNr/4-1]->geschwindigkeit.x-geschwindigkeit.x);
			tmpGeschwindigkeit.y = -(allAutos[kollNr/4-1]->geschwindigkeit.y-geschwindigkeit.y);
			
			tmpvBetrag = GetBetrag(tmpGeschwindigkeit);
			if (tmpvBetrag < 0.5f) tmpvBetrag = 0.5f;
			
			//Winkel errechnen
			beta  = (float)atan2(-tmpGeschwindigkeit.y,tmpGeschwindigkeit.x);
			
			//andere Autos anstossen
			tmpGeschwindigkeit.x = (float)cos(beta)*tmpvBetrag;
			tmpGeschwindigkeit.y = (float)-sin(beta)*tmpvBetrag;
			allAutos[kollNr/4-1]->makeKollision(tmpGeschwindigkeit,true,sPunkt);
			
			//Spiegelvektor errechnen
			alpha = (float)atan2(-g2Diff.y,g2Diff.x);
			beta  = (float)atan2(-geschwindigkeit.y,geschwindigkeit.x);
			beta1 = 2*alpha-beta;
			
			//eigenes Auto anstossen
			tmpGeschwindigkeit.x = geschwindigkeit.x+(float)cos(beta1)*(tmpvBetrag);
			tmpGeschwindigkeit.y = geschwindigkeit.y+(-(float)sin(beta1)*(tmpvBetrag));
			makeKollision(tmpGeschwindigkeit,false,sPunkt);	
		}
		else 
		{
			//Spiegelvektor errechnen
			alpha = (float)atan2(-g2Diff.y,g2Diff.x);
			beta  = (float)atan2(-geschwindigkeit.y,geschwindigkeit.x);
			beta1 = 2*alpha-beta;
			
			//eigenes Auto anstossen
			tmpGeschwindigkeit.x = (float)cos(beta1)*vBetrag;
			tmpGeschwindigkeit.y = -(float)sin(beta1)*vBetrag;
			makeKollision(tmpGeschwindigkeit,false,sPunkt);	
		}
		//Play Crash-Sound
		float pos[3] = {sPunkt.x, 0.05f, sPunkt.y};
		float vel[3] = {0.0f, 0.0f, 0.0f};
		if ((crashSoundBuffer == -1) || (!FSOUND_IsPlaying(crashSoundBuffer)))
		{
			crashSoundBuffer = FSOUND_PlaySound(FSOUND_FREE, crashSoundSample);
			FSOUND_SetPriority(crashSoundBuffer,255);
		}
		if (FSOUND_IsPlaying(crashSoundBuffer))
			FSOUND_3D_SetAttributes(crashSoundBuffer,pos,vel);

		break;
	}
}

void Auto::checkStreckenPos()
{
	XYFloat wunschPos;
	int i;

	if (streckenPos == NULL) return; //Fehlerhafte Strecke -> raus;
	if (streckenPos->next == NULL) return;	//Fehlerhafte Strecke -> raus;

	wunschPos.x = streckenPos->next->teil->position.x;
	wunschPos.y = streckenPos->next->teil->position.z;
	if ((position.x > wunschPos.x-KIKORREKT) && (position.x < wunschPos.x+KACHELBREITE+KIKORREKT) &&
		(position.y > wunschPos.y-KIKORREKT) && (position.y < wunschPos.y+KACHELHOEHE+KIKORREKT))
	{
		streckenPos = streckenPos->next;
		lastOnRoad = clock;
		if (streckenPos == strecke->startZiel) startZielFlag = false;
	}
	wunschPos.x = streckenPos->teil->position.x;
	wunschPos.y = streckenPos->teil->position.z;
	if ((position.x > wunschPos.x-KIKORREKT) && (position.x < wunschPos.x+KACHELBREITE+KIKORREKT) &&
		(position.y > wunschPos.y-KIKORREKT) && (position.y < wunschPos.y+KACHELHOEHE+KIKORREKT))
	{
		
		if ((streckenPos ==  strecke->startZiel) &&//wenn start/ziel	
		    (!startZielFlag)) //und in dieser Runde noch nicht r�bergefahren
		{
			if (backOverStartZiel)		//wenn zuvor �ber Start/Ziel-Linie zur�ckgesetz, dann ignorieren
			{
				backOverStartZiel = false;
			}
			else						//normalfall
			{	
				if (!beforeFirstStartZiel) lastRundenZeit = clock-lastStartZielZeit;
				else clock = 0.0f;
				if ((lastRundenZeit < bestRundenZeit) && (lastRundenZeit != 0.0f)) 
					bestRundenZeit = lastRundenZeit;
				lastStartZielZeit = clock;
				runde++;
				if ((runde > anzRunden) || (*raceStatus == RSLASTROUND)) 
				{
					for (i=0;i<MAXAUTOS;i++)
					{
						if (!allAutos[i]->computer)
							allAutos[i]->cockpit->newImZiel(anzRunden-runde+1,clock,bestRundenZeit,name);
					}
					imZiel = true;
				}
				if (beforeFirstStartZiel) beforeFirstStartZiel = false;
			}
			startZielFlag = true;
		}
	}
	
	//find the number of the act. Kachel
	RouteNode* tmpPos = strecke->startZiel;
	i=0;
	while (tmpPos != streckenPos) 
	{
		i++;
		tmpPos = tmpPos->next;
	}
	//calculate the comparable value of the position
	refPos[indexNr] = runde*1000+i;
}

void Auto::driveComputer()
{
	struct XYSpecial
	{
		XYFloat p;
		int dirx,diry;		//in which half of a quad do the correction?
	};

	XYFloat tmpPunkt,tmpPunkt2,tmpPunkt3;
	XYSpecial ziel;
	float tmpWinkel1,tmpWinkel2,tmpWinkel3;
	XYFloat zielDiff;
	float vBetrag,aktAbstand,bestAbstand = 100000;
	XYSpecial quad[4];
	XYFloat	corrVector;	//In the direction do the correction
	XYFloat sPunkt;
	int i,bestEcke;
		
	//Wenn keine Strecke vorhanden ist, dann auch kein Computergegner
	if (streckenPos == NULL) return; //Fehlerhafte Strecke -> raus;
	if (streckenPos->next == NULL) return;	//Fehlerhafte Strecke -> raus;
	if (streckenPos->next->next == NULL) return;	//Fehlerhafte Strecke -> raus;

	//Schon zulange ohne Streckenkontakt unterwegs? Dann zur�ck auf Strecke setzen
	if ((clock-lastOnRoad) > 10.0f) reset();

	vBetrag = (float)sqrt(geschwindigkeit.x*geschwindigkeit.x+geschwindigkeit.y*geschwindigkeit.y);

	//N�chstes Etappenziel ermitteln
	tmpPunkt.x = streckenPos->next->next->teil->position.x;	//die Mitte der �bern�chsten Kachel
	tmpPunkt.y = streckenPos->next->next->teil->position.z;
	ziel.p.x = tmpPunkt.x+KACHELBREITE/2;
	ziel.p.y = tmpPunkt.y+KACHELBREITE/2;
	ziel.dirx = -2;			//ist wurscht in welche Richtung
	ziel.diry = -2;

	//Geht der Weg zum Ziel nicht durch die n�chste Kachel?
	tmpPunkt.x = streckenPos->next->teil->position.x;
	tmpPunkt.y = streckenPos->next->teil->position.z;
	quad[0].p.x = tmpPunkt.x+KIKORREKT;			//Die Eckpunkte erstellen
	quad[0].p.y = tmpPunkt.y+KIKORREKT;
	quad[0].dirx = +1;
	quad[0].diry = +1;
	quad[1].p.x = tmpPunkt.x+KACHELBREITE-KIKORREKT;
	quad[1].p.y = tmpPunkt.y+KIKORREKT;
	quad[1].dirx = -1;
	quad[1].diry = +1;
	quad[2].p.x = tmpPunkt.x+KACHELBREITE-KIKORREKT;
	quad[2].p.y = tmpPunkt.y+KACHELHOEHE-KIKORREKT;
	quad[2].dirx = -1;
	quad[2].diry = -1;
	quad[3].p.x = tmpPunkt.x+KIKORREKT;
	quad[3].p.y = tmpPunkt.y+KACHELHOEHE-KIKORREKT;
	quad[3].dirx = +1;
	quad[3].diry = -1;
	sPunkt = Schnittpunkt(position,ziel.p,quad[0].p,quad[1].p);
	if ((sPunkt.x == -1) && (sPunkt.y == -1))
	{
		sPunkt = Schnittpunkt(position,ziel.p,quad[1].p,quad[2].p);
		if ((sPunkt.x == -1) && (sPunkt.y == -1))
		{
			sPunkt = Schnittpunkt(position,ziel.p,quad[2].p,quad[3].p);
			if ((sPunkt.x == -1) && (sPunkt.y == -1))
			{
				sPunkt = Schnittpunkt(position,ziel.p,quad[3].p,quad[0].p);
				if ((sPunkt.x == -1) && (sPunkt.y == -1))
				{
					for (i=0;i<4;i++)		//Ecke mit dem geringsten Abstand finden
					{
						aktAbstand = GPAbstand(position,ziel.p,quad[i].p);
						if (aktAbstand < bestAbstand)
						{
							bestAbstand = aktAbstand;
							bestEcke = i;
						}
					}
					ziel.p.x = quad[bestEcke].p.x;
					ziel.p.y = quad[bestEcke].p.y;
					ziel.dirx = quad[bestEcke].dirx;
					ziel.diry = quad[bestEcke].diry;
				}
			}
		}
	}

//	if (*debug && (indexNr == 1)) testLine->drawLine(16,position,ziel.p);
	
	for (i=0;i<10;i++)		//make max. 10 correction
	{
		//is there a obstacle in way? (check left and right side of car)
		kList->setCheckLine(autoRad[2]->position,ziel.p); //set new testLine
		if (kList->checkKollision(&tmpPunkt,&tmpPunkt2,&tmpPunkt3,kollisionsNr,4,true) == -1) 
		{	
			kList->setCheckLine(autoRad[3]->position,ziel.p); //set new testLine
			if (kList->checkKollision(&tmpPunkt,&tmpPunkt2,&tmpPunkt3,kollisionsNr,4,true) == -1) 
				break; //no kollision
		}
		if (i==0)	//only the first time
		{
			//Differenz zum Ziel ermitteln
			zielDiff.x = ziel.p.x - position.x;
			zielDiff.y = ziel.p.y - position.y;
			//Calculate in which direction do the correction
			corrVector = GetSenkrecht(zielDiff);
			//Point the vector in the wrong direction?
			if ((corrVector.x*ziel.dirx < 0) || (corrVector.y*ziel.diry < 0))
			{
				corrVector.x = -corrVector.x;	//Switch the vector
				corrVector.y = -corrVector.y;
			}
		}
		else if (ziel.dirx == -2)
		{
			corrVector.x = -i*corrVector.x;	//Switch the vector
			corrVector.y = -i*corrVector.y;
		}
		//change the ziel
		ziel.p.x += corrVector.x*KIKORREKT;
		ziel.p.y += corrVector.y*KIKORREKT;
	}
	//Differenz zum Ziel ermitteln
	zielDiff.x = ziel.p.x - position.x;
	zielDiff.y = ziel.p.y - position.y;

//	if ((*debug && indexNr == 1)) testLine->drawLine(15,position,ziel.p);

	//beide Winkel ermitteln und differenz ausrechnen
	tmpWinkel1 = (float)atan2(-zielDiff.y,zielDiff.x);
	if (((zielDiff.x < 0) && (zielDiff.y > 0)) ||
		((zielDiff.x > 0) && (zielDiff.y > 0))) tmpWinkel1 += 2*(float)pi;

	tmpWinkel2 = (float)atan2(-richtung.y,richtung.x);
	if ((richtung.x < 0) && (richtung.y > 0)) tmpWinkel2 += 2*(float)pi;

	tmpWinkel3 = tmpWinkel1-tmpWinkel2;
	if (tmpWinkel3 > pi) tmpWinkel3 -= 2*(float)pi;

	//Lenkrichtung bestimmen
	setzeLenkRichtung(-tmpWinkel3,true);

	//Bei zu starker Winkelabweichung: runter vom Gas
	if (((tmpWinkel3 > pi/5) || (tmpWinkel3 < -pi/5)) && (vBetrag > 0.6f)) 
	{
		setzeGasPedal(0,true);
		setzeBremsPedal(0,true);
	}
	else 
	{
		setzeGasPedal(MAXAXIS,true);//sonst Vollgas
		setzeBremsPedal(0,true);
	}
}

void Auto::setze(float x, float y, XYFloat newRichtung)
{
	XYFloat tmpRichtung,neuRadPos[4],tmp;
	int i;

	richtung = newRichtung;
	position.x = x;
	position.y = y;
	tmpRichtung.x = richtung.y;			//vektor erzeugen, der senkrecht auf dem anderen steht
	tmpRichtung.y = -richtung.x;
	neuRadPos[0].x = x+richtung.x*radAbstLaenge+tmpRichtung.x*radAbstBreite;
	neuRadPos[0].y = y+richtung.y*radAbstLaenge+tmpRichtung.y*radAbstBreite;
	neuRadPos[1].x = x+richtung.x*radAbstLaenge-tmpRichtung.x*radAbstBreite;
	neuRadPos[1].y = y+richtung.y*radAbstLaenge-tmpRichtung.y*radAbstBreite;
	neuRadPos[2].x = x-richtung.x*radAbstLaenge+tmpRichtung.x*radAbstBreite;
	neuRadPos[2].y = y-richtung.y*radAbstLaenge+tmpRichtung.y*radAbstBreite;
	neuRadPos[3].x = x-richtung.x*radAbstLaenge-tmpRichtung.x*radAbstBreite;
	neuRadPos[3].y = y-richtung.y*radAbstLaenge-tmpRichtung.y*radAbstBreite;

	tmp.x = 0;
	tmp.y = 0;
	for (i=0;i<4;i++) 
	{
		autoRad[i]->setzePosition(neuRadPos[i],false);
		autoRad[i]->ups = 0;
		autoRad[i]->setzeGeschwindigkeit(tmp);
	}
}

void Auto::reset()
{
	RouteNode* checkPos = streckenPos;
	XYFloat newRichtung;
	POINT tmpPos1,tmpPos2;
	XYFloat newPosition;
	int vonWo,i;
	float sinPiViertel = (float)sin(pi/4);
	
	while(1)
	{
		if ((checkPos == NULL) || (checkPos->next == NULL)) break; //fehlerhafter Strecke raus
		
		if (checkPos->next == streckenPos)		//das Feld vor dem aktuellem gefunden
		{
			streckenPos = checkPos;	//das aktuelle ist jetzt das davor
			
			//wie ist die aktuelle Kachel gerichtet (nicht gut gel�st)
			tmpPos1 = checkPos->pos;
			tmpPos2 = checkPos->next->pos;
			if (tmpPos1.x > tmpPos2.x) i = 3;
			else if (tmpPos1.x < tmpPos2.x) i = 1;
			else if (tmpPos1.y > tmpPos2.y) i = 0;
			else i = 2;
			vonWo = checkPos->teil->getWay(i);

			newRichtung.x = 1;
			newRichtung.y = 0;
			//neue Richtung rausfinden
			switch(i)
			{
			case 0:
				switch (vonWo)
				{
				case 1:
					newRichtung.x = -sinPiViertel;
					newRichtung.y = -sinPiViertel;
					break;
				case 2:
					newRichtung.x = 0;
					newRichtung.y = -1;
					break;
				case 3:
					newRichtung.x = +sinPiViertel;
					newRichtung.y = -sinPiViertel;
					break;
				}
				break;
			case 1:
				switch (vonWo)
				{
				case 0:
					newRichtung.x = +sinPiViertel;
					newRichtung.y = +sinPiViertel;
					break;
				case 2:
					newRichtung.x = +sinPiViertel;
					newRichtung.y = -sinPiViertel;
					break;
				case 3:
					newRichtung.x = 1;
					newRichtung.y = 0;
					break;
				}
				break;
			case 2:
				switch (vonWo)
				{
				case 0:
					newRichtung.x = 0;
					newRichtung.y = 1;
					break;
				case 1:
					newRichtung.x = -sinPiViertel;
					newRichtung.y = +sinPiViertel;
					break;
				case 3:
					newRichtung.x = +sinPiViertel;
					newRichtung.y = +sinPiViertel;
					break;
				}
				break;
			case 3:
				switch (vonWo)
				{
				case 0:
					newRichtung.x = -sinPiViertel;
					newRichtung.y = +sinPiViertel;
					break;
				case 1:
					newRichtung.x = -1;
					newRichtung.y = 0;
					break;
				case 2:
					newRichtung.x = -sinPiViertel;
					newRichtung.y = -sinPiViertel;
					break;
				}
				break;
			}

			newPosition.x = streckenPos->teil->position.x;
			newPosition.y = streckenPos->teil->position.z;
			setze(newPosition.x+KACHELBREITE/2,newPosition.y+KACHELBREITE/2,newRichtung);

			//wurde �ber die StartZiel-Linie zur�ckgesetzt?
			if (((streckenPos == strecke->startZiel) || (streckenPos->next == strecke->startZiel)) &&
				(startZielFlag)) backOverStartZiel = true;
			break;
		}
		checkPos = checkPos->next;
	}
	lastOnRoad = clock;
}

