//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_AUTO)
#define N_AUTO

#include "rad.h"
#include "kollisionlist.h"
#include "karte.h"
#include "textures.h"
#include "testtext.h"
#include "testline.h"
#include "cockpit.h"
#include "smoke.h"
#include "viewfrustum.h"

class Auto
{
public: 
	Auto(D3DXMATRIX      *matWorldSet,		
		 D3DXVECTOR3	 *vEyePtSet,
		 D3DXVECTOR3	 *vLookatPtSet,
		 FLOAT           *fElapsedTimeSet,
		 Textures		 *texturesSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 TestLine		 *testLineSet,
		 Smoke			 *smokeSet,
		 int			 *raceStatusSet,
		 int			 *refPosSet,
		 bool			  menueSet,
		 int			  startNrSet,
		 int			  indexNrSet,
		 KollisionList   *kL, 
		 Auto			 **allA, 
		 Karte			 *streckeSet, 
		 bool			  comp,
		 int			  art,
		 int			  anzRundenSet,
		 D3DVIEWPORT8	  *viewPort,
		 char			 *nameSet,
		 bool			 *debugSet,
		 CViewFrustum	 *viewFrustumSet);			
	~Auto();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool DeleteDeviceObjects();
	bool InvalidateDeviceObjects();
	bool RestoreDeviceObjects();
    bool Render(int checkValue);
    bool FrameMove();
	void update(float t);								//berechnet den aktuellen Zustand des Autos (l�sst das Auto fahren)
	void setzeLenkRichtung(float Winkel, bool now);		//Setzt das Lenkrad in eine bestimmte Richtung
	void setzeGasPedal(int newGasPedal, bool now);		//setzt das Gaspedal auf eine bestimmte Stellung
	void setzeBremsPedal(int newBremsPedal, bool now);	//setzt das Bremspedal auf eine bestimmte Stellung 
	void makeKollision(XYFloat stoss, bool relativ, XYFloat stossPos); //Schuckt das Auto mit einem bestimmten Stossvektor an einem bestimmten Punkt an
	void checkKollision();								//pr�ft, ob Auto mit einem Objekt auf der Karte kollidiert ist
	void checkStreckenPos();							//pr�ft, ob Auto auf der Strecke ist und n�chstes Streckenst�ck erreicht hat
	void driveComputer();								//berechnet die Aktionen des Computers
	void setze(float x, float y, XYFloat newRichtung);	//setzt das Auto an eine bestimmte Stelle mit einer bestimmten Richtung
	void reset();										//setzt das Auto zur�ck auf die Strecke
	int kollisionsNr[4];								//dort sind die 4 KollisionsNummer der 4 Seiten des Autos gespeichert (wo sie in der kollisionlist gespeichert sind)

	XYFloat position;			//Position der Mitte des Autos
	XYFloat richtung;			//Richtungsvektor f�rs Auto (L�nge immer =1)
	float	gasPedal;			//Wie weit ist das Gaspedal gedr�ckt 
	float	bremsPedal;			//Wie weit ist das Bemspedal gedr�ckt
	RouteNode* streckenPos;		//Pointer zu dem Streckenknoten, dass das Auto als letztes richtig passiert hat
	XYFloat geschwindigkeit;	//Geschwindigkeitsvektor 			
	bool	reverse;			//reverse controll

	Cockpit	*cockpit;			//the cockpit
	bool	imZiel;				//is the car in ziel
	
private:
	D3DXMATRIX      *matWorld;
	D3DXVECTOR3		*vEyePt;
	D3DXVECTOR3		*vLookatPt;
    FLOAT           *fElapsedTime;
	Textures		*textures;
	char			*homeDir;
	TestText		*testText;
	TestLine		*testLine;
	IDirect3DDevice8 *d3dDevice;
	Karte			*strecke;
	int				*raceStatus;
	int				*refPos;	//the comparable positions of all cars
	char			*name;
	bool			*debug;
	CViewFrustum	*viewFrustum;

	float laenge,breite;		//Die Breite und L�nge des Autos
	char xFile[MAXSTRING];		//Den Namen der Modelldatei
	float radAbstLaenge,radAbstBreite;	//Die Verschiebung der R�der vom Mittelpunkt
	float power;				//the power of the car
	float brakePower;			//the brake power of the car
	float airPower;				//the power of the air against the car

	float wunschGasPedal;		//Soweit soll es gedr�ckt sein
	float wunschBremsPedal;		//Soweit soll das Bremspedal gedr�ckt sein
	XYFloat lenkRichtung;		//Richtungsvektor relativ zu 'richtung' (L�nge immer =1)
	XYFloat wunschLenkRichtung;	//So soll die Lenkrichtung sein
	Rad *autoRad[4];			//Die viel Radobjekte des Autos

	KollisionList *kList;		//Pointer zum KollisionList-Objekt (um rauszufinden, wo W�nde sind)
	Auto **allAutos;			//Pointer zum Feld, wo alle Auto-Objekte drin sind (um z.B. Kollisionen an andere Autos weiterzugeben) 
	int  startNr;				//Startnummer des Auto (alle fahrenden Autos sind durchnummeriert)
	int	 indexNr;				//which index in the allAutos-List?
	bool computer;				//true, wenn das Auto vom Computer gesteuert wird
	float	lastRundenZeit;		//die letzte Rundenzeit in Sekunden
	float	bestRundenZeit;		//the best driven round
	float	lastStartZielZeit;	//letzte Uhrzeit, an der das Auto Start/Ziel passiert hat
	bool	startZielFlag;		//startZiel, in der aktuellen Runde schon durchfahren?
	int		runde;				//In welcher Runde ist das Auto
	int		anzRunden;			//How many rounds to drive
	float	clock;				//add fElapsedTime each frame
	float lastOnRoad;			//letzte Uhrzeit, an der das Auto richtig auf der Strecke war (um den Computer nach bestimmter Zeit automatisch zur�ckzusetzen)
	bool backOverStartZiel;		//true, wenn �ber die StartZiel-Linie zur�ckgesetzt wurde
	bool beforeFirstStartZiel;	//after the start, but before the startZiel-Line
	
	LPD3DXMESH				mesh;			// Das Drahtgittermodell
	DWORD					anzMat;			// Anzahl der Materiale bei diesem Objekt
	D3DMATERIAL8*           materials;		// Die Materialien
	int						*texNr;			// die Texturen
	D3DXMATRIX				mat;			// the transformation matrix
	D3DXMATRIX				matEnv;			// the transformation matrix (enviroment mapping)
	int envTexNr;				//the enviroment texture

	D3DXVECTOR3		bsMOriginal;//the bounding-sphere-middle of the unmoved object
	D3DXVECTOR3		bsM;		//the bounding-sphere-middle
	float			bsR;		//the bounding-sphere-radius

	bool menue;					//show the car in menue?
	float menueRotation;		//in which direction look the car

	int timer;					//some elements need a timer (its ++ each frame)

	FSOUND_SAMPLE	*motorSoundSample;		//Pointer to the motor Sound Sample
	int				motorSoundBuffer;		//in this buffer is the motor sound
	int				motorSoundFrequency;	//The standard-frequency of the motor sound
	FSOUND_SAMPLE	*bremsSoundSample;		//Pointer to the brems Sound Sample
	int				bremsSoundBuffer;		//in this buffer is the brems sound
	FSOUND_SAMPLE	*crashSoundSample;		//Pointer to the crash Sound Sample
	int				crashSoundBuffer;		//in this buffer is the crash sound
};

#endif