//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "cockpit.h"
#include "helpfunctions.h"

Cockpit::Cockpit(D3DXMATRIX *matWorldSet,
				Textures	*texturesSet,
				char		*homeDirSet,
				TestText	*testTextSet,
				FLOAT       *fElapsedTimeSet,
				char		*camFile,
				XYFloat		*positionSet,
				XYFloat		*richtungSet,
				int			*raceStatusSet,
				D3DXVECTOR3	*vEyePtSet,
				D3DXVECTOR3 *vLookatPtSet,
				float		*clockSet,
				float		*lastStartZielZeitSet,
				float		*lastRundenZeitSet,
				float		*bestRundenZeitSet,
				int			*rundeSet,
				int			*anzRundenSet,
				int			*refPosSet,
				int			*indexNrSet,
				D3DVIEWPORT8 *viewPortSet,
				bool		enableSoundSet,
				char		*nameSet,
				CViewFrustum *viewFrustumSet)
{
	std::ifstream	file;
	char		buffer[MAXSTRING];

	matWorld			= matWorldSet;
	textures			= texturesSet;
	homeDir				= homeDirSet;
	testText			= testTextSet;
	position			= positionSet;
	richtung			= richtungSet;
	raceStatus			= raceStatusSet;
	vEyePt				= vEyePtSet;
	vLookatPt			= vLookatPtSet;
	fElapsedTime		= fElapsedTimeSet,
	clock				= clockSet;
	lastStartZielZeit	= lastStartZielZeitSet;
	lastRundenZeit		= lastRundenZeitSet;
	bestRundenZeit		= bestRundenZeitSet;
	runde				= rundeSet;
	anzRunden			= anzRundenSet;
	refPos				= refPosSet;
	indexNr				= indexNrSet;
	viewPort			= viewPortSet;
	enableSound			= enableSoundSet;
	name				= nameSet;
	viewFrustum			= viewFrustumSet;
	
	pfeilMesh		= NULL;
	pfeilAnzMat		= 0;
	pfeilMaterials	= NULL;
	pfeilTexNr		= NULL;

	aktCam = 0;		//take the first cam..

	//change in the home-directory
	if (_chdir(homeDir) == -1) 
	{
		MessageBox(NULL,homeDir,NULL,NULL);
		return;
	}

	file.open(camFile,std::ios::in);
	if (!file.is_open())
	{
		MessageBox(NULL,"Can't open the Camera File",NULL,NULL);
		return;
	}
	anzCams = 0;
	while(file.getline(camList[anzCams].name,MAXSTRING))
	{
		if (anzCams >= MAXCAMS)
		{
			MessageBox(NULL,"Too many different cameras",NULL,NULL);
			break;
		}
		file >> camList[anzCams].pos.x; file.get();
		file >> camList[anzCams].pos.z; file.get();
		file >> camList[anzCams].pos.y; file.getline(buffer,MAXSTRING);
		file >> camList[anzCams].lookTo.x; file.get();
		file >> camList[anzCams].lookTo.z; file.get();
		file >> camList[anzCams].lookTo.y; file.getline(buffer,MAXSTRING);
		if (file.get() == 'y') camList[anzCams].fest = true;
		else camList[anzCams].fest = false;
		file.getline(buffer,MAXSTRING);
		anzCams++;
	}
	file.close();

	checkTime = (float)SECONDSTOSTART;

	//make the font-object
	font = new CD3DFont((char*)FONTNAME, 25);
	angle = 0;

	anzImZiel = 0;

	FSOUND_3D_SetDistanceFactor((float)KACHELEINHEIT);

	fontBackVB = NULL;
	tachoVB = NULL;
	nadelVB = NULL;
}

Cockpit::~Cockpit()
{
	InvalidateDeviceObjects();
    DeleteDeviceObjects();
}

bool Cockpit::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	LPD3DXBUFFER pD3DXMtrlBuffer;
	D3DXMATERIAL* d3dxMaterials; 
	DWORD i;
	char changeDir[MAXSTRING];
	HRESULT hr;

	d3dDevice = d3dDeviceSet;	//update the d3dDevice

	//init the font-object
	hr = font->InitDeviceObjects(d3dDevice);
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	//set the font materials
	ZeroMemory(&fontMat, sizeof(D3DMATERIAL8));
	fontMat.Ambient.r = 0.5f;
    fontMat.Ambient.g = 0.5f;
    fontMat.Ambient.b = 1.0f;
	fontMat.Ambient.a = 0.8f;
	fontMat.Diffuse.a = 0.8f;

	//now load the arrow
	//change in the model-directory
	strcpy_s(changeDir,homeDir);
	strcat_s(changeDir,MODELSDIR);
	if (_chdir(changeDir) == -1) 
	{
		MessageBox(NULL,changeDir,NULL,NULL);
		return false;
	}

	//Jetzt Modell des Pfeils laden
	if (FAILED(D3DXLoadMeshFromX("pfeil.x", D3DXMESH_MANAGED, 
		d3dDevice, NULL, &pD3DXMtrlBuffer, &pfeilAnzMat, 
		&pfeilMesh)))
	{
		MessageBox(NULL,"Can't load pfeil model",NULL,NULL);
		return false;
	}
	
	d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	pfeilMaterials = new D3DMATERIAL8[pfeilAnzMat];
	pfeilTexNr  = new int[pfeilAnzMat];
	
	for( i=0; i<pfeilAnzMat; i++ )
	{
		pfeilMaterials[i] = d3dxMaterials[i].MatD3D;
		pfeilMaterials[i].Ambient.r = pfeilMaterials[i].Diffuse.r-0.2f;
		pfeilMaterials[i].Ambient.g = pfeilMaterials[i].Diffuse.g-0.2f;
		pfeilMaterials[i].Ambient.b = pfeilMaterials[i].Diffuse.b-0.2f;
		pfeilTexNr[i] = textures->newTex(d3dDevice,d3dxMaterials[i].pTextureFilename); 
	}
	SAFE_RELEASE(pD3DXMtrlBuffer);

	//tacho stuff
	tachoTexNr = textures->newTex(d3dDevice,"stuff.tga");
	nadelTexNr = textures->newTex(d3dDevice,"stuff.tga"); //Doppeltgemoppelt, aber konsequent

	return true;
}

bool Cockpit::updateView(D3DXMATRIX *matProj)
{
	if (FAILED(d3dDevice->SetTransform(D3DTS_VIEW,&matView)))
	{
		MessageBox(NULL,"Error: d3dDevice->SetTransform() (Cockpit::FrameMove())",NULL,NULL);
		return false;
	}
	viewFrustum->ExtractPlanes(&matView,matProj);
	
	return true;
}

bool Cockpit::FrameMove(D3DXVECTOR3 *newZiel,float upsSchnitt)
{
	int i;
	float moveFaktor;
	D3DXVECTOR3		eyePtAlt;			//The last eyePt (to calculate the speed)

	D3DXMATRIX mat1,mat2,viewMatrixI;
	D3DXVECTOR3	arrowVec,EyeToLookAtVec,earSpeed;
	D3DXVECTOR4 vTransVec;
	D3DXVECTOR3 vNewVec;
	D3DXVECTOR3 carZiel;
	HRESULT hr;
	XYFloat tmpPunkt;

	eyePtAlt.x = vEyePt->x;
	eyePtAlt.y = vEyePt->y;
	eyePtAlt.z = vEyePt->z;
	
	//set the camera position
	if (*raceStatus == RSBEFORESTART) 
	{
		//init the start-position
		if (checkTime >= (float)SECONDSTOSTART)
		{
			vEyePt->x = position->x+
				(camList[aktCam].pos.x-2.0f)*richtung->y+
				(camList[aktCam].pos.z-4.0f)*richtung->x;
			vEyePt->y = camList[aktCam].pos.y+1.0f;
			vEyePt->z = position->y-
				(camList[aktCam].pos.x-2.0f)*richtung->x+
				(camList[aktCam].pos.z-4.0f)*richtung->y;
			vLookatPt->x = position->x+
				camList[aktCam].lookTo.x*richtung->y+
				camList[aktCam].lookTo.z*richtung->x;
			vLookatPt->y = camList[aktCam].lookTo.y;
			vLookatPt->z = position->y-
				camList[aktCam].lookTo.x*richtung->x+
				camList[aktCam].lookTo.z*richtung->y;
		}
		//Calculate the time until start
		checkTime -= *fElapsedTime;
		moveFaktor = checkTime/(*fElapsedTime);
	}
	else if (*raceStatus == RSAFTERZIEL)
	{
		checkTime += *fElapsedTime;
		vEyePt->x = position->x+(float)sin(checkTime)*0.5f;
		vEyePt->y = 0.25f;
		vEyePt->z = position->y+(float)cos(checkTime)*0.5f;
		vLookatPt->x = position->x;
		vLookatPt->y = 0.0f;
		vLookatPt->z = position->y;
	}
	else
	{
		if (*raceStatus == RSLASTROUND) checkTime -= *fElapsedTime;
		if (camList[aktCam].fest) moveFaktor = 0.0f;
		else moveFaktor = 0.1f/(*fElapsedTime);
	}
	
	if (*raceStatus != RSAFTERZIEL)
	{
		vEyePt->x = (position->x+
			camList[aktCam].pos.x*richtung->y+
			camList[aktCam].pos.z*richtung->x+
			vEyePt->x*moveFaktor)/(moveFaktor+1);
		vEyePt->y = (camList[aktCam].pos.y+
			vEyePt->y*moveFaktor)/(moveFaktor+1);
		vEyePt->z = (position->y-
			camList[aktCam].pos.x*richtung->x+
			camList[aktCam].pos.z*richtung->y+
			vEyePt->z*moveFaktor)/(moveFaktor+1);
		vLookatPt->x = (position->x+
			camList[aktCam].lookTo.x*richtung->y+
			camList[aktCam].lookTo.z*richtung->x+
			vLookatPt->x*moveFaktor)/(moveFaktor+1);
		vLookatPt->y = (camList[aktCam].lookTo.y+
			vLookatPt->y*moveFaktor)/(moveFaktor+1);
		vLookatPt->z = (position->y-
			camList[aktCam].lookTo.x*richtung->x+
			camList[aktCam].lookTo.z*richtung->y+
			vLookatPt->z*moveFaktor)/(moveFaktor+1);
	}
	D3DXMatrixLookAtLH(&matView, vEyePt, vLookatPt, &D3DXVECTOR3(0.0f,1.0f,0.0f));

///////////////////////////////////////////////////////
	D3DXMatrixInverse(&viewMatrixI,NULL,&matView);
	D3DXVec3Subtract(&EyeToLookAtVec,vLookatPt,vEyePt);
	//Calculate the font-matrix (the special font)
	if (*raceStatus == RSBEFORESTART)
	{
		//Verschiebungsmatrix erstellen
		vNewVec.x = 0.0f;
		vNewVec.y = 0.0f;
		vNewVec.z = 0.1f;
		
		D3DXVec3Transform(&vTransVec,&vNewVec,&viewMatrixI);
		D3DXMatrixTranslation( &mat2, vTransVec.x, vTransVec.y, vTransVec.z);
		//Verschiebungsmatrix mit Weltmatrix multipilizieren
		D3DXMatrixMultiply( &mat2, matWorld, &mat2 );
		//Rotationmatrizen erstellen und zur Transformationsmatrix hinzuf�gen
		GetRotationMatrixToVector(&mat2,&EyeToLookAtVec);
		//Scale font to the right size (the two special fonts)
		D3DXMatrixScaling(&mat1,0.01f,0.01f,0.01f);
		D3DXMatrixMultiply( &matFont, &mat1, &mat2 );
		//Rotate font
		angle = -pi/2+(checkTime-(int)(checkTime))*pi;
		D3DXMatrixRotationY(&mat1,angle);
		D3DXMatrixMultiply( &matFont, &mat1, &matFont );
	}
	if ((*raceStatus == RSLASTROUND) || (*raceStatus == RSINRACE))
	{
		//Calculate the arrow
		carZiel.x = newZiel->x+KACHELBREITE/2;
		carZiel.y = 0;
		carZiel.z = newZiel->z+KACHELHOEHE/2;
		D3DXVec3Subtract(&arrowVec,&carZiel,vEyePt);
		//Verschiebungsmatrix erstellen
		vNewVec.x = 0.04f;
		vNewVec.y = -0.03f;
		vNewVec.z = 0.1f;
		D3DXVec3Transform(&vTransVec,&vNewVec,&viewMatrixI);
		D3DXMatrixTranslation( &pfeilMat, vTransVec.x, vTransVec.y, vTransVec.z);
		//Verschiebungsmatrix mit Weltmatrix multipilizieren
		D3DXMatrixMultiply( &pfeilMat, matWorld, &pfeilMat );
		//Rotationmatrizen erstellen und zur Transformationsmatrix hinzuf�gen
		GetRotationMatrixToVector(&pfeilMat,&arrowVec);
	}
	
	//Update the ear
	if (enableSound)		//Play only the sound for one player
	{
		//Calculate the speed of the ear
		D3DXVec3Subtract(&earSpeed,vEyePt,&eyePtAlt);
		earSpeed /= *fElapsedTime;
		float pos[3] = {vEyePt->x,vEyePt->y,vEyePt->z};
		float vel[3] = {earSpeed.x,earSpeed.y,earSpeed.z};
		
		FSOUND_3D_Listener_SetAttributes(pos,vel,
			EyeToLookAtVec.x,EyeToLookAtVec.y,EyeToLookAtVec.z,
			0.0f,1.0f,0.0f);
		//make the changes
		FSOUND_Update();
	}
	//calculate the tacho stuff
	D3DVERTEX2D		*pVertices;
	//the tachopointer (Tachonadel)
	D3DVERTEX2D	vertices2[4] =
	{
		{0.008f,	(TACHOWIDTH/2-0.02f),	0.0f, 10.0f,  0.16f, 0.036f},
		{-0.008f,	(TACHOWIDTH/2-0.02f),	0.0f, 10.0f,  0.16f, 0.0f},	//x y z w tx ty
		{0.008f,	-0.01f,					0.0f, 10.0f,  0.5f,	0.036f},
		{-0.008f,	-0.01f,					0.0f, 10.0f,  0.5f,	0.0f},
	};
	//Rotate and move the pointer
	if (upsSchnitt >= 40.0f) upsSchnitt = 40.0f;	//Not more the 40UpS
	float rotateAngle = 0.8f+(5.48f-0.8f)/40.0f*upsSchnitt; //0.8f is the min angle,5.48 is the max
	for (i=0;i<4;i++)
	{
		tmpPunkt.x = vertices2[i].x;
		tmpPunkt.y = vertices2[i].y;
		tmpPunkt = PointRotate(tmpPunkt, rotateAngle);		//rotate
		vertices2[i].x = tmpPunkt.x;
		vertices2[i].y = tmpPunkt.y;
		vertices2[i].x = vertices2[i].x+TACHOWIDTH/2;		//move
		vertices2[i].x *= viewPort->Height;					//bring it to screen coordinates
		vertices2[i].x += viewPort->X;
		vertices2[i].y = vertices2[i].y+1.0f-TACHOWIDTH/2;	//move
		vertices2[i].y *= viewPort->Height;					//bring it to screen coordinates
		vertices2[i].y += viewPort->Y;
	}
	//Vertexbuffer locken
	if (FAILED(hr=nadelVB->Lock( 0, 4*sizeof(D3DVERTEX2D),(BYTE**)&pVertices,D3DLOCK_DISCARD)))
	{
		DXTrace(__FILE__,__LINE__,hr,"Lock()",true);
		return false;
	}
	memcpy( pVertices, vertices2, 4*sizeof(D3DVERTEX2D));
	nadelVB->Unlock();	//Vertexbuffer wieder freigeben
	return true;
}

bool Cockpit::Render(int checkValue)
{
	HRESULT hr;
	char buffer[MAXSTRING]; 
	char buffer2[MAXSTRING];
	int position,i;
	
	d3dDevice->SetRenderState( D3DRS_ZENABLE, false);

	//Draw the timer
	if (*raceStatus == RSBEFORESTART) 
	{
		d3dDevice->SetMaterial(&fontMat);
		d3dDevice->SetTransform( D3DTS_WORLD, &matFont);
		_itoa_s((int)checkTime+1,buffer,10);
		hr = font->Render3DText(buffer,D3DFONT_CENTERED|D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"cockpit->Render3DText()",true);
	}
	if (*raceStatus == RSPAUSE) 
	{
		strcpy_s(buffer,TXTPAUSEMENUE);
		hr = font->DrawTextScaled(-0.2f,-0.5f,0.5f,0.05f,0.05f,
			viewPort, 0xFF7F7FFF,buffer,D3DFONT_FILTERED);
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"cockpit->DrawTextScaled()",true);
	}
	if (*raceStatus == RSAFTERZIEL)
	{
		strcpy_s(buffer,TXTENDOFRACE);
		hr = font->DrawTextScaled(-0.7f,-0.7f,0.5f,0.1f,0.1f,
			viewPort, 0xFF7F7FFF,buffer,D3DFONT_FILTERED);
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"cockpit->DrawTextScaled()",true);

	}
	if (((*raceStatus == RSLASTROUND) || (*raceStatus == RSINRACE)) && (checkValue != 5))
	{
		if ( checkValue != 1)
		{
			d3dDevice->SetRenderState( D3DRS_ZENABLE, true);
			//Draw the arrow
			//Erstellte Transformationsmatrix einstellen
			d3dDevice->SetTransform( D3DTS_WORLD, &pfeilMat);
			
			for( i=0; i<(signed int)pfeilAnzMat; i++ )
			{
				d3dDevice->SetMaterial( &pfeilMaterials[i]);
				
				if (pfeilTexNr[i] != -1) d3dDevice->SetTexture(0,textures->getTex(pfeilTexNr[i]));
				
				if (FAILED(pfeilMesh->DrawSubset(i)))
				{
					MessageBox(NULL,"error: mesh->DrawSubset() (Cockpit::Render())",NULL,NULL);
					return false;
				}
			}
			d3dDevice->SetRenderState( D3DRS_ZENABLE, false);
		}
		if (checkValue != 2)
		{
			d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
			d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
			d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
			
			// Enable alpha testing (skips pixels with less than a certain alpha.)
			d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
			d3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
			d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

			d3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
			d3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
			
			//render the font background
			hr = d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX2D2);
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"SetVertexShader()",true);
				return false;
			}
			hr = d3dDevice->SetStreamSource( 0, fontBackVB, sizeof(D3DVERTEX2D2));
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
				return false;
			}
			hr = d3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP  , 0, 4-2 );
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
				return false;
			}

			d3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
			d3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		}
		if (checkValue != 3)
		{
			//Draw the times
			//calc the position
			position = 1;
			for (i=0;i<MAXAUTOS;i++) if (refPos[i] > refPos[*indexNr]) position++;
			strcpy_s(buffer,TXTPOSITION);
			_itoa_s(position,buffer2,10);
			strcat_s(buffer,buffer2);
			strcat_s(buffer,"/");
			_itoa_s(MAXAUTOS,buffer2,10);
			strcat_s(buffer,buffer2);
			strcat_s(buffer,"\n");
			strcat_s(buffer,TXTLAPS);
			_itoa_s(*runde,buffer2,10);
			strcat_s(buffer,buffer2);
			strcat_s(buffer,"/");
			_itoa_s(*anzRunden,buffer2,10);
			strcat_s(buffer,buffer2);
			hr = font->DrawTextScaled(+0.5f,-0.99f,0.5f,0.04f,0.04f,
				viewPort, 0xFFFFFF7F,buffer,D3DFONT_FILTERED);
			if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->DrawTextScaled()",true);
			
			strcpy_s(buffer,TXTLASTLAP);
			GetTimeStringFromFloat(buffer2, *lastRundenZeit);
			strcat_s(buffer,buffer2);
			strcat_s(buffer,"\n");
			strcat_s(buffer,TXTBESTLAP);
			GetTimeStringFromFloat(buffer2, *bestRundenZeit);
			strcat_s(buffer,buffer2); 
			hr = font->DrawTextScaled(-0.99f,-0.99f,0.5f,0.04f,0.04f,
				viewPort, 0xFFFFFF7F,buffer,D3DFONT_FILTERED);
			if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->DrawTextScaled()",true);
			
			GetTimeStringFromFloat(buffer2, *clock-*lastStartZielZeit);
			strcpy_s(buffer,buffer2);
			hr = font->DrawTextScaled(-0.2f,-0.95f,0.5f,0.05f,0.05f,
				viewPort, 0xFFFFFF7F,buffer,D3DFONT_FILTERED);
			if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->DrawTextScaled()",true);
		}
		if (checkValue != 4)
		{
			d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
			d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
			d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
			
			// Enable alpha testing (skips pixels with less than a certain alpha.)
			d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
			d3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
			d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
			
			/////////////////////////////////////////////////	
			//render the tacho
			hr = d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX2D);
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"SetVertexShader()",true);
				return false;
			}
			
			//the tacho
			hr = d3dDevice->SetStreamSource( 0, tachoVB, sizeof(D3DVERTEX2D));
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
				return false;
			}
			if (tachoTexNr != -1) d3dDevice->SetTexture( 0,textures->getTex(tachoTexNr));
			hr = d3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP  , 0, 4-2 );
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
				return false;
			}
			//the tacho-pointer
			hr = d3dDevice->SetStreamSource( 0, nadelVB, sizeof(D3DVERTEX2D));
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
				return false;
			}
			if (nadelTexNr != -1) d3dDevice->SetTexture( 0,textures->getTex(nadelTexNr));
			hr = d3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP  , 0, 4-2 );
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
				return false;
			}
		}
		d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
		d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );
	}
	if ((*raceStatus == RSLASTROUND) || (*raceStatus == RSAFTERZIEL))
	{
		if (checkTime >= 0)
		{
			for (i=0;i<anzImZiel;i++)
			{
				if (strcmp(name,finishTable[i].name) == 0) 
					hr = font->DrawTextScaled(-0.5f,-0.2f+i*0.1f,0.5f,0.04f,0.04f,
					viewPort, 0xFFFFFF7F,finishTable[i].lineText,D3DFONT_FILTERED);
				else hr = font->DrawTextScaled(-0.5f,-0.2f+i*0.1f,0.5f,0.04f,0.04f,
					viewPort, 0xFF7F7FFF,finishTable[i].lineText,D3DFONT_FILTERED);
				if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->DrawTextScaled()",true);
			}
		}
	}

	d3dDevice->SetRenderState( D3DRS_ZENABLE, true);
	return true;
}

bool Cockpit::InvalidateDeviceObjects()
{
	HRESULT hr;

	hr = font->InvalidateDeviceObjects(); 
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"font->InvalidateDeviceObjects()",true);
		return false;
	}

	SAFE_RELEASE(fontBackVB);
	SAFE_RELEASE(tachoVB);
	SAFE_RELEASE(nadelVB);
	return true;
}

bool Cockpit::RestoreDeviceObjects()
{
	HRESULT hr;

	hr = font->RestoreDeviceObjects();
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"font->RestoreDeviceObjects()",true);
		return false;
	}
	hr = d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX2D2),
                                        D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0,
                                        D3DPOOL_DEFAULT, &fontBackVB );  
    if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"cockpit->RestoreDeviceObjects()",true);
		return false;
	}

	hr = d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX2D),
                                        D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0,
                                        D3DPOOL_DEFAULT, &tachoVB );  
    if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"cockpit->RestoreDeviceObjects()",true);
		return false;
	}
	hr = d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX2D),
                                        D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0,
                                        D3DPOOL_DEFAULT, &nadelVB );  
    if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"cockpit->RestoreDeviceObjects()",true);
		return false;
	}

	//Calculate the fontbackground
	D3DVERTEX2D2	*pVertices;
	D3DVERTEX2D2	vertices[4] =
	{
		{viewPort->X+0.0f*viewPort->Width,	viewPort->Y+0.1f*viewPort->Height,	
		0.0f, 0.0f,  0x80000080},
		{viewPort->X+0.0f*viewPort->Width,	viewPort->Y+0.0f*viewPort->Height,	
		0.0f, 0.0f,  0x80000080},	//x y z w diffuse
		{viewPort->X+1.0f*viewPort->Width,	viewPort->Y+0.1f*viewPort->Height,	
		0.0f, 0.0f,  0x80000080},
		{viewPort->X+1.0f*viewPort->Width,	viewPort->Y+0.0f*viewPort->Height,	
		0.0f, 0.0f,  0x80000080},
	};
	
	//Vertexbuffer locken
	if (FAILED(hr=fontBackVB->Lock( 0, 4*sizeof(D3DVERTEX2D2),(BYTE**)&pVertices,D3DLOCK_DISCARD )))
	{
		DXTrace(__FILE__,__LINE__,hr,"Lock()",true);
		return false;
	}
	memcpy( pVertices, vertices, 4*sizeof(D3DVERTEX2D2));
	fontBackVB->Unlock();	//Vertexbuffer wieder freigeben
	
	//calculate the tacho
	D3DVERTEX2D	vertices2[4] =
	{
		{viewPort->X+0.0f*viewPort->Height, viewPort->Y+1.0f*viewPort->Height,				
		0.0f, 10.0f,  0.5f, 0.5f},
		{viewPort->X+0.0f*viewPort->Height,	viewPort->Y+(1.0f-TACHOWIDTH)*viewPort->Height,	
		0.0f, 10.0f,  0.5f, 0.0f},	//x y z w tx ty
		{viewPort->X+TACHOWIDTH*viewPort->Height, viewPort->Y+1.0f*viewPort->Height,				
		0.0f, 10.0f,  1.0f, 0.5f},
		{viewPort->X+TACHOWIDTH*viewPort->Height, viewPort->Y+(1.0f-TACHOWIDTH)*viewPort->Height,	
		0.0f, 10.0f,  1.0f, 0.0f},
	};
	
	//Vertexbuffer locken
	if (FAILED(hr=tachoVB->Lock( 0, 4*sizeof(D3DVERTEX2D),(BYTE**)&pVertices,D3DLOCK_DISCARD)))
	{
		DXTrace(__FILE__,__LINE__,hr,"Lock()",true);
		return false;
	}
	memcpy( pVertices, vertices2, 4*sizeof(D3DVERTEX2D));
	tachoVB->Unlock();	//Vertexbuffer wieder freigeben

	return true;
}

bool Cockpit::DeleteDeviceObjects()
{
	HRESULT hr;

	SAFE_DELETE_ARRAY(pfeilMaterials);	
	SAFE_DELETE_ARRAY(pfeilTexNr);
	SAFE_RELEASE(pfeilMesh);
	pfeilAnzMat = 0;
	
	if (font)
	{
		hr = font->DeleteDeviceObjects();
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	}

	d3dDevice = NULL;
	return true;
}

void Cockpit::nextCam()
{
	aktCam++;
	if (aktCam >= anzCams) aktCam = 0;
	testText->drawText(5,camList[aktCam].name);
	
}

void Cockpit::newImZiel(int lapsBack, float newTime, float newBestTime, char *newName)
{
	int i;
	if (anzImZiel >= MAXAUTOS) return;

	//find the right position for this car
	for (i=anzImZiel;i>=0;i--)
	{
		if (i!=0) 
		{
			if (lapsBack < finishTable[i-1].laps)	//its driven more laps -> its better
			{
				finishTable[i].name = finishTable[i-1].name;	 //set the car before ones back
				finishTable[i].time = finishTable[i-1].time;
				finishTable[i].bestTime = finishTable[i-1].bestTime;
				finishTable[i].laps = finishTable[i-1].laps;
				continue;
			}
		}
		finishTable[i].name	= newName;
		finishTable[i].time = newTime;
		finishTable[i].bestTime = newBestTime;
		finishTable[i].laps = lapsBack;
		break;
	}

	anzImZiel++;
	makeLineTexts();	//get the new strings for the table

	checkTime = 4.0f;	//display the new times a certain time
}

void Cockpit::makeLineTexts()
{
	int i;
	char buffer[MAXSTRING];

	for (i=0;i<anzImZiel;i++)
	{
		_itoa_s(i+1,finishTable[i].lineText,10);
		strcat_s(finishTable[i].lineText,". ");
		strcat_s(finishTable[i].lineText,finishTable[i].name);
		strcat_s(finishTable[i].lineText," ");
		if (finishTable[i].laps == 0)
			GetTimeStringFromFloat(buffer,finishTable[i].time);
		else
		{
			_itoa_s(finishTable[i].laps,buffer,10);
			if (finishTable[i].laps == 1) strcat_s(buffer,TXTONELAP);
			else  strcat_s(buffer,TXTMORELAPS);
		}
		strcat_s(finishTable[i].lineText,buffer);
		strcat_s(finishTable[i].lineText," ");
		GetTimeStringFromFloat(buffer,finishTable[i].bestTime);
		strcat_s(finishTable[i].lineText,buffer);
	}
}
