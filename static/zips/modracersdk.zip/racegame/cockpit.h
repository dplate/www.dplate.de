//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_COCKPIT)
#define N_COCKPIT

#include "konstanten.h"
#include "textures.h"
#include "testtext.h"
#include "viewfrustum.h"

class Cockpit
{
public: 
	Cockpit(D3DXMATRIX      *matWorldSet,
			Textures		*texturesSet,
			char			*homeDirSet,
			TestText		*testTextSet,
			FLOAT           *fElapsedTimeSet,
			char			*camFile,
			XYFloat			*positionSet,
			XYFloat			*richtungSet,
			int				*raceStatusSet,
			D3DXVECTOR3		*vEyePtSet,
			D3DXVECTOR3		*vLookatPtSet,
			float			*clockSet,
			float			*lastStartZielZeitSet,
			float			*lastRundenZeitSet,
			float			*bestRundenZeitSet,
			int				*rundeSet,
			int				*anzRundenSet,
			int				*refPosSet,
			int				*indexNrSet,
			D3DVIEWPORT8	*viewPortSet,
			bool			enableSoundSet,
			char			*nameSet,
			CViewFrustum	*viewFrustumSet);
	~Cockpit();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
	bool FrameMove(D3DXVECTOR3 *newZiel,float upsSchnitt);
	bool updateView(D3DXMATRIX *matProj);
    bool DeleteDeviceObjects();
	bool InvalidateDeviceObjects();
	bool RestoreDeviceObjects();
    bool Render(int checkValue);
	void nextCam();
	void newImZiel(int lapsBack, float newTime, float newBestTime, char *newName);

	struct Cam
	{
		char	name[MAXSTRING];	//the name of this camera-position
		D3DXVECTOR3 pos;			//the position of this camera
		D3DXVECTOR3 lookTo;			//the "look to" position
		bool	fest;				//is the camera fixed on the car?
	} camList[MAXCAMS];		//All cameras for this car
	int anzCams;			//How many cams for this car		
	int	aktCam;				//This is the cam

private:
	void makeLineTexts();

	D3DXMATRIX      *matWorld;
	D3DXMATRIX      matView;
	Textures		*textures;
	IDirect3DDevice8 *d3dDevice;
	char			*homeDir;
	TestText		*testText;
	FLOAT           *fElapsedTime;
	XYFloat			*position;
	XYFloat			*richtung;
	int				*raceStatus;
	D3DXVECTOR3		*vEyePt;
	D3DXVECTOR3		*vLookatPt;
	float			checkTime;	
	float			*clock;
	float			*lastStartZielZeit;
	float			*lastRundenZeit;
	float			*bestRundenZeit;
	int				*runde;
	int				*anzRunden;
	int				*refPos;
	int				*indexNr;
	D3DVIEWPORT8	*viewPort;
	bool			enableSound;
	char			*name;
	CViewFrustum	*viewFrustum;

	struct FinishTable
	{
		char    *name;	//the startNr. of this car
		float	time;	//the driven time
		float	bestTime; //the best lap-time
		int		laps;	//how many laps driven
		char	lineText[MAXSTRING];
	} finishTable[MAXAUTOS]; //All strings of the finish-table
	int				anzImZiel;				//How many cars have finished the race?

	LPD3DXMESH		pfeilMesh;				// Das Drahtgittermodell des Pfeils
	DWORD			pfeilAnzMat;			// Anzahl der Materiale bei diesem Objekt
	D3DMATERIAL8*   pfeilMaterials;			// Die Materialien
	int				*pfeilTexNr;			// die Texturenindexe
	D3DXMATRIX		pfeilMat;				// die Transformationsmatrix des Pfeils

	CD3DFont		*font;
	D3DXMATRIX		matFont;				//for timer and end
	D3DMATERIAL8	fontMat;				//the normal material

	float			angle;

	LPDIRECT3DVERTEXBUFFER8 fontBackVB;	//Pointer to the font background

	int				tachoTexNr;			//the texture of the tacho
	LPDIRECT3DVERTEXBUFFER8 tachoVB;	//Pointer to the tacho rectangle

	int				nadelTexNr;			//the texture of the tacho pointer
	LPDIRECT3DVERTEXBUFFER8 nadelVB;	//Pointer to the tacho pointer rectangle
};

#endif