//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#define STRICT
#include "stdafx.h"
#include "credits.h"

Credits::Credits(IDirect3DDevice8 *d3dDeviceSet,
		   FLOAT           *fElapsedTimeSet,
		   char			   *homeDirSet,
		   TestText		   *testTextSet,
		   TestLine		   *testLineSet)
{
	int i;
	POINT tmp;
	char buffer[MAXSTRING];

	d3dDevice = d3dDeviceSet;
	fElapsedTime = fElapsedTimeSet;
	homeDir	= homeDirSet;
	testText = testTextSet;
	testLine = testLineSet;

	//change in the home-directory
	if (_chdir(homeDir) == -1) 
	{
		MessageBox(NULL,homeDir,NULL,NULL);
		return;
	}
	
	//Die Textureverwaltungsklasse einrichten
	textures = new Textures(homeDir,testText);

	//Make prolschrift
	font = new CD3DFont((char*)FONTNAME, 50);
	location = 0.0f;

	//make the streetkacheln
	for (i=0;i<STREETLENGTH;i++)
	{
		tmp.x = 0;
		tmp.y = i;
		street[i] = new Kachel(&matWorld,textures,false,"Gerade Asphalt Senkrecht",tmp,NULL);
	}
	if (!OneTimeSceneInit())
	{
		MessageBox(NULL,"Error: Credits->OneTimeSceneInit() (3)",NULL,NULL);
		return;
	}
	if (!InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: Credits->InitDeviceObjects() (3)",NULL,NULL);
		return;
	}
	if (!RestoreDeviceObjects())
	{
		MessageBox(NULL,"Error: Credits->RestoreDeviceObjects() (3)",NULL,NULL);
		return;
	}
	strcpy_s(buffer,homeDir);
	strcat_s(buffer,SOUNDDIR);
	if (_chdir(buffer) == -1) MessageBox(NULL,buffer,NULL,NULL);
	music = FMUSIC_LoadSong("credits.mid");
	if (!music)
	{
		printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
		exit(1);
	}
}

Credits::~Credits()
{
	int i;

	SAFE_DELETE(font);

	DeleteDeviceObjects();
	FinalCleanup();

	for (i=0;i<STREETLENGTH;i++)
		delete street[i];

	FMUSIC_StopSong(music);
	FMUSIC_FreeSong(music);
}

bool Credits::OneTimeSceneInit()
{
	return true;
}


bool Credits::FrameMove()
{
	//Loop midi
	if (!FMUSIC_IsPlaying(music)) FMUSIC_PlaySong(music);

	location += *fElapsedTime;
	return true;
}


bool Credits::Render()
{
	HRESULT hr;
	char buffer[MAXSTRING];
	int i;
	D3DXMATRIX mat1;

	for (i=0;i<STREETLENGTH;i++)
	{
		if (!street[i]->Render())
		{
			MessageBox(NULL,"Error: kachel->Render()",NULL,NULL);
			return false;
		}
	}
	
	
	for (i=0;i<MAXCREDITTEXT;i++)
	{	
		if (TXTCREDITTEXT[i][0] == '-')
			d3dDevice->SetMaterial(&fontMatH);
		else
			d3dDevice->SetMaterial(&fontMat);
		D3DXMatrixScaling(&mat1,0.007f,0.007f,0.007f);
		D3DXMatrixMultiply(&matFont,&matWorld,&mat1);
		D3DXMatrixRotationX(&mat1, pi/2);
		D3DXMatrixMultiply(&matFont,&matFont,&mat1);
		D3DXMatrixTranslation(&mat1, 0.5f,0.1f,location/20-(float)i*0.1f);
		D3DXMatrixMultiply(&matFont,&matFont,&mat1);
		
		d3dDevice->SetTransform( D3DTS_WORLD, &matFont);
		if (TXTCREDITTEXT[i][0] == '-') strcpy_s(buffer,TXTCREDITTEXT[i]+1);
		else strcpy_s(buffer,TXTCREDITTEXT[i]);
		hr = font->Render3DText(buffer,D3DFONT_CENTERED|D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->Render3DText()",true);
	}
	return true;
}

bool Credits::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	HRESULT hr;
	int i;

	d3dDevice = d3dDeviceSet;

	for (i=0;i<STREETLENGTH;i++)
	{
		if (!street[i]->InitDeviceObjects(d3dDevice))
		{
			MessageBox(NULL,"Error: kachel->InitDeviceObjects()",NULL,NULL);
			return false;
		}
	}

	hr = font->InitDeviceObjects(d3dDevice );
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	ZeroMemory(&fontMat, sizeof(D3DMATERIAL8));
	fontMat.Diffuse.r = 0.5f;
	fontMat.Diffuse.g = 0.5f;
	fontMat.Diffuse.b = 1.0f;
	fontMat.Diffuse.a = 1.0f;
	fontMat.Ambient.r = 0.5f;
	fontMat.Ambient.g = 0.5f;
	fontMat.Ambient.b = 1.0f;
	fontMat.Ambient.a = 1.0f;
	ZeroMemory(&fontMatH, sizeof(D3DMATERIAL8));
	fontMatH.Diffuse.r = 1.0f;
	fontMatH.Diffuse.g = 1.0f;
	fontMatH.Diffuse.b = 0.5f;
	fontMatH.Diffuse.a = 1.0f;
	fontMatH.Ambient.r = 1.0f;
	fontMatH.Ambient.g = 1.0f;
	fontMatH.Ambient.b = 0.5f;
	fontMatH.Ambient.a = 1.0f;

	return true;
}

bool Credits::RestoreDeviceObjects()
{
	HRESULT hr;

    vEyePt 		= D3DXVECTOR3( 0.5f, 0.3f,  0.0f );
	vLookatPt 	= D3DXVECTOR3( 0.5f, -40.0f,  100.0f);
	vUpVec      = D3DXVECTOR3( 0.0f, +1.0f,  0.0f );

	hr = font->RestoreDeviceObjects();
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	   
	D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec );
	if (FAILED(hr=d3dDevice->SetTransform(D3DTS_VIEW, &matView)))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetTransform()",true);
		return false;
	}
	D3DXMatrixIdentity( &matWorld );
    
    // Set default render states
	for (int i=0;i<7;i++)
	{
		d3dDevice->SetTextureStageState(i, D3DTSS_MINFILTER, D3DTEXF_ANISOTROPIC);
    	d3dDevice->SetTextureStageState(i, D3DTSS_MAGFILTER, D3DTEXF_ANISOTROPIC);
		d3dDevice->SetTextureStageState(i, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
		d3dDevice->SetTextureStageState(i, D3DTSS_MAXANISOTROPY, 2 );
	}
	
	// Turn on D3D lighting
	d3dDevice->SetRenderState( D3DRS_LIGHTING, true );
    // Turn on the zbuffer
    d3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	d3dDevice->SetRenderState( D3DRS_SPECULARENABLE, false );

	// Initialize the structure.
	ZeroMemory(&d3dLight, sizeof(D3DLIGHT8));
	
	// Set up a white directional light
	d3dLight.Type = D3DLIGHT_DIRECTIONAL;
	d3dLight.Diffuse.r  = 0.0f;
	d3dLight.Diffuse.g  = 0.0f;
	d3dLight.Diffuse.b  = 0.0f;
	d3dLight.Ambient.r  = 1.0f;
	d3dLight.Ambient.g  = 1.0f;
	d3dLight.Ambient.b  = 1.0f;
	d3dLight.Specular.r = 1.0f;
	d3dLight.Specular.g = 1.0f;
	d3dLight.Specular.b = 1.0f;
	
	d3dLight.Direction.x = +0.0f;
	d3dLight.Direction.y = -1.0f;
	d3dLight.Direction.z = -0.5f;
	
	// Set the property information for the first light.
	d3dDevice->SetLight(0, &d3dLight);
    if (FAILED(d3dDevice->LightEnable(0, true)))
	{
		MessageBox(NULL,"Error: d3dDevice->LightEnable() (Menue::RestoreDeviceObjects)",NULL,NULL);
		return false;
	}

	return true;
}


bool Credits::InvalidateDeviceObjects()
{
	HRESULT hr;

	hr = font->InvalidateDeviceObjects();
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InvalidateDeviceObjects()",true);
    return true;
}


bool Credits::DeleteDeviceObjects()
{
	HRESULT hr;
	int i;

	if (!textures->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: textures->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}

	for (i=0;i<STREETLENGTH;i++)
	{
		if (!street[i]->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: kachel->DeleteDeviceObjects()",NULL,NULL);
			return false;
		}
	}

	if (font)
	{
		hr = font->DeleteDeviceObjects();
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	}
	return true;
}

bool Credits::FinalCleanup()
{
	SAFE_DELETE(font);
	return true;
}

int Credits::message(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch( uMsg )
    {
    case WM_KEYDOWN:
		switch (wParam)
		{
			case VK_ESCAPE:
			return SZMENUE;
			break;
		}
		break;
	}
    return -1;
}

