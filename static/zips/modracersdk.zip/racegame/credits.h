//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_CREDITS)
#define N_CREDITS

#include "Textures.h"
#include "testtext.h"
#include "testline.h"
#include "kachel.h"

class Credits
{
public:
    Credits(IDirect3DDevice8 *d3dDeviceSet,
		 FLOAT           *fElapsedTimeSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 TestLine		 *testTextLine);
	~Credits();
	bool OneTimeSceneInit();
    bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool RestoreDeviceObjects();
    bool InvalidateDeviceObjects();
    bool DeleteDeviceObjects();
    bool Render();
    bool FrameMove();
    bool FinalCleanup();
	int message(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	// Transform matrices
	D3DXMATRIX      matWorld;
    D3DXMATRIX      matView;
    D3DXMATRIX      matProj;
	FLOAT           *fElapsedTime;
	char			*homeDir;
	TestText		*testText;
	TestLine		*testLine;
	IDirect3DDevice8 *d3dDevice;
	
	D3DXVECTOR3		vEyePt;      
    D3DXVECTOR3		vLookatPt;   
    D3DXVECTOR3		vUpVec;
	D3DLIGHT8		d3dLight;
	Textures		*textures;

	Kachel			*street[STREETLENGTH];

	CD3DFont		*font;
	D3DXMATRIX		matFont;	//the transformation matrix
	D3DMATERIAL8	fontMat;	//the normal material
	D3DMATERIAL8	fontMatH;	//the highlighted material

	float			location;	//how much have the fonts move?

	FMUSIC_MODULE	*music;				//The backgroundmidi-file
};

#endif