//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "helpfunctions.h"

XYFloat Schnittpunkt(XYFloat g1Punkt0,XYFloat g1Punkt1, XYFloat g2Punkt0, XYFloat g2Punkt1)
{
	XYFloat erg;
	float g2a,g2b,g1a,g1b;
	XYFloat mauerDiff,posDiff,sPunkt;
	bool check = true;

	erg.x = -1;
	erg.y = -1;

	posDiff.x = g1Punkt0.x - g1Punkt1.x;
	posDiff.y = g1Punkt0.y - g1Punkt1.y;
	mauerDiff.x = g2Punkt1.x - g2Punkt0.x;
	mauerDiff.y = g2Punkt1.y - g2Punkt0.y;
	
	//Steigung errechnen
	if (posDiff.x == 0) g1a = FLT_MAX;
	else g1a = posDiff.y/posDiff.x;
	if (mauerDiff.x == 0) g2a = FLT_MAX;
	else g2a = mauerDiff.y/mauerDiff.x;

	//Achsenabschnitt berechnen
	g1b = g1Punkt0.y-g1Punkt0.x*g1a;
	g2b = g2Punkt0.y-g2Punkt0.x*g2a;
		
	//Schnittpunkt berechnen
	if (g1a >= FLT_MAX-1000)				//Sonderf�lle bei senkrechten Geraden
	{
		sPunkt.x = g1Punkt1.x;
		sPunkt.y = sPunkt.x*g2a+g2b;
	}
	else if (g2a >= FLT_MAX-1000)
	{
		sPunkt.x = g2Punkt1.x;
		sPunkt.y = sPunkt.x*g1a+g1b;
	}
	else if (g2a == g1a)			//beide Geraden sind parallel
	{
		erg.x = -1;
		erg.y = -1;
		check = false;
	}
	else							//normale F�lle
	{
		sPunkt.x = (g1b-g2b)/(g2a-g1a);
		sPunkt.y = (sPunkt.x*g1a)+g1b;
	}
	if (check) 
	{
		//Ist Schnittpunkt innerhalb der Grenzen?
		if (((sPunkt.x >= g1Punkt0.x-0.001f) && (sPunkt.x <= g1Punkt1.x+0.001f)) ||
			((sPunkt.x <= g1Punkt0.x+0.001f) && (sPunkt.x >= g1Punkt1.x-0.001f)))
		{
			if (((sPunkt.y >= g1Punkt0.y-0.001f) && (sPunkt.y <= g1Punkt1.y+0.001f)) ||
				((sPunkt.y <= g1Punkt0.y+0.001f) && (sPunkt.y >= g1Punkt1.y-0.001f)))
			{
				if (((sPunkt.x >= g2Punkt0.x-0.001f) && (sPunkt.x <= g2Punkt1.x+0.001f)) ||
					((sPunkt.x <= g2Punkt0.x+0.001f) && (sPunkt.x >= g2Punkt1.x-0.001f)))
				{
					if (((sPunkt.y >= g2Punkt0.y-0.001f) && (sPunkt.y <= g2Punkt1.y+0.001f)) ||
						((sPunkt.y <= g2Punkt0.y+0.001f) && (sPunkt.y >= g2Punkt1.y-0.001f)))
					{
						erg.x = sPunkt.x;
						erg.y = sPunkt.y;
					}
				}
			}
		}
	}
	return erg;
}

float GPAbstand(XYFloat gPunkt0,XYFloat gPunkt1, XYFloat punkt)
{
	float a1,a2,b1,b2;
	XYFloat sPunkt;
	
	//steigung
	if ((gPunkt1.x-gPunkt0.x) == 0) a1 = 1000; 
	else a1 = (gPunkt1.y-gPunkt0.y)/(gPunkt1.x-gPunkt0.x);
	if (a1 == 0) a2 = 1000;
	else a2 = -1/a1;
	//achsenabschnitte
	b1 = gPunkt0.y-a1*gPunkt0.x;
	b2 = punkt.y-a2*punkt.x;
	//Schnittpunkt berechnen
	sPunkt.x = (b1-b2)/(a2-a1);
	sPunkt.y = (sPunkt.x*a1)+b1;
	//Abstand
	return (float)sqrt((sPunkt.x-punkt.x)*(sPunkt.x-punkt.x)+(sPunkt.y-punkt.y)*(sPunkt.y-punkt.y));
}

XYFloat GetSenkrecht(XYFloat vector0)
{
	XYFloat vector1;
	float length0 = GetBetrag(vector0);
	vector1.x = -vector0.y/length0;
	vector1.y = vector0.x/length0;
	return vector1;
}

float GetBetrag(XYFloat vector)
{
	return (float)sqrt(vector.x*vector.x+vector.y*vector.y);
}

XYFloat PointRotate(XYFloat origPunkt, float degree)
{
	XYFloat newPunkt;
	double radius;
	double absDegree;

	radius = sqrt(origPunkt.x*origPunkt.x+origPunkt.y*origPunkt.y);
	absDegree = atan2(origPunkt.y,origPunkt.x)+degree;
	
	newPunkt.x = float(radius*cos(absDegree));
	newPunkt.y = float(radius*sin(absDegree));

	return newPunkt;
}

void GetRotationMatrixToVector( D3DXMATRIX *erg, D3DXVECTOR3 *richtung)
{
	D3DXMATRIX matTmp;
	float rotY = -(float)(atan2(richtung->z,richtung->x)-pi/2);

	D3DXMatrixRotationY(&matTmp, rotY); 
	D3DXMatrixMultiply( erg, &matTmp, erg );
	
	if ((rotY >= -pi/4) && (rotY < pi/4))
		D3DXMatrixRotationX( &matTmp, +(float)(atan2(richtung->z,richtung->y)-pi/2));
	else if ((rotY >= 3*pi/4) && (rotY < 5*pi/4))
		D3DXMatrixRotationX( &matTmp, -(float)(atan2(richtung->z,richtung->y)+pi/2));
	else if ((rotY >= pi/4) && (rotY < 3*pi/4))
		D3DXMatrixRotationX( &matTmp, -(float)(atan2(-richtung->x,richtung->y)+pi/2)); 
	else 
		D3DXMatrixRotationX( &matTmp, (float)(atan2(-richtung->x,richtung->y)-pi/2)); 
	D3DXMatrixMultiply(erg,&matTmp,erg);
}

void GetTimeStringFromFloat(char *string, float value)
{
	char buffer[MAXSTRING];
	
	_itoa_s((int)(value/60),buffer,10);
	value -= (float)((int)(value/60)*60);
	MakeString2Long(buffer);
	strcpy_s(string, MAXSTRING - 1,buffer);
	strcat_s(string, MAXSTRING - 1,":");
	_itoa_s((int)(value),buffer,10);
	MakeString2Long(buffer);
	value -= (int)(value);
	strcat_s(string, MAXSTRING - 1,buffer);
	strcat_s(string, MAXSTRING - 1,":");
	_itoa_s((int)(value*100),buffer,10);
	MakeString2Long(buffer);
	strcat_s(string, MAXSTRING - 1,buffer);
}

void MakeString2Long(char *string)
{
	if (strlen(string) == 1)
	{
		string[2] = string[1];
		string[1] = string[0];
		string[0] = '0';
	}
}

void DeleteBlanksOfString(char *string)
{
	int i;

	for (i=strlen(string)-1;i>=0;i--)
	{
		if (string[i] == ' ') string[i] = '\0';
		else break;
	}
}
