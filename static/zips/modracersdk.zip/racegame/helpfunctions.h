//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_HELPFUNCTIONS)
#define N_HELPFUNCTIONS

#include "konstanten.h"

#define MAX(a,b) ((a > b) ? a:b)
#define MIN(a,b) ((a  <b) ? a:b)


XYFloat Schnittpunkt(XYFloat g1Punkt0,XYFloat g1Punkt1, XYFloat g2Punkt0, XYFloat g2Punkt1); //Berechnet den Schnittpunkt von 2 Geraden
float GPAbstand(XYFloat gPunkt0,XYFloat gPunkt1, XYFloat punkt);	//Berechnet den Abstand von einem Punkt und einer Geraden
XYFloat GetSenkrecht(XYFloat vector0);					//Berechnet einen senkrechten Einheitsvektor auf einen Vektor
float GetBetrag(XYFloat vector);						//Calculate the length of a vector
XYFloat PointRotate(XYFloat origPunkt, float degree);	//rotate a point around (0/0)
void GetRotationMatrixToVector( D3DXMATRIX *erg, D3DXVECTOR3 *richtung); //get a rotation matrix that bring a vector to the same direction then an other vector
void GetTimeStringFromFloat(char *string, float value); //convert float to xx:xx:xx time
void MakeString2Long(char *string);						//make a 1 string to a 2 string
void DeleteBlanksOfString(char *string);				//Delete the blanks at the end of a string

#endif