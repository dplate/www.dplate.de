//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#define STRICT
#include "stdafx.h"

#include "inputdevicemanager.h"

DIACTION g_rgGameAction[NUMBER_OF_SEMANTICS] =
{
	// Device input (joystick, etc.) that is pre-defined by DirectInput
	{ INPUT_LEFTRIGHT_AXIS,	DIAXIS_DRIVINGR_STEER,				NULL  , _T(TXTSTEER), },
	{ INPUT_UPDOWN_AXIS,	DIAXIS_DRIVINGR_ACCEL_AND_BRAKE,	NULL  , _T(TXTACCBRA), },
	{ INPUT_UP_AXIS,		DIAXIS_DRIVINGR_ACCELERATE,			NULL  , _T(TXTACCELERATE), },
	{ INPUT_DOWN_AXIS,		DIAXIS_DRIVINGR_BRAKE,				NULL  , _T(TXTBRAKE), },
	{ INPUT_CHANGECAM,		DIBUTTON_DRIVINGR_VIEW,				NULL  , _T(TXTCHANGECAMERA), },
	{ INPUT_REVERSE,		DIBUTTON_ANY(0),					NULL  , _T(TXTREVERSE), },
	{ INPUT_RESET,			DIBUTTON_ANY(1),					NULL  , _T(TXTRESET), },
	
	// Keyboard input mappings
	{ INPUT_STEERLEFT,      DIKEYBOARD_LEFT,    NULL  , _T(TXTSTEERLEFT), },
	{ INPUT_STEERRIGHT,     DIKEYBOARD_RIGHT,   NULL  , _T(TXTSTEERRIGHT), },
	{ INPUT_UP,				DIKEYBOARD_UP,      NULL  , _T(TXTACCELERATE), },
	{ INPUT_DOWN,			DIKEYBOARD_DOWN,    NULL  , _T(TXTBRAKE), },
	{ INPUT_CHANGECAM,		DIKEYBOARD_C,		NULL  , _T(TXTCHANGECAMERA), },
	{ INPUT_REVERSE,		DIKEYBOARD_V,		NULL  , _T(TXTREVERSE), },
	{ INPUT_RESET,			DIKEYBOARD_B,		NULL  , _T(TXTRESET), },
	
	// Mouse input mappings
	{ INPUT_LEFTRIGHT_AXIS,	DIMOUSE_XAXIS,		NULL  , _T(TXTSTEER), },
	{ INPUT_UPDOWN_AXIS,	DIMOUSE_YAXIS,		NULL  , _T(TXTACCBRA), },
	{ INPUT_CHANGECAM,		DIMOUSE_BUTTON0,	NULL  , _T(TXTCHANGECAMERA), }, 
	{ INPUT_REVERSE,		DIMOUSE_BUTTON1,	NULL  , _T(TXTREVERSE), },
	{ INPUT_RESET,			DIMOUSE_BUTTON2,	NULL  , _T(TXTRESET), },
};	


CInputDeviceManager::CInputDeviceManager()
{
    //call CoInitialize();
    CoInitialize(NULL);

	m_dwNumDevices = 0;
    m_pDI          = NULL;
}


CInputDeviceManager::~CInputDeviceManager()
{
    // Release() all devices
    for( int i=0; i<m_dwNumDevices; i++ )
    {
        m_pdidDevices[i]->Unacquire();
        m_pdidDevices[i]->Release();
        m_pdidDevices[i] = NULL;
    }

    // Release() base object
    SAFE_RELEASE( m_pDI );

    //call CoUninitialize();
    CoUninitialize();
}


HRESULT CInputDeviceManager::GetDevices( LPDIRECTINPUTDEVICE8** ppDevice, 
                                         DWORD* pdwCount )
{
    if( NULL==ppDevice || NULL==pdwCount )
        return E_INVALIDARG;

    (*ppDevice) = m_pdidDevices;
    (*pdwCount) = m_dwNumDevices;

    return S_OK;
}

bool CInputDeviceManager::GetDeviceForPlayer(int playerNr,int deviceNr,LPDIRECTINPUTDEVICE8 **device)
{
	if (userDevice[playerNr][deviceNr] == -1) return false;
	*device = (LPDIRECTINPUTDEVICE8*)&m_pdidDevices[userDevice[playerNr][deviceNr]];
	return true;
}


BOOL CALLBACK CInputDeviceManager::BuildFlatListCB( LPCDIDEVICEINSTANCE  pdidi,
                                                    LPDIRECTINPUTDEVICE8 pdidDevice, 
													DWORD  dwFlags,
													DWORD  dwRemainingDevices,
													LPVOID pContext )
{
	static DWORD dwIndex = 0;
    LPDIRECTINPUTDEVICE8* pdidDevArray;
    pdidDevArray = (LPDIRECTINPUTDEVICE8*)pContext;

    pdidDevArray[dwIndex++] = pdidDevice;
    pdidDevice->AddRef(); // Must AddRef any interfaces we keep.

	 if(!dwRemainingDevices)
    {
        dwIndex = 0; 
    }
    return DIENUM_CONTINUE;
}

VOID CInputDeviceManager::ReassignDevices()
{
    TCHAR szNameDev[MAX_PATH];
    DWORD dwDev;
	int i;
	int  nr;
	bool check;
	char *name;
	
    // Release() all devices
    for(i=0; i<m_dwNumDevices; i++ )
    {
        m_pdidDevices[i]->Unacquire();
        m_pdidDevices[i]->Release();
        m_pdidDevices[i] = NULL;
    }
	m_dwNumDevices = 0;
	for (nr=0;nr<anzSpieler;nr++) 
		for (i=0;i<MAXDEVICES;i++) 
			userDevice[nr][i] = -1;

    // Build a simple flat list of all devices currently attached to the machine. 
    ZeroMemory( m_pdidDevices, sizeof(m_pdidDevices) );
    m_pDI->EnumDevicesBySemantics( NULL, &m_diaf, BuildFlatListCB, 
                                   m_pdidDevices, DIEDBSFL_ATTACHEDONLY); 
   
    DIPROPSTRING dips;
	dips.diph.dwSize       = sizeof(DIPROPSTRING); 
	dips.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	dips.diph.dwObj        = 0; // device property 
	dips.diph.dwHow        = DIPH_DEVICE; 

    // Now we've got an array with every device attached to the system. 
    // Loop through them all and assign them to a player in the temp array.
    dwDev = 0;
    while( m_pdidDevices[dwDev] )
    {
		m_dwNumDevices++;		//count the devices
	
        m_pdidDevices[dwDev]->GetProperty( DIPROP_USERNAME,
							           &dips.diph );
        
        // Convert the string from Unicode to ANSI.
        WideCharToMultiByte( CP_ACP, 0, dips.wsz, -1,
                             szNameDev, MAX_PATH,NULL, NULL);

        // Determine who this device is now assigned to (as a DWORD value)
        // If the device is unassigned (i.e. no username), we skip it.
        if( strlen(szNameDev) )
        {
            // Get the device ready to go again for their user.
            m_pdidDevices[dwDev]->BuildActionMap( &m_diaf, szNameDev, DIDBAM_DEFAULT );
            m_pdidDevices[dwDev]->SetActionMap( &m_diaf, szNameDev, DIDSAM_DEFAULT );
           
			setDeviceSettings(dwDev);
			
			//Find the number of this user
			for (nr=0;nr<anzSpieler;nr++) 
			{
				getOneName(nr,&name);
				if (strcmp(szNameDev, name) == 0) break;
			}
			if (nr != anzSpieler)
			{
				// Now add it for the player.
				for (i=0;i<MAXDEVICES;i++) if (userDevice[nr][i] == -1) break;
				if (i != MAXDEVICES) userDevice[nr][i] = dwDev;
			}
        }
		dwDev++;  
    }
	//if a device not attached to a player, give it to a player without device
	
	dwDev = 0;
    while( m_pdidDevices[dwDev] )
    {
		check = false;
		for (nr=0;nr<anzSpieler;nr++) 
		{
			for (i=0;i<MAXDEVICES;i++)
				if (userDevice[nr][i] == (signed)dwDev) check = true;
		}
		if (!check)
		{
			for (nr=0;nr<anzSpieler;nr++) 
			{
				if (userDevice[nr][0] == -1)
				{
					getOneName(nr,&name);
					// Get the device ready to go again for their user.
					m_pdidDevices[dwDev]->BuildActionMap( &m_diaf, name, DIDBAM_DEFAULT );
					m_pdidDevices[dwDev]->SetActionMap( &m_diaf, name, DIDSAM_DEFAULT );
					
					setDeviceSettings(dwDev);

					userDevice[nr][0] = (signed)dwDev;
					break;
				}
			}
		}
		dwDev++; 
	}
}

void CInputDeviceManager::setDeviceSettings(int deviceNr)
{
	DIDEVICEINSTANCE pdidi;
	pdidi.dwSize = sizeof(DIDEVICEINSTANCE);
	m_pdidDevices[deviceNr]->GetDeviceInfo(&pdidi);
	DWORD   dwDeviceType = pdidi.dwDevType;
	
	// Set the device's coop level
	if( GET_DIDEVICE_TYPE(dwDeviceType) == DI8DEVTYPE_MOUSE )
		m_pdidDevices[deviceNr]->SetCooperativeLevel( m_hWnd, DISCL_EXCLUSIVE|DISCL_FOREGROUND );
	else
		m_pdidDevices[deviceNr]->SetCooperativeLevel( m_hWnd, DISCL_NONEXCLUSIVE|DISCL_BACKGROUND );
		
	// Set absolute/*relative*/ mode for mouse
	if( GET_DIDEVICE_TYPE(dwDeviceType) == DI8DEVTYPE_MOUSE )
	{
		DIPROPDWORD dipdw;
		dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
		dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
		dipdw.diph.dwObj        = 0;
		dipdw.diph.dwHow        = DIPH_DEVICE;
		dipdw.dwData            = DIPROPAXISMODE_ABS ;//DIPROPAXISMODE_REL;
		m_pdidDevices[deviceNr]->SetProperty( DIPROP_AXISMODE, &dipdw.diph );
	}
}

void CInputDeviceManager::getOneName(int nr, char** name)
{
	*name = userNames;
	for (int i=0;i<nr;i++) *name += strlen(*name)+1;
}

HRESULT CInputDeviceManager::Create(HWND hWnd, int anzSpielerSet)
{
    HRESULT hr;
	char * name;

	GUID g_AppGuid    = { 0x451F8DEF, 0xA7E9, 0x4DF4, 0x9A, 0x6B,
                          0xF4, 0xb6,0xC7, 0x06, 0xF3, 0x98 };
	char *tmpPointer;

	tmpPointer = userNames;
	strcpy_s(tmpPointer, 9,"Player 1");
	tmpPointer += strlen(tmpPointer)+1;
	strcpy_s(tmpPointer, 9,"Player 2");
	tmpPointer += strlen(tmpPointer)+1;
	strcpy_s(tmpPointer, 9,"Player 3");
	tmpPointer += strlen(tmpPointer)+1;
	strcpy_s(tmpPointer, 9,"Player 4");
	
   // Setup action format for suitable input devices for this app
    ZeroMemory( &m_diaf, sizeof(DIACTIONFORMAT) );
    m_diaf.dwSize        = sizeof(DIACTIONFORMAT);
    m_diaf.dwActionSize  = sizeof(DIACTION);
    m_diaf.dwDataSize    = NUMBER_OF_SEMANTICS * sizeof(DWORD);
    m_diaf.dwNumActions  = NUMBER_OF_SEMANTICS;
    m_diaf.guidActionMap = g_AppGuid;
    m_diaf.dwGenre       = DIVIRTUAL_DRIVING_RACE;
    m_diaf.rgoAction     = g_rgGameAction;
    m_diaf.dwBufferSize  = BUFFER_SIZE;
    m_diaf.lAxisMin      = -MAXAXIS;
    m_diaf.lAxisMax      = MAXAXIS;
    _tcscpy_s( m_diaf.tszActionMap, _T(TXTWINDOWTITEL) );
   
    // Store data
  	anzSpieler	  = anzSpielerSet;
	if (hWnd != NULL) m_hWnd = hWnd;
  	//make the double 0 after the last player
	getOneName(anzSpieler,&name);
	name[0] = '\0';

	 // Create the base DirectInput object
    hr = DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                              IID_IDirectInput8, (VOID**)&m_pDI, NULL );
    if( FAILED(hr) )
        return hr;

    ReassignDevices( );

    return S_OK;
}


HRESULT CInputDeviceManager::ConfigureDevices( IUnknown* pSurface,
                                               VOID* ConfigureDevicesCB,
                                               DWORD dwFlags )
{
    HRESULT hr;

    // Initialize all the colors here
    DICOLORSET dics;
    ZeroMemory(&dics, sizeof(DICOLORSET));
    dics.dwSize = sizeof(DICOLORSET);

    // Fill in all the params
    DICONFIGUREDEVICESPARAMS dicdp;
    ZeroMemory(&dicdp, sizeof(dicdp));
    dicdp.dwSize = sizeof(dicdp);
    dicdp.dwcFormats     = 1;
    dicdp.lprgFormats    = &m_diaf;
    dicdp.hwnd           = m_hWnd;
    dicdp.lpUnkDDSTarget = pSurface;

    dicdp.dwcUsers       = anzSpieler;
    dicdp.lptszUserNames = userNames;
   
    // Unacquire the devices so that mouse doesn't control the game while in control panel
    UnacquireDevices();

    hr = m_pDI->ConfigureDevices( (LPDICONFIGUREDEVICESCALLBACK)ConfigureDevicesCB, 
                                  &dicdp, dwFlags, NULL );

    if( dwFlags & DICD_EDIT )
    {
        // Re-set up the devices
        ReassignDevices();
    }

    return hr;
}


VOID CInputDeviceManager::UnacquireDevices()
{
    for( int i=0; i<m_dwNumDevices; i++ )
        m_pdidDevices[i]->Unacquire();
}


