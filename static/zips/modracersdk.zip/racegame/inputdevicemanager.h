//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_INPUTDEVICEMANAGER)
#define N_INPUTDEVICEMANAGER

//#include "text.h"
#include "konstanten.h"



//-----------------------------------------------------------------------------
// Name: class CInputDeviceManager
// Desc: Input device manager using DX8 action mapping
//-----------------------------------------------------------------------------
class CInputDeviceManager
{
public:
    CInputDeviceManager();
    ~CInputDeviceManager();
	// Device control
    HRESULT GetDevices( LPDIRECTINPUTDEVICE8** ppDevices, DWORD* pdwNumDevices );
    HRESULT ConfigureDevices( IUnknown* pSurface, VOID* pCallback, DWORD dwFlags );
    VOID UnacquireDevices();
	bool GetDeviceForPlayer(int playerNr,int deviceNr,LPDIRECTINPUTDEVICE8** device);
	VOID ReassignDevices();
    // Construction
    HRESULT Create( HWND hWnd, int anzSpielerSet );

	static BOOL CALLBACK BuildFlatListCB( LPCDIDEVICEINSTANCE, LPDIRECTINPUTDEVICE8, 
                                          DWORD, DWORD, LPVOID );
	void getOneName(int nr,char** name);
	void setDeviceSettings(int deviceNr);

private:    
	HWND                 m_hWnd;
    char				 userNames[MAXSTRING];
	int					 userDevice[MAXSPIELER][MAXDEVICES]; //Which device of the list has the user
	int					 anzSpieler;

    LPDIRECTINPUT8       m_pDI;
    LPDIRECTINPUTDEVICE8 m_pdidDevices[MAXDEVICES];
	int					 m_dwNumDevices;
    DIACTIONFORMAT       m_diaf;
};

#endif
