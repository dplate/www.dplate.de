//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "helpfunctions.h"
#include "kachel.h"

Kachel::Kachel(D3DXMATRIX      *matWorldSet,
		 Textures		 *texturesSet,
		 bool			  menueSet,
		 char *name, POINT pos,
		 CViewFrustum	 *viewFrustumSet)
{
	std::ifstream file;
	int i,zahl1 = -1,zahl2 = -1,zahl3 = -1,zahl4 = -1;
	char buffer[MAXSTRING];

	matWorld = matWorldSet;
	textures = texturesSet;
	menue = menueSet;
	viewFrustum = viewFrustumSet;

	for (i=0;i<4;i++) type.way[i] = -1;
	
	position.x = (float)pos.x;
	position.y = 0;
	position.z = (float)pos.y;

	file.open("ground.txt",std::ios::in);
	if (!file.is_open())
	{
		MessageBox(NULL,"Can't open file ground.txt",NULL,NULL);
		return;
	}
	i=0;
	while (file.getline(buffer,MAXSTRING))
	{
		DeleteBlanksOfString(buffer);	//Shorten string
		if (strcmp(buffer,name) == 0)
		{
			file.getline(type.texture,MAXSTRING);	//Den Texturnamen
			if (file.get() == 'y')
			{
				file >> zahl1; file.get();
				file >> zahl2; 
			}
			file.getline(buffer,MAXSTRING);
			if (file.get() == 'y')
			{
				file >> zahl3; file.get();
				file >> zahl4; 
			}
			file.getline(buffer,MAXSTRING);
			file >> type.reibung;file.get();
			file >> type.glaette;file.getline(buffer,MAXSTRING);
			if (file.get() == 'y')
			{
				file >> type.dustColor.r;file.get();
				file >> type.dustColor.g;file.get();
				file >> type.dustColor.b;file.getline(buffer,MAXSTRING);	
				type.dustColor.a = 1.0f;
				type.dust = true;
			}
			else type.dust = false;
							
			if (zahl1 != -1) type.way[zahl1] = zahl2;
			if (zahl2 != -1) type.way[zahl2] = zahl1;
			if (zahl3 != -1) type.way[zahl3] = zahl4;
			if (zahl4 != -1) type.way[zahl4] = zahl3;
			art = i;
			break;
		}
		for (i=0;i<ANZGROUNDLINES-1;i++) file.getline(buffer,MAXSTRING);
		i++;
	}
	file.close();
}

Kachel::~Kachel()
{
	
}

bool Kachel::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	D3DVERTEX3D2* pVertices;
	d3dDevice = d3dDeviceSet;
	
	D3DVERTEX3D2 g_Vertices[] =
	{
		{  KACHELBREITE+position.x, 0.0f, KACHELHOEHE+position.z, 0.0f, +1.0f, 0.0f, 1.0f, 1.0f},
		{  KACHELBREITE+position.x, 0.0f, position.z,			  0.0f, +1.0f, 0.0f, 1.0f, 0.0f},
		{  position.x,				0.0f, KACHELHOEHE+position.z, 0.0f, +1.0f, 0.0f, 0.0f, 1.0f},
		{  position.x,				0.0f, position.z,			  0.0f, +1.0f, 0.0f, 0.0f, 0.0f}, // x, y, z, tx, ty
	};

	texNr = textures->newTex(d3dDevice,type.texture);
	
	if (FAILED(d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX3D2),
		D3DUSAGE_WRITEONLY , D3DFVF_D3DVERTEX3D2,
		D3DPOOL_MANAGED, &g_pVB)))
	{
		MessageBox(NULL,"error: d3dDevice->CreateVertexBuffer() (Kachel::InitDeviceObjects())",NULL,NULL);
		return false;
	}
	
	//Vertexbuffer locken
	if (FAILED(g_pVB->Lock( 0, sizeof(g_Vertices),(BYTE**)&pVertices,0)))
	{
		MessageBox(NULL,"error: g_pVB->Lock() (Kachel::InitDeviceObjects())",NULL,NULL);
		return false;
	}
	memcpy( pVertices, g_Vertices, sizeof(g_Vertices) );
	g_pVB->Unlock();	//Vertexbuffer wieder freigeben
	
	ZeroMemory(&mat, sizeof(D3DMATERIAL8));
	mat.Diffuse.r = 1.0f;
	mat.Diffuse.g = 1.0f;
	mat.Diffuse.b = 1.0f;
	mat.Diffuse.a = 1.0f;
	mat.Ambient.r = 1.0f;
	mat.Ambient.g = 1.0f;
	mat.Ambient.b = 1.0f;
	mat.Ambient.a = 1.0f;

	//Create the bounding sphere
	D3DXComputeBoundingSphere(g_Vertices,4,D3DFVF_D3DVERTEX3D2,&bsM,&bsR);

	return true;
}

bool Kachel::Render()
{
	D3DXMATRIX  mat1,mat2;

	if ((viewFrustum == NULL) || (viewFrustum->CullSphere(&bsM,&bsR) != SPHERE_AUSSERHALB))
	{
		d3dDevice->SetMaterial(&mat);
		
		if (menue)
		{
			D3DXMatrixTranslation( &mat1, -0.25f/(menueScale), 0.0f, -4.0f);
			D3DXMatrixMultiply(&mat2,matWorld,&mat1);
			D3DXMatrixScaling(&mat1,menueScale,menueScale,menueScale);
			D3DXMatrixMultiply(&mat1,&mat2,&mat1);
			d3dDevice->SetTransform( D3DTS_WORLD, &mat1 );
		}
		else d3dDevice->SetTransform( D3DTS_WORLD, matWorld );
		
		if (texNr != -1) d3dDevice->SetTexture( 0, textures->getTex(texNr));
		d3dDevice->SetStreamSource( 0, g_pVB, sizeof(D3DVERTEX3D2) );
		d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX3D2);
		
		if (FAILED(d3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			MessageBox(NULL,"error: d3dDevice->DrawPrimitive() (Kachel::Render())",NULL,NULL);
			return false;
		}
	}
	return true;
}

bool Kachel::DeleteDeviceObjects()
{
	SAFE_RELEASE(g_pVB);

	return true;
}

int	 Kachel::getWay(int seite)
{
	return type.way[seite];
}


