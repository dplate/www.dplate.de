//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_KACHEL)
#define N_KACHEL

#include "konstanten.h"
#include "textures.h"
#include "viewfrustum.h"

struct GroundStruct
{
	char texture[MAXSTRING];
	int way[4];
	int reibung;				//how much brake the car on this ground?
	int glaette;				//how much slide the car on this ground?
	bool dust;					//make the ground dust?
	D3DXCOLOR dustColor;		//which color has the dust
};

class Kachel
{
public: 
	Kachel(D3DXMATRIX      *matWorldSet,
		 Textures		 *texturesSet,
		 bool			  menueSet,
		 char *name, POINT pos,
		 CViewFrustum	 *viewFrustumSet);
	~Kachel();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool DeleteDeviceObjects();
    bool Render();
	int getWay(int seite);

	D3DXVECTOR3 position;			//die linke/obere Ecke der Kachel
	int art;						//welche Art hat die Kachel

	GroundStruct	type;
	int				texNr;			//der Index der verwendeten Textur
	float			menueScale;		//how much must the kachel scale for the menue?
	
private:
	D3DXMATRIX      *matWorld;
    Textures		*textures;
	IDirect3DDevice8 *d3dDevice;
	CViewFrustum	 *viewFrustum;


	D3DMATERIAL8	mat;			//the normal material
		
	LPDIRECT3DVERTEXBUFFER8 g_pVB;	//Pointer zu einem VertexBuffer
	D3DXVECTOR3		bsM;			//the bounding-sphere-middle
	float			bsR;			//the bounding-sphere-radius

	bool			menue;			//where is shown this kachel
};

#endif