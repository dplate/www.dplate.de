//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "helpfunctions.h"
#include "karte.h"

Karte::Karte(D3DXMATRIX		*matWorldSet, 
			 Textures		*texturesSet,
			 char			*homeDirSet,
			 bool			menueSet,
			 KollisionList	*kL,
			 int			which,
			 CViewFrustum	*viewFrustumSet)
{
	int x,y,x1,y1;
	char zahl[3];
	char c;
	int	art;
	POINT pos;
	std::ifstream mapFile;
	XYFloat tmp0,tmp1;
	char mapFileName[MAXSTRING];
	char buffer[MAXSTRING];
	char buffer2[MAXSTRING];
	int i,j;
	int standardKachel;
	float menueScale;
	POINT startZielPos;
	int startRichtung;

	matWorld = matWorldSet;
	textures = texturesSet;
	homeDir  = homeDirSet;
	menue	 = menueSet;
	viewFrustum = viewFrustumSet;

	backTexNr		= NULL;
	anzRouteNodes = 0;
	startZiel = NULL;

	// Initialize the structure.
	ZeroMemory(&d3dLight, sizeof(D3DLIGHT8));

	//change in the home-directory
	if (_chdir(homeDir) == -1) 
	{
		MessageBox(NULL,homeDir,NULL,NULL);
		return;
	}
	//find the name of the file for this map
	mapFile.open("maps.txt",std::ios::in);		//die Kartendatei �ffnen
	if (!mapFile.is_open()) 
	{
		MessageBox(NULL,"Can't open file maps.txt",NULL,NULL);
		return;
	}
	for (j=0;j<which;j++)
	{
		mapFile.getline(buffer,MAXSTRING);
		while(mapFile.get() == 'y')	mapFile.getline(buffer,MAXSTRING);
		for (i=0;i<ANZMAPLINES;i++) mapFile.getline(buffer,MAXSTRING);
	}
	mapFile.getline(buffer,MAXSTRING);
	i=0;
	while(mapFile.get() == 'y')				//Die verwendeten Grounds durchgehen
	{
		if (i >= MAXMAPTEX)
		{
			MessageBox(NULL,"Too many different ground-textures", NULL,NULL);
			break;
		}
		mapFile.getline(groundNames[i],MAXSTRING); //Save the names of the used grounds
		DeleteBlanksOfString(groundNames[i]);		//Shorten the string
		i++;
	}
	mapFile.getline(buffer,MAXSTRING);
	mapFile.getline(mapFileName,MAXSTRING);	//read the name of the map-file
	mapFile.getline(buffer,MAXSTRING);
	mapFile >> standardKachel;				//read the number of the normal kachel
	mapFile.getline(buffer,MAXSTRING);
	mapFile.getline(backBmp,MAXSTRING);	//read the back textur name
	mapFile.getline(skyBmp,MAXSTRING);	//read the back textur name
	mapFile >> startZielPos.x;mapFile.get();//read the x-Coordinate of the Start/Ziel-Kachel
	mapFile >> startZielPos.y;mapFile.get();//read the y-Coordinate
	mapFile >> startRichtung;				//In which direction goes the start/Ziel
	mapFile.getline(buffer,MAXSTRING);
	mapFile >> d3dLight.Diffuse.r;mapFile.get();	//read the color of the light
	mapFile >> d3dLight.Diffuse.g;mapFile.get();
	mapFile >> d3dLight.Diffuse.b;mapFile.getline(buffer,MAXSTRING);
	mapFile >> d3dLight.Direction.x;mapFile.get();	//read the direction of the light
	mapFile >> d3dLight.Direction.y;mapFile.get();
	mapFile >> d3dLight.Direction.z;mapFile.getline(buffer,MAXSTRING);
	mapFile >> fogColor.r;mapFile.get();	//read the color of the fog
	mapFile >> fogColor.g;mapFile.get();
	mapFile >> fogColor.b;mapFile.getline(buffer,MAXSTRING);
	mapFile >> fogDensity;mapFile.getline(buffer,MAXSTRING); //the density of the fog
	mapFile.close();

	// Set up the rest of the light
	d3dLight.Type = D3DLIGHT_DIRECTIONAL;
	d3dLight.Ambient.r  = d3dLight.Diffuse.r;
	d3dLight.Ambient.g  = d3dLight.Diffuse.g;
	d3dLight.Ambient.b  = d3dLight.Diffuse.b;
	d3dLight.Specular.r = 0.8f;
	d3dLight.Specular.g = 0.8f;
	d3dLight.Specular.b = 0.8f;

	mapFile.open(mapFileName,std::ios::in);		//die Kartendatei �ffnen
	if (!mapFile.is_open()) 
	{
		strcpy_s(buffer,"Can't open file ");
		strcat_s(buffer,mapFileName);
		strcat_s(buffer," in the directory ");
		_getcwd(buffer2,MAXSTRING);
		strcat_s(buffer,buffer2);
		MessageBox(NULL,buffer,NULL,NULL);
		return;
	}
	for (x=0;x<KARTEBREITE;x++)
		for (y=0;y<KARTEHOEHE;y++)
			map[x][y] = NULL;		//Karte l�schen
	anzX = 0;
	anzY = 0;
	for (y=0;y<KARTEHOEHE;y++)
		for (x=0;x<KARTEBREITE;x++) //karte aus der Datei einlesen
	{
		c = mapFile.get();
		if (c == '\n') 	break;
		else if (c == EOF)
		{
			//calc the menueScale
			if (menue) menueScale = 0.5f/anzX;
			//fill up the landscape
			for (x1=0;x1<anzX;x1++)
				for (y1=0;y1<anzY;y1++) 
			{
				if (map[x1][y1] == NULL)
				{
					pos.x = x1*(int)KACHELBREITE;
					pos.y = y1*(int)KACHELHOEHE;
					map[x1][y1] = new Kachel(matWorld,textures,menue,groundNames[standardKachel],pos,viewFrustum);
				}
				if (menue) map[x1][y1]->menueScale = menueScale;
			}
			//insert the wall around the landscape
			if (!menue)
			{
				tmp0.x = 0;
				tmp0.y = 0;
				tmp1.x = anzX*KACHELBREITE;
				tmp1.y = 0;
				kL->newObject(tmp0,tmp1);
				tmp0.x = 0;
				tmp0.y = 0;
				tmp1.x = 0;
				tmp1.y = anzY*KACHELBREITE;
				kL->newObject(tmp0,tmp1);
				tmp0.x = anzX*KACHELBREITE;
				tmp0.y = anzY*KACHELBREITE;
				tmp1.x = 0;
				tmp1.y = anzY*KACHELBREITE;
				kL->newObject(tmp0,tmp1);
				tmp0.x = anzX*KACHELBREITE;
				tmp0.y = anzY*KACHELBREITE;
				tmp1.x = anzX*KACHELBREITE;
				tmp1.y = 0;
				kL->newObject(tmp0,tmp1);
			}
				
			startZiel = new RouteNode;
			startZiel->next = NULL;
			startZiel->teil = map[startZielPos.x][startZielPos.y];
			startZiel->pos.x = startZielPos.x;
			startZiel->pos.y = startZielPos.y;	
			makeRoute(startRichtung);			//die Strecke finden und aufbauen
			return;
		}
		if (x >= anzX) anzX = x+1;	//set the new width and height
		if (y >= anzY) anzY = y+1;
		zahl[0] = c;
		zahl[1] = mapFile.get();
		zahl[2] = '\0';
		if (zahl[1] == '\n') break;	//if only one character, then next line
		if (strcmp(zahl,"  ") == 0) art = standardKachel;
		else art = atoi(zahl);
		pos.x = x*(int)KACHELBREITE;
		pos.y = y*(int)KACHELHOEHE;
		map[x][y] = new Kachel(matWorld,textures,menue,groundNames[art],pos,viewFrustum);
	}
	MessageBox(NULL,"Error while loading map",NULL,NULL);
}

Karte::~Karte()
{
	int x,y;
	RouteNode* pos = startZiel;
	RouteNode* tmpPos;
	RouteNode* tmpPos2 = startZiel;

	for (x=0;x<KARTEBREITE;x++)
		for (y=0;y<KARTEHOEHE;y++) SAFE_DELETE(map[x][y]);
		
	if (startZiel != NULL)
	{
		while(1)
		{
			tmpPos = pos->next;
			SAFE_DELETE(pos);
			if (tmpPos == NULL) return;
			pos = tmpPos;
			if (pos = tmpPos2) return;	//einmal rum;
		}
	}
}

bool Karte::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	int x,y;
	bool check = true;
	
	D3DVERTEX3D2* pVertices;

	d3dDevice = d3dDeviceSet;

	for (x=0;x<KARTEBREITE;x++)
		for (y=0;y<KARTEHOEHE;y++) 
		{
			if (map[x][y] != NULL) 
			{
				check = check && map[x][y]->InitDeviceObjects(d3dDevice);
			}
		}
	if (!check)
	{
		MessageBox(NULL,"error: map[x][y]->InitDeviceObjects() (Karte::InitDeviceObjects())",NULL,NULL);
		return false;
	}
	
	if (!menue)
	{
		//make the back
		D3DVERTEX3D2 b_Vertices[] =
		{
			//one side
			{  100.0f,	12.0f,	100.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.0f},
			{  100.0f,	12.0f,	50.0f,	-1.0f, 0.0f, 0.0f,	1.0f,	0.0f}, // x, y, z, tx, ty
			{  100.0f,	-0.1f,	100.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.25f},
			{  100.0f,	-0.1f,	50.0f,	-1.0f, 0.0f, 0.0f,	1.0f,	0.25f},
			
			{  100.0f,	12.0f,	50.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.255f},
			{  100.0f,	12.0f,	0.0f,	-1.0f, 0.0f, 0.0f,	1.0f,	0.255f}, // x, y, z, tx, ty
			{  100.0f,	-0.1f,	50.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.5f},
			{  100.0f,	-0.1f,	0.0f,	-1.0f, 0.0f, 0.0f,	1.0f,	0.5f},
			
			{  100.0f,	12.0f,	0.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.505f},
			{  100.0f,	12.0f,	-50.0f,	-1.0f, 0.0f, 0.0f,	1.0f,	0.505f}, // x, y, z, tx, ty
			{  100.0f,	-0.1f,	0.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.75f},
			{  100.0f,	-0.1f,	-50.0f,	-1.0f, 0.0f, 0.0f,	1.0f,	0.75f},
			
			{  100.0f,	12.0f,	-50.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	0.755f},
			{  100.0f,	12.0f,	-100.0f,-1.0f, 0.0f, 0.0f,	1.0f,	0.755f}, // x, y, z, tx, ty
			{  100.0f,	-0.1f,	-50.0f,	-1.0f, 0.0f, 0.0f,	0.0f,	1.0f},
			{  100.0f,	-0.1f,	-100.0f,-1.0f, 0.0f, 0.0f,	1.0f,	1.0f},
			
			//the blue sky (not the clouds)
			{  100.0f,	11.9f,	-100.0f,0.0f, -1.0f, 0.0f,	0.0f,	0.0f},
			{  100.0f,	11.9f,	100.0f,	0.0f, -1.0f, 0.0f,	0.0f,	0.0f}, // x, y, z, tx, ty
			{  -100.0f,	11.9f,	-100.0f,0.0f, -1.0f, 0.0f,	0.0f,	0.0f},
			{  -100.0f,	11.9f,	100.0f,	0.0f, -1.0f, 0.0f,	0.0f,	0.0f},
			
			//the floor (you shouldn't see this)
			{  101.0f,	-0.05f,	101.0f,	0.0f, +1.0f, 0.0f,	0.0f,	0.0f},
			{  101.0f,	-0.05f,	-101.0f,0.0f, +1.0f, 0.0f,	0.0f,	200.0f}, // x, y, z, tx, ty
			{  -101.0f,	-0.05f,	101.0f,	0.0f, +1.0f, 0.0f,	200.0f,	0.0f},
			{  -101.0f,	-0.05f,	-101.0f,0.0f, +1.0f, 0.0f,	200.0f,	200.0f},
		};
		
		floorTexNr = map[0][0]->texNr;	//take the standard kachel as floor-textur
		backTexNr = textures->newTex(d3dDevice,backBmp);
		if (FAILED(d3dDevice->CreateVertexBuffer( 24*sizeof(D3DVERTEX3D2),
			D3DUSAGE_WRITEONLY , D3DFVF_D3DVERTEX3D2,
			D3DPOOL_MANAGED, &backVB)))
		{
			MessageBox(NULL,"error: d3dDevice->CreateVertexBuffer() (Kachel::InitDeviceObjects())",NULL,NULL);
			return false;
		}
		
		//Vertexbuffer locken
		if (FAILED(backVB->Lock( 0, sizeof(b_Vertices),(BYTE**)&pVertices,0)))
		{
			MessageBox(NULL,"error: backVB->Lock() (Kachel::InitDeviceObjects())",NULL,NULL);
			return false;
		}
		memcpy( pVertices, b_Vertices, sizeof(b_Vertices) );
		backVB->Unlock();	//Vertexbuffer wieder freigeben
		
		
		//make the sky-vertex
		D3DVERTEX3D2 g_Vertices[] =
		{
			{  -100.0f,8.0f, 100.0f, 0.0f, -1.0f, 0.0f, 0.0f, 10.0f},
			{  -100.0f,8.0f, -100.0f,0.0f, -1.0f, 0.0f, 0.0f, 0.0f}, // x, y, z, nx, ny ,nz, tx, ty
			{  100.0f, 8.0f, 100.0f, 0.0f, -1.0f, 0.0f, 10.0f, 10.0f},
			{  100.0f, 8.0f, -100.0f,0.0f, -1.0f, 0.0f, 10.0f, 0.0f},
		};
		
		skyTexNr = textures->newTex(d3dDevice,skyBmp);
		if (FAILED(d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX3D2),
			D3DUSAGE_WRITEONLY , D3DFVF_D3DVERTEX3D2,
			D3DPOOL_MANAGED, &skyVB)))
		{
			MessageBox(NULL,"error: d3dDevice->CreateVertexBuffer() (Kachel::InitDeviceObjects())",NULL,NULL);
			return false;
		}
		
		//Vertexbuffer locken
		if (FAILED(skyVB->Lock( 0, sizeof(g_Vertices),(BYTE**)&pVertices,0)))
		{
			MessageBox(NULL,"error: skyVB->Lock() (Kachel::InitDeviceObjects())",NULL,NULL);
			return false;
		}
		memcpy( pVertices, g_Vertices, sizeof(g_Vertices) );
		skyVB->Unlock();	//Vertexbuffer wieder freigeben
		
		//make the normal material
		D3DUtil_InitMaterial( skyMat, 1.0f, 1.0f, 1.0f );
	}
	return true;
}

bool Karte::RestoreDeviceObjects()
{
	// Set the property information for the first light.
	d3dDevice->SetLight(0, &d3dLight);
    if (FAILED(d3dDevice->LightEnable(0, true)))
	{
		MessageBox(NULL,"Error: d3dDevice->LightEnable() (Race::RestoreDeviceObjects)",NULL,NULL);
		return false;
	}

	if (fogDensity != 0.0f)
	{
		//Set fog
		float fFogStart	  = -0.0f;
		float fFogEnd	  = 120.0f;
		d3dDevice->SetRenderState(D3DRS_FOGENABLE,TRUE);
		d3dDevice->SetRenderState(D3DRS_FOGDENSITY,*((DWORD*) (&fogDensity)));
		d3dDevice->SetRenderState(D3DRS_FOGCOLOR,
			D3DCOLOR_COLORVALUE(fogColor.r,fogColor.g,fogColor.b,fogColor.a));
		d3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE,false);
		d3dDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_EXP);
		d3dDevice->SetRenderState(D3DRS_FOGSTART, *((DWORD*) (&fFogStart)));
		d3dDevice->SetRenderState(D3DRS_FOGEND, *((DWORD*) (&fFogEnd)));
	}
	else d3dDevice->SetRenderState(D3DRS_FOGENABLE,false);
	return true;
}

bool Karte::Render()
{
	int x,y;
	int i,j;
	bool check = true;
	D3DXMATRIX  mat;

	d3dDevice->SetMaterial(&skyMat);
	
	//render the landscape
	for (x=0;x<KARTEBREITE;x++)
		for (y=0;y<KARTEHOEHE;y++) 
		{
			if (map[x][y] != NULL) check = check && map[x][y]->Render();
		}

	if (!check)
	{
		MessageBox(NULL,"error: map[x][y]->Render() (Karte::Render())",NULL,NULL);
		return false;
	}

	if (!menue)
	{
		// Turn off D3D lighting
		d3dDevice->SetRenderState( D3DRS_LIGHTING, false );
		//render the back
		if (backTexNr != -1) d3dDevice->SetTexture( 0, textures->getTex(backTexNr));
		d3dDevice->SetStreamSource( 0, backVB, sizeof(D3DVERTEX3D2) );
		d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX3D2 );
		for (j=0;j<4;j++)
		{
			D3DXMatrixRotationY( &mat, (float)j*pi/2);
			D3DXMatrixMultiply( &mat, matWorld, &mat );
			d3dDevice->SetTransform( D3DTS_WORLD, &mat);
			for (i=0;i<4;i++)
			{
				if (FAILED(d3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, i*4, 2)))
				{
					MessageBox(NULL,"error: d3dDevice->DrawPrimitive() (Karte::Render())",NULL,NULL);
					return false;
				}
			}
		}
		//render the blue sky (not the clouds)
		d3dDevice->SetTransform( D3DTS_WORLD, matWorld );
		if (FAILED(d3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 16, 2)))
		{
			MessageBox(NULL,"error: d3dDevice->DrawPrimitive() (Karte::Render())",NULL,NULL);
			return false;
		}

		// Turn on D3D lighting
		d3dDevice->SetRenderState( D3DRS_LIGHTING, true );

		//render the floor
		if (floorTexNr != -1) d3dDevice->SetTexture( 0, textures->getTex(floorTexNr));
		d3dDevice->SetTransform( D3DTS_WORLD, matWorld );
		if (FAILED(d3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 20, 2)))
		{
			MessageBox(NULL,"error: d3dDevice->DrawPrimitive() (Karte::Render())",NULL,NULL);
			return false;
		}
		//render the sky
		d3dDevice->SetTransform( D3DTS_WORLD, matWorld );
		if (skyTexNr != -1) d3dDevice->SetTexture( 0, textures->getTex(skyTexNr));
		d3dDevice->SetStreamSource( 0, skyVB, sizeof(D3DVERTEX3D2) );
		
		// Set diffuse blending for alpha set in vertices.
		d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
		d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
		d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
		
		// Enable alpha testing (skips pixels with less than a certain alpha.)
		d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
		d3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
		d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
		
		d3dDevice->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_MIRROR);
		d3dDevice->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_MIRROR);
		
		d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX3D2 );
		if (FAILED(d3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			MessageBox(NULL,"error: d3dDevice->DrawPrimitive() (Karte::Render())",NULL,NULL);
			return false;
		}
		d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
		d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );
	}
	return true;
}

bool Karte::DeleteDeviceObjects()
{
	int x,y;
	bool check = true;

	for (x=0;x<KARTEBREITE;x++)
		for (y=0;y<KARTEHOEHE;y++) 
		{
			if (map[x][y] != NULL) check = check && map[x][y]->DeleteDeviceObjects();
		}

	if (!check)
	{
		MessageBox(NULL,"error: map[x][y]->DeleteDeviceObjects() (Karte::DeleteDeviceObjects())",NULL,NULL);
		return false;
	}

	if (!menue)
	{
		SAFE_RELEASE(backVB);
		SAFE_RELEASE(skyVB);
	}
	return true;
}

void Karte::makeRoute(int startRichtung)
{
	POINT aktPos;
	int richtung,newRichtung;
	RouteNode* pos = startZiel;
	bool flag = false;
	char buffer[MAXSTRING], buffer2[MAXSTRING];

	aktPos = startZiel->pos;
	richtung = startRichtung;
	
	while(1)
	{
		if (map[aktPos.x][aktPos.y] == NULL)
		{
			strcpy_s(buffer,"Route get out of the map at ");
			_itoa_s(aktPos.x,buffer2,10);
			strcat_s(buffer,buffer2);
			strcat_s(buffer,"/");
			_itoa_s(aktPos.y,buffer2,10);
			strcat_s(buffer,buffer2);
			MessageBox(NULL,buffer,NULL,NULL);
			break;
		}
		if ((map[aktPos.x][aktPos.y] == startZiel->teil) && (flag)) //start/ziel wieder erreicht
		{
			if (map[aktPos.x][aktPos.y]->getWay(richtung) == startRichtung)
			{
				strcpy_s(buffer,"Route ended not at the start at ");
				_itoa_s(aktPos.x,buffer2,10);
				strcat_s(buffer,buffer2);
				strcat_s(buffer,"/");
				_itoa_s(aktPos.y,buffer2,10);
				strcat_s(buffer,buffer2);
				MessageBox(NULL,buffer,NULL,NULL);
				break;
			}
			pos->next = startZiel;
			break;	
		}
		newRichtung = map[aktPos.x][aktPos.y]->getWay(richtung);
		if (newRichtung == -1)		//Kein passendes Teil vorhanden
		{
			strcpy_s(buffer,"Wrong Route at ");
			_itoa_s(aktPos.x,buffer2,10);
			strcat_s(buffer,buffer2);
			strcat_s(buffer,"/");
			_itoa_s(aktPos.y,buffer2,10);
			strcat_s(buffer,buffer2);
			MessageBox(NULL,buffer,NULL,NULL);
			break;
		}
		if (flag)
		{
			pos->next = new RouteNode;	//neues Streckenteil an Streckenverlauf anh�ngen
			pos = pos->next;
			pos->pos = aktPos;
			pos->next = NULL;
			pos->teil = map[aktPos.x][aktPos.y];
		}
		richtung = (newRichtung+2)%4;
		switch(newRichtung)
		{
		case 0:
			aktPos.y--;
			break;
		case 1:
			aktPos.x++;
			break;
		case 2:
			aktPos.y++;
			break;
		case 3:
			aktPos.x--;
			break;
		}
		anzRouteNodes++;
		
		flag = true;
	}
}

