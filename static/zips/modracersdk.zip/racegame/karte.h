//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_KARTE)
#define N_KARTE

#include "konstanten.h"
#include "kachel.h"
#include "textures.h"
#include "kollisionlist.h"
#include "viewfrustum.h"

struct RouteNode		//ein Streckenteil
{
	RouteNode* next;	//Pointer zum nachfolgenden Teil
	Kachel* teil;		//Pointer auf die Kachel
	POINT	pos;		//Position der Kachel in Kacheleinheiten
};

class Karte
{
public: 
	Karte(D3DXMATRIX      *matWorldSet,
		  Textures		  *texturesSet,
		  char			  *homeDirSet,
		  bool			  menueSet,
		  KollisionList   *kL,
		  int			   which,
		  CViewFrustum	  *viewFrustumSet);
	~Karte();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
	bool RestoreDeviceObjects();
    bool DeleteDeviceObjects();
    bool Render();
       
	RouteNode* startZiel;		//Pointer zur Start/Ziel-Kachel
	int	 anzRouteNodes;			//How many streets from Start to Ziel
	Kachel *map[KARTEBREITE][KARTEHOEHE];	//2-Dimensonales Feld mit Pointern zu jeder Kachel
	int anzX;					//how big is the landscape
	int anzY;	


private:
	void makeRoute(int startRichtung);	//erstellt die Strecke (und pr�ft den Streckenverlauf)
	
	D3DXMATRIX      *matWorld;
    Textures		*textures;
	char			*homeDir;
	IDirect3DDevice8 *d3dDevice;
	CViewFrustum	 *viewFrustum;

	char					backBmp[MAXSTRING];		//which texturfile
	int						backTexNr;				//the backtexture
	LPDIRECT3DVERTEXBUFFER8 backVB;					//the sky vertex buffer
	int						floorTexNr;				//the floortexture

	char					skyBmp[MAXSTRING];		//which texturfile
	int						skyTexNr;				//the skytexture
	LPDIRECT3DVERTEXBUFFER8 skyVB;					//the sky vertex buffer
	D3DMATERIAL8			skyMat;					//the normal material

	char			groundNames[MAXMAPTEX][MAXSTRING];	//The name of the used ground-textures

	D3DLIGHT8			d3dLight;		//the sun

	float				fogDensity;		//The density of the fog
	D3DCOLORVALUE		fogColor;		//The color of the fog

	bool menue;					//where is the map shown
};

#endif