//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "kollisionlist.h"
#include "helpfunctions.h"

KollisionList::KollisionList()
{
	anz = 0;
}

KollisionList::~KollisionList()
{
}

int KollisionList::newObject(XYFloat p1, XYFloat p2)
{
	if (p1.x < p2.x) 
	{
		list[anz].kachelPos1.x = p1.x;
		list[anz].kachelPos2.x = p2.x;
	}
	else 
	{
		list[anz].kachelPos1.x = p2.x;
		list[anz].kachelPos2.x = p1.x;
	}
	if (p1.y < p2.y) 
	{
		list[anz].kachelPos1.y = p1.y;
		list[anz].kachelPos2.y = p2.y;
	}
	else 
	{
		list[anz].kachelPos1.y = p2.y;
		list[anz].kachelPos2.y = p1.y;
	}

	list[anz].punkt1 = p1;
	list[anz].punkt2 = p2;
	anz++;
	return anz-1;
}

void KollisionList::updateObject(int nr, XYFloat p1, XYFloat p2)
{
	if (p1.x < p2.x) 
	{
		list[nr].kachelPos1.x = p1.x;
		list[nr].kachelPos2.x = p2.x;
	}
	else 
	{
		list[nr].kachelPos1.x = p2.x;
		list[nr].kachelPos2.x = p1.x;
	}
	if (p1.y < p2.y) 
	{
		list[nr].kachelPos1.y = p1.y;
		list[nr].kachelPos2.y = p2.y;
	}
	else 
	{
		list[nr].kachelPos1.y = p2.y;
		list[nr].kachelPos2.y = p1.y;
	}
	list[nr].punkt1 = p1;
	list[nr].punkt2 = p2;
}

bool KollisionList::getObject(int nr, XYFloat *p1, XYFloat *p2)
{
	if (nr >= anz) return false;

	p1->x = list[nr].punkt1.x;
	p1->y = list[nr].punkt1.y;
	p2->x = list[nr].punkt2.x;
	p2->y = list[nr].punkt2.y;
	return true;
}

int KollisionList::checkKollision(XYFloat *erg1, XYFloat *erg2, XYFloat *sPunkt, 
				   int *ignoreList, int anzIgnore, bool nearest)
{
	int i,j,bestI = -1;
	float newAbstand,bestAbstand = 1001;
	XYFloat newSPunkt;
	XYFloat tmpVector;
		
	for (i=0;i<anz;i++)		//Alle Objekte durchgehen
	{	
		if (!list[i].check) continue;	//don't check this
		if ((cLKPos1.x > list[i].kachelPos2.x) || 
			(cLKPos1.y > list[i].kachelPos2.y) || 
			(cLKPos2.x < list[i].kachelPos1.x) || 
			(cLKPos2.y < list[i].kachelPos1.y)) 
		{
			list[i].check = false;	//don't check this anymore
			continue; //Objekte, die nicht in Reichweite sind, ignorieren
		}
		for (j=0;j<anzIgnore;j++) if (ignoreList[j] == i) break; 
		if (j != anzIgnore) continue;	//ignore this line
		newSPunkt = Schnittpunkt(cL1,cL2,list[i].punkt1,list[i].punkt2);
		if ((newSPunkt.x == -1) && (newSPunkt.y == -1)) continue; //keine Kollision
		if (nearest)	//take the nearest point
		{
			tmpVector.x = cL1.x-newSPunkt.x;
			tmpVector.y = cL1.y-newSPunkt.y;
			newAbstand=GetBetrag(tmpVector);
			if (newAbstand < bestAbstand) //find the nearest SPunkt
			{
				erg1->x = list[i].punkt1.x;
				erg1->y = list[i].punkt1.y;
				erg2->x = list[i].punkt2.x;
				erg2->y = list[i].punkt2.y;
				sPunkt->x = newSPunkt.x;
				sPunkt->y = newSPunkt.y;
				bestAbstand = newAbstand;
				bestI = i;
			}
		}
		else		//take the first found point
		{
			erg1->x = list[i].punkt1.x;
			erg1->y = list[i].punkt1.y;
			erg2->x = list[i].punkt2.x;
			erg2->y = list[i].punkt2.y;
			sPunkt->x = newSPunkt.x;
			sPunkt->y = newSPunkt.y;
			return i;
		}
	}
	return bestI;
}

void KollisionList::setCheckLine(XYFloat p1, XYFloat p2)
{
	int i;

	//save the line
	cL1.x = p1.x;
	cL1.y = p1.y;
	cL2.x = p2.x;
	cL2.y = p2.y;

	//get the rectangle around this line
	if (p1.x < p2.x) 
	{
		cLKPos1.x = p1.x;
		cLKPos2.x = p2.x;
	}
	else 
	{
		cLKPos1.x = p2.x;
		cLKPos2.x = p1.x;
	}
	if (p1.y < p2.y) 
	{
		cLKPos1.y = p1.y;
		cLKPos2.y = p2.y;
	}
	else 
	{
		cLKPos1.y = p2.y;
		cLKPos2.y = p1.y;
	}

	for (i=0;i<anz;i++)	list[i].check = true;	//the first time, check all
}
