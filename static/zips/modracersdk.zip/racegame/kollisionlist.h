//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_KOLLISIONLIST)
#define N_KOLLISIONLIST

#include "konstanten.h"

class KollisionList
{
public: 
	KollisionList();
	~KollisionList();
	int newObject(XYFloat p1, XYFloat p2);
	void updateObject(int nr, XYFloat p1, XYFloat p2);	//�berschreibt eine bestimmte Wand in der Liste
	bool getObject(int nr, XYFloat *p1, XYFloat *p2);	//Gibt eine bestimmte Wand zur�ck
	int checkKollision(XYFloat *erg1, XYFloat *erg2, XYFloat *sPunkt,
			int *ignoreList, int anzIgnore, bool nearest);	//Pr�ft, ob sich die Gerade p mit irgendeiner Geraden kreuzt (bei Bedarf werden Linien ignoriert)
	void setCheckLine(XYFloat p1, XYFloat p2);	//set a new Line to test
private:
	struct KollisionListStruct
	{
		XYFloat	kachelPos1;			//in welchem Bereich befindet sich die Wand
		XYFloat	kachelPos2;			//(auf allen zwischen Pos1 und Pos2)
		XYFloat punkt1;				//der Anfang der Wand
		XYFloat punkt2;				//das Ende der Wand
		bool	check;				//true if in the near else fals
	} list[MAXKOLLISIONLIST];
	int anz;						//wieviele W�nde sind eingetragen
	XYFloat cL1;					//Point1 of the checkline
	XYFloat cL2;					//Point2 of the checkline
	XYFloat cLKPos1;				//KachelPos of the checkline	
	XYFloat cLKPos2;
};

#endif