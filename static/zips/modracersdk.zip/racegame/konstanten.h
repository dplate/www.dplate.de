//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_KONST)
#define N_KONST

#include "text.h"

const float pi = 3.1415926535897932384626433832795f;
const float e = 2.718281828f;
const int	MAXSTRING = 1024;	//How many chars for a big string?

const char	FONTNAME[] = "Bank Gothic Medium BT";	//the standard-font
const char	FONTFILE[] = "bank.ttf";

const int	MAXKOLLISIONLIST = 1000;
const int	MAXSPIELER = 4;		//How many human players maximal
const int	MAXAUTOS = 4;		//How many cars?
const int	MAXCARTYPES = 100;	//how many different car types?
const int	ANZCARLINES = 9;	//How many lines have one car-section in autos.txt
const int	ID_CARS	= 20000;	//the menue-id's of the cars
const int	ANZMAPLINES = 11;	//How many lines have one map-section in map.txt (without the y's)
const int	ID_MAPS	= 21000;	//the menue-id's of the maps
const int	MAXOBJECTS = 500;
const int	ID_PLAYER = 22000;	//the menue-id's of the player-menu
const int	ANZGROUNDLINES = 6;	//how many lines in the grounds.txt
const int	ID_RUNDEN = 23000;	//The menue_id's of the rounds

const int	MAXTESTTEXT = 15;	//How many message texts?	
const int	MAXTESTLINE = 500;	//How many test lines?	
const int	MAXSKIDMARKS = 5;	//How many skidmarks?
const int	MAXSKIDMARKSVERT = 40;	//How many vertices in one skidmark?
const int	MAXSMOKES = 200;	//How many smoke?
const float	SMOKETIME = 0.1f;	//How many times should the smoke apears?
const int	MAXCAMS = 20;		//How many different cams for one car?

const int	MAXMAPTEX = 50;		//Wieviele verschiedene Bodentexturen gibt es maximal auf der Karte
const int	MAXTEX = 200;		//Wieviele verschiedene Texturen maximal insgesamt?
const float KACHELHOEHE = 1.0f;
const float KACHELBREITE= 1.0f;
const int	KARTEHOEHE  = 100;
const int	KARTEBREITE = 100;
const int	KACHELEINHEIT = 10;	//How many metres has one kachel?

const float KIKORREKT = 0.1f;		//Der Computer steuert nicht genau auf die Ecken, sondern ein wenig in die Kachel rein
const float LENKANPASSUNG = 1.0f;	//So schnell passt sich die Lenkrichtung der Wunschlenkrichtung an
const float LENKANPASSUNGZ = 4.0f;	//und so schnell schnellt es zur�ck in die Normalposition
const float GASANPASSUNG = 4.0f;	//wie sich das Gaspedal der Wunschgaspedalstellung anpasst
const float MAXLENKWINKEL = 0.5f;

const int	SECONDSTOSTART = 5;		//How many seconds until the game start
const int	MAXRUNDENLIST = 5;		//How many items has the rundenlist
const int	RUNDENLIST[MAXRUNDENLIST] = {1,2,4,8,16};

const float	TACHOWIDTH = 0.3f;		//How many % has the tacho of the screen

const int	STREETLENGTH = 50;		//How long is the street in the credits 

//Die Spielzust�nde
const int   SZMENUE		= 0;		//im Men�
const int	SZSPIEL		= 1;		//im eigentlichen Rennspiel	
const int	SZEXIT		= 2;		//beendet das Spiel
const int	SZCREDITS	= 3;		//game in the credits
const int	SZTITEL		= 4;		//the start image

//The RaceStates
const int	RSBEFORESTART	= 0;	//before start of race
const int	RSINRACE		= 1;	//in the race
const int	RSLASTROUND		= 2;	//one is in finish, then only one more round
const int	RSAFTERZIEL		= 3;	//all cars in finish
const int	RSPAUSE			= 4;	//Pause the game and show the exit menue


//the directories
const char	TEXDIR[] = "\\textures\\";	
const char	MODELSDIR[] = "\\models\\";
const char	SOUNDDIR[] = "\\sounds\\";

//the inputs
#define INPUT_LEFTRIGHT_AXIS   1L
#define INPUT_UPDOWN_AXIS      2L
#define INPUT_STEERLEFT        3L
#define INPUT_STEERRIGHT       4L
#define INPUT_UP			   5L
#define INPUT_DOWN			   6L
#define INPUT_UP_AXIS		   7L
#define INPUT_DOWN_AXIS        8L
#define	INPUT_CHANGECAM		   9L
#define INPUT_REVERSE		   10L
#define INPUT_RESET			   11L
#define NUMBER_OF_SEMANTICS 19

const int MAXAXIS = 100;			//the maximum of the joystick axies
const int BUFFER_SIZE = 16;			//The buffer size for the inputs
const int MAXDEVICES = 20;			//how many input devices maximal

struct XYFloat
{
	float x;
	float y;
};

struct D3DVERTEX3D2
{
	D3DVECTOR	p;
	D3DVECTOR	n;
    FLOAT		tx,ty;
};
#define D3DFVF_D3DVERTEX3D2 (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)

struct D3DVERTEX2D 
{
    float x, y;      // screen position    
    float z;         // Z-buffer depth    
    float rhw;       // reciprocal homogeneous W    
	float tx, ty;	// texture coordinates
};
#define D3DFVF_D3DVERTEX2D (D3DFVF_XYZRHW | D3DFVF_TEX1)

struct D3DVERTEX2D2 
{
    float x, y;      // screen position    
    float z;         // Z-buffer depth    
    float rhw;       // reciprocal homogeneous W    
	D3DCOLOR diffuse;// color of this vertices
};
#define D3DFVF_D3DVERTEX2D2 (D3DFVF_XYZRHW | D3DFVF_DIFFUSE )

struct RACEINIT
{
	int		anzCarTypes;//How many car-type
	int		whichCar[MAXAUTOS];	//Which car drive the player
	char	playerNames[MAXAUTOS][MAXSTRING]; //The names of the players
	int		map;		//Which map
	int		anzRunden;	//How many rounds to drive
	int		anzPlayer;	//How many human player in the game
};

#endif