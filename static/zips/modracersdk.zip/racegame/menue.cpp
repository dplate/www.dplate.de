//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#define STRICT
#include "stdafx.h"
#include "Menue.h"

Menue::Menue(IDirect3DDevice8 *d3dDeviceSet,
		   D3DXMATRIX      *matWorldSet,
		   D3DXMATRIX      *matViewSet,
		   D3DXMATRIX      *matProjSet,
		   FLOAT           *fElapsedTimeSet,
		   char			   *homeDirSet,
		   TestText		   *testTextSet,
		   TestLine		   *testLineSet,
		   HWND			   mhWndSet,
		   RACEINIT		   *raceInitSet,
		   CInputDeviceManager *inputDeviceManagerSet)
{
	int i;
	char buffer[MAXSTRING];

	d3dDevice = d3dDeviceSet;
	matWorld = matWorldSet;
	matView = matViewSet;
	matProj = matProjSet;
	fElapsedTime = fElapsedTimeSet;
	homeDir	= homeDirSet;
	testText = testTextSet;
	testLine = testLineSet;
	mhWnd = mhWndSet;
	raceInit = raceInitSet;
	inputDeviceManager = inputDeviceManagerSet;

	//make menueItems
	startItem = new MenueItem;
	strcpy_s(startItem->string,TXTSTARTRACE);
	autoItem = new MenueItem[MAXAUTOS];
	karteItem = new MenueItem;
	playerItem = new MenueItem;
	rundenItem = new MenueItem;
	creditsItem = new MenueItem;
	strcpy_s(creditsItem->string,TXTCREDITS);
	exitItem = new MenueItem;
	strcpy_s(exitItem->string,TXTEXITGAME);
	startItem->next = karteItem;
	karteItem->next = playerItem;
	playerItem->next = rundenItem;
	rundenItem->next = &autoItem[0];
	for (i=0;i<MAXAUTOS-1;i++) autoItem[i].next = &autoItem[i+1];
	autoItem[MAXAUTOS-1].next = creditsItem;
	creditsItem->next = exitItem;
	exitItem->next = startItem;
	startItem->before = exitItem;
	karteItem->before = startItem;
	playerItem->before = karteItem;
	rundenItem->before = playerItem;
	autoItem[0].before = rundenItem;
	for (i=1;i<MAXAUTOS;i++) autoItem[i].before = &autoItem[i-1];
	creditsItem->before = &autoItem[MAXAUTOS-1];
	exitItem->before = creditsItem;
	aktItem = startItem;

	//Die Textureverwaltungsklasse einrichten
	textures = new Textures(homeDir,testText);

	//Make prolschrift
	font = new CD3DFont((char*)FONTNAME, 50);
	angle = 0;
	
	aktAuto = new Auto(	matWorld,
		&vEyePt,
		&vLookatPt,
		fElapsedTime,
		textures,
		homeDir,
		testText,
		testLine,
		NULL,
		NULL,
		NULL,
		true,
		0,
		0,
		NULL,
		NULL,
		NULL,
		false,
		raceInit->whichCar[0],
		NULL,
		NULL,
		NULL,
		NULL,
		NULL);
	aktKarte = new Karte(matWorld, textures, homeDir,true,NULL,raceInit->map,NULL);

	if (!OneTimeSceneInit())
	{
		MessageBox(NULL,"Error: Menue->OneTimeSceneInit() (2)",NULL,NULL);
		return;
	}
	if (!InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: Menue->InitDeviceObjects() (2)",NULL,NULL);
		return;
	}
	if (!RestoreDeviceObjects())
	{
		MessageBox(NULL,"Error: Menue->RestoreDeviceObjects() (2)",NULL,NULL);
		return;
	}

	anzCars = 0;
	anzMaps = 0;

	strcpy_s(buffer,homeDir);
	strcat_s(buffer,SOUNDDIR);
	if (_chdir(buffer) == -1) MessageBox(NULL,buffer,NULL,NULL);
	music = FMUSIC_LoadSong("menue.mid");
	if (!music)
	{
		printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
		exit(1);
	}
	selectSoundSample = FSOUND_Sample_Load(FSOUND_FREE, "select.wav", FSOUND_HW3D | FSOUND_LOOP_OFF, 0, 0);
	selectSoundBuffer = -1;

	makeMenue();
}

Menue::~Menue()
{
	SAFE_DELETE(font);

	DeleteDeviceObjects();
	FinalCleanup();

	DeleteMenu(GetMenu(mhWnd),1,MF_BYPOSITION);
	DeleteMenu(GetMenu(mhWnd),1,MF_BYPOSITION);
	DeleteMenu(GetMenu(mhWnd),1,MF_BYPOSITION);
	DeleteMenu(GetMenu(mhWnd),1,MF_BYPOSITION);
	DrawMenuBar(mhWnd);
	SAFE_DELETE(textures);
	SAFE_DELETE(aktAuto);
	SAFE_DELETE(aktKarte);

	//delete menueItems
	delete startItem;
	delete karteItem;
	delete rundenItem;
	delete playerItem;
	SAFE_DELETE_ARRAY(autoItem);
	delete creditsItem;
	delete exitItem;

	FMUSIC_StopSong(music);
	FMUSIC_FreeSong(music);
	FSOUND_StopSound(selectSoundBuffer);
}

bool Menue::OneTimeSceneInit()
{
	return true;
}


bool Menue::FrameMove()
{
	D3DXMATRIX mat1;
	MenueItem *akt;
	int i;

	angle+=(*fElapsedTime);

	D3DXMatrixScaling(&matFontTitel,0.01f,0.01f,0.01f);
	D3DXMatrixRotationAxis(&mat1, &D3DXVECTOR3(1.0f,0.0f,0.0f),angle);
	D3DXMatrixMultiply(&matFontTitel,&matFontTitel,&mat1);
	D3DXMatrixTranslation(&mat1, 0.0f,0.165f,0.0f);
	D3DXMatrixMultiply(&matFontTitel,&matFontTitel,&mat1);

	i=0;
	akt = aktItem;
	do
	{
		if (akt == aktItem)
			D3DXMatrixScaling(&(akt->mat),0.006f,0.006f,0.006f);
		else 
			D3DXMatrixScaling(&(akt->mat),0.005f,0.005f,0.005f);
		D3DXMatrixTranslation(&mat1, 0.0f,-0.12f-0.03f*i,0.0f);
		D3DXMatrixMultiply(&(akt->mat),&(akt->mat),&mat1);
		D3DXMatrixRotationX(&mat1,0.2f);
		D3DXMatrixMultiply(&(akt->mat),&(akt->mat),&mat1);
		i++;
		akt = akt->next;
	}
	while(aktItem != akt);
		  
	aktAuto->FrameMove();

	//Loop midi
	if (!FMUSIC_IsPlaying(music)) FMUSIC_PlaySong(music);

	return true;
}


bool Menue::Render()
{
	HRESULT hr;
	MenueItem *akt;
	char buffer[MAXSTRING];

	if (!aktAuto->Render(0))
	{
		MessageBox(NULL,"Error: auto->Render() (2)",NULL,NULL);
		return false;
	}
	if (!aktKarte->Render())
	{
		MessageBox(NULL,"Error: karte->Render() (2)",NULL,NULL);
		return false;
	}

	d3dDevice->SetRenderState(D3DRS_ZENABLE, false);
	d3dDevice->SetMaterial(&fontMatAkt);
	d3dDevice->SetTransform( D3DTS_WORLD, &matFontTitel);
	strcpy_s(buffer,TXTTITEL);
	hr = font->Render3DText(buffer,D3DFONT_CENTERED|D3DFONT_TWOSIDED|D3DFONT_FILTERED);
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->Render3DText()",true);
	
	akt = aktItem;
	do
	{
		d3dDevice->SetTransform( D3DTS_WORLD, &(akt->mat));
		hr = font->Render3DText(akt->string,D3DFONT_CENTERED|D3DFONT_TWOSIDED|D3DFONT_FILTERED);
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->Render3DText()",true);
		if (akt==aktItem) d3dDevice->SetMaterial(&fontMatDeAkt);
		akt = akt->next;
	}
	while(aktItem != akt);
	d3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );

	return true;
}

bool Menue::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	HRESULT hr;

	d3dDevice = d3dDeviceSet;

	hr = font->InitDeviceObjects(d3dDevice );
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	ZeroMemory(&fontMatAkt, sizeof(D3DMATERIAL8));
	fontMatAkt.Diffuse.r = 0.5f;
	fontMatAkt.Diffuse.g = 0.5f;
	fontMatAkt.Diffuse.b = 1.0f;
	fontMatAkt.Diffuse.a = 1.0f;
	fontMatAkt.Ambient.r = 0.5f;
	fontMatAkt.Ambient.g = 0.5f;
	fontMatAkt.Ambient.b = 1.0f;
	fontMatAkt.Ambient.a = 1.0f;
	ZeroMemory(&fontMatDeAkt, sizeof(D3DMATERIAL8));
	fontMatDeAkt.Diffuse.r = 0.2f;
	fontMatDeAkt.Diffuse.g = 0.2f;
	fontMatDeAkt.Diffuse.b = 0.8f;
	fontMatDeAkt.Diffuse.a = 1.0f;
	fontMatDeAkt.Ambient.r = 0.2f;
	fontMatDeAkt.Ambient.g = 0.2f;
	fontMatDeAkt.Ambient.b = 0.8f;
	fontMatDeAkt.Ambient.a = 1.0f;
	
	if (!aktAuto->InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: auto->InitDeviceObjects() (2)",NULL,NULL);
		return false;
	}
	if (!aktKarte->InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: karte->InitDeviceObjects() (2)",NULL,NULL);
		return false;
	}

	return true;
}

bool Menue::RestoreDeviceObjects()
{
	HRESULT hr;

    vEyePt.x      = 0.0f;
	vEyePt.y      = 0.25f;
	vEyePt.z      = -0.5f;

    vLookatPt.x   = 0; 
	vLookatPt.y   = 0;
	vLookatPt.z   = 0; 

    vUpVec      = D3DXVECTOR3( 0.0f, +1.0f,  0.0f );

	hr = font->RestoreDeviceObjects();
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	   
	D3DXMatrixLookAtLH(matView, &vEyePt, &vLookatPt, &vUpVec );
	if (FAILED(hr = d3dDevice->SetTransform(D3DTS_VIEW, matView)))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetTransform()",true);
		return false;
	}
    
    // Set default render states
	for (int i=0;i<7;i++)
	{
		d3dDevice->SetTextureStageState(i, D3DTSS_MINFILTER, D3DTEXF_ANISOTROPIC);
    	d3dDevice->SetTextureStageState(i, D3DTSS_MAGFILTER, D3DTEXF_ANISOTROPIC);
		d3dDevice->SetTextureStageState(i, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
		d3dDevice->SetTextureStageState(i, D3DTSS_MAXANISOTROPY, 2 );
	}
	
	// Turn on D3D lighting
	d3dDevice->SetRenderState( D3DRS_LIGHTING, true );
    // Turn on the zbuffer
    d3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	d3dDevice->SetRenderState( D3DRS_SPECULARENABLE, false );
	d3dDevice->SetRenderState(D3DRS_FOGENABLE,FALSE);

	// Initialize the structure.
	ZeroMemory(&d3dLight, sizeof(D3DLIGHT8));
	
	// Set up a white directional light
	d3dLight.Type = D3DLIGHT_DIRECTIONAL;
	d3dLight.Diffuse.r  = 0.0f;
	d3dLight.Diffuse.g  = 0.0f;
	d3dLight.Diffuse.b  = 0.0f;
	d3dLight.Ambient.r  = 1.0f;
	d3dLight.Ambient.g  = 1.0f;
	d3dLight.Ambient.b  = 1.0f;
	d3dLight.Specular.r = 1.0f;
	d3dLight.Specular.g = 1.0f;
	d3dLight.Specular.b = 1.0f;
	
	d3dLight.Direction.x = +0.0f;
	d3dLight.Direction.y = -1.0f;
	d3dLight.Direction.z = -0.5f;
	
	// Set the property information for the first light.
	d3dDevice->SetLight(0, &d3dLight);
    if (FAILED(d3dDevice->LightEnable(0, true)))
	{
		MessageBox(NULL,"Error: d3dDevice->LightEnable() (Menue::RestoreDeviceObjects)",NULL,NULL);
		return false;
	}

	return true;
}


bool Menue::InvalidateDeviceObjects()
{
	HRESULT hr;

	hr = font->InvalidateDeviceObjects();
	if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InvalidateDeviceObjects()",true);
    return true;
}


bool Menue::DeleteDeviceObjects()
{
	HRESULT hr;

	if (!textures->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: textures->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}

	if (font)
	{
		hr = font->DeleteDeviceObjects();
		if (FAILED(hr)) DXTrace(__FILE__,__LINE__,hr,"font->InitDeviceObjects()",true);
	}

	if (!aktAuto->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: auto->DeleteDeviceObjects() (2)",NULL,NULL);
		return false;
	}
	
	if (!aktKarte->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: karte->DeleteDeviceObjects() (2)",NULL,NULL);
		return false;
	}

	return true;
}

bool Menue::FinalCleanup()
{
	SAFE_DELETE(font);
	return true;
}

int Menue::message(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int i;

	switch( uMsg )
    {
    case WM_KEYDOWN:
		switch (wParam)
		{
		case 38: //hoch
			aktItem = aktItem->before;
			break;
		case 40: //runter
			aktItem = aktItem->next;
			break;
		case 37:
			for (i=0;i<MAXAUTOS;i++) if (aktItem == &autoItem[i]) break;
			if (i != MAXAUTOS)
			{
				raceInit->whichCar[i]--;
				if (raceInit->whichCar[i]==-1) raceInit->whichCar[i] = anzCars-1;
				if (i==0) updateMenue(0);
				else updateMenue(2);
			}
			else if (aktItem == karteItem)
			{
				raceInit->map--;
				if (raceInit->map==-1) raceInit->map = anzMaps-1;
				updateMenue(1);
			}
			else if (aktItem == playerItem)
			{
				raceInit->anzPlayer--;
				if (raceInit->anzPlayer == 0) raceInit->anzPlayer = MAXSPIELER;
				updateMenue(2);
			}
			else if (aktItem == rundenItem)
			{
				raceInit->anzRunden--;
				if (raceInit->anzRunden < 0) raceInit->anzRunden = MAXRUNDENLIST-1;
				updateMenue(2);
			}
			break;
		case 39:
			for (i=0;i<MAXAUTOS;i++) if (aktItem == &autoItem[i]) break;
			if (i != MAXAUTOS)
			{
				raceInit->whichCar[i]++;
				if (raceInit->whichCar[i]==anzCars) raceInit->whichCar[i] = 0;
				if (i==0) updateMenue(0);
				else updateMenue(2);
			}
			else if (aktItem == karteItem)
			{
				raceInit->map++;
				if (raceInit->map==anzMaps) raceInit->map = 0;
				updateMenue(1);
			}
			else if (aktItem == playerItem)
			{
				raceInit->anzPlayer++;
				if (raceInit->anzPlayer == MAXSPIELER+1) raceInit->anzPlayer = 1;
				updateMenue(2);
			}
			else if (aktItem == rundenItem)
			{
				raceInit->anzRunden++;
				if (raceInit->anzRunden >= MAXRUNDENLIST) raceInit->anzRunden = 0;
				updateMenue(2);
			}
			break;

		case VK_RETURN:
			if (aktItem == startItem) return SZSPIEL;
			else if (aktItem == exitItem) return SZEXIT;
			else if (aktItem == creditsItem) return SZCREDITS;
			break;
		}
		break;
	case WM_COMMAND:
		for (i=0;i<MAXAUTOS;i++) if ((LOWORD(wParam) >= ID_CARS) && (LOWORD(wParam) < ID_CARS+MAXCARTYPES*i+anzCars)) break;
        if (i != MAXAUTOS)
        {
			raceInit->whichCar[i] = LOWORD(wParam)-ID_CARS-i*MAXCARTYPES;
			if (i==0) updateMenue(0);
			else updateMenue(2);
	    }
		else if ((LOWORD(wParam) >= ID_MAPS) && (LOWORD(wParam) < ID_MAPS+anzMaps))
        {
			raceInit->map = LOWORD(wParam)-ID_MAPS;
			updateMenue(1);
	    }
		else if ((LOWORD(wParam) >= ID_PLAYER) && (LOWORD(wParam) < ID_PLAYER+MAXSPIELER))
        {
			raceInit->anzPlayer = LOWORD(wParam)-ID_PLAYER+1;
			updateMenue(2);
	    }
		else if ((LOWORD(wParam) >= ID_RUNDEN) && (LOWORD(wParam) < ID_RUNDEN+MAXRUNDENLIST))
        {
			raceInit->anzRunden = LOWORD(wParam)-ID_RUNDEN;
			updateMenue(2);
	    }
        break;
	}

    return -1;
}

void Menue::makeMenue()
{
	std::ifstream file;
	char buffer[MAXSTRING];
	int i,j;

	//update the player-names
	makePlayerNames();

	//change in the home-directory
	if (_chdir(homeDir) == -1) 
	{
		MessageBox(NULL,homeDir,NULL,NULL);
		return;
	}
	//find all available cars
	file.open("autos.txt",std::ios::in);
	if (!file.is_open())
	{
		MessageBox(NULL,"Can't open file autos.txt",NULL,NULL);
		return;
	}
	anzCars = 0;
	i=0;
	while (file.getline(buffer,MAXSTRING))
	{
		if (strcmp(buffer,"") == 0) break;
		if ((i%ANZCARLINES) == 0)
		{
			strcpy_s(autoNamen[anzCars], buffer);	//save the names of the cars
			anzCars++;
		}		
		i++;
	}
	file.close();
	if (anzCars > MAXCARTYPES) MessageBox(NULL,"Too many different cars",NULL,NULL);
	raceInit->anzCarTypes = anzCars;

	//Make the "select car"-Popup-Menu
	InsertMenu(GetMenu(mhWnd),1,MF_BYPOSITION|MF_POPUP,(UINT)CreatePopupMenu(),TXTSELECTCAR);
	for (i=0;i<MAXAUTOS;i++)
	{
		InsertMenu(GetSubMenu(GetMenu(mhWnd),1),i,MF_BYPOSITION|MF_POPUP,
			(UINT)CreatePopupMenu(),raceInit->playerNames[i]);
		
		for (j=0;j<anzCars;j++)
			AppendMenu(GetSubMenu(GetSubMenu(GetMenu(mhWnd),1),i),
				MF_STRING,ID_CARS+i*MAXCARTYPES+j,autoNamen[j]);
	}
	//find all available maps
	file.open("maps.txt",std::ios::in);
	if (!file.is_open())
	{
		MessageBox(NULL,"Can't open file maps.txt",NULL,NULL);
		return;
	}
	//Make the "select map"-Popup-Menu
	InsertMenu(GetMenu(mhWnd),2,MF_BYPOSITION|MF_POPUP,(UINT)CreatePopupMenu(),TXTSELECTMAP);
	anzMaps = 0;
	
	while(file.getline(buffer,MAXSTRING))
	{
		if (strcmp(buffer,"") == 0) break;
		AppendMenu(GetSubMenu(GetMenu(mhWnd),2),MF_STRING,ID_MAPS+anzMaps,buffer);
		anzMaps++;

		while(file.get() == 'y') file.getline(buffer,MAXSTRING);
		for (i=0;i<ANZMAPLINES;i++) file.getline(buffer,MAXSTRING);
	}
	file.close();
	//make the player-menu
	InsertMenu(GetMenu(mhWnd),3,MF_BYPOSITION|MF_POPUP,(UINT)CreatePopupMenu(),TXTPLAYER);
	for (i=0;i<MAXSPIELER;i++)
	{
		_itoa_s(i+1,buffer,10);
		AppendMenu(GetSubMenu(GetMenu(mhWnd),3),MF_STRING,ID_PLAYER+i,buffer);
	}
	//Make the anzRunden-Popup-Menu
	InsertMenu(GetMenu(mhWnd),4,MF_BYPOSITION|MF_POPUP,(UINT)CreatePopupMenu(),TXTTITELLAPS);
	for (i=0;i<MAXRUNDENLIST;i++)
	{
		_itoa_s(RUNDENLIST[i],buffer,10);
		AppendMenu(GetSubMenu(GetMenu(mhWnd),4),MF_STRING,ID_RUNDEN+i,buffer);
	}

	//initialise the menu
	updateMenue(-1);
	DrawMenuBar(mhWnd);
}

void Menue::updateMenue(int which)
{
	int i,j;
	MENUITEMINFO lpmii;
	lpmii.cbSize = sizeof(MENUITEMINFO);
	lpmii.fMask = MIIM_STATE;
	char buffer[MAXSTRING];

	if ((selectSoundBuffer == -1) || (!FSOUND_IsPlaying(selectSoundBuffer)))
	selectSoundBuffer = FSOUND_PlaySound(FSOUND_FREE, selectSoundSample);

	//Update player-names
	makePlayerNames();
	
	//Update the car-checkes
	if ((which == 0) || (which == -1))
	{
		//Load new car model
		if (!aktAuto->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: auto->DeleteDeviceObjects() (3)",NULL,NULL);
			return;
		}
		SAFE_DELETE(aktAuto);
		aktAuto = new Auto(matWorld,&vEyePt,&vLookatPt,fElapsedTime,textures,homeDir,
			testText,testLine,NULL,NULL,NULL,true,0,0,NULL,NULL,NULL,false,
			raceInit->whichCar[0],NULL,NULL,NULL,NULL,NULL);
		if (!aktAuto->InitDeviceObjects(d3dDevice))
		{
			MessageBox(NULL,"Error: auto->InitDeviceObjects() (3)",NULL,NULL);
			return;
		}
	}
	if ((which == 0) || (which == -1) || (which == 2))
	{
		//uncheck all items
		for (j=0;j<MAXAUTOS;j++)
		{
			lpmii.fMask = MIIM_TYPE;
			lpmii.fType = MFT_STRING;
			lpmii.dwTypeData = raceInit->playerNames[j];
			SetMenuItemInfo(GetSubMenu(GetMenu(mhWnd),1),j, true,&lpmii);
			lpmii.fMask = MIIM_STATE;
			
			lpmii.fState = MFS_UNCHECKED;
			i=0;
			while (SetMenuItemInfo(GetSubMenu(GetSubMenu(GetMenu(mhWnd),1),j),i, true,&lpmii)) i++; 
			//check the standard-car
			lpmii.fState = MFS_CHECKED;
			SetMenuItemInfo(GetSubMenu(GetSubMenu(GetMenu(mhWnd),1),j),raceInit->whichCar[j], true,&lpmii);
		}
	
		for (i=0;i<MAXAUTOS;i++)
		{
			strcpy_s(autoItem[i].string,raceInit->playerNames[i]);
			strcat_s(autoItem[i].string,": ");
			strcat_s(autoItem[i].string,autoNamen[raceInit->whichCar[i]]);
		}
	}

	//Update the map-checkes
	if ((which == 1) || (which == -1))
	{
		//uncheck all items
		lpmii.fState = MFS_UNCHECKED;
		i=0;
		while (SetMenuItemInfo(GetSubMenu(GetMenu(mhWnd),2),i, true,&lpmii)) i++; 
		//check the standard-map
		lpmii.fState = MFS_CHECKED;
		SetMenuItemInfo( GetSubMenu(GetMenu(mhWnd),2),raceInit->map, true,&lpmii);
		GetMenuString( GetSubMenu(GetMenu(mhWnd),2),raceInit->map,karteItem->string,MAXSTRING,MF_BYPOSITION ); 
	
		//load new map 
		if (!aktKarte->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: karte->DeleteDeviceObjects() (3)",NULL,NULL);
			return;
		}
		SAFE_DELETE(aktKarte);
		aktKarte = new Karte(matWorld, textures, homeDir,true,NULL,raceInit->map,NULL);
		if (!aktKarte->InitDeviceObjects(d3dDevice))
		{
			MessageBox(NULL,"Error: Karte->InitDeviceObjects() (3)",NULL,NULL);
			return;
		}
	}
	//Update the player-checkes
	if ((which == 2) || (which == -1))
	{
		lpmii.fState = MFS_UNCHECKED;
		i=0;
		while (SetMenuItemInfo(GetSubMenu(GetMenu(mhWnd),3),i, true,&lpmii)) i++; 
		//check
		lpmii.fState = MFS_CHECKED;
		SetMenuItemInfo( GetSubMenu(GetMenu(mhWnd),3),raceInit->anzPlayer-1, true,&lpmii);
		
		_itoa_s(raceInit->anzPlayer,buffer,10);
		strcat_s(buffer," ");
		strcat_s(buffer, TXTPLAYER);
		strcpy_s(playerItem->string,buffer);

		//update the input-device-manager
		inputDeviceManager->Create(NULL,raceInit->anzPlayer);
	}
	//Update the runden-Checkes
	if ((which == 2) || (which == -1))
	{
		//uncheck all items
		lpmii.fState = MFS_UNCHECKED;
		i=0;
		while (SetMenuItemInfo(GetSubMenu(GetMenu(mhWnd),4),i, true,&lpmii)) i++; 
		//check 
		lpmii.fState = MFS_CHECKED;
		SetMenuItemInfo( GetSubMenu(GetMenu(mhWnd),4),raceInit->anzRunden, true,&lpmii);
		_itoa_s(RUNDENLIST[raceInit->anzRunden],buffer,10);
		strcat_s(buffer, TXTANZLAPS);
		strcpy_s(rundenItem->string,buffer);
	}
}

void Menue::makePlayerNames()
{
	int i;
	char buffer[MAXSTRING];

	for(i=0;i<raceInit->anzPlayer;i++)
	{
		strcpy_s(raceInit->playerNames[i],TXTPLAYER);
		strcat_s(raceInit->playerNames[i]," ");
		_itoa_s(i+1,buffer,10);
		strcat_s(raceInit->playerNames[i],buffer);
	}
	for (i=raceInit->anzPlayer;i<MAXAUTOS;i++)
	{
		strcpy_s(raceInit->playerNames[i],TXTCOMPUTER);
		strcat_s(raceInit->playerNames[i]," ");
		_itoa_s(i+1,buffer,10);
		strcat_s(raceInit->playerNames[i],buffer);
	}
}
