//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_MENUE)
#define N_MENUE

#include "Textures.h"
#include "testtext.h"
#include "testline.h"
#include "auto.h"
#include "karte.h"
#include "inputDeviceManager.h"

class Menue
{
public:
    Menue(IDirect3DDevice8 *d3dDeviceSet,
		 D3DXMATRIX      *matWorldSet,
		 D3DXMATRIX      *matViewSet,
		 D3DXMATRIX      *matProjSet,
		 FLOAT           *fElapsedTimeSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 TestLine		 *testTextLine,
		 HWND			  mhWndSet,
		 RACEINIT		 *raceInitSet,
		 CInputDeviceManager *inputDeviceManagerSet);
	~Menue();
	bool OneTimeSceneInit();
    bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool RestoreDeviceObjects();
    bool InvalidateDeviceObjects();
    bool DeleteDeviceObjects();
    bool Render();
    bool FrameMove();
    bool FinalCleanup();
	int message(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	void makeMenue();				//Make the menue-item
	void updateMenue(int which);	//update the menue-items
	void makePlayerNames();			//make the player names

	// Transform matrices
	D3DXMATRIX      *matWorld;
    D3DXMATRIX      *matView;
    D3DXMATRIX      *matProj;
	FLOAT           *fElapsedTime;
	char			*homeDir;
	TestText		*testText;
	TestLine		*testLine;
	HWND            mhWnd;   // The main app window
	IDirect3DDevice8 *d3dDevice;
	RACEINIT		*raceInit;
	CInputDeviceManager *inputDeviceManager;
	
	D3DXVECTOR3		vEyePt;      
    D3DXVECTOR3		vLookatPt;   
    D3DXVECTOR3		vUpVec;
	D3DLIGHT8		d3dLight;
	Textures		*textures;

	int				anzCars;
	int				anzMaps;

	struct MenueItem
	{
		char		string[MAXSTRING];
		D3DXMATRIX	mat;
		MenueItem	*next;
		MenueItem	*before;
	} *aktItem,
	  *autoItem,
	  *karteItem,
	  *startItem,
	  *exitItem,
	  *playerItem,
	  *rundenItem,
	  *creditsItem;

	char			autoNamen[MAXCARTYPES][MAXSTRING];

	Auto			*aktAuto;
	Karte			*aktKarte;

	CD3DFont		*font;
	D3DXMATRIX		matFontTitel;
	D3DMATERIAL8	fontMatAkt;	//the normal material
	D3DMATERIAL8	fontMatDeAkt;
	float			angle;

	FMUSIC_MODULE	*music;				//The backgroundmidi-file
	FSOUND_SAMPLE	*selectSoundSample;		//Pointer to the crash Sound Sample
	int				selectSoundBuffer;		//in this buffer is the crash sound
};

#endif