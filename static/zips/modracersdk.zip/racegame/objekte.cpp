//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "objekte.h"

Objekte::Objekte(D3DXMATRIX		*matWorldSet,
			Textures			*texturesSet,
			char			    *homeDirSet,
			TestLine			*testLineSet,
			KollisionList		*kList,
			int					art,
			CViewFrustum		*viewFrustumSet)
{
	std::ifstream objektFile;
	float zahl2;
	ObjektStruct *newObjekt;
	ObjektStruct *aktObjekt = firstObjekt = NULL;
	int i=0,j;
	char buffer[MAXSTRING];
	char name[MAXSTRING];
	XYFloat wand[2],tmpWand[2];
	char mapOFileName[MAXSTRING];

	matWorld = matWorldSet;
	textures = texturesSet;
	homeDir  = homeDirSet;
	testLine = testLineSet;
	viewFrustum = viewFrustumSet;

	anzMeshes = 0;

	//change in the home-directory
	if (_chdir(homeDir) == -1) 
	{
		MessageBox(NULL,homeDir,NULL,NULL);
		return;
	}

	objektFile.open("maps.txt",std::ios::in);		//die Kartendatei �ffnen
	if (!objektFile.is_open()) 
	{
		MessageBox(NULL,"Can't open file maps.txt",NULL,NULL);
		return;
	}

	for (j=0;j<=art;j++)
	{
		objektFile.getline(buffer,MAXSTRING);
		while(objektFile.get() == 'y')	objektFile.getline(buffer,MAXSTRING);
		objektFile.getline(buffer,MAXSTRING);
		if (j!=art) for (i=0;i<ANZMAPLINES-1;i++) objektFile.getline(buffer,MAXSTRING);
	}
	objektFile.getline(buffer,MAXSTRING);
	objektFile.getline(mapOFileName,MAXSTRING);	//read the name of the mapo-file
	objektFile.close();

	objektFile.open(mapOFileName,std::ios::in);		//die Objektdatei �ffnen
	if (!objektFile.is_open()) 
	{
		MessageBox(NULL,"Can't open file <mapname>o.txt",NULL,NULL);
		return;
	}
	
	while(objektFile.getline(name,MAXSTRING))
	{
		DeleteBlanksOfString(name);	//shorten string
		if (strcmp(name,"") == 0) break;
		newObjekt = new ObjektStruct;
		strcpy_s(newObjekt->art,name);
		objektFile >> zahl2;
		newObjekt->position.x = zahl2;
		objektFile.get();
		objektFile >> zahl2;
		newObjekt->position.y = zahl2;
		objektFile.get();
		objektFile >> zahl2;
		newObjekt->rotation = zahl2;
		objektFile.getline(buffer,MAXSTRING);
		if (objektFile.get() == 'y')
			newObjekt->soundBuffer = 0;		//Enable Sound for this object
		else newObjekt->soundBuffer = -1;	//Disable Sound for this object
		newObjekt->index = -1;
		newObjekt->next = NULL;
		if (aktObjekt != NULL) aktObjekt->next = newObjekt;
		else firstObjekt = newObjekt;
		aktObjekt=newObjekt;
		objektFile.getline(buffer,MAXSTRING);
	}
	objektFile.close();

	objektFile.open("objects.txt",std::ios::in);
	if (!objektFile.is_open()) MessageBox(NULL,"Can file objects.txt",NULL,NULL);
	
	//Change into the sound-directory
	strcpy_s(buffer,homeDir);
	strcat_s(buffer,SOUNDDIR);
	if (_chdir(buffer) == -1) MessageBox(NULL,buffer,NULL,NULL);
	i=0;
	while(objektFile.getline(name,MAXSTRING))
	{
		DeleteBlanksOfString(name);		//shorten string
		if (strcmp(name,"") == 0) break;
		if (i >= MAXOBJECTS) 
		{
			MessageBox(NULL,"Too many different objects",NULL,NULL);
			break;
		}
		objektFile.getline(buffer,MAXSTRING);
		strcpy_s(xFile[i],buffer);		//Den Namen der X-Datei speichern
		//Load the sound sample of this object
		objektFile.getline(buffer,MAXSTRING);
		if (strcmp(buffer,"n") != 0)
		{
			soundSample[i] = FSOUND_Sample_Load(FSOUND_FREE, buffer, FSOUND_HW3D | FSOUND_LOOP_NORMAL, 0, 0);
		}
		else soundSample[i] = NULL;
	
		aktObjekt = firstObjekt;
		while(1)		//Alle Objekte durchgehen
		{
			if (aktObjekt == NULL) break;
			if (strcmp(aktObjekt->art,name) == 0)
			{
				aktObjekt->index = i;		//save the index of the object
			
				//start playing the sound
				if ((aktObjekt->soundBuffer != -1) && (soundSample[i] != NULL))
				{
					aktObjekt->soundBuffer = FSOUND_PlaySoundEx(FSOUND_FREE, soundSample[i], NULL, true);
					FSOUND_SetPriority(aktObjekt->soundBuffer,0);
					float pos[3] = {aktObjekt->position.x, 0.05f, aktObjekt->position.y};
					float vel[3] = {0.0f, 0.0f, 0.0f};
					FSOUND_3D_SetAttributes(aktObjekt->soundBuffer,pos,vel);
				}
			}
			aktObjekt = aktObjekt->next;
		}
		
		while(objektFile.get() == 'y')	//Die W�nde durchgehen
		{
			objektFile >> wand[0].x; objektFile.get();	//Die 4 notwendigen Punkte f�r die Wand speichern
			objektFile >> wand[0].y; objektFile.get();
			objektFile >> wand[1].x; objektFile.get();
			objektFile >> wand[1].y; objektFile.get();
			aktObjekt = firstObjekt;
			while(1)		//Alle Objekte durchgehen
			{
				if (aktObjekt == NULL) break;
				if (strcmp(aktObjekt->art,name) == 0)	//Nur die Objekte die dem Entsprechen  
				{
					tmpWand[0] = PointRotate(wand[0],-aktObjekt->rotation);
					tmpWand[1] = PointRotate(wand[1],-aktObjekt->rotation);
					tmpWand[0].x = (aktObjekt->position.x)+tmpWand[0].x;
					tmpWand[0].y = (aktObjekt->position.y)+tmpWand[0].y;
					tmpWand[1].x = (aktObjekt->position.x)+tmpWand[1].x;
					tmpWand[1].y = (aktObjekt->position.y)+tmpWand[1].y;
					testLine->drawLine(kList->newObject(tmpWand[0],tmpWand[1]),	//Wand eintragen
										tmpWand[0],tmpWand[1]);
				}
				aktObjekt = aktObjekt->next;
			}
			objektFile.get();
		}
		objektFile.get();
		i++;
	}
	objektFile.close();

	//Check if all objects found
	aktObjekt = firstObjekt;
	while(1)		//Alle Objekte durchgehen
	{
		if (aktObjekt == NULL) break;
		
		if (aktObjekt->index == -1)
		{
			strcpy_s(buffer,aktObjekt->art);
			strcat_s(buffer," not found");
			MessageBox(NULL,buffer,NULL,NULL);
		}
		aktObjekt = aktObjekt->next;
	}
}

Objekte::~Objekte()
{
	ObjektStruct *delObjekt;
	ObjektStruct *aktObjekt = firstObjekt;

	while(1)
	{
		if (aktObjekt == NULL) break;
		FSOUND_StopSound(aktObjekt->soundBuffer);
		delObjekt = aktObjekt;
		aktObjekt = aktObjekt->next;
		SAFE_DELETE(delObjekt);
	}
}

bool Objekte::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	LPD3DXBUFFER pD3DXMtrlBuffer;
	D3DXMATERIAL* d3dxMaterials; 
	ObjektStruct *aktObjekt = firstObjekt;
	int i;
	DWORD j;
	bool schonDrin;
	char aktXFile[MAXSTRING];
	char changeDir[MAXSTRING];
	D3DVERTEX3D2 *pVertices;	//Pointer to the object-vertices

	d3dDevice = d3dDeviceSet;

	while(1)	//Alle Objekte durchgehen
	{
		if (aktObjekt == NULL) break;
		
		strcpy_s(aktXFile,xFile[aktObjekt->index]);

		//Nachpr�fen, ob dieses Modell schon geladen
		schonDrin = false;
		for (i=0;i<anzMeshes;i++)
		{
			if (strcmp(aktXFile, meshes[i].name) == 0)
			{
				aktObjekt->meshIndex = i;
				schonDrin = true;
				break;
			}
		}
		if (schonDrin) 
		{
			aktObjekt = aktObjekt->next;
			continue;	//Wenn schon eingetragen, dann weiter
		}
		//change in the model-directory
		strcpy_s(changeDir,homeDir);
		strcat_s(changeDir,MODELSDIR);
		if (_chdir(changeDir) == -1) MessageBox(NULL,changeDir,NULL,NULL);

		//Jetzt Modell laden
		if (FAILED(D3DXLoadMeshFromX(aktXFile, D3DXMESH_MANAGED, 
                                   d3dDevice, NULL, 
                                   &pD3DXMtrlBuffer, &(meshes[anzMeshes].anzMat), 
                                   &(meshes[anzMeshes].mesh))))
		{
			MessageBox(NULL,"Can't load object-model",NULL,NULL);
			MessageBox(NULL,aktXFile,NULL,NULL);
			return false;
		}
		   
	    d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
		meshes[anzMeshes].materials = new D3DMATERIAL8[meshes[anzMeshes].anzMat];
		meshes[anzMeshes].texNr  = new int[meshes[anzMeshes].anzMat];
		
		for(j=0; j<meshes[anzMeshes].anzMat; j++)
		{
			meshes[anzMeshes].materials[j] = d3dxMaterials[j].MatD3D;
	        meshes[anzMeshes].materials[j].Ambient = meshes[anzMeshes].materials[j].Diffuse;
			meshes[anzMeshes].texNr[j] = textures->newTex(d3dDevice,d3dxMaterials[j].pTextureFilename);
		}
	    SAFE_RELEASE(pD3DXMtrlBuffer);

		strcpy_s(meshes[anzMeshes].name,aktXFile);
		aktObjekt->meshIndex = anzMeshes;
		anzMeshes++;
		
		aktObjekt = aktObjekt->next;
	}
	
	//Calculate the bounding spheres
	aktObjekt = firstObjekt;
	while(1)	//Alle Objekte durchgehen
	{
		if (aktObjekt == NULL) break;
		meshes[(aktObjekt->meshIndex)].mesh->LockVertexBuffer(D3DLOCK_READONLY,(BYTE**)&pVertices);
		D3DXComputeBoundingSphere(pVertices,meshes[(aktObjekt->meshIndex)].mesh->GetNumVertices(),
			D3DFVF_D3DVERTEX3D2,&aktObjekt->bsM,&aktObjekt->bsR);
		aktObjekt->bsM.x += aktObjekt->position.x;
		aktObjekt->bsM.z += aktObjekt->position.y;
		meshes[(aktObjekt->meshIndex)].mesh->UnlockVertexBuffer();
		aktObjekt = aktObjekt->next;
	}

	return true;
}

bool Objekte::DeleteDeviceObjects()
{
	int i;

	for (i=0;i<anzMeshes;i++)
	{
		SAFE_DELETE_ARRAY(meshes[i].materials);
		SAFE_DELETE_ARRAY(meshes[i].texNr);
		SAFE_RELEASE(meshes[i].mesh);
		strcpy_s(meshes[i].name,"");
	}
	anzMeshes = 0;
	return true;
}

bool Objekte::Render()
{
	D3DXMATRIX  mat1,mat2;
	ObjektStruct *aktObjekt = firstObjekt;

	// Set diffuse blending for alpha set in vertices.
    d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
    d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
    d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
    d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
    d3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
    d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
    
	while(1)
	{
		if (aktObjekt == NULL) break;
		if ((viewFrustum == NULL) || (viewFrustum->CullSphere(&aktObjekt->bsM,&aktObjekt->bsR) != SPHERE_AUSSERHALB))
		{
			D3DXMatrixRotationY( &mat1, aktObjekt->rotation);
			D3DXMatrixMultiply( &mat1, matWorld, &mat1 );
			D3DXMatrixTranslation( &mat2, aktObjekt->position.x, 0.0f, aktObjekt->position.y );
			D3DXMatrixMultiply( &mat1, &mat1, &mat2 );
			d3dDevice->SetTransform( D3DTS_WORLD, &mat1);
			
			for( DWORD i=0; i<meshes[(aktObjekt->meshIndex)].anzMat; i++ )
			{
				d3dDevice->SetMaterial( &(meshes[(aktObjekt->meshIndex)].materials[i]));
				if (meshes[(aktObjekt->meshIndex)].texNr[i] != -1) 
					d3dDevice->SetTexture( 0,textures->getTex(meshes[(aktObjekt->meshIndex)].texNr[i]));
				
				if (FAILED((meshes[(aktObjekt->meshIndex)].mesh)->DrawSubset(i)))
				{
					MessageBox(NULL,"error: mesh->DrawSubset() (Objekte::Render)",NULL,NULL);
					return false;
				}
			}
		}
		aktObjekt = aktObjekt->next;
	}

	 // Restore state
    d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
    d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );

	return true;
}

