//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_OBJEKTE)
#define N_OBJEKTE

#include "kollisionlist.h"
#include "konstanten.h"
#include "textures.h"
#include "testline.h"
#include "helpfunctions.h"
#include "viewfrustum.h"

class Objekte
{
public: 
	Objekte(D3DXMATRIX	 *matWorldSet,
		 Textures		 *texturesSet,
		 char			 *homeDirSet,
		 TestLine		 *testLineSet,
		 KollisionList   *kList,
		int				 art,
		CViewFrustum	 *viewFrustumSet);
	~Objekte();
    bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool DeleteDeviceObjects();
    bool Render();

private:
	IDirect3DDevice8 *d3dDevice;
    D3DXMATRIX		*matWorld;
	Textures		*textures;
	char			*homeDir;
	TestLine		*testLine;
	CViewFrustum	 *viewFrustum;
	
	struct ObjektStruct
	{
		char	art[MAXSTRING];		//welches Objekt?
		int		index;				//which object in the objects-field
		XYFloat	position;			//auf welcher Kachel befindet sich der Mittelpunkt des Objekt
		float	rotation;			//rotation of the object

		int		meshIndex;			//Index f�r das Drahtgittermodell
		int		soundBuffer;		//in this buffer is the sound

		D3DXVECTOR3		bsM;		//the bounding-sphere-middle
		float			bsR;		//the bounding-sphere-radius

				
		ObjektStruct	*next;		//Pointer auf das n�chste Objekt in der Liste
	};
	ObjektStruct *firstObjekt;		//Pointer auf das erste Objekt in der Liste
	
	struct MeshStruct
	{
		char					name[MAXSTRING];	// Der Name dieser x-Datei
		LPD3DXMESH				mesh;			// Das Drahtgittermodell
		DWORD					anzMat;			// Anzahl der Materiale bei diesem Objekt
		D3DMATERIAL8*           materials;		// Die Materialien
		int						*texNr;			// die Texturen
	} meshes[MAXOBJECTS];
	int		anzMeshes;				//Wieviel verschiedenen Meshes wurden geladen
	
	char xFile[MAXSTRING][MAXOBJECTS]; //Hier werden die Einstellungen der objects.txt gespeichert
	FSOUND_SAMPLE *soundSample[MAXOBJECTS];	//Pointer to the sound Samples  
};

#endif