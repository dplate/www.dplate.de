//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "race.h"

Race::Race(IDirect3DDevice8 *d3dDeviceSet,
		   D3DXMATRIX      *matWorldSet,
		   FLOAT           *fElapsedTimeSet,
		   char			   *homeDirSet,
		   TestText		   *testTextSet,
		   TestLine		   *testLineSet,
		   CInputDeviceManager	*inputDeviceManagerSet,
		   RACEINIT		   *raceInitSet,
		   POINT		   *screenMaxSet,
		   bool			   *debugSet)
{
	int i;
	float savefElapsedTime;

	d3dDevice = d3dDeviceSet;
	matWorld = matWorldSet;
	fElapsedTime = fElapsedTimeSet;
	homeDir	= homeDirSet;
	testText = testTextSet;
	testLine = testLineSet;
	inputDeviceManager = inputDeviceManagerSet;
	raceInit = raceInitSet;
	screenMax = screenMaxSet;
	debug = debugSet;

	savefElapsedTime = *fElapsedTime;

	raceStatus = RSBEFORESTART;
	startRaceTime = (float)SECONDSTOSTART;

	//Die Textureverwaltungsklasse einrichten
	raceTextures = new Textures(homeDir,testText);

	raceSmoke = new Smoke(matWorld,testText,raceTextures,fElapsedTime);

	karte = new Karte(matWorld,raceTextures,homeDir,false,&kollisionList,raceInit->map,&viewFrustum);
	
	for (i=0;i<MAXAUTOS;i++) startNrBelegt[i] = false;

	for (i=0;i<MAXAUTOS;i++)
	{
		if (i<raceInit->anzPlayer) autos[i] = new Auto(
									matWorld,
									&vEyePt[i],
									&vLookatPt[i],
									fElapsedTime,
									raceTextures,
									homeDir,
									testText,
									testLine,
									raceSmoke,
									&raceStatus,
									refPos,
									false,
									getRandomStartNr(),
									i,
									&kollisionList,
									autos,
									karte,
									false,
									raceInit->whichCar[i],
									RUNDENLIST[raceInit->anzRunden],
									&playerViewPort[i],
									raceInit->playerNames[i],
									debug,
									&viewFrustum);
		else autos[i] = new Auto(
									matWorld,
									NULL,
									NULL,
									fElapsedTime,
									raceTextures,
									homeDir,
									testText,
									testLine,
									raceSmoke,
									&raceStatus,
									refPos,
									false,
									getRandomStartNr(),
									i,
									&kollisionList,
									autos,
									karte,
									true,
									raceInit->whichCar[i],
									RUNDENLIST[raceInit->anzRunden],
									NULL,
									raceInit->playerNames[i],
									debug,
									&viewFrustum);
	}

	objekte = new Objekte(matWorld,raceTextures,homeDir,testLine,&kollisionList,raceInit->map,&viewFrustum);
	
	for (i=0;i<raceInit->anzPlayer;i++)
	{
		playerKeys[i].steerLeft		= false;
		playerKeys[i].steerRight	= false;
		playerKeys[i].accelerate	= false;
		playerKeys[i].brake			= false;
		playerKeys[i].xAxisData		= 0;
		playerKeys[i].yAxisData		= 0;
	}
	wireFrame = false;

	if (!OneTimeSceneInit())
	{
		MessageBox(NULL,"Error: race->OneTimeSceneInit() (2)",NULL,NULL);
		return;
	}
	if (!InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: race->InitDeviceObjects() (2)",NULL,NULL);
		return;
	}
	if (!RestoreDeviceObjects())
	{
		MessageBox(NULL,"Error: race->RestoreDeviceObjects() (2)",NULL,NULL);
		return;
	}

	checkValue = 0;

	*fElapsedTime = 0;
}

Race::~Race()
{
	int i;

	DeleteDeviceObjects();
	FinalCleanup();

	delete raceTextures;
	delete raceSmoke;
	delete karte;
	delete objekte;
	for (i=0;i<MAXAUTOS;i++) delete autos[i];
	testLine->deleteAllTestLines();
}

bool Race::OneTimeSceneInit()
{
	return true;
}


bool Race::FrameMove()
{
	int i;

	parsePlayerInput();	//get the keys of the player

	for (i=0;i<raceInit->anzPlayer;i++)
	{
		//steer the car
		if (playerKeys[i].accelerate)
		{
			autos[i]->setzeGasPedal(playerKeys[i].yAxisData,false);
		}
		else if (playerKeys[i].brake) 
		{
			autos[i]->setzeBremsPedal(playerKeys[i].yAxisData,false);
		}
		else
		{
			if (playerKeys[i].yAxisData > 0)
			{
				autos[i]->setzeBremsPedal(0,true);
				autos[i]->setzeGasPedal(playerKeys[i].yAxisData,true);
			}
			else 
			{
				autos[i]->setzeGasPedal(0,true);
				autos[i]->setzeBremsPedal(-playerKeys[i].yAxisData,true);
			}
		}
		if (playerKeys[i].steerLeft) 
			autos[i]->setzeLenkRichtung((-(float)playerKeys[i].xAxisData*MAXLENKWINKEL)/(float)MAXAXIS,false);
		else if (playerKeys[i].steerRight) 
			autos[i]->setzeLenkRichtung((-(float)playerKeys[i].xAxisData*MAXLENKWINKEL)/(float)MAXAXIS,false);
		else 
			autos[i]->setzeLenkRichtung((-(float)playerKeys[i].xAxisData*MAXLENKWINKEL)/(float)MAXAXIS,true);
	}
	for (i=0;i<MAXAUTOS;i++) autos[i]->FrameMove();
	
	//Calc the smoke
	if (raceStatus != RSPAUSE) raceSmoke->FrameMove();

	if (raceStatus == RSBEFORESTART)
	{
		//wait a few seconds until start the game
		startRaceTime -= *fElapsedTime;
		if (startRaceTime < 0) raceStatus++;
	}
	else if (raceStatus == RSINRACE)
	{
		//Have a cars finished the race?
		for (i=0;i<MAXAUTOS;i++)
			if (autos[i]->imZiel) raceStatus = RSLASTROUND;
	}
	else if (raceStatus == RSLASTROUND)
	{
		//Have all cars finished the race?
		for (i=0;i<MAXAUTOS;i++)
			if (!autos[i]->imZiel) break;
		if (i == MAXAUTOS) raceStatus++;
	}

	return true;
}


bool Race::Render()
{
	int i, player;

	for (player = 0; player < raceInit->anzPlayer; player++)
	{
		//Set the screen for this player
		d3dDevice->SetViewport(&playerViewPort[player]);
		d3dDevice->SetTransform( D3DTS_PROJECTION, &matProj[player] );

		//Set the right view
		if (!autos[player]->cockpit->updateView(&matProj[player]))
		{
			MessageBox(NULL,"Error: autos[i]->cockpit->updateView() (Race::Render)",NULL,NULL);
			return false;
		}
		
		if (!karte->Render())
		{
			MessageBox(NULL,"Error: karte->Render()",NULL,NULL);
			return false;
		}
	
		if (!objekte->Render())
		{
			MessageBox(NULL,"Error: objekte->Render()",NULL,NULL);
			return false;
		}
		for (i=0;i<MAXAUTOS;i++)
		{
			if (!autos[i]->Render(checkValue))
			{
				MessageBox(NULL,"Error: auto->Render()",NULL,NULL);
				return false;
			}
		}
		if (!raceSmoke->Render(&vEyePt[player],&vLookatPt[player]))
		{
			MessageBox(NULL,"Error: raceSmoke->Render()",NULL,NULL);
			return false;
		}
		if (*debug)
		{
			//Display the test lines
			if (!testLine->Render())
			{
				MessageBox(NULL,"Error: testline->Render()",NULL,NULL);
				return S_FALSE;
			}
		}
		d3dDevice->SetTransform( D3DTS_PROJECTION, &matfullProj);
		//render the cockpit
		if (!autos[player]->cockpit->Render(checkValue))
		{
			MessageBox(NULL,"Error: autos[i]->cockpit->Render() (Race::Render)",NULL,NULL);
			return false;
		}
	}
	d3dDevice->SetViewport(&fullViewPort);
	return true;
}

bool Race::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	int i;

	d3dDevice = d3dDeviceSet;

	if (!karte->InitDeviceObjects(d3dDevice))			//Die Koordinatenpunkte der Karte erstellen
	{
		MessageBox(NULL,"Error: karte->InitDeviceObjects()",NULL,NULL);
		return false;
	}
	if (!objekte->InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: objekte->InitDeviceObjects()",NULL,NULL);
		return false;
	}
	for (i=0;i<MAXAUTOS;i++)
	{
		if (!autos[i]->InitDeviceObjects(d3dDevice))
		{
			MessageBox(NULL,"Error: auto->InitDeviceObjects()",NULL,NULL);
			return false;
		}
	}
	if (!raceSmoke->InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: raceSmoke->InitDeviceObjects()",NULL,NULL);
		return false;
	}
	
	if (raceStatus != RSPAUSE)
		FSOUND_SetPaused(FSOUND_ALL,false);//Enable all channels after game loaded
	return true;
}

bool Race::RestoreDeviceObjects()
{
	int i;

	//Set the viewports
	fullViewPort.X = 0; fullViewPort.Y = 0;
	fullViewPort.Width = screenMax->x;
	fullViewPort.Height = screenMax->y;
	fullViewPort.MinZ = 0.0f; fullViewPort.MaxZ = 1.0f;
	D3DXMatrixPerspectiveFovLH( &matfullProj, pi/4, 
			(float)fullViewPort.Width/(float)fullViewPort.Height, 
			0.01f, 1000.0f );

	for (i=0;i<raceInit->anzPlayer;i++)
	{
		playerViewPort[i].MinZ = 0.0f; playerViewPort[i].MaxZ = 1.0f;
		playerViewPort[i].X = screenMax->x-(screenMax->x/((i/2)%2+1));
		playerViewPort[i].Y = screenMax->y-(screenMax->y/(i%2+1));
		playerViewPort[i].Width = screenMax->x/
			(((raceInit->anzPlayer-1)/2)%2+1-((i==1) && (raceInit->anzPlayer == 3)));
		playerViewPort[i].Height =screenMax->y/((raceInit->anzPlayer != 1)+1);
	
		D3DXMatrixPerspectiveFovLH( &matProj[i], pi/4, 
			(float)playerViewPort[i].Width/(float)playerViewPort[i].Height, 
			0.01f, 300.0f );
	}

	if (!karte->RestoreDeviceObjects())	
	{
		MessageBox(NULL,"Error: karte->InitDeviceObjects()",NULL,NULL);
		return false;
	}
	for (i=0;i<MAXAUTOS;i++)
	{
		if (!autos[i]->RestoreDeviceObjects())
		{
			MessageBox(NULL,"Error: auto->RestoreDeviceObjects()",NULL,NULL);
			return false;
		}
	}

    // Set default render states
	for (i=0;i<7;i++)
	{
		d3dDevice->SetTextureStageState(i, D3DTSS_MINFILTER, D3DTEXF_ANISOTROPIC);
    	d3dDevice->SetTextureStageState(i, D3DTSS_MAGFILTER, D3DTEXF_ANISOTROPIC);
		d3dDevice->SetTextureStageState(i, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
		d3dDevice->SetTextureStageState(i, D3DTSS_MAXANISOTROPY, 2 );
	}
	
	// Turn on D3D lighting
    d3dDevice->SetRenderState( D3DRS_LIGHTING, true );
    // Turn on the zbuffer
    d3dDevice->SetRenderState( D3DRS_ZENABLE, true );
	d3dDevice->SetRenderState( D3DRS_SPECULARENABLE, false );

	d3dDevice->SetRenderState( D3DRS_SHADEMODE ,D3DSHADE_GOURAUD);
	d3dDevice->SetRenderState( D3DRS_AMBIENT , 0x00000000);

	if (wireFrame) d3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
	else d3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);  
	return true;
}


bool Race::InvalidateDeviceObjects()
{
	int i;
	
	for (i=0;i<MAXAUTOS;i++)
	{
		if (!autos[i]->InvalidateDeviceObjects())
		{
			MessageBox(NULL,"Error: auto->InvalidateDeviceObjects()",NULL,NULL);
			return false;
		}
	}

    return true;
}


bool Race::DeleteDeviceObjects()
{
	int i;

	if (!karte->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: karte->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}
	if (!objekte->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: objekte->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}
	
	for (i=0;i<MAXAUTOS;i++)
	{
		if (!autos[i]->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: auto->DeleteDeviceObjects()",NULL,NULL);
			return false;
		}
	}
	if (!raceTextures->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: textures->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}
	if (!raceSmoke->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: raceSmoke->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}
	return true;
}

bool Race::FinalCleanup()
{
	return true;
}

void Race::parsePlayerInput()
{
    DWORD   dwItems;
    DIDEVICEOBJECTDATA adod[BUFFER_SIZE];
	LPDIRECTINPUTDEVICE8 *device;
	HRESULT hr;
	int i,j;
	
	// Loop through all players and check game input.
    for(i=0; i < raceInit->anzPlayer; i++ )
    {
		//Loop through all devices
		for (j=0;j<MAXDEVICES;j++)
		{
			// Get access to the list of input devices.
			if (!inputDeviceManager->GetDeviceForPlayer( i,j, &device )) break;
			
			// Poll the device to read the current state
			if( FAILED(device[0]->Poll()))  
			{
				hr = device[0]->Acquire();
				if( DIERR_INPUTLOST  == hr) hr = device[0]->Acquire();
				return; 
			}        
			// Retrieve the buffered actions from the device.
			dwItems = BUFFER_SIZE;
			hr = device[0]->GetDeviceData( sizeof(DIDEVICEOBJECTDATA),
				adod, &dwItems, 0 );
			if( SUCCEEDED(hr) )
			{           
				for( DWORD j=0; j<dwItems; j++ )
				{
					// Non-axis data is recieved as "button pressed" or "button
					// released". Parse input as such.
					BOOL bState = (adod[j].dwData != 0 ) ? TRUE : FALSE;
					
					switch (adod[j].uAppData)
					{
					case INPUT_LEFTRIGHT_AXIS: // Parse the left-right axis data
						playerKeys[i].xAxisData  = adod[j].dwData;
						playerKeys[i].steerRight = playerKeys[i].steerLeft  = FALSE;					
						break;
						
					case INPUT_UPDOWN_AXIS: // Parse the up-down axis data
						playerKeys[i].yAxisData   = -(int)adod[j].dwData;
						playerKeys[i].brake = playerKeys[i].accelerate = FALSE;
						break;
						
					case INPUT_UP_AXIS: // Parse the up axis data
						playerKeys[i].yAxisData   = -(int)adod[j].dwData;
						playerKeys[i].accelerate = false;
						break;
						
					case INPUT_DOWN_AXIS: // Parse the up axis data
						playerKeys[i].yAxisData   = adod[j].dwData;
						playerKeys[i].brake = false;
						break;
						
					case INPUT_STEERLEFT:		
						playerKeys[i].steerLeft    = bState; 
						if (bState) playerKeys[i].xAxisData = -MAXAXIS;
						else 
						{
							if (playerKeys[i].steerRight)
								playerKeys[i].xAxisData = +MAXAXIS;
							else
								playerKeys[i].xAxisData = 0;
						}
						break;
					case INPUT_STEERRIGHT:		
						playerKeys[i].steerRight   = bState; 
						if (bState) playerKeys[i].xAxisData = +MAXAXIS;
						else 
						{
							if (playerKeys[i].steerLeft)
								playerKeys[i].xAxisData = -MAXAXIS;
							else
								playerKeys[i].xAxisData = 0;
						}
						break;
					case INPUT_UP:				
						playerKeys[i].accelerate	= bState; 
						if (bState) playerKeys[i].yAxisData = +MAXAXIS;
						else 
						{
							if (!playerKeys[i].brake)
								playerKeys[i].yAxisData = 0;
						}
						break;
					case INPUT_DOWN:	
						playerKeys[i].brake		= bState; 
						if (bState) playerKeys[i].yAxisData = +MAXAXIS;
						else 
						{
							if (!playerKeys[i].accelerate)
								playerKeys[i].yAxisData = 0;
						}
						break;
					case INPUT_CHANGECAM:
						if (bState) autos[i]->cockpit->nextCam();
						break;
					case INPUT_REVERSE:
						if (bState) autos[i]->reverse = !autos[i]->reverse;
						break;
					case INPUT_RESET:
						if ((bState) && 
							((raceStatus == RSINRACE) || (raceStatus == RSLASTROUND))) 
							autos[i]->reset();
						break;
					}
				}
			}
			
		}
	}
}

int Race::getRandomStartNr()
{
	int erg;

	while(1)
	{
		erg = rand()%MAXAUTOS;
		if (startNrBelegt[erg]) continue;
		startNrBelegt[erg] = true;
		break;
	}
	return erg;
}

int Race::message(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch( uMsg )
    {
		case WM_KILLFOCUS:
			tmpRaceStatus = raceStatus;
			FSOUND_SetPaused(FSOUND_ALL,true);	//Mute all channels
			raceStatus = RSPAUSE;
			break;
		
        case WM_KEYDOWN:
		/*	char buffer[10];
			_itoa(wParam,buffer,10);
			MessageBox(NULL,buffer,NULL,NULL);
		*/	
			switch (wParam)
			{
			case 83:
				if (*debug) autos[0]->cockpit->camList[autos[0]->cockpit->aktCam].pos.x -= 0.01f;
				break;
			case 69:
				if (*debug) autos[0]->cockpit->camList[autos[0]->cockpit->aktCam].pos.z += 0.01f;
				break;
			case 70:
				if (*debug) autos[0]->cockpit->camList[autos[0]->cockpit->aktCam].pos.x += 0.01f;
				break;
			case 68:
				if (*debug) autos[0]->cockpit->camList[autos[0]->cockpit->aktCam].pos.z -= 0.01f;
				break;
			case 65:
				if (*debug) autos[0]->cockpit->camList[autos[0]->cockpit->aktCam].pos.y += 0.01f;
				break;
			case 89:
				if (*debug) autos[0]->cockpit->camList[autos[0]->cockpit->aktCam].pos.y -= 0.01f;
				break;
			case 81:
				if (*debug) 
				{
					if (wireFrame) wireFrame = false;
					else wireFrame = true;
					if (wireFrame) d3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_WIREFRAME);
					else d3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID);  
				}
				break;
			case VK_ESCAPE:
				if ((raceStatus == RSINRACE) || (raceStatus == RSLASTROUND))
				{
					tmpRaceStatus = raceStatus;
					FSOUND_SetPaused(FSOUND_ALL,true);	//Mute all channels
					raceStatus = RSPAUSE;
				}
				else if (raceStatus == RSAFTERZIEL)	return SZMENUE;
				else if (raceStatus == RSPAUSE) 
				{
					FSOUND_SetPaused(FSOUND_ALL,false);//Enable all channels
					raceStatus = tmpRaceStatus;
				}
				break;
			case VK_RETURN:
				if (raceStatus == RSPAUSE) return SZMENUE;
			case '0':
				if (*debug) checkValue = 0;
				break;
			case '1':
				if (*debug) checkValue = 1;
				break;
			case '2':
				if (*debug) checkValue = 2;
				break;
			case '3':
				if (*debug) checkValue = 3;
				break;
			case '4':
				if (*debug) checkValue = 4;
				break;
			case '5':
				if (*debug) checkValue = 5;
				break;
			}
		break;
	}
    return -1;
}



