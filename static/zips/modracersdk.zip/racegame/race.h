//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_RACE)
#define N_RACE

#include "Karte.h"
#include "Objekte.h"
#include "Auto.h"
#include "Textures.h"
#include "testtext.h"
#include "testline.h"
#include "inputdevicemanager.h"
#include "smoke.h"
#include "viewfrustum.h"

class Race
{
public:
    Race(IDirect3DDevice8 *d3dDeviceSet,
		 D3DXMATRIX      *matWorldSet,
		 FLOAT           *fElapsedTimeSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 TestLine		 *testTextLine,
		 CInputDeviceManager *inputDeviceManagerSet,
		 RACEINIT		 *raceInitSet,
		 POINT			 *screenMaxSet,
		 bool			 *debugSet);
	~Race();
	bool OneTimeSceneInit();
    bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool RestoreDeviceObjects();
    bool InvalidateDeviceObjects();
    bool DeleteDeviceObjects();
    bool Render();
    bool FrameMove();
    bool FinalCleanup();
	int message(UINT uMsg, WPARAM wParam, LPARAM lParam);
	void parsePlayerInput();

private:
	int	getRandomStartNr();

	// Transform matrices
	D3DXMATRIX      *matWorld;
  	FLOAT           *fElapsedTime;
	char			*homeDir;
	TestText		*testText;
	TestLine		*testLine;
	CInputDeviceManager *inputDeviceManager;
	IDirect3DDevice8 *d3dDevice;
		
	D3DXVECTOR3		vEyePt[MAXSPIELER];      
    D3DXVECTOR3		vLookatPt[MAXSPIELER];   
    Textures		*raceTextures;
	KollisionList	kollisionList;
	Karte			*karte;
	Objekte			*objekte;
	Auto			*autos[MAXAUTOS];
	Smoke			*raceSmoke;
	RACEINIT		*raceInit;
	POINT			*screenMax;
	bool			*debug;

	struct PlayerKeys
	{
		BOOL  steerRight;
		BOOL  brake;
		BOOL  steerLeft;
		BOOL  accelerate;
		int xAxisData;
		int yAxisData;
	} playerKeys[MAXSPIELER];

	int raceStatus;			//in which status is the race?
	int tmpRaceStatus;		//save the status before pause...
	float startRaceTime;	//time, when the race should start
	int refPos[MAXAUTOS];	//the actual position of all cars
	bool startNrBelegt[MAXAUTOS];	//which startNr is already gone

	D3DVIEWPORT8 playerViewPort[MAXSPIELER];//The viewports for the player
	D3DVIEWPORT8 fullViewPort;		//The viewport for the whole screen	

	D3DXMATRIX   matProjLong[MAXSPIELER];	//The projection-matrix for each player whith long view
	D3DXMATRIX   matProj[MAXSPIELER];		//The projection-matrix for each player whith short view
	D3DXMATRIX   matfullProj;		//The projection-matix for the whole screen

	CViewFrustum viewFrustum;		//the act. view-frustum

	int checkValue;
	bool wireFrame;
};



#endif