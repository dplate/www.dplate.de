//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#define STRICT
#include "stdafx.h"
#include "resource.h"
#include "racegame.h"


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    RaceGame App;
	
    if( FAILED( App.Create( hInst ) ) )
        return 0;
	return App.Run();
}

RaceGame::RaceGame()
{
	int         count; 

	m_strWindowTitle = new char[100];
    strcpy_s(m_strWindowTitle, 99, TXTWINDOWTITEL);
    m_bUseDepthBuffer   = true;
	spielZustand = -1;		//Spielzustand noch undefiniert
	fElapsedTime = 0.01f;

	//first find the homedirectory
	// Jump to directory the .exe resides in   
	GetModuleFileName(GetModuleHandle(NULL), homeDirectory, sizeof(homeDirectory));   
	for(count = strlen(homeDirectory) - 1; count > 0; count--) 
	{     
		if(homeDirectory[count] == '\\') 
		{       
			homeDirectory[count] = '\0';       
			break;     
		}   
	}

	if (_chdir(homeDirectory) == -1) 
	{
		MessageBox(NULL,homeDirectory,NULL,NULL);
		return;
	}
	AddFontResource(FONTFILE); 

	testLine = new TestLine(&matWorld);
}

RaceGame::~RaceGame()
{
	switch (spielZustand)
	{
	case SZTITEL:
		delete titel;					//then delete titel object
		break;
	case SZMENUE:
		delete menue;					//dann Men�objekt zerst�ren
		break;
	case SZSPIEL:
		delete race;					//dann Rennobjekt zerst�ren
		break;
	}

	saveProperties();	//The the properties of the game
	
	if (_chdir(homeDirectory) == -1) 
	{
		MessageBox(NULL,homeDirectory,NULL,NULL);
		return;
	}
	RemoveFontResource(FONTFILE);

	FSOUND_Close();
	delete testLine;
}

int RaceGame::Run()
{	
	int i;

	if (m_pd3dDevice == NULL) MessageBox(NULL,"d3dDevice not initialised",NULL,NULL);
	
	//Use standard-raceinit
	for (i=0;i<MAXAUTOS;i++) raceInit.whichCar[i] = 0;
	raceInit.map = 0;
	raceInit.anzCarTypes = 0;
	raceInit.anzRunden = 1;
	raceInit.anzPlayer = 1;
	loadProperties();	//Overwrite the properties with the saved ones

	//make the sound stuff
	FSOUND_SetHWND(m_hWnd);		//give it the windows-handle
	FSOUND_SetOutput(FSOUND_OUTPUT_DSOUND);		//Select sound driver (directx)
	FSOUND_SetDriver(0);	//use standard-sound-driver
	FSOUND_Init(44100,16,0);	//init the sound system...
	
	// Create the DirectInput helper class
	g_pInputDeviceManager = new CInputDeviceManager();
    if( !g_pInputDeviceManager ) return E_OUTOFMEMORY;
	g_pInputDeviceManager->Create(m_hWnd, raceInit.anzPlayer);

	debug = false;

	titel = new Titel(m_pd3dDevice,&matWorld,&matProj,&fElapsedTime, 
		homeDirectory,&testText,testLine,&screenMax);	//Create the titel-object 

	spielZustand = SZTITEL;			//Mit dem Men� beginnen

	return CD3DApplication::Run();
}

void RaceGame::saveProperties()
{
	int i;

	if (_chdir(homeDirectory) == -1) 
	{
		MessageBox(NULL,homeDirectory,NULL,NULL);
		return;
	}
	std::ofstream ofs( "save.dat", std::ios::binary );
	
	for (i=0;i<MAXAUTOS;i++) 
		ofs.write( (char*)&raceInit.whichCar[i], sizeof(raceInit.whichCar[i]));
	
	ofs.write( (char*)&raceInit.map, sizeof(raceInit.map) );
	ofs.write( (char*)&raceInit.anzCarTypes, sizeof(raceInit.anzCarTypes) );
	ofs.write( (char*)&raceInit.anzRunden, sizeof(raceInit.anzRunden) );
	ofs.write( (char*)&raceInit.anzPlayer, sizeof(raceInit.anzPlayer) );
}

void RaceGame::loadProperties()
{
	int i;

	if (_chdir(homeDirectory) == -1) 
	{
		MessageBox(NULL,homeDirectory,NULL,NULL);
		return;
	}
	std::ifstream ifs( "save.dat", std::ios::binary);
	
	for (i=0;i<MAXAUTOS;i++) 
		ifs.read( (char*)&raceInit.whichCar[i], sizeof(raceInit.whichCar[i]));
	
	ifs.read( (char*)&raceInit.map, sizeof(raceInit.map) );
	ifs.read( (char*)&raceInit.anzCarTypes, sizeof(raceInit.anzCarTypes) );
	ifs.read( (char*)&raceInit.anzRunden, sizeof(raceInit.anzRunden) );
	ifs.read( (char*)&raceInit.anzPlayer, sizeof(raceInit.anzPlayer) );
}


HRESULT RaceGame::OneTimeSceneInit()
{
	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->OneTimeSceneInit())
		{
			MessageBox(NULL,"Error: titel->OneTimeSceneInit()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->OneTimeSceneInit())
		{
			MessageBox(NULL,"Error: menue->OneTimeSceneInit()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->OneTimeSceneInit())
		{
			MessageBox(NULL,"Error: race->OneTimeSceneInit()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->OneTimeSceneInit())
		{
			MessageBox(NULL,"Error: credits->OneTimeSceneInit()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	return S_OK;
}


HRESULT RaceGame::FrameMove()
{
	if (fElapsedTime == 0) fElapsedTime = 1.0f/100.0f;
	else fElapsedTime = (9.0f*fElapsedTime+m_fElapsedTime)/10.0f;
	
	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->FrameMove())
		{
			MessageBox(NULL,"Error: titel->FrameMove()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->FrameMove())
		{
			MessageBox(NULL,"Error: menue->FrameMove()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->FrameMove())
		{
			MessageBox(NULL,"Error: race->FrameMove()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->FrameMove())
		{
			MessageBox(NULL,"Error: credits->FrameMove()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	//update the fps-text
	if (debug) testText.drawText(0,m_strFrameStats);

	return S_OK;
}


HRESULT RaceGame::Render()
{
	// Clear the viewport
   m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,0), 1.0f, 0L );

   // Begin the scene 
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		switch (spielZustand)
		{
		case SZTITEL:
			if (!titel->Render())
			{
				MessageBox(NULL,"Error: titel->Render()",NULL,NULL);
				return S_FALSE;
			}
			break;
		case SZMENUE:
			if (!menue->Render())
			{
				MessageBox(NULL,"Error: menue->Render()",NULL,NULL);
				return S_FALSE;
			}
			break;
		case SZSPIEL:
			if (!race->Render())
			{
				MessageBox(NULL,"Error: race->Render()",NULL,NULL);
				return S_FALSE;
			}
			break;
		case SZCREDITS:
			if (!credits->Render())
			{
				MessageBox(NULL,"Error: credits->Render()",NULL,NULL);
				return S_FALSE;
			}
			break;
		}
		if (debug)
		{
			//Display the screen messages
			if (!testText.Render())
			{
				MessageBox(NULL,"Error: testtext->Render()",NULL,NULL);
				return S_FALSE;
			}
		}

		// End the scene.
        m_pd3dDevice->EndScene();
	}

    return S_OK;
}

HRESULT RaceGame::InitDeviceObjects()
{
	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->InitDeviceObjects(m_pd3dDevice))
		{
			MessageBox(NULL,"Error: titel->InitDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->InitDeviceObjects(m_pd3dDevice))
		{
			MessageBox(NULL,"Error: menue->InitDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->InitDeviceObjects(m_pd3dDevice))
		{
			MessageBox(NULL,"Error: race->InitDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->InitDeviceObjects(m_pd3dDevice))
		{
			MessageBox(NULL,"Error: credits->InitDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	if (!testText.InitDeviceObjects(m_pd3dDevice))
	{
		MessageBox(NULL,"Error: testtext->InitDeviceObjects()",NULL,NULL);
		return S_FALSE;
	}
	if (!testLine->InitDeviceObjects(m_pd3dDevice))
	{
		MessageBox(NULL,"Error: testline->InitDeviceObjects()",NULL,NULL);
		return S_FALSE;
	}
	return S_OK;
}


HRESULT RaceGame::RestoreDeviceObjects()
{
	screenMax.x = m_d3dsdBackBuffer.Width;
	screenMax.y = m_d3dsdBackBuffer.Height;

	FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixIdentity( &matWorld );
	m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );
	D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 0.01f, 1000.0f );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->RestoreDeviceObjects())
		{
			MessageBox(NULL,"Error: titel->RestoreDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->RestoreDeviceObjects())
		{
			MessageBox(NULL,"Error: menue->RestoreDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->RestoreDeviceObjects())
		{
			MessageBox(NULL,"Error: race->RestoreDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->RestoreDeviceObjects())
		{
			MessageBox(NULL,"Error: credits->RestoreDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	if (!testText.RestoreDeviceObjects())
	{
		MessageBox(NULL,"Error: testtext->RestoreDeviceObjects()",NULL,NULL);
		return S_FALSE;
	}
	return S_OK;
}


HRESULT RaceGame::InvalidateDeviceObjects()
{
	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->InvalidateDeviceObjects())
		{
			MessageBox(NULL,"Error: titel->InvalidateDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->InvalidateDeviceObjects())
		{
			MessageBox(NULL,"Error: menue->InvalidateDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->InvalidateDeviceObjects())
		{
			MessageBox(NULL,"Error: race->InvalidateDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->InvalidateDeviceObjects())
		{
			MessageBox(NULL,"Error: credits->InvalidateDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	if (!testText.InvalidateDeviceObjects())
	{
		MessageBox(NULL,"Error: testtext->InvalidateDeviceObjects()",NULL,NULL);
		return S_FALSE;
	}
    return S_OK;
}

HRESULT RaceGame::DeleteDeviceObjects()
{
	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: titel->DeleteDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: menue->DeleteDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: race->DeleteDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->DeleteDeviceObjects())
		{
			MessageBox(NULL,"Error: credits->DeleteDeviceObjects()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	if (!testText.DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: testtext->DeleteDeviceObjects()",NULL,NULL);
		return S_FALSE;
	}
	if (!testLine->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: testline->DeleteDeviceObjects()",NULL,NULL);
		return S_FALSE;
	}
    return S_OK;
}

HRESULT RaceGame::FinalCleanup()
{
	switch (spielZustand)
	{
	case SZTITEL:
		if (!titel->FinalCleanup())
		{
			MessageBox(NULL,"Error: titel->FinalCleanup()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZMENUE:
		if (!menue->FinalCleanup())
		{
			MessageBox(NULL,"Error: menue->FinalCleanup()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZSPIEL:
		if (!race->FinalCleanup())
		{
			MessageBox(NULL,"Error: race->FinalCleanup()",NULL,NULL);
			return S_FALSE;
		}
		break;
	case SZCREDITS:
		if (!credits->FinalCleanup())
		{
			MessageBox(NULL,"Error: credits->FinalCleanup()",NULL,NULL);
			return S_FALSE;
		}
		break;
	}
	if (!testText.FinalCleanup())
	{
		MessageBox(NULL,"Error: testtext->FinalCleanup()",NULL,NULL);
		return S_FALSE;
	}
	
	SAFE_DELETE(g_pInputDeviceManager);
   	
	return S_OK;
}

LRESULT RaceGame::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int erg;

	switch( uMsg )
	{
	case WM_KEYDOWN:
			/*char buffer[10];
			_itoa(wParam,buffer,10);
			MessageBox(NULL,buffer,NULL,NULL);
			*/
			switch (wParam)
			{
			case 73:
				debug = !debug;
				break;
			}
			break;
	case WM_COMMAND:
		switch( LOWORD(wParam) )
		{
		case IDM_CHOOSECONTROL:
			if( m_bActive && m_bReady )
			{
				Pause(TRUE);
				
				g_pInputDeviceManager->ConfigureDevices(NULL, NULL, DICD_EDIT );
				
				Pause(FALSE);
			}
			return S_OK;
		}
	}

	switch (spielZustand)
	{
	case SZTITEL:
		erg = titel->message(uMsg,wParam,lParam);
		if (erg == SZMENUE)
		{
			delete titel;
			menue = new Menue(m_pd3dDevice,&matWorld,&matView,&matProj,&fElapsedTime, 
				homeDirectory,&testText,testLine,m_hWnd,&raceInit,g_pInputDeviceManager);	//das Menueobjekt erstellen 
			spielZustand = SZMENUE;
			return S_OK;
		}
		break;
	case SZMENUE:
		erg = menue->message(uMsg,wParam,lParam);
		if (erg == SZSPIEL)
		{	
			delete menue;
			race = new Race(m_pd3dDevice,&matWorld,&fElapsedTime, 
				homeDirectory,&testText,testLine,g_pInputDeviceManager,&raceInit,
				&screenMax,&debug);	//das Raceobjekt erstellen 
			spielZustand = SZSPIEL;
			return S_OK;
		}
		if (erg == SZEXIT)
		{	
			Cleanup3DEnvironment();
            DestroyMenu( GetMenu(hWnd) );
            DestroyWindow( hWnd );
            PostQuitMessage(0);
            return 0;
		}
		if (erg == SZCREDITS)
		{	
			delete menue;
			credits = new Credits(m_pd3dDevice,&fElapsedTime, 
				homeDirectory,&testText,testLine);	//das Creditsobjekt erstellen 
			spielZustand = SZCREDITS;
			return S_OK;
		}
		break;
	case SZSPIEL:
		erg = race->message(uMsg,wParam,lParam);
		if (erg == SZMENUE)
		{
			delete race;
			menue = new Menue(m_pd3dDevice,&matWorld,&matView,&matProj,&fElapsedTime, 
				homeDirectory,&testText,testLine,m_hWnd,&raceInit,g_pInputDeviceManager);	//das Menueobjekt erstellen 
			spielZustand = SZMENUE;
			return S_OK;
		}
		break;
	case SZCREDITS:
		erg = credits->message(uMsg,wParam,lParam);
		if (erg == SZMENUE)
		{
			delete credits;
			menue = new Menue(m_pd3dDevice,&matWorld,&matView,&matProj,&fElapsedTime, 
				homeDirectory,&testText,testLine,m_hWnd,&raceInit,g_pInputDeviceManager);	//das Menueobjekt erstellen 
			spielZustand = SZMENUE;
			return S_OK;
		}
		break;
	}
	return CD3DApplication::MsgProc(hWnd,uMsg,wParam,lParam);
}






