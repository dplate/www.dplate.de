//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_RACEGAME)
#define N_RACEGAME

#include "inputdevicemanager.h"
#include "race.h"
#include "konstanten.h"
#include "testtext.h"
#include "testline.h"
#include "menue.h"
#include "credits.h"
#include "titel.h"

class RaceGame : public CD3DApplication
{
public:
    RaceGame();
	~RaceGame();
	int Run();

private:
	void saveProperties();		//save the game properties
	void loadProperties();		//load the game properties

	// Transform matrices
    D3DXMATRIX	matWorld;
    D3DXMATRIX	matView;
    D3DXMATRIX	matProj;
	FLOAT       fElapsedTime;      // Time elapsed since last frame (adjusted)

	Race		*race;
	Menue		*menue;
	Credits		*credits;
	Titel		*titel;
	int			spielZustand;			//in welchem Zustand befindet sich das Spiel?
	char		homeDirectory[MAXSTRING];//the directory with the exe
	TestText	testText;				//An object to write screen messages
	TestLine	*testLine;
	bool		debug;					//show the debug messages and lines?
	CInputDeviceManager *g_pInputDeviceManager; //The DirectInputManager Class
	RACEINIT	raceInit;				//the setup for the race-class
	POINT		screenMax;				//Save the maximums of the screen
protected:
    HRESULT OneTimeSceneInit();
    HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
    HRESULT FrameMove();
    HRESULT FinalCleanup();
	LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
};

#endif