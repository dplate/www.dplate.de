//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "rad.h"
#include "helpfunctions.h"

Rad::Rad(D3DXMATRIX      *matWorldSet,
		 FLOAT           *fElapsedTimeSet,
		 Textures		 *texturesSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 Smoke			 *smokeSet,
		 int			 *raceStatusSet,
		 char			 *xFileSet,
		 float			 radiusSet,
		 float			 haftungSet,
		 float			 airPowerSet,
		 bool			 menueSet,
		 CViewFrustum	 *viewFrustumSet)
{
	matWorld = matWorldSet;
	fElapsedTime = fElapsedTimeSet;
	textures = texturesSet;
	homeDir = homeDirSet;
	testText = testTextSet;
	smoke = smokeSet;
	strcpy_s(xFile,xFileSet);
	haftung = haftungSet;
	menue = menueSet;
	raceStatus = raceStatusSet;
	airPower = airPowerSet;
	viewFrustum = viewFrustumSet;

	ups = 0;
	radius = radiusSet;
	rutscht = false;
	geschwindigkeit.x = 0;
	geschwindigkeit.y = 0;
	umdrehungsWinkel = 0;
	timeToNextSmoke = (float)(rand()%(int)(SMOKETIME*10000))/10000;

	skidMarks = new SkidMarks(matWorld,testText,textures);	//make the skidmarks-object

	mesh		= NULL;
	anzMat		= 0;
	materials	= NULL;
	texNr		= NULL;

	menueRotation = 0;
}

Rad::~Rad()
{
	SAFE_DELETE(skidMarks);		
}

bool Rad::Render()
{
	if ((viewFrustum == NULL) || (viewFrustum->CullSphere(&bsM,&bsR) != SPHERE_AUSSERHALB))
	{
		d3dDevice->SetTransform( D3DTS_WORLD, &mat);
		
		for( DWORD i=0; i<anzMat; i++ )
		{
			d3dDevice->SetMaterial( &materials[i]);
			if (texNr[i] != -1) d3dDevice->SetTexture( 0,textures->getTex(texNr[i]));
			
			if (FAILED(mesh->DrawSubset(i)))
			{
				MessageBox(NULL,"error: mesh->DrawSubset() (Rad::Render())",NULL,NULL);
				return false;
			}
		}
	}
	if (!skidMarks->Render())
	{
		MessageBox(NULL,"Error: skidmarks->Render() (Rad::Render())",NULL,NULL);
		return false;
	}
	return true;
}

bool Rad::FrameMove(GroundStruct *kachelType, bool debug)
{
	XYFloat wunschv;
	float scalar;
	XYFloat skidPoint1,skidPoint2;
	XYFloat v1;
	float v1Betrag;
	float aktUps;
	D3DXMATRIX  mat2;

	if (menue)
	{
		menueRotation += (*fElapsedTime)/2;
		D3DXMatrixTranslation( &mat2, position.x, radius, position.y );
		D3DXMatrixMultiply( &mat, matWorld, &mat2 );
		D3DXMatrixRotationY( &mat2, menueRotation); 
		D3DXMatrixMultiply( &mat, &mat, &mat2 );
		D3DXMatrixRotationZ( &mat2, umdrehungsWinkel);
		D3DXMatrixMultiply( &mat, &mat2, &mat );
		return true;
	}

	wunschv.x = ups * 2 * pi * radius * richtung.x;
	wunschv.y = ups * 2 * pi * radius * richtung.y;

	if (!rutscht)
	{
		geschwindigkeit.x += (wunschv.x-geschwindigkeit.x)*haftung;
		geschwindigkeit.y += (wunschv.y-geschwindigkeit.y)*haftung;
	}
	else
	{
		geschwindigkeit.x += (wunschv.x-geschwindigkeit.x)*haftung/2.0f;
		geschwindigkeit.y += (wunschv.y-geschwindigkeit.y)*haftung/2.0f;
	}

	//Abremsen durch Reibung einbauen
	if (kachelType != NULL)
	{
		geschwindigkeit.x -= geschwindigkeit.x*(kachelType->reibung+airPower)**fElapsedTime;
		geschwindigkeit.y -= geschwindigkeit.y*(kachelType->reibung+airPower)**fElapsedTime;
	}
	//if before start, no speed to the wheels
	if (*raceStatus == RSBEFORESTART)
	{
		geschwindigkeit.x = 0;
		geschwindigkeit.y = 0;
	}

	scalar = geschwindigkeit.x*richtung.x+geschwindigkeit.y*richtung.y;
	v1.x = geschwindigkeit.x-scalar*richtung.x;
	v1.y = geschwindigkeit.y-scalar*richtung.y;

	v1Betrag = GetBetrag(v1);
	if ((v1Betrag > 0.0f)  && (kachelType != NULL))
	{
		geschwindigkeit.x -= v1.x*(*fElapsedTime)*2/kachelType->glaette;
		geschwindigkeit.y -= v1.y*(*fElapsedTime)*2/kachelType->glaette;
	}
	//rutscht initialisieren
	rutscht = false;
	//die aktuelle ups berechnen
	aktUps = scalar/(2*pi*radius);

	//durchdrehende oder zu starkt bremsend?
	if (aktUps<ups)
	{
		if ((fabs(aktUps-ups)/(*fElapsedTime) > 1100.0f)) rutscht = true;
	}
	else
	{
		if ((fabs(aktUps-ups)/(*fElapsedTime) > 300.0f)) rutscht = true;
	}

	if (v1Betrag > 0.3f) rutscht = true;			//Rutscht das Auto seitw�rts?

	position.x += geschwindigkeit.x * (*fElapsedTime);
	position.y += geschwindigkeit.y * (*fElapsedTime);
		
	umdrehungsWinkel += 2*pi*ups*(*fElapsedTime);
	if (umdrehungsWinkel > 2*pi) umdrehungsWinkel -= 2*pi;

	//make the skidmark and smoke
	if (rutscht == true)
	{
		//the skidmark
		skidPoint1.x = position.x+richtung.y*0.005f;
		skidPoint1.y = position.y-richtung.x*0.005f;
		skidPoint2.x = position.x-richtung.y*0.005f;
		skidPoint2.y = position.y+richtung.x*0.005f;
		if (scalar > 0) skidMarks->newMark(skidPoint1,skidPoint2);
		else skidMarks->newMark(skidPoint2,skidPoint1);

		//the smoke
		if (kachelType != NULL)
		{
			if (!kachelType->dust)	//only if no dust
			{	
				timeToNextSmoke -= *fElapsedTime;
				if (timeToNextSmoke < 0)	//Now make smoke
				{
					timeToNextSmoke = SMOKETIME;
					smoke->newSmoke(D3DXVECTOR3(position.x,0,position.y),radius/2,1.5f,0.05f,
						0.05f,D3DXCOLOR(1.0f,1.0f,1.0f,0.5f));
				}
			}
		}
	}
	else skidMarks->noMark();

	//Make the dust
	if (kachelType != NULL)
	{
		if (kachelType->dust)
		{
			timeToNextSmoke -= *fElapsedTime;
			if (timeToNextSmoke < 0)	//Now make dust
			{
				timeToNextSmoke = SMOKETIME*2;	//Not so much
				smoke->newSmoke(D3DXVECTOR3(position.x,0,position.y),radius/2,1.5f,0.03f,
					0.01f*aktUps,kachelType->dustColor);
			}
		}
	}

	//die aktuelle ups zuweisen
	ups = aktUps;

	//Calculate the transformation matrix
	D3DXMatrixTranslation( &mat2, position.x, radius, position.y );
	D3DXMatrixMultiply( &mat, matWorld, &mat2 );
	D3DXMatrixRotationY( &mat2, (float)(atan2(richtung.x,richtung.y)+pi/2)); 
	D3DXMatrixMultiply( &mat, &mat2, &mat );
	D3DXMatrixRotationZ( &mat2, umdrehungsWinkel);
	D3DXMatrixMultiply( &mat, &mat2, &mat );

	//update the bounding sphere
	bsM = bsMOriginal;
	bsM.x += position.x;
	bsM.z += position.y; 

	return true;
}

bool Rad::DeleteDeviceObjects()
{
	//Rad l�schen
	SAFE_DELETE_ARRAY(materials);	
	SAFE_DELETE_ARRAY(texNr);
	SAFE_RELEASE(mesh);
	anzMat = 0;	

	if (!skidMarks->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: skidmarks->DeleteDeviceObjects() (Rad::InitDeviceObjects()",NULL,NULL);
		return false;
	}
	
	return true;
}

bool Rad::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	LPD3DXBUFFER pD3DXMtrlBuffer;
	D3DXMATERIAL* d3dxMaterials; 
	DWORD i;
	char changeDir[MAXSTRING];
	D3DVERTEX3D2 *pVertices;	//Pointer to the object-vertices

	d3dDevice = d3dDeviceSet;

	//change in the model-directory
	strcpy_s(changeDir,homeDir);
	strcat_s(changeDir,MODELSDIR);
	if (_chdir(changeDir) == -1) 
	{
		MessageBox(NULL,changeDir,NULL,NULL);
		return false;
	}

	//Jetzt Modell des Rades laden
	if (FAILED(D3DXLoadMeshFromX(xFile, D3DXMESH_MANAGED, 
		d3dDevice, NULL, 
		&pD3DXMtrlBuffer, &anzMat, 
		&mesh)))
	{
		MessageBox(NULL,"Can't load wheelmodel",NULL,NULL);
		return false;
	}
	
	d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	materials = new D3DMATERIAL8[anzMat];
	texNr  = new int[anzMat];
	
	for( i=0; i<anzMat; i++ )
	{
		materials[i] = d3dxMaterials[i].MatD3D;
		materials[i].Ambient = materials[i].Diffuse;
		texNr[i] = textures->newTex(d3dDevice,d3dxMaterials[i].pTextureFilename); 
	}
	SAFE_RELEASE(pD3DXMtrlBuffer);

	if (!skidMarks->InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: skidmarks->InitDeviceObjects() (Rad::InitDeviceObjects())",NULL,NULL);
		return false;
	}
	
	mesh->LockVertexBuffer(D3DLOCK_READONLY,(BYTE**)&pVertices);
	D3DXComputeBoundingSphere(pVertices,mesh->GetNumVertices(),D3DFVF_D3DVERTEX3D2,&bsMOriginal,&bsR);
	mesh->UnlockVertexBuffer();
	return true;
}

void Rad::changeRichtung(float addWinkel)
{
	float tmpWinkel;

	tmpWinkel = (float)atan2(richtung.y,richtung.x);
	richtung.x = (float)cos(tmpWinkel+addWinkel);
	richtung.y = (float)sin(tmpWinkel+addWinkel);
}

void Rad::setzeRichtung(XYFloat newRichtung)
{
	richtung.x = newRichtung.x;
	richtung.y = newRichtung.y;
}

void Rad::setzePosition(XYFloat newPosition, bool calcV)
{
	if (calcV)	//die daraus resultierende Geschwindigkeit berechnen
	{
		geschwindigkeit.x += (newPosition.x-position.x)/(*fElapsedTime);
		geschwindigkeit.y += (newPosition.y-position.y)/(*fElapsedTime);
	}
	position = newPosition;
}

void Rad::changeGeschwindigkeit(XYFloat addV)
{
	geschwindigkeit.x += addV.x;
	geschwindigkeit.y += addV.y;
}

void Rad::setzeGeschwindigkeit(XYFloat newV)
{
	geschwindigkeit.x = newV.x;
	geschwindigkeit.y = newV.y;
}

