//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_RAD)
#define N_RAD

#include "konstanten.h"
#include "textures.h"
#include "skidmarks.h"
#include "testtext.h"
#include "smoke.h"
#include "kachel.h"

class Rad
{
public: 
	Rad( D3DXMATRIX      *matWorldSet,
		 FLOAT           *fElapsedTimeSet,
		 Textures		 *texturesSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 Smoke			 *smokeSet,
		 int			 *raceStatusSet,
		 char			 *xFileSet,
		 float			 radiusSet,
		 float			 haftungSet,
		 float			 airPowerSet,
		 bool			 menueSet,
		 CViewFrustum	 *viewFrustumSet);
	~Rad();
    bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool DeleteDeviceObjects();
    bool Render();
    bool FrameMove(GroundStruct *kachelType, bool debug);
    void changeRichtung(float addWinkel);		//gibt dem Rad eine neue Richtung
	void changeGeschwindigkeit(XYFloat addV);	//�nder die Bewegungsgeschwindigkeit des Rades
	void setzeRichtung(XYFloat newRichtung);	//setzt das Rad direkt in eine bestimmte Richtung
	void setzePosition(XYFloat newPosition, bool calcV);	//�ndert die Position des Rades (eventuell mit automatischer Geschwindigkeitsanpassung)
	void setzeGeschwindigkeit(XYFloat newV);	//setzt die Gschwindigkeit auf einen bestimmten Wert
	XYFloat geschwindigkeit,position;			//der Geschwindigkeitsvektor und die Position des Rades
	float ups;									//die Umdrehungsgeschwindigkeit
	bool rutscht;								//der Reifen rutscht gerade


private:
	D3DXMATRIX      *matWorld;
    FLOAT           *fElapsedTime;
	Textures		*textures;
	char			*homeDir;
	TestText		*testText;
	IDirect3DDevice8 *d3dDevice;
	Smoke			*smoke;
	int				*raceStatus;
	float			haftung;
	float			airPower;
	CViewFrustum	*viewFrustum;

	float			timeToNextSmoke;			//the time, when the next smoke appears

	char xFile[MAXSTRING];						//Den Namen der Radmodelldatei
	LPD3DXMESH				mesh;				// Das Drahtgittermodell des Rades
	DWORD					anzMat;				// Anzahl der Materiale bei diesem Objekt
	D3DMATERIAL8*           materials;			// Die Materialien
	int						*texNr;				// die Texturenindexe
	D3DXMATRIX				mat;				// the transformation matrix
	
	D3DXVECTOR3		bsMOriginal;//the bounding-sphere-middle of the unmoved object
	D3DXVECTOR3		bsM;		//the bounding-sphere-middle
	float			bsR;		//the bounding-sphere-radius

	SkidMarks				*skidMarks;			//the skidmarks for this wheel

	float umdrehungsWinkel;						//wie weit ist das Rad von normalen Zustand gedreht
	XYFloat richtung;							//der Richtungsvektor des Rad (L�nge immer =1)
	float radius;								//die Gr��e des Rades
	bool menue;									//is the wheel in the menue?
	float menueRotation;						//in which direction look the wheel
};

#endif