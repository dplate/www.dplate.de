//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "skidmarks.h"

SkidMarks::SkidMarks(D3DXMATRIX      *matWorldSet,
					 TestText		 *testTextSet,
					Textures		 *texturesSet)
{
	int i; 

	matWorld = matWorldSet;
	testText = testTextSet;
	textures = texturesSet;

	tCoord = true;

	anzSkidMarks = 0;
	aktSkidMark = -1;
	for (i=0;i<MAXSKIDMARKS;i++) 
	{
		anzVertices[i] = 0;
		g_pVB[i] = NULL;
	}
	markOn = false;
}

SkidMarks::~SkidMarks()
{

}

void SkidMarks::noMark()
{
	markOn = false;
}

bool SkidMarks::newMark(XYFloat point1, XYFloat point2)
{
	D3DVERTEX3D2*		pVertices;
	double			actDegree;
	double			divX,divY;
	double			actAbs;
	float			height;

	if ((!markOn) || (anzVertices[aktSkidMark] >= MAXSKIDMARKSVERT-3))
	{
		if (aktSkidMark >= MAXSKIDMARKS-1) aktSkidMark = 0;
		else 
		{
			aktSkidMark++;
			if (anzSkidMarks < MAXSKIDMARKS) anzSkidMarks++;		//one more skidmark
		}
		anzVertices[aktSkidMark] = 0;
		markOn = true;					//now its true;
	}
	
	//do we continue with the act. polygon or make a new one
	if (anzVertices[aktSkidMark] >= 4)		//only if enough vertices
	{
		//calculate the act. degree
		divX = point1.x-allVertices[aktSkidMark][firstPoint].p.x;
		divY = point1.y-allVertices[aktSkidMark][firstPoint].p.z;
		
		actAbs = sqrt(divX*divX+divY*divY);
		actDegree = atan2(divY,divX)-atan2(firstDivY,firstDivX);

		if ((fabs(actDegree) < (pi/50)) && //if there is a small degree
			(actAbs < KACHELBREITE/2))		//and the polygon not too long 	
		{
			anzVertices[aktSkidMark] -= 2;		//overwrite the old vertices
		}
		else 
		{
			firstPoint = anzVertices[aktSkidMark]-2;
			firstDivX = point1.x-allVertices[aktSkidMark][firstPoint].p.x;
			firstDivY = point1.y-allVertices[aktSkidMark][firstPoint].p.z;
		}
	}
	else if (anzVertices[aktSkidMark] == 2)	//safe the first degree
	{
		firstPoint = 0;
		firstDivX = point1.x-allVertices[aktSkidMark][firstPoint].p.x;
		firstDivY = point1.y-allVertices[aktSkidMark][firstPoint].p.z;
	}
	
	//make vertices
	height = (float)(rand()%5)/10000+0.0001f;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]].p.x = point1.x;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]].p.y = height;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]].p.z = point1.y;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]].n.x = 0.0f;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]].n.y = 1.0f;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]].n.z = 0.0f;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].p.x = point2.x;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].p.y = height;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].p.z = point2.y;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].n.x = 0.0f;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].n.y = 1.0f;
	allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].n.z = 0.0f;
	
	if (tCoord)
	{
		allVertices[aktSkidMark][anzVertices[aktSkidMark]].tx = 0.0f;
		allVertices[aktSkidMark][anzVertices[aktSkidMark]].ty = 0.0f;
		allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].tx = 0.14f;
		allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].ty = 0.0f;
	}
	else
	{
		allVertices[aktSkidMark][anzVertices[aktSkidMark]].tx = 0.0f;
		allVertices[aktSkidMark][anzVertices[aktSkidMark]].ty = 0.14f;
		allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].tx = 0.14f;
		allVertices[aktSkidMark][anzVertices[aktSkidMark]+1].ty = 0.14f;
	}
	tCoord = !tCoord;

	anzVertices[aktSkidMark] += 2;
	
	//Vertexbuffer locken
	if (FAILED(g_pVB[aktSkidMark]->Lock( 0, anzVertices[aktSkidMark]*sizeof(D3DVERTEX3D2),
			(BYTE**)&pVertices,0)))
	{
		MessageBox(NULL,"error: g_pVB->Lock() (SkidMarks::newMark())",NULL,NULL);
		return false;
	}
	memcpy( pVertices, allVertices[aktSkidMark], anzVertices[aktSkidMark]*sizeof(D3DVERTEX3D2));
	g_pVB[aktSkidMark]->Unlock();	//Vertexbuffer wieder freigeben
	
	return true;
}

bool SkidMarks::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	int i;

	d3dDevice = d3dDeviceSet; //save the new pointer
	texNr = textures->newTex(d3dDevice,"stuff.tga");
	ZeroMemory(&mat, sizeof(D3DMATERIAL8));
	mat.Diffuse.r = 1.0f;
	mat.Diffuse.g = 1.0f;
	mat.Diffuse.b = 1.0f;
	mat.Diffuse.a = 1.0f;

	mat.Ambient.r = 1.0f;
	mat.Ambient.g = 1.0f;
	mat.Ambient.b = 1.0f;
	mat.Ambient.a = 1.0f;
	
	for (i=0;i<MAXSKIDMARKS;i++)
	{
		//Save new vertices in buffer
		if (FAILED(d3dDevice->CreateVertexBuffer( MAXSKIDMARKSVERT*sizeof(D3DVERTEX3D2),
			D3DUSAGE_WRITEONLY , D3DFVF_D3DVERTEX3D2,
			D3DPOOL_MANAGED, &g_pVB[i])))
		{
			MessageBox(NULL,"error: d3dDevice->CreateVertexBuffer() (SkidMarks::InitDeviceObjects())",NULL,NULL);
			return false;
		}
	}

	return true;
}

bool SkidMarks::Render()
{
	int i;
	HRESULT hr;

	d3dDevice->SetTransform( D3DTS_WORLD, matWorld );
	d3dDevice->SetMaterial(&mat);
	if (texNr != -1 ) d3dDevice->SetTexture( 0, textures->getTex(texNr));

	// Set diffuse blending for alpha set in vertices.
    d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
    d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
    d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

    // Enable alpha testing (skips pixels with less than a certain alpha.)
    d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
    d3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
    d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
		
	hr = d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX3D2 );
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetVertexShader()",true);
		return false;
	}

	for (i=0;i<anzSkidMarks;i++)
	{
		hr = d3dDevice->SetStreamSource( 0, g_pVB[i], sizeof(D3DVERTEX3D2));
		if (FAILED(hr))
		{
			DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
			return false;
		}

		if (anzVertices[i] > 2)
		{
			hr = d3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, anzVertices[i]-2 );
			if (FAILED(hr))
			{
				DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
				return false;
			}
		}
	}

	d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
    d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );

	return true;
}

bool SkidMarks::DeleteDeviceObjects()
{
	int i;

	for (i=0;i<MAXSKIDMARKS;i++) SAFE_RELEASE(g_pVB[i]);
	anzSkidMarks = 0;
	aktSkidMark = -1;
	markOn = false;

	return true;
}
