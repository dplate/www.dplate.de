//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_SKIDMARKS)
#define N_SKIDMARKS

#include "konstanten.h"
#include "testtext.h"
#include "textures.h"

class SkidMarks
{
public: 
	SkidMarks(D3DXMATRIX		*matWorldSet,
			  TestText			*testTextSet,
			  Textures			*texturesSet);
	~SkidMarks();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool DeleteDeviceObjects();
    bool Render();
	bool newMark(XYFloat point1, XYFloat point2);
	void noMark();
	
private:
	D3DXMATRIX      *matWorld;
	IDirect3DDevice8 *d3dDevice;
	TestText		*testText;
	Textures		*textures;

	int				texNr;			//der Index der verwendeten 
	D3DMATERIAL8	mat;			//the normal material

	bool			tCoord;			//which texture coordinate

	D3DVERTEX3D2	allVertices[MAXSKIDMARKS][MAXSKIDMARKSVERT];//A field with all Vertices
	int				anzVertices[MAXSKIDMARKS];					//nr. of vertices for each skidmark
	int				anzSkidMarks;								//nr. of skidmarks
	int				aktSkidMark;								//the actual skidmark
	double			firstDivX;									//the first differenz
	double			firstDivY;									//the first differenz
	int				firstPoint;									//the first point of the polygon
	
	bool			markOn;										//the next vertices will continue at the act. skidmark
    
	LPDIRECT3DVERTEXBUFFER8 g_pVB[MAXSKIDMARKS];	//Pointer zu einem VertexBuffer
};

#endif