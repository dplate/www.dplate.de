//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "smoke.h"

Smoke::Smoke(D3DXMATRIX      *matWorldSet,
			 TestText		 *testTextSet,
			 Textures		 *texturesSet,
			 FLOAT           *fElapsedTimeSet)
{
	matWorld = matWorldSet;
	testText = testTextSet;
	textures = texturesSet;
	fElapsedTime = fElapsedTimeSet;

	anzSmokes = 0;
}

Smoke::~Smoke()
{

}

void Smoke::newSmoke(D3DVECTOR position, float startWidth, float startOld, float growSpeedSet,
					 float upSpeedSet, D3DXCOLOR color)
{
	if (anzSmokes >= MAXSMOKES) return;	//maximale Anzahl erreicht
	smokeList[anzSmokes].pos.x = position.x;
	smokeList[anzSmokes].pos.y = position.y;
	smokeList[anzSmokes].pos.z = position.z;
	smokeList[anzSmokes].width = startWidth;
	smokeList[anzSmokes].old   = startOld;
	smokeList[anzSmokes].maxOld= startOld;
	smokeList[anzSmokes].growSpeed = growSpeedSet;
	smokeList[anzSmokes].upSpeed = upSpeedSet;
	smokeList[anzSmokes].rotation = (float)(rand()%(int)(2*pi*100))/100;

	ZeroMemory(&smokeList[anzSmokes].mat, sizeof(D3DMATERIAL8));
	smokeList[anzSmokes].mat.Ambient.r = color.r;
    smokeList[anzSmokes].mat.Ambient.g = color.g;
    smokeList[anzSmokes].mat.Ambient.b = color.b;

	anzSmokes++;
	
	return;
}

bool Smoke::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	HRESULT hr;
	D3DVERTEX3D2		vertices[4];
	D3DVERTEX3D2		*pVertices;

	d3dDevice = d3dDeviceSet; //save the new pointer
	
	texNr = textures->newTex(d3dDevice,"stuff.tga");

	//make the smoke rectangle
	vertices[1].p.x = -1.0f;
	vertices[1].p.y = -1.0f;
	vertices[1].p.z = 0.0f;
	vertices[1].n.x = 0.0f;
	vertices[1].n.y = 0.0f;
	vertices[1].n.z = 1.0f;
	vertices[1].tx = 0.0f;
	vertices[1].ty = 0.5f;
	vertices[0].p.x = 1.0f;
	vertices[0].p.y = -1.0f;
	vertices[0].p.z = 0.0f;
	vertices[0].n.x = 0.0f;
	vertices[0].n.y = 0.0f;
	vertices[0].n.z = 1.0f;
	vertices[0].tx = 0.5f;
	vertices[0].ty = 0.5f;
	vertices[3].p.x = -1.0f;
	vertices[3].p.y = 1.0f;
	vertices[3].p.z = 0.0f;
	vertices[3].n.x = 0.0f;
	vertices[3].n.y = 0.0f;
	vertices[3].n.z = 1.0f;
	vertices[3].tx = 0.0f;
	vertices[3].ty = 1.0f;
	vertices[2].p.x = 1.0f;
	vertices[2].p.y = 1.0f;
	vertices[2].p.z = 0.0f;
	vertices[2].n.x = 0.0f;
	vertices[2].n.y = 0.0f;
	vertices[2].n.z = 1.0f;
	vertices[2].tx = 0.5f;
	vertices[2].ty = 1.0f;

	//Save new vertices in buffer
	if (FAILED(hr=d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX3D2),
		D3DUSAGE_WRITEONLY , D3DFVF_D3DVERTEX3D2,
		D3DPOOL_MANAGED, &g_pVB)))
	{
		DXTrace(__FILE__,__LINE__,hr,"CreateVertexBuffer()",true);
		return false;
	}
	
	//Vertexbuffer locken
	if (FAILED(hr=g_pVB->Lock( 0, 4*sizeof(D3DVERTEX3D2),(BYTE**)&pVertices,0)))
	{
		DXTrace(__FILE__,__LINE__,hr,"Lock()",true);
		return false;
	}
	memcpy( pVertices, vertices, 4*sizeof(D3DVERTEX3D2));
	g_pVB->Unlock();	//Vertexbuffer wieder freigeben
	return true;
}

bool Smoke::FrameMove()
{
	int i;
	D3DXMATRIX  mat1;

	for (i=0;i<anzSmokes;i++)
	{
		//the smoke gets old
		smokeList[i].old -= *fElapsedTime;
		if (smokeList[i].old < 0)		//delete smoke
		{
			//copy the last to this position
			anzSmokes--;
			smokeList[i].pos.x = smokeList[anzSmokes].pos.x;
			smokeList[i].pos.y = smokeList[anzSmokes].pos.y;
			smokeList[i].pos.z = smokeList[anzSmokes].pos.z;
			smokeList[i].width = smokeList[anzSmokes].width;
			smokeList[i].old   = smokeList[anzSmokes].old;
			smokeList[i].maxOld= smokeList[anzSmokes].maxOld;
			smokeList[i].growSpeed = smokeList[anzSmokes].growSpeed;
			smokeList[i].upSpeed = smokeList[anzSmokes].upSpeed;
			smokeList[i].mat = smokeList[anzSmokes].mat;
		}

		//Move the smoke up
		smokeList[i].pos.y += *fElapsedTime*smokeList[i].upSpeed;

		//widthen the smoke
		smokeList[i].width += *fElapsedTime*smokeList[i].growSpeed;

		//move the smoke
		D3DXMatrixTranslation( &smokeList[i].transMat, 
			smokeList[i].pos.x, 
			smokeList[i].pos.y, 
			smokeList[i].pos.z);
	
		//scale the smoke
		D3DXMatrixScaling(&mat1,smokeList[i].width,smokeList[i].width,smokeList[i].width);
		D3DXMatrixMultiply(&smokeList[i].transMat, &mat1, &smokeList[i].transMat);
	}
	return true;
}

bool Smoke::Render(D3DXVECTOR3 *vEyePt, D3DXVECTOR3 *vLookatPt)
{
	int i;
	HRESULT hr;
	D3DXMATRIX  mat1;
	D3DXMATRIX  tmpMat;
	D3DXVECTOR3	vDiff;

	if (texNr != -1) d3dDevice->SetTexture( 0, textures->getTex(texNr));

	// Set diffuse blending for alpha set in vertices.
    d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
    d3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
    d3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

    // Enable alpha testing (skips pixels with less than a certain alpha.)
    d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
    d3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
		
	hr = d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX3D2 );
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetVertexShader()",true);
		return false;
	}
	hr = d3dDevice->SetStreamSource( 0, g_pVB, sizeof(D3DVERTEX3D2));
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
		return false;
	}

	for (i=0;i<anzSmokes;i++)
	{
		d3dDevice->SetMaterial(&smokeList[i].mat);
		//set the intensity of the smoke
		d3dDevice->SetRenderState( D3DRS_ALPHAREF,0xFF-(int)(-(float)0xFF/smokeList[i].maxOld*
			  (smokeList[i].maxOld-smokeList[i].old)+(float)0xFF));
		
		//Calculate the transformation to the akt player
		//Calculate the vector from eye to the "look at" point
		D3DXVec3Subtract(&vDiff,vLookatPt,vEyePt);
		
		//Rotationmatrizen erstellen und zur Transformationsmatrix hinzuf�gen
		float rotY = -(float)(atan2(vDiff.z,vDiff.x)-pi/2);
		
		D3DXMatrixRotationY(&mat1, rotY);
		D3DXMatrixMultiply(&tmpMat, &mat1, &smokeList[i].transMat);
				
		if ((rotY >= -pi/4) && (rotY < pi/4))
			D3DXMatrixRotationX( &mat1, (float)(atan2(vDiff.z,vDiff.y)-pi/2));
		else if ((rotY >= 3*pi/4) && (rotY < 5*pi/4))
			D3DXMatrixRotationX( &mat1, -(float)(atan2(vDiff.z,vDiff.y)+pi/2));
		else if ((rotY >= pi/4) && (rotY < 3*pi/4))
			D3DXMatrixRotationX( &mat1, -(float)(atan2(-vDiff.x,vDiff.y)+pi/2)); 
		else 
			D3DXMatrixRotationX( &mat1, (float)(atan2(-vDiff.x,vDiff.y)-pi/2)); 
		D3DXMatrixMultiply(&tmpMat, &mat1, &tmpMat);

		//rotate the smoke
		D3DXMatrixRotationZ(&mat1,smokeList[i].rotation); 
		D3DXMatrixMultiply(&tmpMat, &mat1, &tmpMat);
		
		d3dDevice->SetTransform( D3DTS_WORLD, &tmpMat);

		hr = d3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP  , 0, 4-2 );
		if (FAILED(hr))
		{
			DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
			return false;
		}
	}

	d3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
    d3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );

	return true;
}

bool Smoke::DeleteDeviceObjects()
{
	anzSmokes = 0;
	SAFE_RELEASE(g_pVB);

	return true;
}
