//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_SMOKE)
#define N_SMOKE

#include "konstanten.h"
#include "testtext.h"
#include "textures.h"

class Smoke
{
public: 
	Smoke(D3DXMATRIX		*matWorldSet,
		  TestText			*testTextSet,
		  Textures			*texturesSet,
		  FLOAT             *fElapsedTimeSet);
	~Smoke();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
	bool FrameMove();
    bool DeleteDeviceObjects();
    bool Render(D3DXVECTOR3 *vEyePt, D3DXVECTOR3 *vLookatPt);
	void newSmoke(D3DVECTOR position, float startWidth, float startOld, float growSpeedSet, 
				float upSpeedSet, D3DXCOLOR color);
	
private:
	D3DXMATRIX      *matWorld;
	IDirect3DDevice8 *d3dDevice;
	TestText		*testText;
	Textures		*textures;
	FLOAT           *fElapsedTime;

	int				texNr;			//der Index der verwendeten 
	
	struct SmokeStruct
	{
		D3DVECTOR	pos;			//the position of the smoke
		float		width;			//how big is the smoke
		float		old;			//how long will the smoke visible
		float		maxOld;			//
		float		growSpeed;		//how fast grow the smoke?
		float		upSpeed;		//how fast move the smoke up?
		float		rotation;	
		D3DXMATRIX  transMat;		//the transformation matrix
		D3DMATERIAL8 mat;			//the material (color)
	} smokeList[MAXSMOKES];
	int				anzSmokes;		//nr. of smokes

	LPDIRECT3DVERTEXBUFFER8 g_pVB;	//Pointer to the smoke rectangle
};

#endif