//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "testline.h"

TestLine::TestLine(D3DXMATRIX      *matWorldSet)
{
	matWorld = matWorldSet;
	g_pVB = NULL;
}

TestLine::~TestLine()
{
}

void TestLine::deleteAllTestLines()
{
	int i;

	for (i=0; i<MAXTESTLINE; i++) 
	point1[i].x = -1;	//delete the lines
}

void TestLine::drawLine(int index, XYFloat newPoint1, XYFloat newPoint2)
{
	if (index >= MAXTESTLINE) return;
	
	point1[index] = newPoint1;
	point2[index] = newPoint2;
	makeVertices();
}

void TestLine::drawLine(XYFloat newPoint1, XYFloat newPoint2)
{
	int i;

	//find a free index
	for (i=0;i<MAXTESTLINE;i++) 
	{
		if (point1[i].x == -1)
		{
			point1[i] = newPoint1;
			point2[i] = newPoint2;
			makeVertices();
		}
	}
	return;	//if no free found, then write nothing
}

void TestLine::makeVertices()
{
	int i;
	D3DVERTEX3D2 oneLine[MAXTESTLINE*2];	
	D3DVERTEX3D2* pVertices;
	
	for (i=0;i<MAXTESTLINE;i++)
	{
		oneLine[2*i].n.x = 0.0f;
		oneLine[2*i].n.y = 0.0f;
		oneLine[2*i].n.z = 0.0f;
		oneLine[2*i].tx = 0.0f;
		oneLine[2*i].ty = 0.0f;
		oneLine[2*i+1].n.x = 0.0f;
		oneLine[2*i+1].n.y = 0.0f;
		oneLine[2*i+1].n.z = 0.0f;
		oneLine[2*i+1].tx = 0.0f;
		oneLine[2*i+1].ty = 0.0f;

		if (point1[i].x == -1) 
		{
			oneLine[2*i].p.x = 0.0f;
			oneLine[2*i].p.y = 0.0f;
			oneLine[2*i].p.z = 0.0f;
			oneLine[2*i+1].p.x = 0.0f;
			oneLine[2*i+1].p.y = 0.0f;
			oneLine[2*i+1].p.z = 0.0f;
		}
		else
		{
			//make vertices
			oneLine[2*i].p.x = point1[i].x;
			oneLine[2*i].p.y = 0.1f;
			oneLine[2*i].p.z = point1[i].y;
			oneLine[2*i+1].p.x = point2[i].x;
			oneLine[2*i+1].p.y = 0.1f;
			oneLine[2*i+1].p.z = point2[i].y;
		}
		
	}
	//Save new vertices in buffer
	//Vertexbuffer locken
	if (FAILED(g_pVB->Lock( 0, MAXTESTLINE*2*sizeof(D3DVERTEX3D2),(BYTE**)&pVertices,0)))
	{
		MessageBox(NULL,"error: g_pVB->Lock() (TestLine::makeVertices())",NULL,NULL);
		return;
	}
	memcpy( pVertices, oneLine, MAXTESTLINE*2*sizeof(D3DVERTEX3D2));
	g_pVB->Unlock();	//Vertexbuffer wieder freigeben
}

bool TestLine::Render()
{
	HRESULT hr;

	d3dDevice->SetMaterial(&mat);
	if (FAILED(hr =d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX3D2)))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetVertexShader()",true);
		return false;
	}
	d3dDevice->SetTransform( D3DTS_WORLD, matWorld );
	if (FAILED(hr = d3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE)))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetTexturStageState()",true);
		return false;
	}
	if (FAILED(hr = d3dDevice->SetStreamSource( 0, g_pVB, sizeof(D3DVERTEX3D2))))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
		return false;
	}
	if (FAILED(hr = d3dDevice->DrawPrimitive(D3DPT_LINELIST, 0, MAXTESTLINE)))
	{
		DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
		return false;
	}
	if (FAILED(hr = d3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE)))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetTexturStageState()",true);
		return false;
	}
	return true;
}

bool TestLine::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	d3dDevice = d3dDeviceSet;		//update the d3dDevice
	
	ZeroMemory(&mat, sizeof(D3DMATERIAL8));
	mat.Ambient.r = 1.0f;
    mat.Ambient.g = 1.0f;
    mat.Ambient.b = 1.0f;
	mat.Ambient.a = 1.0f;
	mat.Diffuse.a = 1.0f;
	
	if (FAILED(d3dDevice->CreateVertexBuffer(MAXTESTLINE*2*sizeof(D3DVERTEX3D2),
		D3DUSAGE_WRITEONLY , D3DFVF_D3DVERTEX3D2,
		D3DPOOL_MANAGED, &g_pVB)))
	{
		MessageBox(NULL,"error: d3dDevice->CreateVertexBuffer() (TestLine::InitDeviceObjects())",NULL,NULL);
		return false;
	}
	
	makeVertices();
	return true;
}


bool TestLine::DeleteDeviceObjects()
{
	SAFE_RELEASE(g_pVB);
	return true;
}

