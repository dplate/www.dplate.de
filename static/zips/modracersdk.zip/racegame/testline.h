//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_TESTLINE)
#define N_TESTLINE

#include "konstanten.h"

class TestLine
{
public: 
	TestLine(D3DXMATRIX      *matWorldSet);
	~TestLine();
	void deleteAllTestLines();
	void drawLine(int index, XYFloat newPoint1, XYFloat newPoint2);
	void drawLine(XYFloat newPoint1, XYFloat newPoint2);
	void makeVertices();
	bool Render();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
	bool DeleteDeviceObjects();

private:
	IDirect3DDevice8 *d3dDevice;
	D3DXMATRIX      *matWorld;
	D3DMATERIAL8	mat;

	XYFloat point1[MAXTESTLINE];
	XYFloat point2[MAXTESTLINE];

	LPDIRECT3DVERTEXBUFFER8 g_pVB;	//Pointer zu einem VertexBuffer
};

#endif