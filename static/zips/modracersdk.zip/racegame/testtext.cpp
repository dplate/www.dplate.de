//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "testtext.h"

TestText::TestText()
{
	int i;

	font = new CD3DFont((char*)FONTNAME, 12, D3DFONT_BOLD );
	for (i=0; i<MAXTESTTEXT; i++) strcpy_s(oneText[i],"");	//delete all texts
}

TestText::~TestText()
{
	SAFE_DELETE(font);
}

void TestText::drawText(int index, char *newText)
{
	int i;

	if (index >= MAXTESTTEXT) return;

	if (strlen(newText)+strlen(allText) >= MAXSTRING)	//safety check
	{
		MessageBox(NULL,"Can't make message text",NULL,NULL);
		return;
	}

	strcpy_s(oneText[index],newText);	//copy the new string
	strcpy_s(allText,"");				//delete the complete string
	for (i=0;i<MAXTESTTEXT;i++) 
	{
		strcat_s(allText,oneText[i]);	//build up the complete string
		strcat_s(allText,"\n");
	}
}

void TestText::drawText(char *newText)
{
	int i;

	//find a free index
	for (i=0;i<MAXTESTTEXT;i++) 
	{
		if (strcmp(oneText[i],"") == 0)
		{
			drawText(i,newText);
			return;
		}
	}
	return;	//if no free found, then write nothing
}

bool TestText::Render()
{
	if (font->DrawText( 2, 2, D3DCOLOR_ARGB(255,255,255,0), allText) != S_OK)
	{
		MessageBox(NULL,"Error: cd3dfont->Render()",NULL,NULL);
		return false;
	}
	return true;
}

bool TestText::InitDeviceObjects(IDirect3DDevice8 *d3dDevice)
{
	if (font->InitDeviceObjects(d3dDevice) != S_OK)
	{
		MessageBox(NULL,"Error: cd3dfont->InitDeviceObjects()",NULL,NULL);
		return false;
	}
	return true;
}

bool TestText::RestoreDeviceObjects()
{
	if (font->RestoreDeviceObjects() != S_OK)
	{
		MessageBox(NULL,"Error: cd3dfont->RestoreDeviceObjects()",NULL,NULL);
		return false;
	}
	return true;
}

bool TestText::InvalidateDeviceObjects()
{
	if (font->InvalidateDeviceObjects() != S_OK)
	{
		MessageBox(NULL,"Error: cd3dfont->InvalidateDeviceObjects()",NULL,NULL);
		return false;
	}
	return true;
}

bool TestText::DeleteDeviceObjects()
{
	if (font->DeleteDeviceObjects() != S_OK)
	{
		MessageBox(NULL,"Error: cd3dfont->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}
	return true;
}

bool TestText::FinalCleanup()
{
	SAFE_DELETE(font);
	return true;
}