//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_TESTTEXT)
#define N_TESTTEXT

#include "konstanten.h"
#include "D3DFont2.h"

class TestText
{
public: 
	TestText();
	~TestText();
	void drawText(int index, char *newText);
	void drawText(char *newText);
	bool Render();
	bool InitDeviceObjects(IDirect3DDevice8 *d3dDevice);
	bool RestoreDeviceObjects();
	bool InvalidateDeviceObjects();
	bool DeleteDeviceObjects();
	bool FinalCleanup();

private:
	CD3DFont *font;
	char allText[MAXSTRING];				//all texts in one string
	char oneText[MAXTESTTEXT][MAXSTRING];	//the texts
	
};

#endif