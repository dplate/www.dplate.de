//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_TEXT)
#define N_TEXT

//Deutsch

const char TXTPOSITION[] 	= "Position: ";			//Positionsanzeige
const char TXTLAPS[] 		= "Runde: ";			//Rundenanzeige
const char TXTLASTLAP[] 	= "Letzte Runde: ";		//Letzte Rundenzeitanzeige
const char TXTBESTLAP[] 	= "Beste Runde: ";		//Beste Rundenzeitanzeige

const char TXTONELAP[] 		= " Runde";				//eine Runde R�ckstand 
const char TXTMORELAPS[] 	= " Runden";			//mehrere Runden R�ckstand
const char TXTENDOFRACE[]	= "Ende des Rennens";	//Rennen ist zu Ende
const char TXTPAUSEMENUE[]	= "Return = Exit\nEsc = Weiter"; //the pause-menue

const char TXTSTARTRACE[] 	= "Rennen starten";		//Im Men�
const char TXTEXITGAME[] 	= "Spiel beenden";		
const char TXTTITEL[] 		= "ModRacer";			//der Name des Spiels
const char TXTSELECTCAR[] 	= "Autos";				//Windowsmen�titel
const char TXTSELECTMAP[] 	= "Strecke";			//Windowsmen�titel
const char TXTTITELLAPS[]	= "Runden";				//Windowsmen�titel
const char TXTANZLAPS[]		= " Runden";			//Im Men�
const char TXTPLAYER[]		= "Spieler";			//Im Men�
const char TXTCOMPUTER[]	= "Computer";			//Im Men�
const char TXTCREDITS[]		= "Credits";			//Im Men�
const char TXTWINDOWTITEL[] = "ModRacer";			//Windowtitel

const char TXTSTEER[]		= "Lenken";				//F�r die Controllerauswahl
const char TXTACCBRA[]		= "Gas/Bremse";
const char TXTACCELERATE[]	= "Gas";
const char TXTBRAKE[]		= "Bremse";
const char TXTCHANGECAMERA[]= "Wechsle Kamera";
const char TXTREVERSE[]		= "R�ckw�rts";
const char TXTSTEERLEFT[]	= "links Lenken";
const char TXTSTEERRIGHT[]	= "rechts Lenken";
const char TXTRESET[]		= "Zur�cksetzen";

const int MAXCREDITTEXT		= 42;
const char TXTCREDITTEXT[MAXCREDITTEXT][50] = 
{	"-Programmierung",
	"Dirk Plate",
	"",
	"-Modelle",
	"Dirk Plate",
	"Pawel Pohulajewski",
	"Andre Targaschewski",
	"Lutz Tewes",
	"",
	"-Texturen",
	"David Novak",
	"Dirk Plate",
	"Pawel Pohulajewski",
	"Andre Targaschewski",
	"Lutz Tewes",
	"",
	"-Sound",
	"Dirk Plate",
	"",
	"-Musik",
	"Heiko Plate",
	"",
	"-Strecken",
	"Jan Goepfert",
	"Dirk Plate",
	"",
	"-Betatester",
	"Matthias Buchetics",
	"Jan Goepfert",
	"Dominic Hehenberger",
	"David Novak",
	"Dirk Plate",
	"Pawel Pohulajewski",
	"Andre Targaschewski",
	"Lutz Tewes",
	"",
	"-Besonderer Dank",
	"Lutzs Texture-CD",
	"fmod Sound-System",
	"http://www.ta-pp.de",
};

/*
//English
const char TXTPOSITION[] 	= "Position: ";			//Positionsanzeige
const char TXTLAPS[] 		= "Lap: ";				//Rundenanzeige
const char TXTLASTLAP[] 	= "Last lap: ";			//Letzte Rundenzeitanzeige
const char TXTBESTLAP[] 	= "Best lap: ";			//Beste Rundenzeitanzeige
const char TXTPAUSEMENUE[]	= "Return = Exit\nEsc = Continue"; //the pause-menue

const char TXTONELAP[] 		= " Lap";				//eine Runde R�ckstand 
const char TXTMORELAPS[] 	= " Laps";				//mehrere Runden R�ckstand
const char TXTENDOFRACE[]	= "End of Race";		//Rennen ist zu Ende

const char TXTSTARTRACE[] 	= "Start Race";			//Im Men�
const char TXTEXITGAME[] 	= "Exit Game";		
const char TXTTITEL[] 		= "ModRacer";			//der Name des Spiels
const char TXTSELECTCAR[] 	= "Select cars";		//Windowsmen�titel
const char TXTSELECTMAP[] 	= "Select map";			//Windowsmen�titel
const char TXTTITELLAPS[]	= "Laps";				//Windowsmen�titel
const char TXTANZLAPS[]		= " Laps";				//Im Men�
const char TXTPLAYER[]		= "Player";
const char TXTCOMPUTER[]	= "Computer";
const char TXTCREDITS[]		= "Credits";			//Im Men�
const char TXTWINDOWTITEL[] = "ModRacer";			//Windowtitel

const char TXTSTEER[]		= "Steer";				//F�r die Controllerauswahl
const char TXTACCBRA[]		= "Accelerate/Brake";
const char TXTACCELERATE[]	= "Accelerate";
const char TXTBRAKE[]		= "Brake";
const char TXTCHANGECAMERA[]= "Change Camera";
const char TXTREVERSE[]		= "Reverse";
const char TXTSTEERLEFT[]	= "Steer left";
const char TXTSTEERRIGHT[]	= "Steer right";
const char TXTRESET[]		= "Reset";

 const int MAXCREDITTEXT		= 42;
const char TXTCREDITTEXT[MAXCREDITTEXT][50] = 
{	"-Programming",
	"Dirk Plate",
	"",
	"-Models",
	"Dirk Plate",
	"Pawel Pohulajewski",
	"Andre Targaschewski",
	"Lutz Tewes",
	"",
	"-Textures",
	"David Novak",
	"Dirk Plate",
	"Pawel Pohulajewski",
	"Andre Targaschewski",
	"Lutz Tewes",
	"",
	"-Sound",
	"Dirk Plate",
	"",
	"-Music",
	"Heiko Plate",
	"",
	"-Maps",
	"Jan Goepfert",
	"Dirk Plate",
	"",
	"-Betatesting",
	"Matthias Buchetics",
	"Jan Goepfert",
	"Dominic Hehenberger",
	"David Novak",
	"Dirk Plate",
	"Pawel Pohulajewski",
	"Andre Targaschewski",
	"Lutz Tewes",
	"",
	"-Special Thanks",
	"Lutzs Texture-CD",
	"fmod Sound-System",
	"http://www.ta-pp.de",
};
 */ 
#endif
