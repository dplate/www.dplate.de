//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "textures.h"

Textures::Textures(char			*homeDirSet,
				   TestText		*testTextSet)
{
	anzTex = 0;
	homeDir = homeDirSet;
	testText = testTextSet;
}

Textures::~Textures()
{

}

int Textures::newTex(IDirect3DDevice8 *d3dDevice,char *fileName)
{
	int i;
	char changeDir[MAXSTRING];
	char buffer1[128];
	char buffer2[128];
	HRESULT hr;

	if (fileName == NULL) return -1;
	if (anzTex >= MAXTEX)
	{
		MessageBox(NULL,"Too many different textures",NULL,NULL);
		return -1;
	}
	//ist die Texture schon drin?
	for (i=0;i<anzTex;i++) 
	{
		if (strcmp(texture[i].name,fileName) == 0) return i;
	}

	//change in the texture-directory
	strcpy_s(changeDir,homeDir);
	strcat_s(changeDir,TEXDIR);
	if (_chdir(changeDir) == -1) MessageBox(NULL,changeDir,NULL,NULL);
	//Texture laden
	hr = D3DXCreateTextureFromFileEx( d3dDevice, fileName, 
                D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, 
			D3DFMT_A8R8G8B8             /*D3DFMT_UNKNOWN*/, 
                D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR, 
                D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR, 0xFF000000, NULL, NULL, &texture[anzTex].tex );
	if (FAILED(hr)) return -1;

	strcpy_s(texture[anzTex].name,fileName);
	anzTex++;

	//test writing
	strcpy_s(buffer1,"Textures: ");
	_itoa_s(anzTex,buffer2,10);
	strcat_s(buffer1,buffer2);
	testText->drawText(1,buffer1);

	return anzTex-1;
}

LPDIRECT3DTEXTURE8 Textures::getTex(int index)
{
	if ((index < 0) || (index >= anzTex)) return NULL;
	return texture[index].tex;
}

bool Textures::DeleteDeviceObjects()
{
	int i;

	for (i=0;i<anzTex;i++) 
	{
		SAFE_RELEASE(texture[i].tex);
		strcpy_s(texture[i].name,"");
	}
	anzTex = 0;
	return true;
}
