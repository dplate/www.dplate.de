//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_TEXTURES)
#define N_TEXTURES

#include "konstanten.h"
#include "testtext.h"

class Textures
{
public: 
	Textures(char			*homeDirSet,
			TestText		*testTextSet);
	~Textures();

	int newTex(IDirect3DDevice8 *d3dDevice,char *fileName);
	LPDIRECT3DTEXTURE8 getTex(int index);
	bool DeleteDeviceObjects();
	
private:
	char			*homeDir;
	TestText		*testText;

	struct texStruct
	{
		LPDIRECT3DTEXTURE8  tex;
		char name[MAXSTRING];	
	} texture[MAXTEX];
	int anzTex;						//Wieviele verschiedene Texturen gibt?
};

#endif