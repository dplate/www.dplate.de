//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#define STRICT
#include "stdafx.h"
#include "Titel.h"

Titel::Titel(IDirect3DDevice8 *d3dDeviceSet,
			D3DXMATRIX      *matWorldSet,
		 	D3DXMATRIX      *matProjSet,
		   FLOAT           *fElapsedTimeSet,
		   char			   *homeDirSet,
		   TestText		   *testTextSet,
		   TestLine		   *testLineSet,
		   POINT		   *screenMaxSet)
{
	char buffer[MAXSTRING];

	d3dDevice = d3dDeviceSet;
	matWorld = matWorldSet;
	matProj = matProjSet;
	fElapsedTime = fElapsedTimeSet;
	homeDir	= homeDirSet;
	testText = testTextSet;
	testLine = testLineSet;
	screenMax = screenMaxSet;

	//Die Textureverwaltungsklasse einrichten
	textures = new Textures(homeDir,testText);
	vertexBuffer = NULL;
	countDown = 10.0f;

	if (!OneTimeSceneInit())
	{
		MessageBox(NULL,"Error: Titel->OneTimeSceneInit() (4)",NULL,NULL);
		return;
	}
	if (!InitDeviceObjects(d3dDevice))
	{
		MessageBox(NULL,"Error: Titel->InitDeviceObjects() (4)",NULL,NULL);
		return;
	}
	if (!RestoreDeviceObjects())
	{
		MessageBox(NULL,"Error: Titel->RestoreDeviceObjects() (4)",NULL,NULL);
		return;
	}

	strcpy_s(buffer,homeDir);
	strcat_s(buffer,SOUNDDIR);
	if (_chdir(buffer) == -1) MessageBox(NULL,buffer,NULL,NULL);
	music = FMUSIC_LoadSong("titel.mid");
	if (!music)
	{
		printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
		exit(1);
	}
}

Titel::~Titel()
{
	InvalidateDeviceObjects();
 	DeleteDeviceObjects();
	FinalCleanup();

	FMUSIC_StopSong(music);
	FMUSIC_FreeSong(music);
}

bool Titel::OneTimeSceneInit()
{
	return true;
}

bool Titel::FrameMove()
{
	HRESULT hr;
	int i;

	//Loop midi
	if (!FMUSIC_IsPlaying(music)) FMUSIC_PlaySong(music);

	countDown -= *fElapsedTime;

	if (countDown < 0)
	{
		for (i=0;i<4;i++)
		{
			edge[i].x += rand()%5-2;
			edge[i].y += rand()%5-2;
		}
	}

	D3DVERTEX2D2	*pVertices;
	D3DVERTEX2D	vertices2[4] =
	{
		{(float)edge[3].x,	(float)edge[3].y,	1.0f, 0.1f,  0.0f, 1.0f},
		{(float)edge[0].x,	(float)edge[0].y,	1.0f, 0.1f,  0.0f, 0.0f},	//x y z w tx ty
		{(float)edge[2].x,	(float)edge[2].y,	1.0f, 0.1f,  1.0f, 1.0f},
		{(float)edge[1].x,	(float)edge[1].y,	1.0f, 0.1f,  1.0f, 0.0f},
	};
	
	//Vertexbuffer locken
	if (FAILED(hr=vertexBuffer->Lock( 0, 4*sizeof(D3DVERTEX2D),(BYTE**)&pVertices,D3DLOCK_DISCARD)))
	{
		DXTrace(__FILE__,__LINE__,hr,"Lock()",true);
		return false;
	}
	memcpy( pVertices, vertices2, 4*sizeof(D3DVERTEX2D));
	vertexBuffer->Unlock();	//Vertexbuffer wieder freigeben


	return true;
}

bool Titel::Render()
{
	HRESULT hr;

	hr = d3dDevice->SetVertexShader( D3DFVF_D3DVERTEX2D);
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetVertexShader()",true);
		return false;
	}
	hr = d3dDevice->SetStreamSource( 0, vertexBuffer, sizeof(D3DVERTEX2D));
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetStreamSource()",true);
		return false;
	}
	if (texNr != -1) d3dDevice->SetTexture( 0,textures->getTex(texNr));
	hr = d3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP  , 0, 2 );
	if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"DrawPrimitive()",true);
		return false;
	}
	return true;
}

bool Titel::InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet)
{
	d3dDevice = d3dDeviceSet;

	D3DCAPS8 d3dCaps;
    d3dDevice->GetDeviceCaps( &d3dCaps );
    if( 640 < d3dCaps.MaxTextureWidth )
		texNr = textures->newTex(d3dDevice,"titelbig.bmp");
	else texNr = textures->newTex(d3dDevice,"titel.bmp");
	return true;
}

bool Titel::RestoreDeviceObjects()
{
	HRESULT hr;

    vEyePt.x      = 0.0f;
	vEyePt.y      = 1.0f;
	vEyePt.z      = 0.0f;

    vLookatPt.x   = 0; 
	vLookatPt.y   = 0;
	vLookatPt.z   = 0; 

    vUpVec      = D3DXVECTOR3( 0.0f, +1.0f,  0.0f );

	D3DXMatrixLookAtLH(&matView, &vEyePt, &vLookatPt, &vUpVec );
	if (FAILED(hr = d3dDevice->SetTransform(D3DTS_VIEW, &matView)))
	{
		DXTrace(__FILE__,__LINE__,hr,"SetTransform()",true);
		return false;
	}
    
    // Set default render states
	for (int i=0;i<7;i++)
	{
		d3dDevice->SetTextureStageState(i, D3DTSS_MINFILTER, D3DTEXF_ANISOTROPIC);
    	d3dDevice->SetTextureStageState(i, D3DTSS_MAGFILTER, D3DTEXF_ANISOTROPIC);
		d3dDevice->SetTextureStageState(i, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
		d3dDevice->SetTextureStageState(i, D3DTSS_MAXANISOTROPY, 2 );
	}
	
	// Turn off D3D lighting
	d3dDevice->SetRenderState( D3DRS_LIGHTING, false );
    // Turn off the zbuffer
    d3dDevice->SetRenderState( D3DRS_ZENABLE, false );

	hr = d3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX2D),
                                        D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0,
                                        D3DPOOL_DEFAULT, &vertexBuffer );  
    if (FAILED(hr))
	{
		DXTrace(__FILE__,__LINE__,hr,"titel->RestoreDeviceObjects()",true);
		return false;
	}

	//Wabble the screen
	edge[0].x = 0; edge[0].y = 0;
	edge[1].x = screenMax->x; edge[1].y = 0;
	edge[2].x = screenMax->x; edge[2].y = screenMax->y;
	edge[3].x = 0; edge[3].y = screenMax->y;


	return true;
}


bool Titel::InvalidateDeviceObjects()
{
	SAFE_RELEASE(vertexBuffer);
	return true;
}


bool Titel::DeleteDeviceObjects()
{
	if (!textures->DeleteDeviceObjects())
	{
		MessageBox(NULL,"Error: textures->DeleteDeviceObjects()",NULL,NULL);
		return false;
	}
	d3dDevice = NULL;
	return true;
}

bool Titel::FinalCleanup()
{
	return true;
}

int Titel::message(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch( uMsg )
    {
    case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_ESCAPE: case VK_SPACE: case VK_RETURN:
			return SZMENUE;
			break;
		}
		break;
	}
    return -1;
}


