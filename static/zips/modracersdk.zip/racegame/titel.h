//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(N_TITEL)
#define N_TITEL

#include "Textures.h"
#include "testtext.h"
#include "testline.h"

class Titel
{
public:
    Titel(IDirect3DDevice8 *d3dDeviceSet,
    	 D3DXMATRIX      *matWorldSet,
		 D3DXMATRIX      *matProjSet,
		 FLOAT           *fElapsedTimeSet,
		 char			 *homeDirSet,
		 TestText		 *testTextSet,
		 TestLine		 *testTextLine,
		 POINT			 *screenMaxSet);
	~Titel();
	bool OneTimeSceneInit();
    bool InitDeviceObjects(IDirect3DDevice8 *d3dDeviceSet);
    bool RestoreDeviceObjects();
    bool InvalidateDeviceObjects();
    bool DeleteDeviceObjects();
    bool Render();
    bool FrameMove();
    bool FinalCleanup();
	int message(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	// Transform matrices
	D3DXMATRIX      *matWorld;
    D3DXMATRIX      *matProj;
	FLOAT           *fElapsedTime;
	char			*homeDir;
	TestText		*testText;
	TestLine		*testLine;
	IDirect3DDevice8 *d3dDevice;
	POINT			*screenMax;

	D3DXMATRIX      matView;
	D3DXVECTOR3		vEyePt;      
    D3DXVECTOR3		vLookatPt;   
    D3DXVECTOR3		vUpVec;
	Textures		*textures;

	int						texNr;			//the texture of the titel
	LPDIRECT3DVERTEXBUFFER8 vertexBuffer;	//Pointer to the titel rectangle

	FMUSIC_MODULE	*music;				//The backgroundmidi-file

	POINT			edge[4];			//The position of the four edges
	float			countDown;			//count down until wabble will begin
};

#endif