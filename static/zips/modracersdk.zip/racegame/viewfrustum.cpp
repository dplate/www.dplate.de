//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#include "stdafx.h"
#include "ViewFrustum.h"

//-----------------------------------------------------------------------------
// Name: CViewFrustum::ExtractPlanes()
// Desc: Die 6 Frustum-Ebenen werden erstellt
//-----------------------------------------------------------------------------
void CViewFrustum::ExtractPlanes(D3DXMATRIX *g_matView, D3DXMATRIX *g_matProj)
{
	float fCalc;
	D3DXMATRIX	matViewProj;
	D3DXVECTOR3	vNormal;

	D3DXMatrixMultiply ( &matViewProj, g_matView, g_matProj);
	
	// Linke Clipping Plane
	FrustumPlanes[VF_LEFT].a = -(matViewProj._14 + matViewProj._11);
	FrustumPlanes[VF_LEFT].b = -(matViewProj._24 + matViewProj._21);
	FrustumPlanes[VF_LEFT].c = -(matViewProj._34 + matViewProj._31);
	FrustumPlanes[VF_LEFT].d  = -(matViewProj._44 + matViewProj._41);

	// Rechte Clipping Plane
	FrustumPlanes[VF_RIGHT].a = -(matViewProj._14 - matViewProj._11);
	FrustumPlanes[VF_RIGHT].b = -(matViewProj._24 - matViewProj._21);
	FrustumPlanes[VF_RIGHT].c = -(matViewProj._34 - matViewProj._31);
	FrustumPlanes[VF_RIGHT].d  = -(matViewProj._44 - matViewProj._41);

	// Obere Clipping Plane
	FrustumPlanes[VF_UP].a = -(matViewProj._14-matViewProj._12);
	FrustumPlanes[VF_UP].b = -(matViewProj._24-matViewProj._22);
	FrustumPlanes[VF_UP].c = -(matViewProj._34-matViewProj._32);
	FrustumPlanes[VF_UP].d  = -(matViewProj._44-matViewProj._42);

	// Untere Clipping Plane
	FrustumPlanes[VF_BOTTOM].a = -(matViewProj._14+matViewProj._12);
	FrustumPlanes[VF_BOTTOM].b = -(matViewProj._24+matViewProj._22);
	FrustumPlanes[VF_BOTTOM].c = -(matViewProj._34+matViewProj._32);
	FrustumPlanes[VF_BOTTOM].d  = -(matViewProj._44+matViewProj._42);

	// Nahe Clipping Plane
	FrustumPlanes[VF_NEAR].a = -(matViewProj._14+matViewProj._13);
	FrustumPlanes[VF_NEAR].b = -(matViewProj._24+matViewProj._23);
	FrustumPlanes[VF_NEAR].c = -(matViewProj._34+matViewProj._33);
	FrustumPlanes[VF_NEAR].d  = -(matViewProj._44+matViewProj._43);

	// Ferne Clipping Plane
	FrustumPlanes[VF_FAR].a = -(matViewProj._14-matViewProj._13);
	FrustumPlanes[VF_FAR].b = -(matViewProj._24-matViewProj._23);
	FrustumPlanes[VF_FAR].c = -(matViewProj._34-matViewProj._33);
	FrustumPlanes[VF_FAR].d  = -(matViewProj._44-matViewProj._43);

	// Normalenvektoren der Ebenen normalisieren
	for (int i = 0; i < 6; i++) 
	{
		vNormal = D3DXVECTOR3 ( FrustumPlanes[i].a, FrustumPlanes[i].b, FrustumPlanes[i].c );

		fCalc = 1.0f / sqrtf( D3DXVec3Dot( &vNormal, &vNormal ) );

		FrustumPlanes[i].a *= fCalc;
		FrustumPlanes[i].b *= fCalc;
		FrustumPlanes[i].c *= fCalc;
		FrustumPlanes[i].d *= fCalc;
	}
}

int CViewFrustum::CullSphere( D3DXVECTOR3 *sphereCenter, float *sphereRadius)
{
	D3DXVECTOR3	vNormal;
	float		fDistance;
	int i;
	
	for (i=0;i<6;i++)
	{
		vNormal = D3DXVECTOR3 ( FrustumPlanes[i].a, FrustumPlanes[i].b, FrustumPlanes[i].c );
		fDistance = FrustumPlanes[i].d;
		if (D3DXVec3Dot( &vNormal, sphereCenter ) + fDistance > *sphereRadius)
			return SPHERE_AUSSERHALB;
	}
	return SPHERE_GECLIPPED;
}

