//programmed by Dirk Plate in 2001
//http://dP-Software.home.pages.de/

#if !defined(H_VIEWFRUSTUM)
#define H_VIEWFRUSTUM

#include "konstanten.h"

// ViewFrustrum Seiten: 
#define VF_LEFT		0 // Linke Clipping Plane
#define VF_RIGHT	1 // Rechte Clipping Plane
#define VF_UP		2 // Obere Clipping Plane
#define VF_BOTTOM	3 // Untere Clipping Plane
#define VF_NEAR		4 // Ferne Clipping Plane
#define VF_FAR		5 // Nahe Clipping Plane

// Culling Ergebnisse:
#define SPHERE_AUSSERHALB 0
#define SPHERE_GECLIPPED  1

class CViewFrustum
{
	D3DXPLANE	FrustumPlanes[6];

public:
	CViewFrustum() {};
	CViewFrustum(D3DXMATRIX *g_matView, D3DXMATRIX *g_matProj)	
		{ ExtractPlanes (g_matView,g_matProj ); };
	
	void ExtractPlanes(D3DXMATRIX *g_matView, D3DXMATRIX *g_matProj);
	int CullSphere( D3DXVECTOR3 *sphereCenter, float *sphereRadius);
};

#endif