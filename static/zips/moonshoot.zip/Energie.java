import java.awt.*;

public class Energie extends Component
{
	float aktEnergie = 0;	//Wieviel Energie gerade
	int maxEnergie = 0; //Wieviel Energie gibt es maximal
	int limEnergie = 0; //Wieviel Energie wird f�r eine Aktion gebraucht
	float speed = 0;	//Mit welcher Geschwindigkeit f�r die Energie erzeugt
	int posR = 0;		//die rechte Seite des Balkens
	int posL = 0;		//die linke Seite des Balkens
	int posO = 100;		//die obere Seite des Balkens
	int posU = 0;		//die untere Seite des Balkens
	int breite = 10;	//die breite des Balkens

	public Energie(int setMaxEnergie, int setLimEnergie, float setSpeed, int setPosX)
	{
		maxEnergie = setMaxEnergie;	//die maximale Energie des Balkens festlegen
		limEnergie = setLimEnergie;	//Die Mindestenergie f�r eine Aktion festlegen
		speed = setSpeed;			//Die Energieerzeugungsgeschwindigkeit festlegen
		posL = setPosX;				//die linke Seite des Balkens festlegen
		posR = posL+breite;			//Die rechte Seite des Balkens festlegen
		posU = posO+maxEnergie;		//die untere Seite des Balkens festlegen
	}

	public void reCalc()
	{
		aktEnergie += speed;		//Energie erzeugen
		if ((int)aktEnergie > maxEnergie) aktEnergie = (float)maxEnergie;	//Energie begrenzen
	}

	public boolean checkEnergie()
	{
		if ((int)aktEnergie < limEnergie) return false;	//Falsch zur�ckliefern, wenn Energie nicht reicht
		else return true;	//sonst reicht die Energie
	}

	public void changeEnergie(int anz)
	{
		aktEnergie += (float)anz;				//Energie abziehen oder hinzuf�gen
		if ((int)aktEnergie > maxEnergie) aktEnergie = (float)maxEnergie;	//Energie begrenzen
		if ((int)aktEnergie < 0) aktEnergie = (float)0;
	}

	public void display(Graphics screen)
	{
		Color farbe;
		if (aktEnergie < limEnergie)		//bei nicht ausreichender Energie
			farbe = new Color(255,0,0); 	//Farbe des Energiebalkens rot
		else farbe = new Color(0,255,0);	//sonst Farbe des Energiebalkens gr�n
		screen.setColor(farbe);				//Farbe einstellen
		screen.fillRect(posL,posU-(int)aktEnergie, breite,(int)aktEnergie);	//Energiebalken malen
    	farbe = new Color(0,150,0);			//Farbe des Rahmens einstellen
		screen.setColor(farbe);				//Farbe festlegen
		screen.drawRect(posL,posU-maxEnergie, breite,maxEnergie);	//Rahmen malen
		screen.drawLine(posL,posU-limEnergie,posR,posU-limEnergie);
		farbe = new Color(0,80,0);			//Farbe des Rand des Rahmens festlegen
		screen.setColor(farbe);				//Farbe �bernehmen
		screen.drawRect(posL+1,posU-limEnergie+1, breite-2,limEnergie-2);	//Rand des Rahmens malen
		screen.drawRect(posL+1,posO+1, breite-2,maxEnergie-limEnergie-2);
		screen.drawRect(posL-1,posO-1, breite+2,maxEnergie+2);
	}
}