import java.awt.*;
import java.awt.event.*;
import java.awt.Font;

public class Game extends Frame implements Runnable
{
	final int szIntro = 0;		//Die Introschrift anzeigen
	final int szInit  = 1;		//alle n�tigen Variablen f�rs Spiel initialisieren
	final int szSpiel = 2;		//das eigentliche Spiel
	final int szEnde  = 3;		//Ergebnis-Schriftzug anzeigen
	int spielZustand = 0;		//der aktuelle Zustand des Spiels

	//Die Objekte
	Punkte gamePunkte = new Punkte();						//die Punkteanzeige
	Objekte gameObjekte[] = new Objekte[Konst.anzObjekte];	//die fliegenden Objekte
	Kanone gameKanone;		//die Kanone (und Schild und Energieanzeige)
	Kuppeln gameKuppeln;	//Die Wohnkuppeln
	Titel gameTitel;		//Die rotierende Schrift

	Image offscreenImage;	//F�r die doppelte Pufferung
	Graphics offscreen;

	Image backBild;			//Das Hintergrundbild

	Thread gameThread;		//zeigt auf den Thread, wenn das Spiel gestartet
	GameApplet applet = null;	//wenn als applet gestartet, dann ist hier der Pointer drin

	int spielDauer;			//die Spieldauer in Frames (f�r die Level)

    public Game(GameApplet setApplet)	//Konstruktor
    {
		super("Moon Shoot");	//Titelleiste benennen

		applet = setApplet;		//Falls ein Applet, dann haben wir jetzt ein Pointer darauf
		setSize(Konst.maxX,Konst.maxY);	//Fenster auf die richtige Gr��e bringen
		setResizable(false);	//Fenster soll nicht in der Gr��e ver�nderbar sein
		setVisible(true);		//Fenster anzeigen

		WindowListener l = new WindowAdapter()	//Den Zustand des Fensters �berwachen
		{
			public void windowClosing(WindowEvent e) //Wenn das Fenster geschlossen wird
			{
				gameThread = null;					//Den Thread schliessen
				if (applet == null)	System.exit(0); //Wenn kein Applet, dann einfach raus
				applet.stop();						//sonst die Stop-Routine vom Applet aufrufen
			}
		};
		addWindowListener(l);	//Den Listener zum Fenster hinzuf�gen

		Keysteuerung steuer = new Keysteuerung();	//Die Tastenabfrage aktivieren

	    offscreenImage = createImage(getSize().width,getSize().height);	//Ein imagin�res Bild im Speicher erstellen
		offscreen = offscreenImage.getGraphics();	//Den Handle von dem Bild offscreen hinzuf�gen

		gameKuppeln = new Kuppeln(applet,gameObjekte);			//Die Kuppeln erzeugen
		gameKanone = new Kanone(applet,gameObjekte,gamePunkte);	//Die Kanone erzeugen

		for (int i=0;i<Konst.anzObjekte;i++) gameObjekte[i] = new Objekte(applet); //Alle fliegende Objekte erzeugen

		try
		{
			if (applet == null)			//Wenn kein Applet
			{
				backBild = Toolkit.getDefaultToolkit().getImage("back.gif"); //Hintergrundbild laden
			}
			else						//Wenn Applet
			{
				backBild = applet.getImage(applet.getCodeBase(),"back.gif"); //Hintergrundbild laden
			}
			MediaTracker tracker = new MediaTracker(this);	//Mediatracker erzeugen
			tracker.addImage(backBild, 0); 	//Bild zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.waitForAll();			//solange warten, bis alle Bilder geladen sind
		}
		catch(java.lang.InterruptedException ie)	//Falls ein Fehler beim Laden
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes");	//Fehlermeldung ins Konsolenfenster schreiben
		}

		gameTitel = new Titel("Moon Shoot","dP-Software");	//Die Introschrift initialisieren

		gameThread = new Thread(this);		//neuen Thread f�r das Spiel erzeugen
		gameThread.start();					//Thread starten (weiter gehts dann in run())
	}

    public Thread getGameThread()	//benutzt die Klasse "GameApplet", um Zugriff auf den Thread zu bekommen
    {
		return gameThread;
	}

	public void run()		//wird von thread.start aufgerufen
    {
		int anzFutsch;		//Wieviele Kuppeln sind noch heil

		Thread thisThread = Thread.currentThread(); //den namen des aktuellen Threads speichern
		while(gameThread == thisThread)		//solange wiederholen, bis Thread nicht mehr vorhanden
		{
			try
			{
				Thread.sleep(50);			//eine 20tel Sekunde Pause machen (ergibt ca. 20 Bilder/sek)
			}
			catch(InterruptedException ie)
			{
				System.out.println("Irgendein Sleep Fehler");
			}

			switch (spielZustand)			//Je nach Spielzustand etwas anderes machen
			{
			case szIntro:					//beim Intro
				gameTitel.reCalc();			//nur die rotierende Schrift neu berechnen
				break;
			case szInit:					//beim init
				for (int i=0;i<Konst.anzObjekte;i++) gameObjekte[i].init(2);	//alle fliegende Objekte initialisieren
				gameKanone.init();			//die Kanone in den Ursprungszustand setzen
				gameKuppeln.init();			//den Kuppeln ihre Lebensenergie geben
				gamePunkte.init();			//die Punktzahl auf 0 setzen
				spielDauer = 0;				//wieder Level 0 einstellen
				spielZustand++;				//dann gleich weiter mit dem n�chsten Zustand
				break;
			case szSpiel:					//im eigentlichen Spiel
				for (int i=0;i<Konst.anzObjekte;i++) 		//alle fliegenden Objekte durchgehen
					if (!gameObjekte[i].reCalc()) 			//neue Position berechnen
						gameObjekte[i].init(spielDauer/500);//wenn futsch (oder au�erhalb des Bildschirms), wieder neu setzen
				gameKanone.reCalc();						//Kollisionsabfrage f�r Schild und Kanone
				anzFutsch = gameKuppeln.reCalc();			//Kollisionsabfrage f�r die Kuppeln (liefert die Anzahl der zerst�rten Kuppeln zur�ck)
				gameKanone.updateEnergy(4-anzFutsch);		//Die Energiezufuhr an die Anzahl der intakten Kuppeln anpassen
				if (anzFutsch >= 4)		//Wenn alle Kuppeln zerst�rt
				{
					spielZustand++;		//weiter zum n�chsten Spielzustand
					gameTitel = new Titel("GAME OVER","Score: "+ String.valueOf(gamePunkte.getPunkte())); //GameOvermeldung initialisieren
				}
				spielDauer++;			//Die Spieldauer weiterz�hlen
				if (spielDauer > 10000) //Wenn > 10000 (entspricht Level 10), dann Sieg
				{
					spielZustand++;		//weiter zum n�chsten Spielzustand
					gameTitel = new Titel("YOU HAVE WON","Score: "+ String.valueOf(gamePunkte.getPunkte())); //Siegesmeldung initialisieren
				}
				break;
			case szEnde:				//bei der Endszene
				for (int i=0;i<Konst.anzObjekte;i++) //Wieder die Objekte rumfliegen lassen
					if (!gameObjekte[i].reCalc())
						gameObjekte[i].init(spielDauer/500);
				gameTitel.reCalc();		//und die rotierende Schrift berechnen
				break;
			}

			repaint();	//jedes mal das Bild neu zeichnen
		}
	}

	public void update(Graphics screen) //wird von repaint aufgerufen
	{
		paint(screen);		//Bildschirm nicht l�schen, sondern einfach wieder Paint
	}

    public void paint(Graphics screen)	//wird von update aufgerufen
	{
		if (gameThread == null) return; //noch nicht initialisiert, also raus

		offscreen.drawImage(backBild,0,0,this); //das Hintergrundbild malen

		gameKuppeln.display(offscreen);			//die Kuppeln malen

		if (spielZustand != szIntro)			//bei allen Zust�nden au�er dem Intro
		{
			gameKanone.display(offscreen);		//die Kanone malen
			for (int i=0;i<Konst.anzObjekte;i++)
				gameObjekte[i].display(offscreen);	//alle rumfliegenden Objekte malen
			gamePunkte.display(offscreen);		//die Punktzahl anzeigen

			offscreen.setColor(Konst.weiss);	//die schriftfarbe auf wei� stellen
			offscreen.setFont(Konst.schrift);	//die schriftart auf die Standardschrift stellen
    		offscreen.drawString("Level: " + String.valueOf(spielDauer/1000), 20, 50); //das aktuelle Level anzeigen
		}

		if ((spielZustand == szEnde) || (spielZustand == szIntro))
			gameTitel.display(offscreen); //die rotierende Schrift nur beim Intro um Endbild anzeigen

		screen.drawImage(offscreenImage, 0, 0, this); //offscreen auf screen malen
	}

	public class Keysteuerung implements KeyListener	//Unterklasse f�r die Tastenabfrage
	{
	    public Keysteuerung()		//Konstruktor
	    {
	      	addKeyListener(this);	//einen Tastendruckaufpasser hinzuf�gen
	    }

	    public void keyPressed(KeyEvent event)	//Wenn eine Taste gedr�ckt wurde
	    {
		   	if (spielZustand == szSpiel)		//im eigentlichen Spiel
		   	{
			   	if (event.getKeyCode() == KeyEvent.VK_LEFT)	//Pfeil nach links gedr�ckt
	    		{
					gameKanone.move((float)1/50);	//Kanone 1/50pi nach links bewegen
				}
				if (event.getKeyCode() == KeyEvent.VK_RIGHT) //Pfeil nach rechts gedr�ckt
				{
					gameKanone.move(-(float)1/50);	//Kanone 1/50pi nach rechts bewegen
				}
			}
			if ((spielZustand == szEnde) || (spielZustand == szIntro))	//im Intro und Endbild
			{
				if (event.getKeyCode() == KeyEvent.VK_ENTER) //Enter-Taste gedr�ckt
				{
					spielZustand = szInit;			//Spiel neu beginnen
				}
			}
		}

		public void keyReleased(KeyEvent event)	//Wenn eine Taste losgelassen wurde
		{
			if (spielZustand == szSpiel)		//im eigentlichen Spiel
			{
				if (event.getKeyCode() == KeyEvent.VK_UP)	//Pfeil nach oben losgelassen
				{
					gameKanone.schuss();		//Kanone schiessen lassen
				}
				if (event.getKeyCode() == KeyEvent.VK_DOWN)	//Pfeil nach unten losgelassen
				{
					gameKanone.schild();		//Schild aktivieren
				}
			}
		}

		public void keyTyped(KeyEvent event)	//Funktion zwar �berschrieben, aber nichts damit gemacht
		{
		}
	}

	public static void main(String[] args)		//Hauptprogramm
	{
		Game frame = new Game(null);			//das GameObjekt erzeugen (zieht alles andere nach sich)
	}
}
