public class GameApplet extends java.applet.Applet	//Notwendige Klassenkopfzeile, damit es ein Applet ist
{
	Game appGame;			//das Objekt des eigentlichen Spiels
	Thread refThread;		//Ein Pointer auf den Hauptthread in der Klasse Game

	public void init()		//Wird automatisch beim starten des Applets aufgerufen
	{
		appGame  = new Game(this);		//Ein Objekt der hauptklasse des Spiels machen
	}

	public void stop()		//Wird vom windowslistener in der Klasse Game aufgerufen
	{
		refThread = appGame.getGameThread();	//Pointer auf Hauptthread besorgen
		refThread = null;		//Thread l�schen
		appGame.dispose();		//Fenster schliessen
	}
}