import java.awt.*;
import java.math.*;

public class Kanone extends Component
{
	final float laenge = 50;	//Wieviel Pixel lang ist die Kanone

	int posX;					//Die Position der Kanone (die Wurzel)
	int posY;

	float winkel;				//der aktuell eingestellte Winkel
	int displaySchuss = 0;		//>0 wenn ein Schuss gemalt werden soll
	int displaySchild = 0;		//>0 wenn Schild aktiviert
	int schildPosY = Konst.maxY-90;	//In welcher H�he befindet sich das Schild
	Objekte [] allObjekte;		//ein Pointer auf ein Feld (f�r die fliegenden Objekte)
	Punkte punkteAnzeige;		//ein Pointer auf die Punkteklasse
	Energie schussEnergie;		//das Objekt f�r die SchussEnergie
	Energie schildEnergie;		//das Objekt f�r die SchildEnergie
	Image schildBild;			//Das Schild-Bitmap
	Image kanoneBild;			//Das Kanonengeb�ude-Bitmap

	public Kanone(GameApplet applet, Objekte [] setAllObjekte, Punkte setPunkteAnzeige)	//Konstruktor
	{
		try
		{
			if (applet == null)	//Wenn nicht als Applet gestartet
			{
				schildBild = Toolkit.getDefaultToolkit().getImage("schild.gif"); //Schildbild laden
				kanoneBild = Toolkit.getDefaultToolkit().getImage("kanone.gif"); //Kanonenbild laden
			}
			else				//wenn als Applet gestartet
			{
				schildBild = applet.getImage(applet.getCodeBase(),"schild.gif"); //Schildbild laden
				kanoneBild = applet.getImage(applet.getCodeBase(),"kanone.gif"); //Kanonenbild laden
			}
			MediaTracker tracker = new MediaTracker(this);	//neuen Mediatracker erzeugen
			// Bilder zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.addImage(schildBild, 0);
			tracker.addImage(kanoneBild, 0);
			tracker.waitForAll(); //warten, bis alle Bilder geladen sind
		}
		catch(java.lang.InterruptedException ie)	//Wenn Fehler beim laden
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes"); //dann Fehlermeldung ausgeben
		}

		posX = Konst.maxX/2; //Die Kanone in die Mitte des unteren Bildschirmrandes setzen
		posY = Konst.boden;
		allObjekte = setAllObjekte;	//Jetzt haben wir einen "pointer" auf das Feld der Objekte
		punkteAnzeige = setPunkteAnzeige; //und einen Pointer auf die Punkteanzeige
	}

	public void init()
	{
		schussEnergie = new Energie(200,50,(float)2,Konst.maxX-25);	//den Schussenergiebalken erzeugen
		schildEnergie = new Energie(200,180,(float)0.5,15);			//den Schildenergiebalken erzeugen
		winkel=Konst.pi/2;		//die Kanone auf senkrecht stellen
	}

	public void reCalc()
	{
		int x,i;

		if (displaySchuss > 0) displaySchuss--;		//falls geschossen wurde, Wert eins runterz�hlen
		if (displaySchild > 0)	//Kollision mit Schild �berpr�fen
		{
			for (x=0;x<Konst.maxX;x++)				//Jeden Pixel des Schildes durchgehen
			{
				for (i=0;i<Konst.anzObjekte;i++)	//jedes Objekt durchgehen
				{
					if (allObjekte[i].checkKollision(x,schildPosY))	//�berpr�fen, ob Punkt im Objekt
					{
						allObjekte[i].explode();	//Objekte explodieren lassen
						punkteAnzeige.newPunkte(1); //und ein Punkt gutschreiben
					}
				}
			}
			displaySchild--;	//schilddauer eins runterz�hlen (bei 0 ist Schild aus)
		}
		//Kollision mit Kanone �berpr�fen
		for (x=(Konst.maxX-kanoneBild.getWidth(this))/2;x<(Konst.maxX+kanoneBild.getWidth(this))/2;x++)
		{
			for (i=0;i<Konst.anzObjekte;i++)	//jedes Objekt durchgehen
				if (allObjekte[i].checkKollision(x,Konst.boden-kanoneBild.getHeight(this)))
					allObjekte[i].explode(); //falls Kollision, Objekt explodieren lassen
		}

		schussEnergie.reCalc();		//den Schussenergiebalken neu berechnen lassen
		schildEnergie.reCalc();		//den Schildenergiebalken neu berechnen lassen
	}

	public void move(float anz)
	{
		winkel += Konst.pi*anz;		//den Winkel der Kanone auf neuen Wert einstellen
		if (winkel < Konst.pi/8) winkel = Konst.pi/8;			//Grenzen einhalten
		if (winkel > Konst.pi-Konst.pi/8) winkel = Konst.pi-Konst.pi/8;
	}

	public void schuss()
	{
		int i,j;
		float cosW,sinW;

		if (schussEnergie.checkEnergie())	//Wenn genug Energie f�r Schuss vorhanden
		{
			cosW = (float)Math.cos(winkel);	//den Kosinus und Sinus des Winkel berechnen (brauchen wir gleich �fters)
			sinW = (float)Math.sin(winkel);

			for (j=0;j<(Konst.maxX+Konst.maxY);j++)	//Jeden Pixel auf dem Laserstrahl durchgehen
			{
				for (i=0;i<Konst.anzObjekte;i++)	//Jedes Objekt durchgehen
				{
					if (allObjekte[i].checkKollision((int)(posX+(float)j*cosW),(int)(posY-(float)j*sinW)))
					{
						allObjekte[i].explode();	//Wenn Kollision, dann Objekt explodieren lassen
						punkteAnzeige.newPunkte(1);	//und ein Punkt gutschreiben
					}
				}
			}
			displaySchuss = 4;					//den Strahl 4 Frames lang anzeigen
			schussEnergie.changeEnergie(-50);	//die Schussenergie abziehen
		}
	}

	public void schild()
	{
		if (schildEnergie.checkEnergie())		//Wenn genug Energie f�rs Schild verf�gbar
		{
			displaySchild = 100;				//Schild 100 Frames lang aktivieren
			schildEnergie.changeEnergie(-180);	//und die Schildenergie abziehen
		}
	}

	public void updateEnergy(int anzKraft)		//neu energieerzeugungsgeschwindigkeit ermitteln
	{
		schildEnergie.speed = (float)anzKraft * (float)0.2;	//beide Balken auf die richtige Geschwindigkeit setzen
		schussEnergie.speed = (float)anzKraft * (float)0.5;
	}

	public void display(Graphics screen)
	{
		int spitzeX,spitzeY;

		spitzeX = posX+(int)(laenge*Math.cos(winkel));		//Die Spitze der Kanone berechnen
		spitzeY = posY-(int)(laenge*Math.sin(winkel));

		if (schussEnergie != null)		//nur wenn die Balken schon initialisiert sind
		{
			schussEnergie.display(screen);		//den Schussenergiebalken malen
			schildEnergie.display(screen);		//den Schildenergiebalken malen
		}
		if (displaySchuss > 0)							//Wenn der Schuss angezeigt werden soll
		{
			Color farbeSchuss = new Color(255,100,100); //Farbe auf rot setzen und mittigen Strahl malen
			screen.setColor(farbeSchuss);
			screen.drawLine(spitzeX,spitzeY,posX+(int)((Konst.maxX+Konst.maxY)*Math.cos(winkel)),posY-(int)((Konst.maxX+Konst.maxY)*Math.sin(winkel)));
			farbeSchuss = new Color(155,0,0);			//Farbe auf dunkelrot setzen und R�nder malen
			screen.setColor(farbeSchuss);
			screen.drawLine(spitzeX-1,spitzeY,posX+(int)((Konst.maxX+Konst.maxY)*Math.cos(winkel))-1,posY-(int)((Konst.maxX+Konst.maxY)*Math.sin(winkel)));
			screen.drawLine(spitzeX+1,spitzeY,posX+(int)((Konst.maxX+Konst.maxY)*Math.cos(winkel))+1,posY-(int)((Konst.maxX+Konst.maxY)*Math.sin(winkel)));
		}

		Color farbeKanone = new Color(100,100,255);		//Farbe auf Violett-Blau setzen
		screen.setColor(farbeKanone);
		screen.drawLine(posX,posY,spitzeX,spitzeY);		//5mal die Kanone malen (immer versetzt, dadurch eine bestimmte Dicke)
		screen.drawLine(posX-1,posY,spitzeX-1,spitzeY);
		screen.drawLine(posX-2,posY,spitzeX-2,spitzeY);
		screen.drawLine(posX+1,posY,spitzeX+1,spitzeY);
		screen.drawLine(posX+2,posY,spitzeX+2,spitzeY);

		screen.drawImage(kanoneBild,(Konst.maxX-kanoneBild.getWidth(this))/2,
									Konst.boden-kanoneBild.getHeight(this),this); //Das Geb�ude der Kanone malen

		if (displaySchild > 0) screen.drawImage(schildBild,0,schildPosY,Konst.maxX,5,this); //Wenn Schild, dann malen
	}
}