import java.awt.*;

public class Konst extends Component		//Hier sind alle Konstanten drin
{
	static float pi = (float)3.1415926535897932384626433832795; //pi: was hast du gedacht, was das sein soll?

	static int maxX = 400;	//Fensterbreite
	static int maxY = 500;	//Fensterh�he

	static int boden = maxY-53;	//Dort stehen die Kuppeln drauf und prallen die Asteroiden auf
	static int anzObjekte = 10; //Wieviel fliegende Objekte gibt es

	static Color weiss = new Color(255,255,255);		//die Farbe wei�
	static Font schrift = new Font("TimesRoman", Font.PLAIN, 18); //die Standardschrift
}