import java.awt.*;

public class Kuppeln extends Component
{
	int [] posX = new int[4];		//Die x-Position aller Kuppeln
	int posY = Konst.boden-25;		//obere Seite der Kuppel
	int breite,hoehe;				//breite und h�he einer Kuppel
	Objekte [] allObjekte;			//Pointer auf alle fliegenden Objekte
	int [] life = new int[4];		//Wieviel Lebensenergie haben die Kuppeln noch?
	Image [] kuppelBild = new Image[5]; //F�r jeden Gesundheitszustand ein Bild

	public Kuppeln(GameApplet applet, Objekte [] setAllObjekte) //Konstruktor
	{
		int i;

		try
		{
			if (applet == null)		//Wenn nicht als Applet gestartet
			{
				kuppelBild[0] = Toolkit.getDefaultToolkit().getImage("kuppel.gif");		//Bild von ganzer Kuppel laden
				kuppelBild[1] = Toolkit.getDefaultToolkit().getImage("kuppel1.gif");	//Bild von leicht zerst�rter Kuppel laden
				kuppelBild[2] = Toolkit.getDefaultToolkit().getImage("kuppel2.gif");	//Bild von mittel zerst�rter Kuppel laden
				kuppelBild[3] = Toolkit.getDefaultToolkit().getImage("kuppel3.gif");	//Bild von stark zerst�rter Kuppel laden
				kuppelBild[4] = Toolkit.getDefaultToolkit().getImage("kuppel4.gif");	//Bild von zerst�rter Kuppel laden
			}
			else 					//Wenn als Applet gestartet
			{
				kuppelBild[0] = applet.getImage(applet.getCodeBase(),"kuppel.gif");		//Bild von ganzer Kuppel laden
				kuppelBild[1] = applet.getImage(applet.getCodeBase(),"kuppel1.gif");	//Bild von leicht zerst�rter Kuppel laden
				kuppelBild[2] = applet.getImage(applet.getCodeBase(),"kuppel2.gif");	//Bild von mittel zerst�rter Kuppel laden
				kuppelBild[3] = applet.getImage(applet.getCodeBase(),"kuppel3.gif");	//Bild von stark zerst�rter Kuppel laden
				kuppelBild[4] = applet.getImage(applet.getCodeBase(),"kuppel4.gif");	//Bild von zerst�rter Kuppel laden
			}
			MediaTracker tracker = new MediaTracker(this);	//Mediatracker erstellen
			// Bilder zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			for (i=0;i<5;i++) tracker.addImage(kuppelBild[i], 0);
			tracker.waitForAll();	//Warten bis fertig geladen
		}
		catch(java.lang.InterruptedException ie)	//falls Fehler beim laden
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes"); //Fehlermeldung
		}

		breite = kuppelBild[0].getWidth(this);	//Die Breite der Kuppeln speichern
		hoehe = kuppelBild[0].getHeight(this);	//Die H�he der Kuppeln speichern
		posX[0] = 30;							//position der linksten Kuppel
		posX[1] = 30 + breite + 20;				//position der zweitlinksten Kuppel
		posX[2] = Konst.maxX-30-breite;			//position der rechtesten Kuppel
		posX[3] = Konst.maxX-30-breite-20-breite;//position der zweitrechtesten Kuppel

		allObjekte = setAllObjekte;	//Jetzt haben wir einen "pointer" auf das Feld der Objekte
	}

	public void init()
	{
		int i;

		for (i=0;i<4;i++) life[i] = 0;	//Zerst�rtheitsgrad auf 0 setzen
	}

	public int reCalc()
	{
		int x,i,j;
		int anzFutsch = 0;		//Die Anzahl der zerst�rten Kuppel

		for (j=0;j<4;j++)		//Kollision f�r jede Kuppel �berpr�fen
		{
			if (life[j] == 4)	//Wenn Kuppel schon zerst�rt, dann keine Kollisionsabfrage
			{
				anzFutsch++;	//Eine mehr kaputt
				continue;
			}
			for (x=posX[j];x<posX[j]+breite;x++)	//Jeden Pixel �ber den Kuppeln durchgehen
			{
				for (i=0;i<Konst.anzObjekte;i++)	//Jedes fliegende Objekt durchgehen
				{
					if (allObjekte[i].checkKollision(x,posY))	//Wenn Pixel in fliegendem Objekt
					{
						allObjekte[i].explode();	//Objekt explodieren lassen
						life[j]++;					//und zerst�rtheitgrad um eins erh�hen
					}
				}
			}
		}
		return anzFutsch;		//die Anzahl der zerst�rten Kuppeln zur�ckliefern
	}

	public void display(Graphics screen)
	{
		int i;

		for (i=0;i<4;i++) screen.drawImage(kuppelBild[life[i]],posX[i],posY, this);	//die vier Kuppeln malen
	}
}