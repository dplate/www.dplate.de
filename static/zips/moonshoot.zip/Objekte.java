import java.awt.*;
import java.math.*;

public class Objekte extends Component
{
	float posX;				//Die Position des Objekts
	float posY;
	Image objektBild;		//Das Bild des ganzen Objekts
	int breite,hoehe; 		//Breite und Hoehe des Objekts
	float vX,vY;			//Die Geschwindigkeit
	float t = (float)0.2;	//Wieviel Zeit vergeht bei einem Frame
	int futsch = 0;			//Zeigt den futschheitzustand des Objekts an (ganz->bruchst�cke->ganz kaputt)
	float [] breakX = new float[5];	//Die Positionen der Bruchst�cke
	float [] breakY = new float[5];
	float [] breakVX = new float[5]; //Die Geschwindigkeiten der Bruchst�cke
	float [] breakVY = new float[5];
	Image breakBild;		//das Bild des Bruchst�cks
	int breakBreite,breakHoehe;	//Die hoehe und breite der Bruchst�cke

	public Objekte(GameApplet applet)	//Konstruktor
	{
		try
		{
			if (applet == null)	//Wenn nicht als Applet gestartet
			{
				objektBild = Toolkit.getDefaultToolkit().getImage("asteroid.gif");	//Bild des Asteroiden laden
				breakBild = Toolkit.getDefaultToolkit().getImage("asterbruch.gif");	//Bild des Asteroidenbruchst�cks laden
			}
			else				//Wenn als Applet gestartet
			{
				objektBild = applet.getImage(applet.getCodeBase(),"asteroid.gif");	//Bild des Asteroiden laden
				breakBild = applet.getImage(applet.getCodeBase(),"asterbruch.gif");	//Bild des Asteroidenbruchst�cks laden
			}
			MediaTracker tracker = new MediaTracker(this);	//Mediatracker erzeugen
			// Bilder zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.addImage(objektBild, 0);
			tracker.addImage(breakBild, 0);
			tracker.waitForAll();		//warten bis alle Bilder geladen
		}
		catch(java.lang.InterruptedException ie)	//wenn Fehler beim laden
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes");	//Fehlermeldung
		}

		breite = objektBild.getWidth(this);		//Breite des Objekts speichern
		hoehe = objektBild.getHeight(this);		//H�he des Objekts speichern
		breakBreite = breakBild.getWidth(this);	//Breite des Bruchst�cks speichern
		breakHoehe = breakBild.getHeight(this); //H�he des Bruchst�cks speichern
	}

	public void init(int maxSpeed)				//Objekt mit bestimmter Maximalgeschwindigkiet initialisieren
	{
		futsch = 0;								//das Objekt ist am Anfang nicht futsch
		posX = (float)Math.random() * Konst.maxX; //Das Objekt beliebig am oberen Bildschirmrand plazieren
		posY = -10;								//Das Objekt ganz nach oben setzen
		vX = (float)Math.random() * 10-5; 		//Zuf�llige Geschwindigkeit (und damit auch Richtung)
		vY = (float)Math.random() * maxSpeed+5;
	}

	public boolean reCalc()
	{
		int i;

		if (futsch != 0) futsch++;	//Wenn schon kaputt, dann weiterz�hlen
		if (futsch > 10) return false;	//Wenn ganz kaputt, Objekt von "Game" neu initialisieren lassen

		if (futsch == 0)			//Wenn nicht kaputt
		{
			posX += vX*t;			//Neue Position mit der Geschwindigkeit errechnen
			posY += vY*t;

			if (posY > Konst.boden)	explode();	//Kollision mit Boden? dann explodieren lassen

			//Wenns au�erhalb vom Bildschirm, dann false zur�ckliefern
			if ((posX > Konst.maxX) || (posX < 0) || (posY > Konst.maxY)) return false;
		}
		else								//wenn kaputt
		{
			for (i=0;i<5;i++)				//Dann die Positionen der 5 Bruchst�cke berechnen
			{
				breakX[i] += breakVX[i]*t;
				breakY[i] += breakVY[i]*t;
			}
		}

		return true; //sonst normal weiter
	}

	public boolean checkKollision(int checkX, int checkY)	//�berpr�fen ob Pixel innerhalb des Objekts
	{
		if (futsch == 0)	//Nur �berpr�fen, wenn Objekt noch heil
		{
			//Pixel innerhalb der Grenzen
			if ((checkX>=(int)posX) && (checkX<=(int)posX+breite) && (checkY>=(int)posY) && (checkY<=(int)posY+hoehe)) return true;
		}
		return false;		//Wenn bis hier gekommen, dann keine Kollision
	}

	public void explode()		//Objekt explodieren lassen
	{
		int i;

		futsch++;				//Objektzustand auf futsch setzen (auf 1)
		for (i=0;i<5;i++)		//Jedes Bruchst�ck durchgehen
		{
			breakX[i] = posX;	//Bruchst�cke bekommen die Position des Objekts
			breakY[i] = posY;
			breakVX[i] = vX+(float)Math.random() * 10-5;	//St�cke in zuf�llige Richtung wegfliegen lassen
			breakVY[i] = vY+(float)Math.random() * 10-5;
		}
	}

	public void display(Graphics screen)
	{
		int i;

		//Wenn Objekt ganz, dann normales Bild malen
		if (futsch == 0) screen.drawImage(objektBild, (int)posX, (int)posY, this);
		else					//sonst
		{
			for (i=0;i<5;i++)	//alle Bruchst�cke
			{
				screen.drawImage(breakBild, (int)breakX[i], (int)breakY[i], this); //malen
			}
		}
	}
}