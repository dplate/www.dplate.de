import java.awt.*;
import java.awt.Font;

public class Punkte extends Component
{
	int gesamtPunkte;	//Wieviele Punkte insgesamt

	public Punkte()		//Konstruktor, brauche ich eigentlich gar nicht
	{

	}

	public void init()
	{
		gesamtPunkte = 0;			//Punktzahl auf 0 setzen
	}

	public void newPunkte(int anz)
	{
		gesamtPunkte += anz;		//Punktzahl um angegebenen Wert erh�hen
	}

	public int getPunkte()
	{
		return gesamtPunkte;		//aktuelle Punktzahl zur�ckliefern
	}

	public void display(Graphics screen)
	{
		screen.setColor(Konst.weiss);	//Schriftfarbe auf wei� setzen
		screen.setFont(Konst.schrift);	//Schrift auf normale Schrift setzen
    	screen.drawString("Score: "+String.valueOf(gesamtPunkte), Konst.maxX-100, 50);	//Punktzahl ausgeben
	}
}