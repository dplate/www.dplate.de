import java.awt.*;
import java.awt.Font;

public class Titel extends Component
{
	String text1;		//Textzeile 1
	String text2;		//Textzeile 2
	int breite1;		//die Breite der Textzeile 1
	int breite2;		//die Breite der Textzeile 2
	int posX = Konst.maxX/2;		//der Mittelpunkt des Rotationskreises
	int posY = Konst.maxY/2;		//(der Mittelpunkt des Fensters)
	float radius = Konst.maxY/2;	//der Radius des Rotationskreises
	float winkel = Konst.pi/2;		//Der aktuelle Winkel, wo sich die Schrift befindet
	FontMetrics fm = getFontMetrics(Konst.schrift);	//Um die Gr��e eines Strings zu ermitteln

	public Titel(String setText1, String setText2)	//Konstruktor
	{
		text1 = setText1;					//Textzeile 1 speichern
		text2 = setText2;					//Textzeile 2 speichern
		breite1 = fm.stringWidth(text1);	//Breite der Textzeile 1 ermitteln
		breite2 = fm.stringWidth(text2);	//H�he der Textzeile 2 ermitteln
	}

	public void reCalc()
	{
		winkel += Konst.pi/40;				//den Winkel weiterdrehen lassen
		radius -= 3;						//den Radius verringern
		if (radius < -Konst.maxY/2) radius = Konst.maxY/2;	//Falls der Radius wieder ganz am Rand, wieder von vorne anfangen
	}

	public void display(Graphics screen)
	{
		screen.setColor(Konst.weiss);		//schriftfarbe auf wei� setzen
		screen.setFont(Konst.schrift);		//Schrift auf normale Schrift setzen
		//Die beiden  Textzeilen an die richtige Position des Rotationskreises malen
    	screen.drawString(text1,(int)((posX+Math.cos(winkel)*radius)-breite1/2),(int)(posY+Math.sin(winkel)*radius));
    	screen.drawString(text2,(int)((posX+Math.cos(winkel+Konst.pi)*radius)-breite1/2),(int)(posY+Math.sin(winkel+Konst.pi)*radius));
	}
}