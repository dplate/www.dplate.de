"Moon Shoot"
von dP-Software


Starten des Spiels:

Es gibt bei Java zwei M�glichkeiten, entweder das Spiel als Applet zu starten oder als Programm.

Als Applet (nicht optimal):
Mit dem "Netscape Navigator", dem "Microsoft Internet Explorer" oder dem "Applet-Viewer" die Datei "index.htm" laden. Dann sollte das Spiel automatisch laden.

Als Programm (optimal):
Daf�r muss Java auf dem Rechner installiert sein. Das Spiel kann dann mit diesem Befehl in der DOS-Eingabeauforderung im Spielverzeichnis gestartet werden: "java Game" (Gro�- und Kleinschreibung beachten)


Anleitung:

Am unteren Bildschirmrand befindet sich eine Siedlung auf dem Mond. Die vier Glaskuppeln dieser Stadt werden st�ndig von Asteroideneinschl�gen bedroht. Aus diesem Grund wurde eine riesige Laserkanone errichtet, die alle anfliegenden Asteroiden vernichten soll. Sie haben nun die Aufgabe, diese Kanone zu steuern. Mit den Pfeiltasten (links/rechts) k�nnen Sie die Kanone ausrichten, mit dem Pfeil nach oben k�nnen Sie den Laser ausl�sen. Zus�tzlich k�nnen Sie noch mit der "Pfeil nach unten"-Taste ein Schild �ber der Siedlung errichten, die s�mtliche Asteroiden abwehrt. Diese Aktionen k�nnen Sie nur durchf�hren, wenn Sie gen�gend Energie besitzen. Der rechte Balken zeigt die Energie f�r die Laserkanone an, der Linke die Energie f�r das Schild. Leider sind Sie auf die Energieversorgung aus der Stadt angewiesen, d.h. je weniger Kuppeln intakt sind, desto weniger Energie bekommen sie f�r Ihre Kanone.
Ziel des Spiels ist es, bis Level 10 durchzuhalten und m�glichst viele Asteroiden abzuschiessen. Sind alle vier Glaskuppeln der Stadt zerst�rt, ist das Spiel zu Ende.


Anmerkungen:

Die *.java Dateien im Spielverzeichnis sind nicht zum Spielen notwendig. Sie enthalten f�r Interessierte den Quellcode des Spiels.
Auf �lteren Browsern kann es sein, dass das Spiel nicht startet, da diese noch nicht vollst�ndig Java unterst�tzt haben.
Unter dem "Internet Explorer 4.0" und dem "Netscape Navigator 4.0" l�uft es fehlerfrei, allerdings reagieren die Tasten beim Navigator etwas sp�t, so dass das Spielen etwas schwieriger wird. Da die Javaunterst�tzung der Browser nicht optimal ist, ruckelt das Spiel auch etwas, wenn es als Applet gestartet wird.


Werbung:

Noch mehr gratis Spiele von dP-Software gibt es unter: http://dP-Software.home.pages.de/
Bei Fragen Email an mich: dP-Software@gmx.de


Dirk Plate 
am 29.11.2000