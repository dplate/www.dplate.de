import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.GridLayout;

public class Game extends JFrame implements Runnable
{
	Thread gameThread;		//zeigt auf den Thread, wenn das Spiel gestartet

	JPanel gPane;			//Die Ebene mit der Grafik
	JLabel text;			//Der Text
	JButton startKnopf;		//Der StartKnopf
	long startZeit =-1;		//Um diese Zeit ist die Ampel auf Rot geschaltet
	boolean check;				//hat der Zufallsgenerator schon zugeschlagen

	public Game()	//Konstruktor
    {
		super("React");			//Titelleiste benennen

		setResizable(false);	//Fenster soll nicht in der Gr��e ver�nderbar sein
		setSize(Konst.maxX,Konst.maxY);	//Fenster auf die richtige Gr��e bringen

		try						//Aussehen der Benutzeroberfl�che festlegen
		{
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		}
		catch (Exception e)
	    {
			System.err.println("Kann nicht auf die Standardbenutzeroberfl�che umschalten" + e);
		}

		WindowListener l = new WindowAdapter()		//Den Zustand des Fensters �berwachen
		{
			public void windowClosing(WindowEvent e)//Wenn das Fenster geschlossen wird
			{
				gameThread = null;
				System.exit(0); //einfach raus
			}
		};
		addWindowListener(l);				//Den Listener zum Fenster hinzuf�gen

		//Die Kn�pfe usw. einf�gen
		JPanel pane = new JPanel();			//Eine neue Ebene erzeugen
		pane.setLayout(new GridLayout(3,1));//Die Anordnung der Schaltfl�chen festlegen
		text = new JLabel("Willkommen bei React",SwingConstants.CENTER);	//Den Text erzeugen
		pane.add(text);						//Textebene in die andere Ebene einf�gen
		gPane = new JPanel();				//Eine neue Ebene f�r die Grafik erzeugen
		gPane.setBackground(Color.green);	//Hintergrundfarbe auf gr�n stellen
		pane.add(gPane);					//Grafikebene in die andere Ebene einf�gen
		startKnopf = new JButton("Start");	//den Startknopf erzeugen
		startKnopf.addActionListener(new startAction());//Die Aktionen von diesem Knopf abfragen
		pane.add(startKnopf);				//Den Knopf hinzuf�gen
		setContentPane(pane);				//die Ebene dem Fenster zurordnen

		setVisible(true);					//Das Fenster anzeigen
	}

   	public void run()		//wird von thread.start aufgerufen
    {
		try	{Thread.sleep(1000);}			//Mindestens 1 Sekunde pausieren
		catch(InterruptedException ie)	{System.out.println("Irgendein Sleep Fehler");}

		Thread thisThread = Thread.currentThread(); //den namen des aktuellen Threads speichern
		while(gameThread == thisThread)		//solange wiederholen, bis Thread nicht mehr vorhanden
		{
			try	{Thread.sleep(1);}			//eine 20tel Sekunde Pause machen (ergibt ca. 20 Bilder/sek)
			catch(InterruptedException ie)	{System.out.println("Irgendein Sleep Fehler");}

			if (((int)(Math.random() * 2000) == 0) && (startZeit == -1))
			{
				gPane.setBackground(Color.red);			//Ampel auf rot schalten
				startZeit = System.currentTimeMillis();	//Startzeit setzen
			}
			if (startZeit != -1)
			{
				text.setText(String.valueOf(System.currentTimeMillis()-startZeit)+" ms");
			}
			repaint();	//jedes mal das Bild neu zeichnen
		}
		//dies geschieht,nachdem Stop gedr�ckt worden ist
		if (startZeit != -1)					//Richtig reagiert
		{
			int zeit = (int)(System.currentTimeMillis()-startZeit);
			if (zeit < 100) text.setText("Betr�ger: "+String.valueOf(zeit)+" ms");
			else if (zeit < 200) text.setText("Perfekt: "+String.valueOf(zeit)+" ms");
			else if (zeit < 250) text.setText("Sehr gut: "+String.valueOf(zeit)+" ms");
			else if (zeit < 300) text.setText("Noch gut: "+String.valueOf(zeit)+" ms");
			else if (zeit < 350) text.setText("Mittelpr�chtig: "+String.valueOf(zeit)+" ms");
			else if (zeit < 400) text.setText("Naja: "+String.valueOf(zeit)+" ms");
			else if (zeit < 500) text.setText("Schlecht: "+String.valueOf(zeit)+" ms");
			else text.setText("Jemand wach? "+String.valueOf(zeit)+" ms");
		}
		else									//Zu fr�h gestoppt
		{
			int i = (int)(Math.random() * 7);
			switch(i)
			{
			case 0:	text.setText("Nerv�s?"); break;
			case 1: text.setText("Kaffee getrunken?"); break;
			case 2:	text.setText("Farbenblind?"); break;
			case 3:	text.setText("Fahr blo� nicht Auto"); break;
			case 4:	text.setText("Ganz ruhig");	break;
			case 5:	text.setText("Kleiner Wahrsager?");	break;
			case 6:	text.setText("Nervenb�ndel"); break;
			}
		}
		startZeit = -1;
		check = false;
	}

    public void paint(Graphics screen)	//wird von update aufgerufen
	{
		gPane.repaint();
		text.repaint();
		startKnopf.repaint();
	}

	class startAction implements ActionListener
	{
		public void actionPerformed(ActionEvent evt)
		{
			if (!check)
			{
				check = true;
				text.setText("Achtung...");				//Text �ndern
				gPane.setBackground(Color.green);		//Ampel wieder auf gr�n
				startKnopf.setText("Stop");				//Den Text auf dem Knopf aktualisieren
				gameThread = new Thread(Game.this);		//neuen Thread erzeugen
				gameThread.start();						//Thread starten (weiter gehts dann in run())
			}
			else
			{
				startKnopf.setText("Start");			//Den Text auf dem Knopf aktualisieren,^1
				gameThread = null;						//Thread beenden
			}
		}
	}

	public static void main(String[] args)		//Hauptprogramm
	{
		Game frame = new Game();			//das GameObjekt erzeugen (zieht alles andere nach sich)
	}
}
