import java.awt.*;

public class Konst extends Component		//Hier sind alle Konstanten drin
{
	static int maxX = 150;	//Fensterbreite
	static int maxY = 100;	//Fensterh�he
}