Object by Jan 'SheDeKi' G�pfert
http://www.shedeki.net