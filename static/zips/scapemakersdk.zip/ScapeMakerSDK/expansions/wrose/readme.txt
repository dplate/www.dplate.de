Object by Jan 'SheDeKi' G�pfert
http://www.shedeki.net


wrose.dds is based on a picture taken from http://www.mg3dart.com