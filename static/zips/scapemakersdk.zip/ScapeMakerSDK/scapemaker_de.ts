<!DOCTYPE TS><TS>
<codec>iso8859-1</codec>
<context>
    <name>BitmapNavBase</name>
    <message>
        <source>BitmapNav</source>
        <translation>BitmapNav</translation>
    </message>
    <message>
        <source>Move</source>
        <translation>Verschieben</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Vergrößern</translation>
    </message>
    <message>
        <source>UnZoom</source>
        <translation>Verkleinern</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>Stift</translation>
    </message>
    <message>
        <source>Rubber</source>
        <translation>Radiergummi</translation>
    </message>
    <message>
        <source>Goes into scroll mode.</source>
        <translation>Setzt die Maus in den Scrollmodus. Damit kann bei gedrückter Maustaste die Ansicht der Heightmap verschoben werden.</translation>
    </message>
    <message>
        <source>Zooms in with a click on the preview.</source>
        <translation>Setzt die Maus in den Vergrößerungsmodus. Durch Klick in die Ansicht der Heightmap kann diese vergrößert werden.</translation>
    </message>
    <message>
        <source>Zooms out with a click on the preview.</source>
        <translation>Setzt die Maus in den Verkleinerungsmodus. Durch Klick in die Ansicht der Heightmap kann diese verkleinert werden.</translation>
    </message>
    <message>
        <source>A pen to manually set positions by clicking on the preview.</source>
        <translation>In dem auf das Preview geklickt wird, können mit diesem Stift Position festgelegt werden.</translation>
    </message>
    <message>
        <source>A rubber to delete positions by clicking on the preview.</source>
        <translation>n dem auf das Preview geklickt wird, können mit diesem Radiergummi Position gelöscht werden.</translation>
    </message>
    <message>
        <source>Shows a smaller image of the preview The blue border shows the area that is shown in the main window.</source>
        <translation>Zeigt das Preview verkleinert an. Der hellblaue Rahmen markiert dabei den Bereich, der gerade in der Ansicht des Previews angezeigt wird. Durch Klick auf diese Übersicht kann der Ansichtsbereich ebenfalls verschoben werden.</translation>
    </message>
</context>
<context>
    <name>CloudsGUI</name>
    <message>
        <source>Density</source>
        <translation>Dichte</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Geschw.</translation>
    </message>
    <message>
        <source>Coverage</source>
        <translation>Bedeckung</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <source>Smoothness</source>
        <translation>Glätte</translation>
    </message>
    <message>
        <source>Frames</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <source>Mutation speed</source>
        <translation>Formgeschw.</translation>
    </message>
    <message>
        <source>Moving speed</source>
        <translation>Geschw.</translation>
    </message>
    <message>
        <source>Repetitions</source>
        <translation>Wiederh.</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Breite</translation>
    </message>
</context>
<context>
    <name>CloudsGUIBase</name>
    <message>
        <source>CloudsGUI</source>
        <translation>CloudsGUI</translation>
    </message>
    <message>
        <source>Cumulus clouds</source>
        <translation>Kumulus-Wolken</translation>
    </message>
    <message>
        <source>Cirrus clouds</source>
        <translation>Zirrus-Wolken</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Cancel generating clouds</source>
        <translation>Wolkengenerierung abbrechen</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <source>Start generating clouds</source>
        <translation>Wolkengenerierung starten</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Auflösung:</translation>
    </message>
    <message>
        <source>256x256</source>
        <translation>256x256</translation>
    </message>
    <message>
        <source>512x512</source>
        <translation>512x512</translation>
    </message>
    <message>
        <source>1024x1024</source>
        <translation>1024x1024</translation>
    </message>
    <message>
        <source>Here, different types of clouds can be defined.</source>
        <translation>Der Wolken-Bereich erscheint durch die Auswahl des "Wolken"-Reiters beim Bearbeiten einer Landschaft. Hier können verschiedene Wolkenarten für die Landschaft eingestellt werden.</translation>
    </message>
    <message>
        <source>Sets the resolution for the cirrus clouds. A high resolution cirrus cloud contains more details but causes a longer generation time and needs more system resources in the 3D-mode.</source>
        <translation>Stellt die Auflösung der Zirruswolkenschicht ein. Eine hochauflösende Wolkenschicht enthält zwar mehr Details, verlängert aber die Berechnungsdauer und erhöht den Speicherverbrauch des 3D-Modus erheblich.</translation>
    </message>
    <message>
        <source>Defines the height of the zirrus clouds. Too low a value can lead to errors, if the zirrus clouds touch the cumulus clouds.</source>
        <translation>Definiert die Höhe der Zirruswolkenschicht. Zu niedrige Höhen können zu Darstellungsfehlern führen, wenn die Wolkenschicht mit den Kumuluswolken in der selben Höhe ist.</translation>
    </message>
    <message>
        <source>Sets the size of the individual cirrus clouds. A big value creates few, big clouds, while a small value creates many small clouds.</source>
        <translation>Legt die Größe der einzelnen Zirruswolken fest. Ein hoher Wert bewirkt wenige großflächige Wolken, ein kleiner Wert dagegen viele kleine Wolken.</translation>
    </message>
    <message>
        <source>Sets how many percent of the sky are covered by cirrus clouds. 100% means a completely covered sky, 0% makes for a clear sky.</source>
        <translation>Setzt die prozentuale Bedeckung des Himmels durch Zirruswolken. 100% bedeutet ein völlig bedeckter Himmel, bei 0% dagegen befinden sich praktisch keine Zirruswolken am Himmel.</translation>
    </message>
    <message>
        <source>Defines the frame count for the animation of the cirrus clouds. Big values result in smoother changing but also need more system resources. If you do not want animated clouds, set this value to 1.</source>
        <translation>Bestimmt die Anzahl der Animationsstufen für die Animation der Zirruswolken. Hohe Werte bewirken eine fließendere Bewegung der Wolken, erhöhen aber den Speicherverbrauch im 3D-Modus. Ist keine Wolkenanimation erwünscht, ist dieser Wert auf 1 zu setzen.</translation>
    </message>
    <message>
        <source>Sets the smoothness of the cirrus clouds. Smaller values give sharp edged clouds, big values make clouds slowly fade into the sky.</source>
        <translation>Stellt die "Weichheit" der Zirruswolken ein. Bei kleinen Werten haben die Zirruswolken scharfe Kanten, bei hohen Werten gehen sie langsamer in den Himmel über.</translation>
    </message>
    <message>
        <source>Defines how often the clouds texture is repeated. High values increase the detail of the clouds, but might lead to visible repititions.</source>
        <translation>Definiert, wie häufig sich die generierte Zirruswolkentextur am Himmel wiederholen soll. Bei hohen Werten steigt der Detailgrad der Wolken, aber die Wiederholungen können störend auffallen.</translation>
    </message>
    <message>
        <source>Defines how quickly cirrus clouds change shape.</source>
        <translation>Legt die Veränderungsgeschwindigkeit der Zirruswolken fest, d.h. wie schnell die berechneten Animationsstufen durchlaufen werden.</translation>
    </message>
    <message>
        <source>Sets the movement speed for the cirrus clouds.</source>
        <translation>Setzt die Bewegungsgeschwindigkeit der Zirruswolken. Dieser Wert ist unabhängig von der Formgeschwindigkeit und legt fest, wie schnell die Zirruswolken über den Himmel ziehen.</translation>
    </message>
    <message>
        <source>Generates the cirrus clouds.</source>
        <translation>Generiert die Zirruswolkenschicht. Besonders bei einer hohen Auflösung und vielen Animationsstufen (Bilder) kann dies längere Zeit dauern.</translation>
    </message>
    <message>
        <source>Sets the density of the cumulus clouds. If its 0, there are no cumulus clouds at all.</source>
        <translation>Legt die Häufigkeit (Dichte) der Kumuluswolken fest. Ist dieser Wert 0, gibt es keine Kumuluswolken.</translation>
    </message>
    <message>
        <source>Defines the length of a cumulus cloud in the direction of its movement.</source>
        <translation>Definiert die Länge einer Kumuluswolke in Bewegungsrichtung.</translation>
    </message>
    <message>
        <source>Sets the speed for movement and changing of chape for the cumulus clouds.</source>
        <translation>Setzt die Zieh- und Veränderungsgeschwindigkeit der Kumuluswolken.</translation>
    </message>
    <message>
        <source>Defines the height of the cumulus clouds.</source>
        <translation>Bestimmt die Höhe einer Kumuluswolke.</translation>
    </message>
    <message>
        <source>Sets the width of the cumulus clouds.</source>
        <translation>Legt die Breite einer Kumuluswolke fest.</translation>
    </message>
    <message>
        <source>Shows a preview of the distribution of the cirrus-clouds.</source>
        <translation>Zeigt eine Vorschau für die Verteilung der Zirruswolken an.</translation>
    </message>
</context>
<context>
    <name>ConfigGUI</name>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Can&apos;t find a display mode!</source>
        <translation>Kein Bildschirmmodus gefunden!</translation>
    </message>
    <message>
        <source>disabled</source>
        <translation>deaktiviert</translation>
    </message>
    <message>
        <source>Height based fog will only be visible at 32bit color depth.</source>
        <translation>Höhenbasierter Nebel ist nur bei einer Farbtiefe von 32bit sichtbar.</translation>
    </message>
</context>
<context>
    <name>ConfigGUIBase</name>
    <message>
        <source>ScapeMaker | Config</source>
        <translation>ScapeMaker | Konfiguration</translation>
    </message>
    <message>
        <source>Hardware</source>
        <translation>Hardware</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Auflösung:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Fog and sea can only be activated if your graphic card has vertex- and pixel-shader support (Directx8).</source>
        <translation type='obsolete'>Nebel und Meer kann nur bei Grafikkarten mit Vertex- und Pixelshadersupport (Directx8) aktiviert werden.</translation>
    </message>
    <message>
        <source>Performance</source>
        <translation>Geschwindigkeit</translation>
    </message>
    <message>
        <source>Terrain detail texture</source>
        <translation>Landschaftsdetailtextur</translation>
    </message>
    <message>
        <source>Sea</source>
        <translation type='obsolete'>Meer</translation>
    </message>
    <message>
        <source>Clouds</source>
        <translation type='obsolete'>Wolken</translation>
    </message>
    <message>
        <source>Fog</source>
        <translation type='obsolete'>Nebel</translation>
    </message>
    <message>
        <source>Terrain geometry</source>
        <translation>Landschaftsgeometrie</translation>
    </message>
    <message>
        <source>Low detail</source>
        <translation>Wenig Details</translation>
    </message>
    <message>
        <source>Middle detail</source>
        <translation>Normale Details</translation>
    </message>
    <message>
        <source>High detail</source>
        <translation>Viele Details</translation>
    </message>
    <message>
        <source>Full detail</source>
        <translation>Alle Details</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Language:</source>
        <translation>Sprache:</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Englisch</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <source>Fog can only be activated if your graphic card has vertex- and pixel-shader support (Directx8).
Sea requires &apos;environment bump mapping&apos; support.</source>
        <translation type='obsolete'>Nebel kann nur bei Grafikkarten mit Vertex- und Pixelshadersupport (Directx8) aktiviert werden.
Meer benötigt &apos;Environment Bump Mapping&apos; Unterstützung.</translation>
    </message>
    <message>
        <source>Sea reflection</source>
        <translation>Meer Reflektionen</translation>
    </message>
    <message>
        <source>Sky and terrain</source>
        <translation>Himmel und Landschaft</translation>
    </message>
    <message>
        <source>Sky</source>
        <translation>Himmel</translation>
    </message>
    <message>
        <source>Sky, terrain, clouds and objects</source>
        <translation>Himmel, Landschaft und Objekte</translation>
    </message>
    <message>
        <source>Changing language implies a restart of ScapeMaker.</source>
        <translation type='obsolete'>Sprachenwechsel benötigt ein Neustart von ScapeMaker.</translation>
    </message>
    <message>
        <source>Water reflection</source>
        <translation>Wasserreflexionen</translation>
    </message>
    <message>
        <source>Cloud shading</source>
        <translation>Wolkenschattierung</translation>
    </message>
    <message>
        <source>Height based fog</source>
        <translation>Höhenbasierter Nebel</translation>
    </message>
    <message>
        <source>Antialiasing:</source>
        <translation>Antialiasing:</translation>
    </message>
    <message>
        <source>Height based fog and water reflection can only be activated if your graphic card has vertex- and pixel-shader support (Directx8).</source>
        <translation type='obsolete'>Höhenbasierter Nebel und Wasserreflexionen können nur auf einer Grafikkarte mit Vertex- und Pixelshaderunterstützung (Directx8) aktiviert werden.</translation>
    </message>
    <message>
        <source>User interface</source>
        <translation>Benutzeroberfläche</translation>
    </message>
    <message>
        <source>Expert mode: Shows all functions</source>
        <translation>Experte: Alle Funktionen anzeigen</translation>
    </message>
    <message>
        <source>Switches the detail texture on/off. When the detail texture is switched on, a high-resolution structure is laid over the whole landscape, which makes the landscape textures look less blury. Needs much system resources and should be switched off with slow graphic cards.</source>
        <translation>Schaltet die Detailtextur an/aus. Bei eingeschalteter Detailtextur wird eine hochauflösende Struktur über die gesamte Landschaft gelegt, die bewirkt, dass die Landschaftstexturen nicht zu unscharf wirken. Bei langsamen Grafikkarten kann dies viel Performance kosten und sollte abgeschaltet werden.</translation>
    </message>
    <message>
        <source>Defines the detail of the landscapes geometry. This only affects the mesh, not the landscape textures. A low level of detail can have a very positive affect on the frame rate, if an old graphic card is used.</source>
        <translation>Legt den Detailgrad der Landschaftsgeometrie fest. Dies wirkt sich nur auf das Drahtgittermodell aus und nicht auf die Landschaftstextur. Eine niedrige Detailstufe kann sich sehr positiv auf die Geschwindigkeit auswirken, wenn eine ältere Grafikkarte verwendet wird.</translation>
    </message>
    <message>
        <source>Switches cloud shading on/off for all landscapes. Not shaded  clouds need less memory, but this option is only available  at better graphic cards.</source>
        <translation>Die Zirruswolken können schattiert oder einfarbig angezeigt werden. Einfarbige verbrauchen deutlich weniger Speicher, sind aber nur auf neueren Grafikkarten möglich, weshalb diese Option auf älteren Grafikkarten nicht zur Verfügung steht.</translation>
    </message>
    <message>
        <source>De-/activates the reflexion of water for all landscapes. Like with height based fog, this is only available for users with vertex-/pixelshader support.</source>
        <translation>De-/Aktiviert die Reflexionen des Wassers. Auch dies wirkt sich auf alle Landschaften aus und kann ebenfalls nur bei Grafikkarten, die Vertex-/Pixelshader unterstützen, ausgewählt werden.</translation>
    </message>
    <message>
        <source>Defines the type of reflection. You get better performance if less elements are visible in reflection.</source>
        <translation>Legt den Detailgrad der Reflektionen des Meeres fest. Desto weniger Bestandteile der Landschaft sich im Meer reflektieren, desto schneller ist die Berechnung.</translation>
    </message>
    <message>
        <source>Switches height based fog on/off for all landscapes. Should be switched off if the graphic card has problems with the used vertex-/pixelshaders. If the graphic card does not support vertex-/pixelshaders, this option is not available.</source>
        <translation>Schaltet im gesamten Programm den höhenbasierten Nebel an/aus. Dies beeinflusst wiederum alle Landschaften und kann ausgeschaltet werden, wenn die Grafikkarte Probleme mit den dafür verwendeten Vertex-/Pixelshadern hat. Falls die verwendete Grafikkarte Vertex-/Pixelshader nicht unterstützt, ist diese Option nicht anwählbar.</translation>
    </message>
    <message>
        <source>Switches resolution, color depth and frequence of the graphic card. Choose only values your graphic card and monitor can handle. Height based fog will only be visible at 32 bit color depth.</source>
        <translation>Stellt die Auflösung, Farbtiefe und Bildwiederholfrequenz der Grafikkarte ein. Eine hohe Auflösung verringert die Geschwindigkeit ebenso wie eine hohe Farbtiefe. Die gewählte Bildwiederholfrequenz muss sowohl von der Grafikarte, als auch vom Monitor unterstützt werden. Höhenbasierter Nebel wird nur bei einer Farbtiefe von 32 Bit dargestellt.</translation>
    </message>
    <message>
        <source>Sets intensity of antialiasing in fullscreen mode. Switch it off for better performance.</source>
        <translation>Bestimmt die Intensität des Antialiasing (Kantenglättung) im Vollbildmodus. Das Deaktivieren des Antialiasing erhöht die Geschwindigkeit.</translation>
    </message>
    <message>
        <source>Switches language of gui.</source>
        <translation>Stellt die Sprache der Benutzeroberfläche um.</translation>
    </message>
    <message>
        <source>Set this flag to unhide all function. If you&apos;re a beginner, let this option turned off.</source>
        <translation>Durch Einschalten dieser Option werden alle Funktionen von ScapeMaker angezeigt. Anfänger sollten diese Option deaktiviert lassen.</translation>
    </message>
    <message>
        <source>Height based fog needs vertex- and pixel-shader 2.0 hardware.
Water reflection needs vertex- and pixel-shader 1.1 hardware with environment bump mapping support.</source>
        <translation>Höhenbasierter Nebel benötigt Vertex- und Pixelshader 2.0 Hardware.
Wasserreflexion benötigt Vertex- und Pixelshader 1.1 Hardware mit Environment-Bump-Mapping-Unterstützung.</translation>
    </message>
</context>
<context>
    <name>CoolSlider</name>
    <message>
        <source>%1</source>
        <translation type='obsolete'></translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>New value?</source>
        <translation>Neuer Wert?</translation>
    </message>
</context>
<context>
    <name>EnviromentGUI</name>
    <message>
        <source>Density</source>
        <translation>Dichte</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type='obsolete'>Geschw.</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Richtung</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Zeit</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Reflection</source>
        <translation type='obsolete'>Reflektion</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Distance</source>
        <translation>Entfernung</translation>
    </message>
</context>
<context>
    <name>EnviromentGUIBase</name>
    <message>
        <source>EnviromentGUI</source>
        <translation>EnviromentGUI</translation>
    </message>
    <message>
        <source>Clouds</source>
        <translation type='obsolete'>Wolken</translation>
    </message>
    <message>
        <source>Sea</source>
        <translation type='obsolete'>Meer</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation type='obsolete'>Farbe:</translation>
    </message>
    <message>
        <source>Color of water</source>
        <translation type='obsolete'>Farbe des Wassers</translation>
    </message>
    <message>
        <source>Sky, sun and shadow</source>
        <translation>Himmel, Sonne und Schatten</translation>
    </message>
    <message>
        <source>--&gt;</source>
        <translation>--&gt;</translation>
    </message>
    <message>
        <source>Diffuse light color</source>
        <translation>Diffuse Farbe des Lichts</translation>
    </message>
    <message>
        <source>First color of sky</source>
        <translation>Erste Farbe des Himmels</translation>
    </message>
    <message>
        <source>Second color of sky</source>
        <translation>Zweite Farbe des Himmels</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <source>Ignore objects</source>
        <translation>Objekte ignorieren</translation>
    </message>
    <message>
        <source>Fast shadow</source>
        <translation>Schnelle Schatten</translation>
    </message>
    <message>
        <source>Ambient light color</source>
        <translation>Ambiente Farbe des Lichts</translation>
    </message>
    <message>
        <source>Fog</source>
        <translation type='obsolete'>Nebel</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Cancel generating lightmaps</source>
        <translation>Generierung der Lightmaps abbrechen</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <source>Start generating lightmaps</source>
        <translation>Generierung der Lightmaps beginnen</translation>
    </message>
    <message>
        <source>Calculate segment</source>
        <translation>Teilberechnung</translation>
    </message>
    <message>
        <source>Export texture</source>
        <translation>Texturexport</translation>
    </message>
    <message>
        <source>Export terrain texture</source>
        <translation>Landschaftstextur exportieren</translation>
    </message>
    <message>
        <source>Height based fog</source>
        <translation>Höhenbasierter Nebel</translation>
    </message>
    <message>
        <source>Dust</source>
        <translation>Dunst</translation>
    </message>
    <message>
        <source>Sets the time of day (and so the height of the sun). It also changes the colors of light and sky.</source>
        <translation>Stellt die Tageszeit (und damit den Sonnenstand) der Szene ein. Außerdem werden die darunterliegenden Farben auf, für diese Tageszeit passende, Farben gestellt.</translation>
    </message>
    <message>
        <source>The color of the sky at the horizon. A click changes the color. This is the color of height based fog and dust/haze also.</source>
        <translation type='obsolete'>Zeigt die Farbe des Himmels am Horizont an. Durch Klick auf die Farbe kann sie verändert werden. Dies ist auch gleichzeitig die Farbe für den höhenbasierten Nebel und den Dunst.</translation>
    </message>
    <message>
        <source>The main color of of the sky. A click changes the color.</source>
        <translation>Zeigt die Hauptfarbe des Himmels an. Durch Klick auf die Farbe kann sie verändert werden.</translation>
    </message>
    <message>
        <source>The color of the shadows. A click changes the color.</source>
        <translation>Zeigt die Farbe der Schatten an. Durch Klick auf die Farbe kann sie verändert werden.</translation>
    </message>
    <message>
        <source>The color of the sunlight. A click changes the color.</source>
        <translation>Zeigt die Farbe des Sonnenlichts an. Durch Klick auf die Farbe kann sie verändert werden.</translation>
    </message>
    <message>
        <source>Defines the direction of the sun. That is, where the sun rises and sets.</source>
        <translation>Legt die Richtung der Sonne fest, also wo sie auf- bzw. untergeht.</translation>
    </message>
    <message>
        <source>Activates a faster way of calculating shadows, which looks much worse than the normal mode.</source>
        <translation>Ist diese Option angewählt, wird für die Berechnung der Schatten eine schnelle Methode verwendet. Diese ist ungefähr 8mal schneller, erzeugt aber deutlich unrealistische Schatten, da die Sonne nur noch als Punkt und nicht als Fläche gesehen wird.</translation>
    </message>
    <message>
        <source>Allows to only render shadows for defined parts of the landscape. If this is not ticked, shadows for the whole landscape are generated</source>
        <translation>Diese Option ermöglicht die Festlegung eines Bereichs, für den die Schatten neu berechnet werden sollen. Ist diese Option nicht gewählt, wird die gesamte Landschaft neu berechnet.</translation>
    </message>
    <message>
        <source>Sets the first tile for which shadows are to be generated.</source>
        <translation>Legt das erste Landschaftsteil fest, das neu berechnet werden soll.</translation>
    </message>
    <message>
        <source>Sets the last tile for which shadows are to be generated.</source>
        <translation>Legt das letzte Landschaftsteil fest, das neu berechnet werden soll.</translation>
    </message>
    <message>
        <source>Opens the texture export dialog. There the generated ground textures can be exported as a single image file.</source>
        <translation>Öffnet den Texturexportdialog. Dort kann die zuvor generierte Bodentextur als Bilddatei exportiert werden.</translation>
    </message>
    <message>
        <source>If activated, objects don&apos;t cast shadows (speeds the shadow generation process up).</source>
        <translation type='obsolete'>Ist diese Option angewählt, werden keine Schatten der Objekte berechnet. Dieses kann die Generierung der Schatten enorm beschleunigen, da nur noch die Schatten der Berge berechnet werden müssen.</translation>
    </message>
    <message>
        <source>Generates shadows.</source>
        <translation>Generiert die Schatten der Landschaft. Da die Berechnung der Schatten sehr aufwändig ist, kann dies eine sehr lange Zeit in Anspruch nehmen (bis zu mehreren Stunden!).</translation>
    </message>
    <message>
        <source>Defines the range of height for the height based fog. Only inside this range, fog occurs.</source>
        <translation>Bestimmt den Höhenbereich des höhenbasierten Nebels. Nur in diesem Bereich kommt Nebel vor. Diese Option ist nur verfügbar, wenn im Einstellungsfenster  höhenbasierter Nebel angestellt ist.</translation>
    </message>
    <message>
        <source>Sets the density of the height based fog. If set to 0, no fog appears at all.</source>
        <translation>Stellt die Dichte des höhenbasierten Nebels ein. Eine Dichte von 0 stellt den Nebel aus. Diese Option ist nur verfügbar, wenn im Einstellungsfenster höhenbasierter Nebel angestellt ist.</translation>
    </message>
    <message>
        <source>Sets the haze of landscape. The left slider defines the beginning ot the haze, the right slider the end. This also affects the visible distance, so you will get a higher performance in 3d mode with small values of the right slider.</source>
        <translation>Definiert den Dunstbereich für die Landschaft. Der linke Regler setzt den Anfang des Dunsts, der rechte das Ende. Kleine Werte des rechten Reglers bewirken eine weniger große Sichtweite und erhöhen damit die Performance im 3D-Modus.</translation>
    </message>
    <message>
        <source>Shows a preview of the shadows. Areas in shadow are red.</source>
        <translation type='obsolete'>Zeigt die Schatten des Gebirges beim aktuellen Sonnestand an. Schattige Bereiche werden rot gekennzeichnet.</translation>
    </message>
    <message>
        <source>If activated, objects don&apos;t cast shadows. Speeds up the generation process.</source>
        <translation>Ist diese Option angewählt, werden keine Schatten der Objekte berechnet. Dieses kann die Generierung der Schatten enorm beschleunigen, da nur noch die Schatten der Berge berechnet werden müssen.</translation>
    </message>
    <message>
        <source>The color of the sky at the horizon. A click changes the color. This is also the color of the heightbased fog, als well as dust/haze.</source>
        <translation>Zeigt die Farbe des Himmels am Horizont an. Durch Klick auf die Farbe kann sie verändert werden. Dies ist auch gleichzeitig die Farbe für den höhenbasierten Nebel und den Dunst.</translation>
    </message>
    <message>
        <source>Shows a preview of the shadows. Areas that lie in shadow are shown in red.</source>
        <translation>Zeigt die Schatten des Gebirges beim aktuellen Sonnestand an. Schattige Bereiche werden rot gekennzeichnet.</translation>
    </message>
</context>
<context>
    <name>GUIHelpers</name>
    <message>
        <source>Images (*.bmp *.gif *.jpg *.png *.ico *.tif *.tga *.pcx *.wmf *.jp2 *.jpc *.pgx *.pnm *.ras)</source>
        <translation>Bilder (*.bmp *.gif *.jpg *.png *.ico *.tif *.tga *.pcx *.wmf *.jp2 *.jpc *.pgx *.pnm *.ras)</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Can&apos;t open file!</source>
        <translation>Datei konnte nicht geöffnet werden!</translation>
    </message>
    <message>
        <source>Invalid file name!</source>
        <translation>Fehlerhafter Dateiname!</translation>
    </message>
    <message>
        <source>Unknown error!</source>
        <translation>Unbekannter Fehler!</translation>
    </message>
    <message>
        <source>Set compression quality (0=bad, 100=good):</source>
        <translation>Qualität einstellen (0=schlecht, 100=gut):</translation>
    </message>
    <message>
        <source>Invalid file extension!</source>
        <translation>Fehlerhafte Dateiendung!</translation>
    </message>
    <message>
        <source>Existing file is read only!</source>
        <translation>Die existierende Datei ist schreibgeschützt!</translation>
    </message>
    <message>
        <source>File already exists!
Do you want to overwrite this file?</source>
        <translation>Datei existiert bereits!
Wollen Sie die Datei überschreiben?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Can&apos;t save file!</source>
        <translation>Datei konnte nicht gespeichert werden!</translation>
    </message>
    <message>
        <source>Image successfully saved as
"%1"</source>
        <translation>Bild erfolgreich gespeicher als
"%1"</translation>
    </message>
    <message>
        <source>Can&apos;t create directory!</source>
        <translation>Verzeichnis konnte nicht angelegt werden!</translation>
    </message>
</context>
<context>
    <name>InfoGUIBase</name>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>ScapeMaker v.1.0 released at 19.11.2003</source>
        <translation type='obsolete'>ScapeMaker v.1.0 veröffentlicht am 19.11.2003</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Entwickler</translation>
    </message>
    <message>
        <source>Matthias Buchetics</source>
        <translation>Matthias Buchetics</translation>
    </message>
    <message>
        <source>Dirk Plate</source>
        <translation>Dirk Plate</translation>
    </message>
    <message>
        <source>Tester</source>
        <translation>Tester</translation>
    </message>
    <message>
        <source>Marek Kubica</source>
        <translation>Marek Kubica</translation>
    </message>
    <message>
        <source>Christian Napierala</source>
        <translation>Christian Napierala</translation>
    </message>
    <message>
        <source>Marco Haase</source>
        <translation>Marco Haase</translation>
    </message>
    <message>
        <source>Franz-Albert Bauer</source>
        <translation>Franz-Albert Bauer</translation>
    </message>
    <message>
        <source>Visit our website: www.scapemaker.de.vu</source>
        <translation>Offizielle Webseite: www.scapemaker.de.vu</translation>
    </message>
    <message>
        <source>ScapeMaker v.1.1 released at xxxxx</source>
        <translation type='obsolete'>ScapeMaker v.1.1 veröffentlicht am xxxxxx</translation>
    </message>
    <message>
        <source>David Novak</source>
        <translation>David Novak</translation>
    </message>
    <message>
        <source>ScapeMaker v.1.1 released at 09.06.2004</source>
        <translation type='obsolete'>ScapeMaker v.1.1 veröffentlicht am 09.06.2004</translation>
    </message>
    <message>
        <source>ScapeMaker v.1.2 released at 09.08.2004</source>
        <translation type='obsolete'>ScapeMaker v.1.2 veröffentlicht am 09.08.2004</translation>
    </message>
    <message>
        <source>ScapeMaker v.1.3 released at 12.02.2005</source>
        <translation>ScapeMaker v.1.3 veröffentlicht am 12.02.2005</translation>
    </message>
</context>
<context>
    <name>Keys3DMode</name>
    <message>
        <source>Keys in 3d mode</source>
        <translation>Tastenbelegung im 3D-Modus</translation>
    </message>
    <message>
        <source>ESC
^
C
O
A or LEFT
D or RIGHT
W or UP
S or DOWN
R
F
M
N
B</source>
        <translation>ESC
^
C
O
A oder LINKS
D oder RECHTS
W oder HOCH
S oder RUNTER
R
F
M
N
B</translation>
    </message>
    <message>
        <source>Exit 3d mode
Open console
Make screenshot
Toggle walk mode
Strafe left
Strafe right
Move forward
Move backward
Move up
Move down
Show minimap
Show debug output
Switch debug output</source>
        <translation>3D-Modus beenden
Konsole öffnen
Screenshot schießen
In Laufmodus wechseln
Linkswärts bewegen
Rechtswärts bewegen
Vorwärts bewegen
Rückwärts bewegen
Aufwärts bewegen
Abwärts bewegen
Karte anzeigen
Debugausgabe anzeigen
Debugausgabe wechseln</translation>
    </message>
    <message>
        <source>Press mouse button to look around</source>
        <translation>Maustaste zum Umschauen gedrückt halten</translation>
    </message>
</context>
<context>
    <name>LoadGUI</name>
    <message>
        <source>Please select an item in the list first!</source>
        <translation>Bitte zuerst ein Element in der Liste wählen!</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Delete landscape</source>
        <translation>Landschaft löschen</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Name of landscape?</source>
        <translation>Name der Landschaft?</translation>
    </message>
    <message>
        <source>You must enter a name</source>
        <translation>Sie müssen einen Namen angeben</translation>
    </message>
    <message>
        <source>Directory already exists!
Please choose an other name.</source>
        <translation type='obsolete'>Verzeichnis existiert bereits!
Wählen Sie bitte einen anderen Namen.</translation>
    </message>
    <message>
        <source>Directory already exists!
Please choose another name.</source>
        <translation>Verzeichnis existiert bereits!
Wählen Sie bitte einen anderen Namen.</translation>
    </message>
    <message>
        <source>New name of landscape?</source>
        <translation>Neuer Name der Landschaft?</translation>
    </message>
    <message>
        <source>Archive already exists!
Please choose an other file.</source>
        <translation type='obsolete'></translation>
    </message>
    <message>
        <source>Can&apos;t open archive!</source>
        <translation>Archiv konnte nicht geöffnet werden!</translation>
    </message>
    <message>
        <source>&lt;error&gt;</source>
        <translation>&lt;Fehler&gt;</translation>
    </message>
    <message>
        <source>Archive already exists!
Please choose another file.</source>
        <translation>Archiv existiert bereits!
Wählen Sie bitte eine andere Datei.</translation>
    </message>
</context>
<context>
    <name>LoadGUIBase</name>
    <message>
        <source>ScapeMaker | Choose landscape</source>
        <translation>ScapeMaker |  Landschaftsauswahl</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Delete selected landscape</source>
        <translation>Gewählte Landschaft löschen</translation>
    </message>
    <message>
        <source>Rename</source>
        <translation>Umbenennen</translation>
    </message>
    <message>
        <source>Rename selected landscape</source>
        <translation>Gewählte Landschaft umbenennen</translation>
    </message>
    <message>
        <source>Duplicate</source>
        <translation>Duplizieren</translation>
    </message>
    <message>
        <source>Duplicate selected landscape</source>
        <translation>Gewählte Landschaft duplizieren</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <source>Create new landscape</source>
        <translation>Neue Landschaft erstellen</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Bearbeiten</translation>
    </message>
    <message>
        <source>Edit selected landscape</source>
        <translation>Gewählte Landschaft bearbeiten</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <source>Export selected landscape</source>
        <translation>Gewählte Landschaft exportieren</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <source>Import a landscape</source>
        <translation>Gewählte Landschaft importieren</translation>
    </message>
    <message>
        <source>Infos</source>
        <translation>Infos</translation>
    </message>
    <message>
        <source>Length:</source>
        <translation>Länge:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Breite:</translation>
    </message>
    <message>
        <source>The landscapes-window appears each time you start Scapemaker, or can be opened at any time over "File/Manage landscapes".</source>
        <translation>Das Verwaltungsfenster für die eigenen Landschaften erscheint bei jedem Start von ScapeMaker oder jederzeit über den Menüpunkt "Datei/Landschaften verwalten".</translation>
    </message>
    <message>
        <source>List of all landscapes that have been created or imported with Scapemaker. A click on a the name of a landscape activated it, a double-click edits the landscape.</source>
        <translation>Liste mit allen Landschaften, die mit ScapeMaker erstellt bzw. importiert wurden. Durch Klick auf den Namen einer Landschaft kann diese ausgewählt werden.</translation>
    </message>
    <message>
        <source>Creates a new (empty) landscape and gives it a name.</source>
        <translation>Legt eine neue (noch leere) Landschaft an. Dabei muss nur der Name der Landschaft angegeben werden.</translation>
    </message>
    <message>
        <source>Clones the selected landscape and gives it a new name. The new landscape is identical to the original.</source>
        <translation>Kopiert die ausgewählte Landschaft und speichert sie unter einem neuen Namen. Die neue Landschaft entspricht genau dem Original.</translation>
    </message>
    <message>
        <source>Gives the selected landscape a new name.</source>
        <translation>Für die ausgewählte Landschaft kann ein neuer Namen eingeben werden.</translation>
    </message>
    <message>
        <source>Deletes the selected landscape. All data of the landscape will be removed completely from the harddisk.</source>
        <translation>Löscht die ausgewählte Landschaft. Dies ist unwiederruflich, da auch alle Dateien auf der Festplatte gelöscht werden. Folglich nur mit großer Vorsicht verwenden!</translation>
    </message>
    <message>
        <source>Imports a landscape from an archive. Only archives that have been created by Scapemaker should be chosen, otherwise errors could occur.</source>
        <translation>Importiert eine Landschaft aus einem Archiv. Hier sollten nur Archive gewählt werden, die mit ScapeMaker erzeugt wurden, sonst kann es zu unvorhersehbaren Fehlern kommen.</translation>
    </message>
    <message>
        <source>Exports the landscape. Stores all important data in a single file.</source>
        <translation>Exportiert die ausgewählte Landschaft. Dabei werden alle relevanten Dateien der Landschaft in ein Archiv verpackt. Dieses Archiv kann dann leicht an andere ScapeMaker-Benutzer weitergegeben werden.</translation>
    </message>
    <message>
        <source>Edits the selected landscape.</source>
        <translation>Bearbeitet die ausgewählte Landschaft. Damit wird der eigentliche Kern von ScapeMaker gestartet.</translation>
    </message>
</context>
<context>
    <name>MaskImportGUIBase</name>
    <message>
        <source>ScapeMaker - Import mask</source>
        <translation>ScapeMaker - Maske importieren</translation>
    </message>
    <message>
        <source>Result</source>
        <translation>Ergebnis</translation>
    </message>
    <message>
        <source>Shows a picture of result mask.</source>
        <translation>Zeigt eine Vorschau der Ergebnismaske</translation>
    </message>
    <message>
        <source>=</source>
        <translation>=</translation>
    </message>
    <message>
        <source>Source 1</source>
        <translation>Quelle 1</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Reset to default mask</source>
        <translation>Zur Standardmaske zurücksetzen</translation>
    </message>
    <message>
        <source>Sets mask to default mask.</source>
        <translation>Setzt die Maske zur Standardmaske, die keine Einschränkungen bewirkt.</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>Invert</translation>
    </message>
    <message>
        <source>Invert a mask</source>
        <translation>Invertiert die Maske</translation>
    </message>
    <message>
        <source>Inverts the mask.</source>
        <translation>Die Maske wird invertiert, dass heißt das Negativ gebildet.</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <source>Import a mask</source>
        <translation>Maske importieren</translation>
    </message>
    <message>
        <source>Imports a mask from a image file.</source>
        <translation>Lädt eine neue Maske aus einer Bilddatei.</translation>
    </message>
    <message>
        <source>Shows a picture of the mask.</source>
        <translation>Zeigt eine Vorschau der Maske.</translation>
    </message>
    <message>
        <source>Source 2</source>
        <translation>Quelle 2</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Addieren</translation>
    </message>
    <message>
        <source>Subtract</source>
        <translation>Subtrahieren</translation>
    </message>
    <message>
        <source>And</source>
        <translation>Und</translation>
    </message>
    <message>
        <source>Or</source>
        <translation>Oder</translation>
    </message>
    <message>
        <source>Exclusive Or</source>
        <translation>Exklusives Oder</translation>
    </message>
    <message>
        <source>Sets the operator for combination of source 1 and source 2.</source>
        <translation>Stellt den Operator ein, der für die Kombination von Quelle 1 und Quelle 2 benutzt wird.</translation>
    </message>
</context>
<context>
    <name>ObjectsGUI</name>
    <message>
        <source>Select Object</source>
        <translation>Objekt auswählen</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>This is not a valid object!
Please check the "settings.txt"</source>
        <translation>Dies ist kein gültiges Objekt!
Überprüfen Sie bitte die "settings.txt"</translation>
    </message>
    <message>
        <source>Name of object?</source>
        <translation>Name des Objekts?</translation>
    </message>
    <message>
        <source>You must enter a name</source>
        <translation>Es muss ein Name angegeben werden</translation>
    </message>
    <message>
        <source>Object with this name already exists!
Please choose another name.</source>
        <translation>Ein Objekt mit diesem Namen existiert bereits!
Wählen Sie bitte einen anderen Namen.</translation>
    </message>
    <message>
        <source>Can&apos;t create directory!</source>
        <translation>Verzeichnis konnte nicht angelegt werden!</translation>
    </message>
    <message>
        <source>Please select an object in the list first!</source>
        <translation>Bitte wählen Sie zuerst ein Objekt aus der Liste!</translation>
    </message>
    <message>
        <source>Delete object</source>
        <translation>Objekt löschen</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>New name of object?</source>
        <translation>Neuer Name des Objekts?</translation>
    </message>
    <message>
        <source>You must enter a name!</source>
        <translation>Sie müssen einen Namen angeben!</translation>
    </message>
    <message>
        <source>Can&apos;t rename object!</source>
        <translation>Objekt konnte nicht umbenannt werden!</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Unable to open a "settings.txt". Ensure that you have a text editor installed.</source>
        <translation>"settings.txt" konnte nicht geöffnet werden. Bitte überprüfen Sie, ob Sie einen Texteditor installiert haben.</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Slope</source>
        <translation>Steigung</translation>
    </message>
    <message>
        <source>Smoothness</source>
        <translation>Glätte</translation>
    </message>
    <message>
        <source>Density</source>
        <translation>Dichte</translation>
    </message>
    <message>
        <source>ScaleRange</source>
        <translation type='obsolete'>Skalierungsbereich</translation>
    </message>
    <message>
        <source>static</source>
        <translation>statisch</translation>
    </message>
    <message>
        <source>dynamic (no preview)</source>
        <translation type='obsolete'>dynamisch (keine Vorschau)</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <source>Can&apos;t load "settings.txt"!
You shouldn&apos;t ignore this.</source>
        <translation>"settings.txt" konnte nicht geladen werden!
Dies ist ein kritischer Fehler, ignorieren Sie ihn nicht.</translation>
    </message>
    <message>
        <source>Can&apos;t rename mask of object!</source>
        <translation>Maske des Objekts konnte nicht umbenannt werden!</translation>
    </message>
    <message>
        <source>Do you want to clear all positions for this object?</source>
        <translation>Wollen Sie wirklich alle Positionen dieses Objekts löschen?</translation>
    </message>
    <message>
        <source>Can&apos;t open file!</source>
        <translation type='obsolete'>Datei konnte nicht geöffnet werden!</translation>
    </message>
    <message>
        <source>Scaling</source>
        <translation>Skalierung</translation>
    </message>
    <message>
        <source>dynamic</source>
        <translation>dynamisch</translation>
    </message>
    <message>
        <source>The directory "%1" already exists!
Please delete it and try again, or choose another name.</source>
        <translation>Das Verzeichnis "%1" existiert bereits!
Bitte löschen Sie es und versuchen es erneut, oder wählen Sie einen anderen Namen.
Please delete it and try again, or choose another name.</translation>
    </message>
    <message>
        <source>Can&apos;t delete directory "%1"!
Please remove it to avoid further errors.</source>
        <translation>Verzeichnis "%1" konnte nicht gelöscht werden!
Um weitere Fehler zu vermeiden, sollten Sie es entfernen.</translation>
    </message>
    <message>
        <source>Can&apos;t remove directory "%1"!
You have to remove the object and to add it again to avoid further errors.</source>
        <translation>Verzeichnis "%1" konnte nicht gelöscht werden!
Um weitere Fehler zu vermeiden, müssen Sie das Objekt entfernen und neu hinzufügen.</translation>
    </message>
</context>
<context>
    <name>ObjectsGUIBase</name>
    <message>
        <source>ObjectsGUI</source>
        <translation>ObjectsGUI</translation>
    </message>
    <message>
        <source>Preview color:</source>
        <translation type='obsolete'>Vorschau-
farbe:</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <source>Import a object</source>
        <translation>Ein Objekt importieren</translation>
    </message>
    <message>
        <source>Objectname:</source>
        <translation type='obsolete'>Objektname:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Cancel generating object distribution</source>
        <translation>Generierung der Objektverteilung abbrechen</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <source>Start generating object distribution</source>
        <translation>Generierung der Objektverteilung beginnen</translation>
    </message>
    <message>
        <source>Remove object</source>
        <translation>Objekt entfernen</translation>
    </message>
    <message>
        <source>Add object</source>
        <translation>Objekt hinzufügen</translation>
    </message>
    <message>
        <source>Rename object</source>
        <translation>Objekt umbenennen</translation>
    </message>
    <message>
        <source>Edit object</source>
        <translation>Objekt editieren</translation>
    </message>
    <message>
        <source>Random distribution</source>
        <translation>Zufällige Verteilung</translation>
    </message>
    <message>
        <source>Mask</source>
        <translation>Maske</translation>
    </message>
    <message>
        <source>Remove texture</source>
        <translation type='obsolete'>Textur entfernen</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Import a texture</source>
        <translation type='obsolete'>Textur importieren</translation>
    </message>
    <message>
        <source>Informations</source>
        <translation>Informationen</translation>
    </message>
    <message>
        <source>Add texture</source>
        <translation>Textur hinzufügen</translation>
    </message>
    <message>
        <source>Count:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Object:</source>
        <translation>Objekt:</translation>
    </message>
    <message>
        <source>Manual distribution</source>
        <translation>Manuelle Verteilung</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Clear manual distribution</source>
        <translation>Manuelle Verteilung löschen</translation>
    </message>
    <message>
        <source>Import a mask</source>
        <translation type='obsolete'>Eine Maske importieren</translation>
    </message>
    <message>
        <source>Reset to default mask</source>
        <translation>Zur Standardmaske zurücksetzen</translation>
    </message>
    <message>
        <source>Here, objects are placed on the landscape.</source>
        <translation>Der Objekte-Bereich erscheint durch die Auswahl des "Objekte"-Reiters beim Bearbeiten einer Landschaft. Hier werden die Objekte (z.B. Bäume) auf der Landschaft plaziert.</translation>
    </message>
    <message>
        <source>Shows a picture of a mask, used to limit the distribution of the object.</source>
        <translation>Zeigt die verwendete Maske an. Die Maske dient dazu, gezielt einzelne Flächen von dem Objekt auszunehmen. In weißen Bereichen der Maske darf das Objekt vorkommen, in schwarzen dagegen nicht.</translation>
    </message>
    <message>
        <source>Changes the mask for the selected object.</source>
        <translation>Ersetzt die aktuelle Maske durch eine neue Bilddatei.</translation>
    </message>
    <message>
        <source>Sets mask for the selected object to default mask.</source>
        <translation>Ersetzt die aktuelle Maske wieder durch die Standardmaske, die keine Einschränkung der Verteilung bewirkt.</translation>
    </message>
    <message>
        <source>Sets the range of slope in which the selected object will occur. For grass a low value would be good, for example.</source>
        <translation>Stellt den Steigungsbereich ein, in dem das Objekt vorkommt. Gras würde sinnvollerweise nur bei relativ flachen Hängen vorkommen.</translation>
    </message>
    <message>
        <source>Sets the density of the selected object, that is how often it will appear.</source>
        <translation>Legt die Häufigkeit (Dichte) für das Objekt fest.</translation>
    </message>
    <message>
        <source>Sets the range of height in which the selected object will occur. For pine trees a high value would be good, for example.</source>
        <translation>Stellt den Höhenbereich ein, in dem das Objekt vorkommt. Bei Laubbäumen wäre z.B. ein niedriger Bereich angebracht.</translation>
    </message>
    <message>
        <source>Sets the range in size of the object. If the range is very big, high variations in size occur.</source>
        <translation>Bestimmt die Variation der Größe des Objekts. Bei einem breiten Bereich haben die Objekte sehr unterschiedliche Größen. Sind die beiden Begrenzungen dagegen auf dem selben Wert, sind alle Objekte gleich groß.</translation>
    </message>
    <message>
        <source>Distributes the objects.</source>
        <translation>Generiert die Verteilung der Objekte anhand der gewählten Einstellungen. Dies müsste sehr schnell gehen.</translation>
    </message>
    <message>
        <source>Shows the original name of the selected object.</source>
        <translation>Zeigt den Originalnamen des ScapeMaker-Objekts.</translation>
    </message>
    <message>
        <source>Allows changing the used "settings.txt" for the selected object.</source>
        <translation>Ersetzt das ScapeMaker-Objekt des gewählten Objekts durch ein anderes.</translation>
    </message>
    <message>
        <source>Shows the type of the object.
"Static": The object is given static positions on the landscape. These positions are defined once and saved. This makes sense with objects, which appear rarely but can be seen over a long distance, e.g. trees. 
"Dynamic": Just the settings for the object are saved, and dynamic objects are displayed only near to the camera.</source>
        <translation>Zeigt den Typ des Objekts an. 
"Statisch": Das Objekt bekommt festgelegte Positionen in der Landschaft. Diese werden beim Generieren erzeugt und gespeichert. Dies ist für Objekte sinnvoll, die seltener vorkommen, aber auch auf große Entfernungen sichtbar sind, z.B. Bäume. 
"Dynamisch": Für das Objekt wird nur gespeichert, bei welchen Gegebenheiten es vorkommt. Die wirklichen Positionen werden erst im 3D-Modus laufend bestimmt. Dies ist für Objekte sinnvoll, die sehr häufig vorkommen, aber nur in unmittelbarer Umgebung der Kamera sichtbar sind, z.B. Gras.</translation>
    </message>
    <message>
        <source>Shows the count of places where the selected object will appear. Only for static objects.</source>
        <translation>Zeigt die Häufigkeit des Objekts an.</translation>
    </message>
    <message>
        <source>The object can be positioned manually, using the pen tool. This is suitable for objects that appear only rarely, e.g. buildings.</source>
        <translation>Die Positionen, an dem das Objekt erscheinen soll, können mit dem Stift frei gewählt werden. Dies ist für Objekte sinnvoll, die nur an sehr wenigen Stellen vorkommen sollen, z.B. Häuser.</translation>
    </message>
    <message>
        <source>Positions for the object will be set randomly by the distribution generator. Suitable for objects that appear frequently and have positions depending on the landscape.</source>
        <translation>Die Positionen des Objekts werden mit dem Verteilungsgenerator zufällig bestimmt. Diese Option ist für Objekte gedacht, die häufig vorkommen und deren Vorkommen durch landschaftliche Gegebenheiten bestimmt werden.</translation>
    </message>
    <message>
        <source>Clears all positions of the selected object.</source>
        <translation>Löscht alle manuell gesetzten Positionen.</translation>
    </message>
    <message>
        <source>Shows the distribution for the selected object.</source>
        <translation>Zeigt die Verteilung des aktuell gewählten Objekts an.</translation>
    </message>
    <message>
        <source>A list of all objects used in this landscape. A click on the name of a texture selects it.</source>
        <translation type='obsolete'>Zeigt alle verwendeten Objekte an. Durch Klick auf einen Namen eines Objekts wird dieses ausgewählt und kann bearbeitet werden.</translation>
    </message>
    <message>
        <source>Adds a new object. Therefor a "settings.txt" must be chosen and a name must be given.</source>
        <translation>Fügt ein neues Objekt hinzu. Dafür muss eine "settings.txt" eines ScapeMaker-Objekts auf der Festplatte ausgewählt werden und ein Name eingeben werden.</translation>
    </message>
    <message>
        <source>Deletes the selected object.</source>
        <translation>Löscht das gewählte Objekt.</translation>
    </message>
    <message>
        <source>Allows changing the name of the selected object.</source>
        <translation>Ermöglicht die Eingabe eines neuen Namens für das gewählte Objekt.</translation>
    </message>
    <message>
        <source>Shows the "settings.txt" in the default text editor. Only make changes if you know what you are doing!</source>
        <translation>Es wird die Einstellungsdatei des gewählte Objekts im Standardtexteditor angezeigt. Die Werte in dieser Datei sollten nur mit weiterem Hintergrundwissen geändert werden.</translation>
    </message>
    <message>
        <source>A list of all objects used in the current landscape. A click on the name of an object selects it.</source>
        <translation>Zeigt alle verwendeten Objekte an. Durch Klick auf einen Namen eines Objekts wird dieses ausgewählt und kann bearbeitet werden.</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Ändern</translation>
    </message>
    <message>
        <source>Changes a mask</source>
        <translation>Ändert eine Maske.</translation>
    </message>
</context>
<context>
    <name>PreviewGUI</name>
    <message>
        <source>A critical error occured, check log file</source>
        <translation type='obsolete'>Ein kritischer Fehler ist aufgetreten!
Bitte überprüfen Sie die Log-Datei</translation>
    </message>
    <message>
        <source>Critical error</source>
        <translation>Kritischer Fehler</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>No heightmap is available!
Please generate a heightmap at "Topografie" first.</source>
        <translation type='obsolete'>Keine Heightmap gefunden!
Bitte generieren Sie zuerst eine Heightmap unter "Topographie".</translation>
    </message>
    <message>
        <source>Not all terrain textures are available!
Please generate terrain textures at "Texture" first.</source>
        <translation>Es wurden nicht alle Landschaftstexturen gefunden!
Bitte generieren Sie zuerst die Landschaftstexturen unter "Oberfläche".</translation>
    </message>
    <message>
        <source>No lightmap for sea is available!
Please generate shadows at "Environment" first.</source>
        <translation type='obsolete'>Es wurde keine Lightmap für das Meer gefunden!
Bitte generieren Sie zuerst die Schatten unter "Umgebung".</translation>
    </message>
    <message>
        <source>Not all cloud layer textures are available!
Please generate cloud layer textures at "Clouds" first.</source>
        <translation>Es wurden nicht alle Texturen für die Zirrus-Wolken gefunden!
Bitte generieren Sie zuerst die Texturen unter "Wolken".</translation>
    </message>
    <message>
        <source>A critical error during initialising 3d engine occured, check log file.
Error: </source>
        <translation>Während der Initialisierung der 3D Engine ist ein Fehler aufgetreten, bitte überprüfen Sie die Log-Datei.
Fehler:</translation>
    </message>
    <message>
        <source>A critical error during terminate 3d engine occured, check log file.
Error: </source>
        <translation>Während der Deinitialisierung der 3D Engine ist ein Fehler aufgetreten, bitte überprüfen Sie die Log-Datei.
Fehler:</translation>
    </message>
    <message>
        <source>A critical error during update loop of 3d engine occured, check log file.
Error: </source>
        <translation>Während der Aktualisierung der 3D Engine ist ein Fehler aufgetreten, bitte überprüfen Sie die Log-Datei.
Fehler:</translation>
    </message>
    <message>
        <source>A critical error during switch of render target occured, check log file.
Error: </source>
        <translation>Während der Umschaltung der 3D Engine ist ein Fehler aufgetreten, bitte überprüfen Sie die Log-Datei.
Fehler:</translation>
    </message>
    <message>
        <source>No heightmap is available!
Please generate a heightmap at "Topography" first.</source>
        <translation>Keine Heightmap gefunden!
Bitte generieren Sie zuerst eine Heightmap unter "Topographie".</translation>
    </message>
    <message>
        <source>No lightmap for water is available!
Please generate shadows at "Environment" first.</source>
        <translation>Es wurde keine Lightmap für das Wasser gefunden!
Bitte generieren Sie zuerst die Schatten unter "Umgebung".</translation>
    </message>
</context>
<context>
    <name>PreviewGUIBase</name>
    <message>
        <source>PreviewGUI</source>
        <translation>PreviewGUI</translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation>Vollbild</translation>
    </message>
    <message>
        <source>Window</source>
        <translation>Fenster</translation>
    </message>
    <message>
        <source>Choose your render target...</source>
        <translation>Vollbild- oder Fenstermodus?</translation>
    </message>
    <message>
        <source>The 3D-Mode displays the landscape in 3d and allows the user to move around freely in it.</source>
        <translation>Der 3D-Modus erscheint durch die Auswahl des "3D"-Reiters beim Bearbeiten einer Landschaft. Hier wird die Landschaft in 3D angezeigt.</translation>
    </message>
    <message>
        <source>Shows the 3d scene in fullscreen.</source>
        <translation>Zeigt die 3D Szene im Vollbildmodus.</translation>
    </message>
    <message>
        <source>Shows the 3d scene in this window.</source>
        <translation>Zeigt die 3D Szene in diesem Fenster.</translation>
    </message>
</context>
<context>
    <name>ScapeMakerDialog</name>
    <message>
        <source>&amp;Manage landscapes</source>
        <translation>&amp;Landschaften verwalten</translation>
    </message>
    <message>
        <source>&amp;Config</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <source>&amp;Manual (English)</source>
        <translation type='obsolete'>&amp;Handbuch (Englisch)</translation>
    </message>
    <message>
        <source>Ma&amp;nual (German)</source>
        <translation type='obsolete'>H&amp;andbuch (Deutsch)</translation>
    </message>
    <message>
        <source>&amp;Tutorial (English)</source>
        <translation type='obsolete'>&amp;Tutorial (Englisch)</translation>
    </message>
    <message>
        <source>T&amp;utorial (German)</source>
        <translation type='obsolete'>T&amp;utorial (Deutsch)</translation>
    </message>
    <message>
        <source>Official &amp;website</source>
        <translation>Offizielle &amp;Webseite</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Unable to open a web browser. Ensure that you have a web browser installed.</source>
        <translation>Der Webbrowser konnte nicht geöffnet werden. Bitte vergewissern Sie sich, dass sie einen Webbrowser installiert haben.</translation>
    </message>
    <message>
        <source>manual_e.html</source>
        <translation>manual.html</translation>
    </message>
    <message>
        <source>tutorial_e.html</source>
        <translation>tutorial.html</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Handbuch</translation>
    </message>
    <message>
        <source>T&amp;utorial</source>
        <translation>T&amp;utorial</translation>
    </message>
    <message>
        <source>&amp;Keys in 3d mode</source>
        <translation>Ta&amp;stenbelegung für 3D-Modus</translation>
    </message>
</context>
<context>
    <name>ScapeMakerDialogBase</name>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Topography</source>
        <translation>Topographie</translation>
    </message>
    <message>
        <source>Texture</source>
        <translation>Oberfläche</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>Objekte</translation>
    </message>
    <message>
        <source>Environment</source>
        <translation>Umgebung</translation>
    </message>
    <message>
        <source>3D</source>
        <translation>3D</translation>
    </message>
    <message>
        <source>Clouds</source>
        <translation>Wolken</translation>
    </message>
    <message>
        <source>Sea</source>
        <translation type='obsolete'>Meer</translation>
    </message>
    <message>
        <source>Water</source>
        <translation>Wasser</translation>
    </message>
</context>
<context>
    <name>SeaGUI</name>
    <message>
        <source>Height</source>
        <translation type='obsolete'>Höhe</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type='obsolete'>Geschwindigkeit</translation>
    </message>
    <message>
        <source>Reflection</source>
        <translation type='obsolete'>Reflexion</translation>
    </message>
    <message>
        <source>Transparency</source>
        <translation type='obsolete'>Transparenz</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation type='obsolete'>ScapeMaker</translation>
    </message>
    <message>
        <source>-default-</source>
        <translation type='obsolete'>-default-</translation>
    </message>
</context>
<context>
    <name>SeaGUIBase</name>
    <message>
        <source>SeaGUI</source>
        <translation type='obsolete'>SeaGUI</translation>
    </message>
    <message>
        <source>Waves</source>
        <translation type='obsolete'>Wellen</translation>
    </message>
    <message>
        <source>Import</source>
        <translation type='obsolete'>Importieren</translation>
    </message>
    <message>
        <source>Import a waves texture</source>
        <translation type='obsolete'>Wellentexture importieren</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type='obsolete'>Reset</translation>
    </message>
    <message>
        <source>Reset to default waves texture</source>
        <translation type='obsolete'>Standardwellentexturen verwenden.</translation>
    </message>
    <message>
        <source>-default-</source>
        <translation type='obsolete'>-default-</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type='obsolete'>Aussehen</translation>
    </message>
    <message>
        <source>Color of water</source>
        <translation type='obsolete'>Farbe des Wassers</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation type='obsolete'>Farbe:</translation>
    </message>
    <message>
        <source>Information</source>
        <translation type='obsolete'>Information</translation>
    </message>
    <message>
        <source>Most changes at this panel needs a recalculation of shadows at &apos;Environment&apos; panel, otherwise they won&apos;t appear in 3D mode.</source>
        <translation type='obsolete'>Die meisten Änderungen in diesem Bereich benötigen eine neue Berechnung der Schatten im &apos;Umgebungs&apos;-Bereich, ansonsten sind sie nicht im 3D Modus sichtbar.</translation>
    </message>
</context>
<context>
    <name>TextureExportGUI</name>
    <message>
        <source>ScapeMaker</source>
        <translation type='obsolete'>ScapeMaker</translation>
    </message>
    <message>
        <source>File already exists!
Do you want to overwrite this file?</source>
        <translation type='obsolete'>Datei existiert bereits!
Wollen Sie die Datei überschreiben?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type='obsolete'>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation type='obsolete'>Nein</translation>
    </message>
</context>
<context>
    <name>TextureExportGUIBase</name>
    <message>
        <source>ScapeMaker - Texture export</source>
        <translation>ScapeMaker - Texturexport</translation>
    </message>
    <message>
        <source>Plain terrain texture</source>
        <translation>Einfache Landschaftstextur</translation>
    </message>
    <message>
        <source>Terrain texture with shadows</source>
        <translation>Landschaftstextur mit Schatten</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Auflösung:</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <source>Export texture</source>
        <translation>Textur exportieren</translation>
    </message>
    <message>
        <source>File:</source>
        <translation type='obsolete'>Datei:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>./terraintexture.bmp</source>
        <translation type='obsolete'>./terraintexture.bmp</translation>
    </message>
    <message>
        <source>...</source>
        <translation type='obsolete'>...</translation>
    </message>
    <message>
        <source>256x256 (0.2MB)</source>
        <translation>256x256 (0.2MB)</translation>
    </message>
    <message>
        <source>512x512 (0.8MB)</source>
        <translation>512x512 (0.8MB)</translation>
    </message>
    <message>
        <source>1024x1024 (3.1MB)</source>
        <translation>1024x1024 (3.1MB)</translation>
    </message>
    <message>
        <source>2048x2048 (12.5MB)</source>
        <translation>2048x2048 (12.5MB)</translation>
    </message>
    <message>
        <source>4096x4096 (50.3MB)</source>
        <translation>4096x4096 (50.3MB)</translation>
    </message>
    <message>
        <source>8192x8192 (201.3MB)</source>
        <translation>8192x8192 (201.3MB)</translation>
    </message>
    <message>
        <source>Defines, which texture should be exported. 
Plain terrain texture: The textures without shadows are exported. 
Terrain texture with shadows: The textures with generated shadows on them are exported.</source>
        <translation>Legt fest, welche Bodentextur exportiert werden soll. 
Einfache Landschaftstextur: Es wird die vom "Oberflächenbereich" erzeugte Bodentextur exportiert. 
Landschaftstextur mit Schatten: Es wird die vom "Umgebungsbereich" erzeugte Bodentextur exportiert.</translation>
    </message>
    <message>
        <source>Sets the resolution for the image file. High resolutions only contain more detail given that the textures were generated in a high resolution as well.</source>
        <translation>Stellt die Auflösung der Bild-Datei ein. Hohe Auflösungen enthalten nur dann auch mehr Details, wenn die Bodentextur ebenfalls in einer entsprechend hohen Auflösung berechnet wurde.</translation>
    </message>
    <message>
        <source>Opens a dialog in which the output file can be specified and then exports the texture.</source>
        <translation>Exportiert die Textur, nachdem in einem Dialog die Zieldatei und Format festgelegt wurde.</translation>
    </message>
</context>
<context>
    <name>TextureGUI</name>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Can&apos;t open file!</source>
        <translation type='obsolete'>Datei konnte nicht geöffnet werden!</translation>
    </message>
    <message>
        <source>Name of texture?</source>
        <translation>Name der Textur?</translation>
    </message>
    <message>
        <source>You must enter a name</source>
        <translation>Sie müssen einen Namen angeben</translation>
    </message>
    <message>
        <source>Texture with this name already exists!
Please choose another name.</source>
        <translation>Eine Textur mit diesem Namen existiert bereits!
Bitte wählen Sie einen anderen Namen.</translation>
    </message>
    <message>
        <source>Please select a texture in the list first!</source>
        <translation>Bitte wählen Sie zuerst eine Textur aus der Liste aus!</translation>
    </message>
    <message>
        <source>Delete texture</source>
        <translation>Textur löschen</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>New name of texture?</source>
        <translation>Neuer Name der Textur?</translation>
    </message>
    <message>
        <source>You must enter a name!</source>
        <translation>Sie müssen einen Namen angeben!</translation>
    </message>
    <message>
        <source>Can&apos;t rename texture!</source>
        <translation>Textur konnte nicht umbenannt werden!</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Slope</source>
        <translation>Steigung</translation>
    </message>
    <message>
        <source>Smoothness</source>
        <translation>Glätte</translation>
    </message>
    <message>
        <source>Can&apos;t rename mask of texture!</source>
        <translation>Die Maske der Textur konnte nicht umbenannt werden!</translation>
    </message>
</context>
<context>
    <name>TextureGUIBase</name>
    <message>
        <source>TextureGUI</source>
        <translation>TextureGUI</translation>
    </message>
    <message>
        <source>Remove texture</source>
        <translation>Textur entfernen</translation>
    </message>
    <message>
        <source>Add texture</source>
        <translation>Texture hinzufügen</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Auflösung:</translation>
    </message>
    <message>
        <source>256x256</source>
        <translation>256x256</translation>
    </message>
    <message>
        <source>512x512</source>
        <translation>512x512</translation>
    </message>
    <message>
        <source>1024x1024</source>
        <translation>1024x1024</translation>
    </message>
    <message>
        <source>Move texture up</source>
        <translation>Textur nach oben verschieben</translation>
    </message>
    <message>
        <source>Move texture down</source>
        <translation>Textur nach unten verschieben</translation>
    </message>
    <message>
        <source>Texture:</source>
        <translation type='obsolete'>Textur:</translation>
    </message>
    <message>
        <source>Rename texture</source>
        <translation>Textur umbenennen</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <source>Start generating ground texture</source>
        <translation>Generierung der Bodentextur beginnen</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Cancel generating ground texture</source>
        <translation>Generierung der Bodentextur abbrechen</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <source>Import a texture</source>
        <translation>Textur importieren</translation>
    </message>
    <message>
        <source>Mask</source>
        <translation>Maske</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Texture</source>
        <translation>Textur</translation>
    </message>
    <message>
        <source>Import a mask</source>
        <translation type='obsolete'>Maske importieren</translation>
    </message>
    <message>
        <source>Reset to default mask</source>
        <translation>Zur Standardmaske zurücksetzen</translation>
    </message>
    <message>
        <source>Export texture</source>
        <translation>Texturexport</translation>
    </message>
    <message>
        <source>Export terrain texture</source>
        <translation>Landschaftstextur exportieren</translation>
    </message>
    <message>
        <source>Detail Map</source>
        <translation>Detailtextur</translation>
    </message>
    <message>
        <source>Reset to default detail mask</source>
        <translation>Standarddetailstextur verwenden</translation>
    </message>
    <message>
        <source>Import a detail mask</source>
        <translation>Detailtextur importieren</translation>
    </message>
    <message>
        <source>64x64</source>
        <translation>64x64</translation>
    </message>
    <message>
        <source>128x128</source>
        <translation>128x128</translation>
    </message>
    <message>
        <source>Here the textures of the landscape are defined and generated.</source>
        <translation>Der Oberflächen-Bereich erscheint durch die Auswahl des "Oberfläche"-Reiters beim Bearbeiten einer Landschaft. Hier wird die Bodentextur der Landschaft festgelegt und generiert.</translation>
    </message>
    <message>
        <source>Shows a picture of the current detail map. The detail map will be overlayed on the whole landscape, so choose a structur which fits to all ground types.</source>
        <translation type='obsolete'>Zeigt ein Bild der aktiven Detailtexture. Diese Detailtextur wird über die gesamte Landschaft gelegt, deshalb sollte eine Struktur gewählt werden, die zu allen verwendeten Bodenarten passt.</translation>
    </message>
    <message>
        <source>Changes the picture of the current detail map. The imported detail map will be converted to grayscale and lightness will be corrected.</source>
        <translation>Wählt eine neue Detailtextur aus. Das ausgewählte Bild wird automatisch in Graustufen umgewandelt und die Helligkeit angepasst.</translation>
    </message>
    <message>
        <source>Sets the detail map to default.</source>
        <translation>Als Detailtextur wird die Standardtextur verwendet.</translation>
    </message>
    <message>
        <source>Shows a picture of the selected texture.</source>
        <translation>Zeigt ein Vorschaubild der Textur der gewählten Bodenart.</translation>
    </message>
    <message>
        <source>Changes the picture for the selected texture.</source>
        <translation>Ersetzt die Textur der gewählten Bodenart durch eine neue Bilddatei.</translation>
    </message>
    <message>
        <source>Shows a picture of the mask used to limit the distribution of the texture.</source>
        <translation>Zeigt die verwendete Maske an. Die Maske dient dazu, gezielt einzelne Flächen von der Bodenart auszunehmen. In weißen Bereichen der Maske darf die Bodenart vorkommen, in schwarzen dagegen nicht.</translation>
    </message>
    <message>
        <source>Changes the mask for the selected texture.</source>
        <translation>Ersetzt die aktuelle Maske durch eine neue Bilddatei.</translation>
    </message>
    <message>
        <source>Sets mask for the selected texture to default mask.</source>
        <translation>Ersetzt die aktuelle Maske wieder durch die Standardmaske, die keine Einschränkung der Verteilung bewirkt.</translation>
    </message>
    <message>
        <source>Red areas show the areas that match the settings for the selected texture.</source>
        <translation>Zeigt die Verteilung der aktuell gewählten Bodenart an.</translation>
    </message>
    <message>
        <source>Sets the resolution of the generated texture. A high value results in sharper textures, but also takes a very long time.</source>
        <translation type='obsolete'>Stellt die Auflösung der generierten Textur ein. Bei einem höheren Wert wird die Landschaftstextur zwar schärfer, aber die Berechnungszeiten steigen sehr stark an. Dieser Wert wirkt sich auch auf die Qualität (und Dauer) der Schattenberechnung im Umgebungs-Bereich aus.</translation>
    </message>
    <message>
        <source>A list of all textures used for this landscape. A click on the name of a texture selects it.</source>
        <translation>Zeigt alle verwendeten Bodenarten an. Durch Klick auf einen Namen einer Bodenart wird diese ausgewählt und kann bearbeitet werden.</translation>
    </message>
    <message>
        <source>Adds a new ground texture. A image file must be selected and a name must be entered.</source>
        <translation>Fügt eine neue Bodenart hinzu. Dafür muss eine Bilddatei auf der Festplatte ausgewählt und ein Name eingeben werden.</translation>
    </message>
    <message>
        <source>Deletes the selected texture.</source>
        <translation>Löscht die gewählte Bodenart.</translation>
    </message>
    <message>
        <source>Allows changing the name of the selected texture.</source>
        <translation>Ermöglicht die Eingabe eines neuen Namens für die gewählte Bodenart.</translation>
    </message>
    <message>
        <source>Moves the selected texture upwards. The texture at the top is rendered last, so it can cover other textures.</source>
        <translation>Verschiebt die gewählte Bodenart in der Hierachie nach oben. Die Bodenarten sollte immer so angeordnet werden, wie dies auch in der Natur der Fall ist, z.B. von unten nach oben: Fels, Erde, Gras und dann Schnee.</translation>
    </message>
    <message>
        <source>Moves the selected texture downwards.</source>
        <translation>Verschiebt die gewählte Bodenart in der Hierachie nach unten.</translation>
    </message>
    <message>
        <source>Sets the width of the seam of the texture. A higher value results in smoother blendings between two textures.</source>
        <translation>Legt die Breite des Randes der Bodenart fest. Je höher dieser Wert, desto weicher werden die Übergänge.</translation>
    </message>
    <message>
        <source>Sets the range of height in which the selected texture will occur. For snow a high value would be good, for example.</source>
        <translation>Stellt den Höhenbereich ein, in dem die Bodenart vorkommt. Bei Schnee wäre z.B. ein hoher Bereich angebracht.</translation>
    </message>
    <message>
        <source>Opens the texture export dialog. There the generated ground textures can be exported as a single image file.</source>
        <translation>Öffnet den Texturexportdialog. Dort kann die zuvor generierte Bodentextur als Bilddatei exportiert werden.</translation>
    </message>
    <message>
        <source>Sets the range of slope in which the selected texture will occur. For snow a low value would be good, for example.</source>
        <translation>Stellt den Steigungsbereich ein, in dem die Bodenart vorkommt. Gras würde sinnvollerweise nur bei relativ flachen Hängen vorkommen.</translation>
    </message>
    <message>
        <source>Generates the texture for the landscape.</source>
        <translation>Generiert die Bodentextur der Landschaft anhand der gewählten Einstellungen. Je nach gewählter Auflösung kann dies längere Zeit in Anspruch nehmen.</translation>
    </message>
    <message>
        <source>Shows a picture of the current detail map. The detail map is overlayed on the whole landscape, so try and choose a structure which suits all ground types.</source>
        <translation>Zeigt ein Bild der aktiven Detailtexture. Diese Detailtextur wird über die gesamte Landschaft gelegt, deshalb sollte eine Struktur gewählt werden, die zu allen verwendeten Bodenarten passt.</translation>
    </message>
    <message>
        <source>Defines the resolution of the generated texture. Higher values result in sharper textures but make for a longer generation process.</source>
        <translation>Stellt die Auflösung der generierten Textur ein. Bei einem höheren Wert wird die Landschaftstextur zwar schärfer, aber die Berechnungszeiten steigen sehr stark an. Dieser Wert wirkt sich auch auf die Qualität (und Dauer) der Schattenberechnung im Umgebungs-Bereich aus.</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Ändern</translation>
    </message>
    <message>
        <source>Changes a mask</source>
        <translation>Ändert eine Maske</translation>
    </message>
</context>
<context>
    <name>TopografieGUI</name>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>Overwrite existing file?</source>
        <translation type='obsolete'>Existierende Datei überschreiben?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type='obsolete'>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation type='obsolete'>Nein</translation>
    </message>
    <message>
        <source>Can&apos;t open file!</source>
        <translation type='obsolete'>Datei konnte nicht geöffnet werden!</translation>
    </message>
    <message>
        <source>Can&apos;t convert to grayscale</source>
        <translation type='obsolete'>Es konnte nicht in Graustufen konvertiert werden</translation>
    </message>
    <message>
        <source>Can&apos;t scale image to right size</source>
        <translation type='obsolete'>Es konnte nicht auf die richtigen Ausmaße skaliert werden</translation>
    </message>
    <message>
        <source>Drops</source>
        <translation>Tropfen</translation>
    </message>
    <message>
        <source>Roughness</source>
        <translation>Rauheit</translation>
    </message>
    <message>
        <source>Smoothness</source>
        <translation>Glätte</translation>
    </message>
    <message>
        <source>Middle layer height</source>
        <translation>Schichtbereich</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Unten</translation>
    </message>
    <message>
        <source>Middle</source>
        <translation>Mitte</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Oben</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Is the heightmap tileable?
(If you&apos;re not sure, please click &apos;No&apos;)</source>
        <translation>Ist die Heightmap wiederholbar?
(Wenn Sie sich nicht sicher sind, wählen Sie &apos;Nein&apos;)</translation>
    </message>
</context>
<context>
    <name>TopografieGUIBase</name>
    <message>
        <source>TopografieGUI</source>
        <translation>TopografieGUI</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <source>Import a heightmap</source>
        <translation>Heightmap importieren</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportieren</translation>
    </message>
    <message>
        <source>Export the heightmap</source>
        <translation>Heightmap exportieren</translation>
    </message>
    <message>
        <source>Random terrain</source>
        <translation>Zufallslandschaft</translation>
    </message>
    <message>
        <source>Reset values</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>Reset all values to default</source>
        <translation>Alle Einstellungen auf Standard zurücksetzen</translation>
    </message>
    <message>
        <source>257x257</source>
        <translation type='obsolete'>257x257</translation>
    </message>
    <message>
        <source>513x513</source>
        <translation type='obsolete'>513x513</translation>
    </message>
    <message>
        <source>1025x1025</source>
        <translation type='obsolete'>1025x1025</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Cancel generating topography</source>
        <translation>Generierung der Topographie abbrechen</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <source>Start generating topography</source>
        <translation>Generierung der Topographie beginnen</translation>
    </message>
    <message>
        <source>Firmness of rocks</source>
        <translation>Felsfestigkeiten</translation>
    </message>
    <message>
        <source>Size:</source>
        <translation>Größe:</translation>
    </message>
    <message>
        <source>Improve current terrain</source>
        <translation>Aktuelle Landschaft verbessern</translation>
    </message>
    <message>
        <source>256x256</source>
        <translation>256x256</translation>
    </message>
    <message>
        <source>512x512</source>
        <translation>512x512</translation>
    </message>
    <message>
        <source>1024x1024</source>
        <translation>1024x1024</translation>
    </message>
    <message>
        <source>Creates the heighmap of the landscape.</source>
        <translation>Der Topografie-Bereich erscheint durch die Auswahl des "Topographie"-Reiters beim Bearbeiten einer Landschaft. Hier wird die Höhenstruktur der Landschaft festgelegt.</translation>
    </message>
    <message>
        <source>Defines the height of the middle layer.</source>
        <translation>Legt die Position der mittleren Gesteinsschicht im Höhenprofil fest.</translation>
    </message>
    <message>
        <source>Sets the firmness of the bottom layer. A low value causes soft stone, on which erosion has a big effect, and so soft slopes. Accordingly, a low value creates steep slopes.</source>
        <translation>Setzt die Festigkeit der unteren Gesteinsschicht. Ein niedriger Wert bedeutet ein weiches Gestein, das viel von den Wassertropfen abgetragen wird und nur flache Hänge erzeugt. Bei einem hohen Wert dagegen wird wenig von den Wassertropfen abgetragen und es entstehen steile Hänge.</translation>
    </message>
    <message>
        <source>Sets the firmness of the middle layer. A low value causes soft stone, on which erosion has a big effect, and so soft slopes. Accordingly, a low value creates steep slopes.</source>
        <translation>Setzt die Festigkeit der mittleren Gesteinsschicht. Ein niedriger Wert bedeutet ein weiches Gestein, das viel von den Wassertropfen abgetragen wird und nur flache Hänge erzeugt. Bei einem hohen Wert dagegen wird wenig von den Wassertropfen abgetragen und es entstehen steile Hänge.</translation>
    </message>
    <message>
        <source>Sets the firmness of the top layer. A low value causes soft stone, on which erosion has a big effect, and so soft slopes. Accordingly, a low value creates steep slopes.</source>
        <translation>Setzt die Festigkeit der oberen Gesteinsschicht. Ein niedriger Wert bedeutet ein weiches Gestein, das viel von den Wassertropfen abgetragen wird und nur flache Hänge erzeugt. Bei einem hohen Wert dagegen wird wenig von den Wassertropfen abgetragen und es entstehen steile Hänge.</translation>
    </message>
    <message>
        <source>Defines the size of the heightmap.</source>
        <translation>Setzt die Größe der zufällig generierten Heightmap. Entsprechend weitläufiger werden die Landschaften.</translation>
    </message>
    <message>
        <source>The newly generated heightmap uses the current heightmap as a basis. Use this to improve your heightmaps by adding new valleys.</source>
        <translation>Bewirkt, dass die bestehende Heightmap als Grundlage für die zufällig generierte Heightmap verwendet wird. Die ist sinnvoll, um eine Heightmap mit zusätzlichen Tälern interessanter zu gestalten.</translation>
    </message>
    <message>
        <source>Sets the number of water tips that are used for the generation of the landscape. Each water tip flows its own way to the border of the landscape and by doing that it causes erosion. More drops result in clearer valleys.</source>
        <translation>Bestimmt die Anzahl der Wassertropfen, die für die Generierung der Landschaft verwendet werden. Jeder Wassertropfen sucht sich dabei einen Weg zum Rand der Landschaft und bewirkt auf dem Weg Erosion, d.h. senkt die Landschaft an diesen Stellen ab. Je mehr Tropfen, desto ausgeprägter werden also die Täler.</translation>
    </message>
    <message>
        <source>A higher value makes the value smoother, independently from the other values.</source>
        <translation>Je höher dieser Wert, desto &apos;weicher&apos; wird die Landschaft. Bei einem hohen Wert gibt es z.B. nur sanfte Hügel, bei einem niedrigen Wert auch scharfe Kanten.</translation>
    </message>
    <message>
        <source>Controls the regularity of the slopes. Low values produce similarly steep slopes, high values result in irregular, rough slopes.</source>
        <translation>Kontrolliert die Gleichmäßigkeit der Hänge. Bei niedrigen Werten sind die Hänge eher gleichmäßig steil, bei hohen Werten dagegen ungleichmäßig und rau.</translation>
    </message>
    <message>
        <source>Resets all settings to the their standard values.</source>
        <translation>Stellt alle Werte wieder auf die Standardeinstellungen zurück.</translation>
    </message>
    <message>
        <source>Generates the heightmap.</source>
        <translation>Generiert die Heightmap anhand der gewählten Einstellungen. Dies kann je nach Einstellungen längere Zeit in Anspruch nehmen.</translation>
    </message>
    <message>
        <source>Shows the heightmap. Every height is represented by a colour, where bright areas represent a mountain, dark areas a valley.</source>
        <translation>Zeigt die aktuelle Höhenstruktur, die sogenannte "Heightmap" an. Dabei wird jeder Koordinate der Landschaft eine Höhe zugeordnet, repräsentiert durch eine Grausstufe. Hellere Bereiche entsprechen somit einem Berg und dunklere einem Tal.</translation>
    </message>
    <message>
        <source>Imports a heightmap from a file. Automatically scales it to the right size and transports it to grey.</source>
        <translation>Importiert eine Heightmap aus einer Bilddatei. Dabei wird sie automatisch in das richtige Format konvertiert, d.h. auf die richtige Größe skaliert und in Grausstufen verwandelt.</translation>
    </message>
    <message>
        <source>Exports the heightmap as a image file.</source>
        <translation type='obsolete'>Exportiert die aktuelle Heightmap in eine Bilddatei. Damit kann sie auch in anderen Programmen, wie Terragen, verwendet werden.</translation>
    </message>
    <message>
        <source>Sets the height of the landscape. The left slider defines the height of the black pixels, the right one defines the height of the white pixels. All other colors are between them.</source>
        <translation>Legt den Höhenbereich der Landschaft fest. Die linke Begrenzung bestimmt die Höhe der schwarzen Pixel der Heightmap in Metern. Die rechte dagegen setzt die Höhe der weißen Pixel. Alle anderen Grausstufen der Heightmap liegen entsprechend dazwischen.</translation>
    </message>
    <message>
        <source>Exports the heightmap as an image file.</source>
        <translation>Exportiert die aktuelle Heightmap in eine Bilddatei. Damit kann sie auch in anderen Programmen, wie Terragen, verwendet werden.</translation>
    </message>
</context>
<context>
    <name>WaterGUI</name>
    <message>
        <source>Height</source>
        <translation>Höhe</translation>
    </message>
    <message>
        <source>Speed</source>
        <translation>Geschwindigkeit</translation>
    </message>
    <message>
        <source>Reflection</source>
        <translation>Reflexion</translation>
    </message>
    <message>
        <source>Transparency</source>
        <translation>Transparenz</translation>
    </message>
    <message>
        <source>Water amount</source>
        <translation>Wassermenge</translation>
    </message>
    <message>
        <source>Stream speed</source>
        <translation>Stromgeschwindigkeit</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Quelle</translation>
    </message>
    <message>
        <source>ScapeMaker</source>
        <translation>ScapeMaker</translation>
    </message>
    <message>
        <source>-default-</source>
        <translation>-default-</translation>
    </message>
    <message>
        <source>Please select a source in the list first!</source>
        <translation>Bitte wählen Sie zuerste eine Quelle aus der List!</translation>
    </message>
    <message>
        <source>New name of source?</source>
        <translation>Neuer Name für die Quelle?</translation>
    </message>
    <message>
        <source>You must enter a name!</source>
        <translation>Sie müssen einen Namen angeben!</translation>
    </message>
</context>
<context>
    <name>WaterGUIBase</name>
    <message>
        <source>WaterGUI</source>
        <translation>WaterGUI</translation>
    </message>
    <message>
        <source>Sea</source>
        <translation>Meer</translation>
    </message>
    <message>
        <source>Waves</source>
        <translation>Wellen</translation>
    </message>
    <message>
        <source>-default-</source>
        <translation>-default-</translation>
    </message>
    <message>
        <source>Import</source>
        <translation>Importieren</translation>
    </message>
    <message>
        <source>Import a waves texture</source>
        <translation>Wellentexture importieren</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Reset to default waves texture</source>
        <translation>Standardwellentexturen verwenden.</translation>
    </message>
    <message>
        <source>Rivers</source>
        <translation>Flüsse</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stoppen</translation>
    </message>
    <message>
        <source>Stop generating rivers</source>
        <translation>Generierung der Flüsse stoppen</translation>
    </message>
    <message>
        <source>Use pen tool to set new sources.</source>
        <translation>Benutzen Sie den Stift, um neue Quellen festzulegen.</translation>
    </message>
    <message>
        <source>Stop generation, if results suit your imagination.</source>
        <translation>Stoppen Sie, sobald das Ergebnis Ihren Vorstellungen entspricht.</translation>
    </message>
    <message>
        <source>Remove a source</source>
        <translation>Quelle entfernen</translation>
    </message>
    <message>
        <source>Rename a source</source>
        <translation>Quelle umbenennen</translation>
    </message>
    <message>
        <source>Generate</source>
        <translation>Generieren</translation>
    </message>
    <message>
        <source>Generate rivers</source>
        <translation>Flüsse generieren</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation>Farbe:</translation>
    </message>
    <message>
        <source>Color of water</source>
        <translation>Farbe des Wassers</translation>
    </message>
    <message>
        <source>Export mask</source>
        <translation>Maske speichern</translation>
    </message>
    <message>
        <source>Export a mask of water</source>
        <translation>Eine Maske des Wassers exportieren</translation>
    </message>
    <message>
        <source>Here, all settings for the sea are defined.</source>
        <translation>Der Wasser-Bereich erscheint durch die Auswahl des "Wasser"-Reiters beim Bearbeiten einer Landschaft. Hier wird das Meer und die Flüsse für die Landschaft eingestellt.</translation>
    </message>
    <message>
        <source>Sets the height of the sea level. 0 deactivates the sea.</source>
        <translation>Legt die Höhe des Meeresspiegels fest. Eine Höhe von 0 bedeutet, dass das Meer ausgeschaltet ist.</translation>
    </message>
    <message>
        <source>Defines the speed of the waves.</source>
        <translation>Bestimmt die Geschwindigkeit der Wellen des Wassers.</translation>
    </message>
    <message>
        <source>Sets another wave texture. A wave texture is not a normal textur, but a so called normal map. A normal map does not contain information about colour, but about the structure of the surface.</source>
        <translation>Ermöglicht die Auswahl einer anderen Wellentextur. Dabei darf es sich um keine normale Textur handeln, sondern um eine sogenannte Normalmap. Diese enthält keine Farb-, sondern Oberflächenstrukturwerte.</translation>
    </message>
    <message>
        <source>Sets the default wave texture.</source>
        <translation>Stellt wieder die Standardwellentextur ein.</translation>
    </message>
    <message>
        <source>List of all set sources.</source>
        <translation>Hier werden alle gesetzten Quellen angezeigt. Ein Klick auf eine Quelle wählt diese aus.</translation>
    </message>
    <message>
        <source>Removes the selected source from the list.</source>
        <translation>Löscht die gewählte Quelle.</translation>
    </message>
    <message>
        <source>Sets a new name for the current selected source.</source>
        <translation>Für die gewählte Quelle kann ein benutzerspezifischer Name eingegeben werden.</translation>
    </message>
    <message>
        <source>Sets the amount of water the current selected source delivers. The right slider sets the amount of water at beginning of generation. Later it goes to the amount of the left slider.</source>
        <translation>Stellt die Wassermenge ein, die die gewählte Quelle liefert. Der rechte Regler setzt die Wassermenge zu Beginn der Generierung. Anschließend geht die Wassermenge langsam zum Wert des linken Reglers zurück.</translation>
    </message>
    <message>
        <source>Sets the amount of stream for the current selected source. A higher value will create more steamy and white rivers.</source>
        <translation>Setzt die &apos;Stromstärke&apos; des Flusses der gewählten Quelle. Ein hoher Wert erzeugt brausende und &apos;weiße&apos; Flüsse.</translation>
    </message>
    <message>
        <source>Starts the generation of rivers. This generation has no end, so you have to stop it by yourself.</source>
        <translation type='obsolete'>Startet die Generierung der Flüsse. Diese Generierung endet nicht von alleine, sondern muss manuell gestoppt werden, wenn das Ergebnis den Anforderungen entspricht.</translation>
    </message>
    <message>
        <source>Defines the reflectivity of the water in %.</source>
        <translation>Stellt die Reflexionsstärke des Wassers ein. Bei 100% Reflexion wird die Umgebung zu 100% vom Wasser reflektiert. Bei 0% findet keine Reflexion statt.</translation>
    </message>
    <message>
        <source>Sets the transparency of the sea, that is up to which deepness the ground gleams through.</source>
        <translation>Setzt die Transparenz des Wassers. Dies legt fest, bis zu welcher Wassertiefe der Untergrund des Meeres durchschimmert.</translation>
    </message>
    <message>
        <source>Shows a preview of the distribution of the sea.</source>
        <translation type='obsolete'>Zeigt eine Vorschau für das Vorkommen des Wassers oder der Flüsse an.</translation>
    </message>
    <message>
        <source>Shows the waters color. Click on the color to change it.</source>
        <translation>Zeigt die Farbe des Wassers an. Durch Klick auf die Farbe, kann die Farbe geändert werden.</translation>
    </message>
    <message>
        <source>Exports a mask of all water elements. Can be used to mask out terrain objects.</source>
        <translation>Exportiert eine Maske aller Wasserelemente. Diese Maske kann als Maske für Objekte verwendet werden, damit sie nicht im Bereich des Wassers vorkommen.</translation>
    </message>
    <message>
        <source>Starts the generation of rivers. This generation has no end, so you&apos;ll have to stop it manually.</source>
        <translation>Startet die Generierung der Flüsse. Diese Generierung endet nicht von alleine, sondern muss manuell gestoppt werden, wenn das Ergebnis den Anforderungen entspricht.</translation>
    </message>
    <message>
        <source>Shows a preview of the distribution of water.</source>
        <translation>Zeigt eine Vorschau für das Vorkommen des Wassers oder der Flüsse an.</translation>
    </message>
</context>
</TS>
