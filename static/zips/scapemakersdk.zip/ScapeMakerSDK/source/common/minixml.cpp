/****************************************************************************
** MiniXML
**
** A help class for writing and loading properties and data in a text file
**
** Author: Dirk Plate
****************************************************************************/

#include "MiniXML.h"
#include <fstream>

/****************************************************************************
** MiniXML Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
MiniXML::MiniXML()
{
	currentEndTag[0] = '\0';
	currentListTag[0] = '\0';
	currentListElementTag[0] = '\0';
	currentStartSearch = 0;
	tempStartSearch = 0;
	modus = NOTOPEN;
}

/****************************************************************************
** MiniXML Destructor
**
** deinit vars
**
** Author: Dirk Plate
****************************************************************************/
MiniXML::~MiniXML()
{
	if (modus == READ)
	{
		inputFile.close();
	}
	if (modus == WRITE)
	{
		outputFile.close();
	}
	modus = NOTOPEN;
}


/****************************************************************************
** MiniXML openFile
**
** open a file for reading or writing
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::openFile(const char* fileName, Modus modusSet)
{
	if (modus == READ)
	{
		inputFile.close();
		inputFile.clear();
	}
	if (modus == WRITE)
	{
		outputFile.close();
		outputFile.clear();
	}

	modus = modusSet;

	if (modus == READ)
	{
		inputFile.open(fileName, std::ifstream::binary);	
		if (!inputFile.fail()) return true;
	}
	else if (modus == WRITE)
	{
		outputFile.open(fileName,NULL);
		if (!outputFile.fail()) return true;
	}
	return false;
}

/****************************************************************************
** MiniXML closeFile
**
** close the file
**
** Author: Dirk Plate
****************************************************************************/
void MiniXML::closeFile()
{
	if (modus == READ)
	{
		inputFile.close();
		inputFile.clear();
	}
	if (modus == WRITE)
	{
		outputFile.close();
		outputFile.clear();
	}
	modus = NOTOPEN;
}

/****************************************************************************
** MiniXML writeBeginTag
**
** write a begin tag (e.g. <html>)
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeBeginTag(const char* tagName)
{
	if ((modus == WRITE) || (modus == WRITELIST) || (modus == WRITELISTELEMENT))
	{
		char string[512];

		buildBeginTag(string,tagName);
		outputFile << string;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML writeEndTag
**
** write a end tag (e.g. </html>)
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeEndTag(const char* tagName)
{
	if ((modus == WRITE) || (modus == WRITELIST) || (modus == WRITELISTELEMENT))
	{
		char string[512];

		buildEndTag(string,tagName);
		outputFile << string << "\n";
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML findBeginTag
**
** find a begin tag (e.g. <html>)
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::findBeginTag(const char* tagName)
{
	if ((modus == READ) || (modus == READLIST) || (modus == READLISTELEMENT))
	{
		char searchString[512];

		//prepare search string
		buildBeginTag(searchString,tagName);

		return findString(searchString);
	}
	else return false;
}

/****************************************************************************
** MiniXML findEndTag
**
** find a end tag (e.g. </html>)
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::findEndTag(const char* tagName)
{
	if ((modus == READ) || (modus == READLIST) || (modus == READLISTELEMENT))
	{
		char searchString[512];
		
		//prepare search string
		buildEndTag(searchString,tagName);

		return findString(searchString);
	}
	else return false;
}

/****************************************************************************
** MiniXML buildBeginTag
**
** build the begin tag(e.g. <html>)
**
** Author: Dirk Plate
****************************************************************************/
void MiniXML::buildBeginTag(char *tag, const char* tagName)
{
	tag[0] = '<';
	stringCopy(tag+1,tagName);
	int i=stringLength(tag);
	tag[i] = '>';
	tag[i+1] = '\0';
}

/****************************************************************************
** MiniXML buildEnTag
**
** build the end tag(e.g. </html>)
**
** Author: Dirk Plate
****************************************************************************/
void MiniXML::buildEndTag(char *tag, const char* tagName)
{
	tag[0] = '<';
	tag[1] = '/';
	stringCopy(tag+2,tagName);
	int i=stringLength(tag);
	tag[i] = '>';
	tag[i+1] = '\0';
}

/****************************************************************************
** MiniXML findString
**
** find a string from the current file position
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::findString(const char* string)
{
	if ((modus == READ) || (modus == READLIST) || (modus == READLISTELEMENT))
	{
		char c;
		bool jumpedBack = false;
		std::streampos startSearch = inputFile.tellg();
		std::streampos startEndTagSearch;

		while(1)
		{
			c = inputFile.get();

			//end of file reached
			if (inputFile.eof())
			{
				//end of search section reached, begin again
				if (!jumpedBack)
				{
					jumpedBack = true;
					inputFile.clear();
					inputFile.seekg(currentStartSearch);
					inputFile.clear();
					continue;
				}
				else return false;
			}

			//begin reached again?
			if (jumpedBack && (inputFile.tellg() > startSearch))
				return false;

			//end tag reached?
			if ((modus == READLIST) || (modus == READLISTELEMENT))
			{
				if (c == currentEndTag[0])
				{
					if (currentEndTag[1] == '\0') return false;

					startEndTagSearch = inputFile.tellg();

					//find the rest of end
					if (findStringRec(currentEndTag+1))
					{
						//end of search section reached, begin again
						if (!jumpedBack)
						{
							jumpedBack = true;
							inputFile.clear();
							inputFile.seekg(currentStartSearch);
							inputFile.clear();
							continue;
						}
						else return false;
					}
					else 
					{
						inputFile.clear();
						inputFile.seekg(startEndTagSearch);
						inputFile.clear();
					}
				}
			}

			//the first character is correct
			if (c == string[0])
			{
				if (string[1] == '\0') return true;

				//find the rest of string
				if (findStringRec(string+1)) return true;;
			}
		}
	}
	return false;
}

/****************************************************************************
** MiniXML findStringRec
**
** recursive help function for findString
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::findStringRec(const char* string)
{
	if ((modus == READ) || (modus == READLIST) || (modus == READLISTELEMENT))
	{
		char c;

		c = inputFile.get();

		//end of file reached
		if (inputFile.eof()) return false;

		//the first character is correct
		if (c == string[0])
		{
			if (string[1] == '\0') return true;

			//find the rest of string
			return findStringRec(string+1);
		}
		else return false;
	}
	else return false;
}

/****************************************************************************
** MiniXML writeInteger
**
** write a integer value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeInteger(const char* tagName, const int value)
{
	if ((modus == WRITE) || (modus == WRITELISTELEMENT))
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << value;
		if (!writeEndTag(tagName)) return false;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML writeUnsignedInteger
**
** write a unsigned integer value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeUnsignedInteger(const char* tagName, const unsigned int value)
{
	if ((modus == WRITE) || (modus == WRITELISTELEMENT))
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << value;
		if (!writeEndTag(tagName)) return false;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML writeFloat
**
** write a float value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeFloat(const char* tagName, const float value)
{
	if ((modus == WRITE) || (modus == WRITELISTELEMENT))
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << value;
		if (!writeEndTag(tagName)) return false;
		return true;
	}
	else return false;
}


/****************************************************************************
** MiniXML writeString
**
** write a string
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeString(const char* tagName, const char* string)
{
	if ((modus == WRITE) || (modus == WRITELISTELEMENT))
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << string;
		if (!writeEndTag(tagName)) return false;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML writeBoolean
**
** write a boolean value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::writeBoolean(const char* tagName, const bool value)
{
	if ((modus == WRITE) || (modus == WRITELISTELEMENT))
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << value;
		if (!writeEndTag(tagName)) return false;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML readInteger
**
** read a integer value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::readInteger(const char* tagName, int *value)
{
	if ((modus == READ) || (modus == READLISTELEMENT))
	{
		if (!findBeginTag(tagName)) return false;
		inputFile >> *value;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML readUnsignedInteger
**
** read a unsigned integer value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::readUnsignedInteger(const char* tagName, unsigned int *value)
{
	if ((modus == READ) || (modus == READLISTELEMENT))
	{
		if (!findBeginTag(tagName)) return false;
		inputFile >> *value;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML readFloat
**
** read a float value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::readFloat(const char* tagName, float *value)
{
	if ((modus == READ) || (modus == READLISTELEMENT))
	{
		if (!findBeginTag(tagName)) return false;
		inputFile >> *value;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML readString
**
** read a string
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::readString(const char* tagName, char *string, int maxLength)
{
	if ((modus == READ) || (modus == READLISTELEMENT))
	{
		if (!findBeginTag(tagName)) return false;

		char c = inputFile.get();
		int i=0;
		while ((c != '<') && (i<maxLength-1))
		{
			string[i] = c;
			i++;
			c = inputFile.get();
		}
		string[i] = '\0';
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML readBoolean
**
** read a boolean value
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::readBoolean(const char* tagName, bool *value)
{
	if ((modus == READ) || (modus == READLISTELEMENT))
	{
		if (!findBeginTag(tagName)) return false;
		int intValue;
		inputFile >> intValue;
		if (intValue == 0) *value=false;
		else if (intValue == 1) *value=true;
		else return false;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML startWriteList
**
** begin of writing a list (you must call endList, if your are done with
** the list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::startWriteList(const char* tagName)
{
	if (modus == WRITE)
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << std::endl;
		stringCopy(currentListTag,tagName);
		modus = WRITELIST;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML endWriteList
**
** end of writing a list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::endWriteList()
{
	if (modus == WRITELIST)
	{
		if (!writeEndTag(currentListTag)) return false;
		currentListTag[0] = '\0';
		modus = WRITE;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML startWriteListElement
**
** begin writing one element in a list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::startWriteListElement(const char* tagName)
{
	if (modus == WRITELIST)
	{
		if (!writeBeginTag(tagName)) return false;
		outputFile << std::endl;
		stringCopy(currentListElementTag,tagName);
		modus = WRITELISTELEMENT;
		return true;
	}
	else return false;
}

bool MiniXML::startWriteListElement(int id)
{
	char tagName[512];
	sprintf(tagName,"%d",id);
	return startWriteListElement(tagName);
}

/****************************************************************************
** MiniXML endWriteListElement
**
** end of writing one element in a list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::endWriteListElement()
{
	if (modus == WRITELISTELEMENT)
	{
		if (!writeEndTag(currentListElementTag)) return false;
		currentListElementTag[0] = '\0';
		modus = WRITELIST;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML startReadList
**
** begin of reading a list (you must call endReadList, if your are done with
** the list)
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::startReadList(const char* tagName)
{
	if (modus == READ)
	{
		if (!findBeginTag(tagName)) return false;

		currentStartSearch = inputFile.tellg();

		stringCopy(currentListTag,tagName);
		buildEndTag(currentEndTag,tagName);
		
		modus = READLIST;
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML endReadList
**
** end of reading a list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::endReadList()
{
	if (modus == READLIST)
	{
		modus = READ;
		currentEndTag[0] = '\0';
		if (!findEndTag(currentListTag)) return false;

		currentStartSearch = 0;

		currentListTag[0] = '\0';
			
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML startReadListElement
**
** begin reading one element in a list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::startReadListElement(const char* tagName)
{
	if (modus == READLIST)
	{
		if (!findBeginTag(tagName)) return false;

		tempStartSearch = currentStartSearch;
		currentStartSearch = inputFile.tellg();

		stringCopy(currentListElementTag,tagName);
		buildEndTag(currentEndTag,tagName);

		modus = READLISTELEMENT;
		return true;
	}
	else return false;
}

bool MiniXML::startReadListElement(int id)
{
	char tagName[512];
	sprintf(tagName,"%d",id);
	return startReadListElement(tagName);
}

/****************************************************************************
** MiniXML endReadListElement
**
** end of reading one element in a list
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::endReadListElement()
{
	if (modus == READLISTELEMENT)
	{
		modus = READLIST;
		buildEndTag(currentEndTag,currentListTag);
		if (!findEndTag(currentListElementTag)) return false;

		currentStartSearch = tempStartSearch;
		currentListElementTag[0] = '\0';
		return true;
	}
	else return false;
}

/****************************************************************************
** MiniXML stringCopy
**
** copy one string to another
**
** Author: Dirk Plate
****************************************************************************/
bool MiniXML::stringCopy(char* dest, const char* src)
{
	char c = src[0];
	int i=0;
	while (c != '\0')
	{
		dest[i] = c;
		i++;
		c = src[i];
	}
	dest[i] = c;

	return true;
}

/****************************************************************************
** MiniXML stringLength
**
** get the length of a string
**
** Author: Dirk Plate
****************************************************************************/
int MiniXML::stringLength(char* string)
{
	char c = string[0];
	int i=0;
	while (c != '\0') 
	{
		i++;
		c = string[i];
	}

	return i;
}