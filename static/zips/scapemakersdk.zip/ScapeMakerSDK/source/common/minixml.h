/****************************************************************************
** MiniXML
**
** A help class for writing and loading properties and data in a text file
**
** Author: Dirk Plate
****************************************************************************/
#if !defined(MINIXML_H)
#define MINIXML_H
#pragma warning(disable:4786)

#include <fstream>

class MiniXML
{
public:
	enum Modus{READ,WRITE,NOTOPEN,READLIST,WRITELIST,READLISTELEMENT,WRITELISTELEMENT};
	
	MiniXML();
	~MiniXML();

	bool openFile(const char* fileName, Modus modusSet);
	void closeFile();

	//output operations
	bool writeInteger(const char* tagName, const int value);
	bool writeUnsignedInteger(const char* tagName, const unsigned int value);
	bool writeFloat(const char* tagName, const float value);
	bool writeString(const char* tagName, const char* string);
	bool writeBoolean(const char* tagName, const bool value);
	bool startWriteList(const char* tagName);
	bool endWriteList();
	bool startWriteListElement(const char* tagName);
	bool startWriteListElement(int id);
	bool endWriteListElement();

	//input operations
	bool readInteger(const char* tagName, int *value);
	bool readUnsignedInteger(const char* tagName, unsigned int *value);
	bool readFloat(const char* tagName, float *value);
	bool readString(const char* tagName, char *string, int maxLength);
	bool readBoolean(const char* tagName, bool *value);
	bool startReadList(const char* tagName);
	bool endReadList();
	bool startReadListElement(const char* tagName);
	bool startReadListElement(int id);
	bool endReadListElement();

private:
	bool writeBeginTag(const char* tagName);
	bool writeEndTag(const char* tagName);
	bool findBeginTag(const char* tagName);
	bool findEndTag(const char* tagName);
	bool findString(const char* string);
	bool findStringRec(const char* string);
	void buildBeginTag(char *tag, const char* tagName);
	void buildEndTag(char *tag, const char* tagName);
	bool stringCopy(char* dest, const char* src);
	int stringLength(char* string);

	Modus modus;
	std::ifstream inputFile;
	std::ofstream outputFile;

	std::streampos currentStartSearch;
	std::streampos tempStartSearch;

	char currentEndTag[512];

	char currentListTag[512]; 
	char currentListElementTag[512];
};

#endif