#include "camera.h"
#include <stdio.h>
#include "../terrain/terrain.h"
#include "../water/water.h"
#include "../input/input.h"
#include "../common/time.h"
#include "../common/config.h"

Camera *Camera::instance = NULL;

/****************************************************************************
** Camera Constructor
**
** inits the variables and forces the first update
** 
** Author: Matthias Buchetics
****************************************************************************/
Camera::Camera()
{
	Module::Module();
	name = "Camera";

	reset();

	setPosition( 0.0f, 0.0f, 0.0f );
	rotateToWorld( 0.0f, 0.0f, 0.0f);
	changed = TRUE;
	mode = FLY;
	lock = TRUE;
	screenWidth = 640;
	screenHeight = 480;

	//init start cameraposition
	setLookAt(50, 30, 50);
	setPosition(10, 40, 10);

	instance = this;
}

/****************************************************************************
** Camera Destructor
**
** nothing
** 
** Author: Matthias Buchetics
****************************************************************************/
Camera::~Camera()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Camera setAspect
**
** set the aspect ratio for camera
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::setAspect(float aspect)
{
	this->aspect = aspect;
}


/****************************************************************************
** Camera createGeometry
**
** stores the pointer to the device and projection matrix
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Camera::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//get current screen resolution
	D3DVIEWPORT9 viewPort;
	pD3DDevice->GetViewport(&viewPort);
	screenWidth = viewPort.Width;
	screenHeight = viewPort.Height;

	//set field of view to default
	nearClipPlane = 0.1f;
	farClipPlane = 15000.0f;
	setFieldOfView(D3DX_PI/4);

	//no moving at begin
	movePositionParameter.on = false;
	moveLookAtParameter.on = false;

	//init screenshot class
	screenshot.init(pD3DDevice, "./screenshots/");

	//init lens flare
	if (FAILED(hr=lensFlare.createGeometry(pD3DDevice)))
		return hr;

	//force the camera to update all matrices...
	forceUpdate();

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Camera DestroyGeometry
**
** destroy the camera device dependent objects
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Camera::destroyGeometry()
{
	HRESULT hr;

	//delete lens flare
	if (FAILED(hr=lensFlare.destroyGeometry()))
		return hr;

	return Module::destroyGeometry();
}

/****************************************************************************
** Camera Update
**
** calculates the up, right and dir vectors for the view matrix
** everytime the camera changes this function has to be called
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Camera::update()
{	
	HRESULT hr;

	//get input
	processInput();

	//move camera
	makeMovePositionStep();

	//move look at
	makeMoveLookAtStep();

	//only update view matrix and view frustums if something changed
	if(changed)
	{
		//create new view matrix
		D3DXMatrixLookAtLH(&viewMatrix, &position, &lookAt, &up);
		
		//create billboard matrix for one axe
		if (direction.x > SMALL_NUM)
			D3DXMatrixRotationY( &matBillboardOne, -atanf(direction.z/direction.x)+D3DX_PI/2 );
		else if (direction.x < -SMALL_NUM)
			D3DXMatrixRotationY( &matBillboardOne, -atanf(direction.z/direction.x)-D3DX_PI/2 );
		else
		{
			if (direction.z > 0)
				D3DXMatrixRotationY( &matBillboardOne, 0 );
			else
				D3DXMatrixRotationY( &matBillboardOne, D3DX_PI );
		}

		//create billboard matrix for two axe
		D3DXMATRIX mat1, mat2;
		float rotY = -(float)(atan2(direction.z,direction.x)-D3DX_PI/2);
		
		D3DXMatrixRotationY(&mat1, rotY);
				
		if ((rotY >= -D3DX_PI/4) && (rotY < D3DX_PI/4))
			D3DXMatrixRotationX( &mat2, (float)(atan2(direction.z,direction.y)-D3DX_PI/2));
		else if ((rotY >= 3*D3DX_PI/4) && (rotY < 5*D3DX_PI/4))
			D3DXMatrixRotationX( &mat2, -(float)(atan2(direction.z,direction.y)+D3DX_PI/2));
		else if ((rotY >= D3DX_PI/4) && (rotY < 3*D3DX_PI/4))
			D3DXMatrixRotationX( &mat2, -(float)(atan2(-direction.x,direction.y)+D3DX_PI/2)); 
		else 
			D3DXMatrixRotationX( &mat2, (float)(atan2(-direction.x,direction.y)-D3DX_PI/2)); 

		D3DXMatrixMultiply(&mat1, &mat2, &mat1);

		matBillboardTwo = mat1;

		//set engine
		viewFrustum.extractPlanes(&viewMatrix, &projectionMatrix);

		pD3DDevice->SetTransform( D3DTS_VIEW, &viewMatrix );

		//update reflection camera settings
		if (Water::instance->getState() != UNINITIALISED)
		{
			float seaHeight = Water::instance->getSea()->getHeight();
			reflectPosition = position;
			reflectPosition.y = seaHeight - (position.y - seaHeight);
			reflectUp = up;
			reflectUp.y = -up.y;
			reflectLookAt = lookAt;
			reflectLookAt.y = seaHeight - (lookAt.y - seaHeight);
			reflectDirection = direction;
			reflectDirection.y = -direction.y;
			D3DXMatrixLookAtLH(&reflectViewMatrix, &reflectPosition, &reflectLookAt, &reflectUp);
			reflectViewFrustum.extractPlanes(&reflectViewMatrix, &projectionMatrix);
		}

		changed = FALSE;
	}

	//check visibility of sun for lensflare effect
	if (FAILED(hr=lensFlare.update()))
		return hr;

	return Module::update();
}

/****************************************************************************
** Camera ForceUpdate
**
** force a camera update in the next frame
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::forceUpdate()
{
	changed = TRUE;
}

/****************************************************************************
** Camera Render
**
** renders all camera elements
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Camera::render(ModuleRenderType renderType)
{
	HRESULT hr;

	if (FAILED(hr=lensFlare.render()))
		return hr;

	return Module::render(renderType);
}


/****************************************************************************
** Camera translateToCamera
**
** translates the camera in x, y and z direction relativ to camera coordinate
** system
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::translateToCamera( float x, float y, float z )
{
	//save length of lookAt direction vector
	float length = D3DXVec3Length(&(lookAt-position));

	//calculate vector to right
	D3DXVECTOR3 right;
	D3DXVec3Cross(&right,&up,&direction);

	//right/left translation
	position.x += right.x * x;
	position.y += right.y * x;
	position.z += right.z * x;

	//up/down translation
	position.x += up.x * y;
	position.y += up.y * y;
	position.z += up.z * y;

	//forward/backwards translation
	position.x += direction.x * z;
	position.y += direction.y * z;
	position.z += direction.z * z;

	//calculate new lookAt position
	lookAt = position+direction*length;

	adjustPosition();

	changed = TRUE;
}

/****************************************************************************
** Camera translateToWorld
**
** translates the camera in x, y and z direction relative to world coordinate
** system
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::translateToWorld( float x, float y, float z )
{
	//translate position
	position += D3DXVECTOR3(x,y,z);

	//calculate new lookAt position
	lookAt += D3DXVECTOR3(x,y,z);

	adjustPosition();

	changed = TRUE;
}

/****************************************************************************
** Camera rotateToCamera
**
** rotate the camera relative to camera coordinate system
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::rotateToCamera( float rotX, float rotY, float rotZ )
{
	D3DXVECTOR3 newUp = up;
	D3DXVECTOR3 newDirection = direction;
	D3DXVECTOR3 newRight = right;
	D3DXMATRIX transformation;

	//save length of lookAt direction vector
	float length = D3DXVec3Length(&(lookAt-position));

	//around right vector (x)
	D3DXMatrixRotationAxis(&transformation,&right,rotX);
	D3DXVec3TransformCoord(&newUp,&newUp,&transformation);
	D3DXVec3TransformCoord(&newDirection,&newDirection,&transformation);
	D3DXVec3TransformCoord(&newRight,&newRight,&transformation);

	//around up vector (y)
	D3DXMatrixRotationAxis(&transformation,&up,rotY);
	D3DXVec3TransformCoord(&newUp,&newUp,&transformation);
	D3DXVec3TransformCoord(&newDirection,&newDirection,&transformation);
	D3DXVec3TransformCoord(&newRight,&newRight,&transformation);

	//around direction vector (z)
	D3DXMatrixRotationAxis(&transformation,&direction,rotZ);
	D3DXVec3TransformCoord(&newUp,&newUp,&transformation);
	D3DXVec3TransformCoord(&newDirection,&newDirection,&transformation);
	D3DXVec3TransformCoord(&newRight,&newRight,&transformation);

	//set new values	
	up = newUp;
	direction = newDirection;
	right = newRight;

	//calculate new lookAt position
	lookAt = position+direction*length;

	changed = TRUE;
}

/****************************************************************************
** Camera rotateToWorld
**
** rotate the camera relative to world coordinate system
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::rotateToWorld( float rotX, float rotY, float rotZ )
{
	D3DXMATRIX transformation;

	//save length of lookAt direction vector
	float length = D3DXVec3Length(&(lookAt-position));

	//around all world axes
	D3DXMatrixRotationYawPitchRoll(&transformation,rotY,rotX,rotZ);
	D3DXVec3TransformCoord(&up,&up,&transformation);
	D3DXVec3TransformCoord(&direction,&direction,&transformation);
	D3DXVec3TransformCoord(&right,&right,&transformation);

	//calculate new lookAt position
	lookAt = position+direction*length;

	changed = TRUE;
}

/****************************************************************************
** Camera setPosition
**
** sets the camera to a new position (lookAt is not changed)
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::setPosition( float posX, float posY, float posZ )
{
	//set position
	position = D3DXVECTOR3( posX, posY, posZ );

	//calculate new orientation vectors
	updateCameraSystem();

	changed = TRUE;
}

/****************************************************************************
** Camera movePosition
**
** moves a camera to endPosition in duration seconds. 
** Start with startDirection and end with endDirection.
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::movePosition(float startDirectionX, float startDirectionY, float startDirectionZ, 
						  float endPositionX, float endPositionY, float endPositionZ,
						  float endDirectionX, float endDirectionY, float endDirectionZ,
						  float duration)
{
	//save settings in intern structure
	movePositionParameter.on = true;
	movePositionParameter.startPosition = position;
	movePositionParameter.startDirection.x = startDirectionX;
	movePositionParameter.startDirection.y = startDirectionY;
	movePositionParameter.startDirection.z = startDirectionZ;
	movePositionParameter.endPosition.x = endPositionX;
	movePositionParameter.endPosition.y = endPositionY;
	movePositionParameter.endPosition.z = endPositionZ;
	movePositionParameter.endDirection.x = endDirectionX;
	movePositionParameter.endDirection.y = endDirectionY;
	movePositionParameter.endDirection.z = endDirectionZ;
	movePositionParameter.restDuration = duration;
	movePositionParameter.duration = duration;
}

/****************************************************************************
** Camera makeMovePositionStep
**
** make one step for moving camera
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::makeMovePositionStep()
{
	//only if camera moving is on
	if (!movePositionParameter.on)
		return;

	//moving camera uses frame time of engine
	float elapsedTime = Time::instance->getEngineFrameTime();

	//calculate spline between begin and end
	D3DXVECTOR3 newPos;
	D3DXVec3Hermite(&newPos, 
					&movePositionParameter.endPosition, &movePositionParameter.endDirection,
					&movePositionParameter.startPosition, &movePositionParameter.startDirection,
					movePositionParameter.restDuration/movePositionParameter.duration);

	//subtract duration
	movePositionParameter.restDuration -= elapsedTime;
							  
 	//stop moving... no time left
	if (movePositionParameter.restDuration < 0)
		movePositionParameter.on = false;

	//set to new position
	setPosition(newPos.x, newPos.y, newPos.z);
}

/****************************************************************************
** Camera setLookAt
**
** set new lookAt position
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::setLookAt(float lookX, float lookY, float lookZ)
{
	//set new look at
	lookAt = D3DXVECTOR3(lookX, lookY, lookZ);

	//calculate new camera orientation
	updateCameraSystem();

	changed = TRUE;
}

/****************************************************************************
** Camera moveLookAt
**
** moves the lookAt position to endPosition in duration seconds. 
** Start with startDirection and end with endDirection.
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::moveLookAt(float startDirectionX, float startDirectionY, float startDirectionZ, 
						float endPositionX, float endPositionY, float endPositionZ,
						float endDirectionX, float endDirectionY, float endDirectionZ,
						float duration)
{
	//save settings in intern structure
	moveLookAtParameter.on = true;
	moveLookAtParameter.startPosition = lookAt;
	moveLookAtParameter.startDirection.x = startDirectionX;
	moveLookAtParameter.startDirection.y = startDirectionY;
	moveLookAtParameter.startDirection.z = startDirectionZ;
	moveLookAtParameter.endPosition.x = endPositionX;
	moveLookAtParameter.endPosition.y = endPositionY;
	moveLookAtParameter.endPosition.z = endPositionZ;
	moveLookAtParameter.endDirection.x = endDirectionX;
	moveLookAtParameter.endDirection.y = endDirectionY;
	moveLookAtParameter.endDirection.z = endDirectionZ;
	moveLookAtParameter.restDuration = duration;
	moveLookAtParameter.duration = duration;
}

/****************************************************************************
** Camera makeLookAtPositionStep
**
** make one step for moving look at position
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::makeMoveLookAtStep()
{
	//only if camera moving is on
	if (!moveLookAtParameter.on)
		return;

	//moving camera uses frame time of engine
	float elapsedTime = Time::instance->getEngineFrameTime();

	//calculate spline between begin and end
	D3DXVECTOR3 newPos;
	D3DXVec3Hermite(&newPos, 
					&moveLookAtParameter.endPosition, &moveLookAtParameter.endDirection,
					&moveLookAtParameter.startPosition, &moveLookAtParameter.startDirection,
					moveLookAtParameter.restDuration/moveLookAtParameter.duration);

	//subtract duration
	moveLookAtParameter.restDuration -= elapsedTime;
							  
 	//stop moving... no time left
	if (moveLookAtParameter.restDuration < 0)
		moveLookAtParameter.on = false;

	//set to new position
	setLookAt(newPos.x, newPos.y, newPos.z);
}

/****************************************************************************
** Camera Reset
**
** resets the rotation values and vectors
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::reset()
{   
	aspect	  = D3DX_PI/4;
	position  = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	right	  = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
	up		  = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
	direction = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
	lookAt	  = position+direction;

	changed = TRUE;
}

/****************************************************************************
** Camera setLock
**
** lock = false if the camera is free moveable, if it is true, the camera
** can not be moved out of bounds
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::setLock(bool lock)
{
	this->lock = lock;
}

/****************************************************************************
** Camera setMode
**
** fly or walk mode
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::setMode(int mode)
{
	this->mode = mode;

	changed = TRUE;
}

/****************************************************************************
** Camera processInput
**
** process inputs from keyboard and mouse
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::processInput()
{
	//process keyboard input
	Keyboard *pKeyboard = Input::instance->getKeyboard();

	//processing keys uses frame time of engine
	float elapsedTime = Time::instance->getEngineFrameTime();

	//make frame undependend
	float translateSpeed;
	if (mode==WALK)
		translateSpeed = 3.0f * elapsedTime;
	else
		translateSpeed = 10.0f * elapsedTime;
	float rotateSpeed = 1.0f * elapsedTime;

    if (pKeyboard->getKeyState(this,DIK_RIGHT) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(translateSpeed*0.5f, 0.0f,  0.0f);
    if (pKeyboard->getKeyState(this,DIK_LEFT) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(-translateSpeed*0.5f, 0.0f, 0.0f);
    if (pKeyboard->getKeyState(this,DIK_UP) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(0.0f, 0.0f, translateSpeed);
    if (pKeyboard->getKeyState(this,DIK_DOWN) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(0.0f, 0.0f, -translateSpeed);
	if (pKeyboard->getKeyState(this,DIK_W) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(0.0f, 0.0f, translateSpeed);
    if (pKeyboard->getKeyState(this,DIK_S) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(0.0f, 0.0f, -translateSpeed);
	if (pKeyboard->getKeyState(this,DIK_A) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(-translateSpeed*0.5f, 0.0f, 0.0f);
    if (pKeyboard->getKeyState(this,DIK_D) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(translateSpeed*0.5f, 0.0f,  0.0f);
	if (pKeyboard->getKeyState(this,DIK_R) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(0.0f, translateSpeed*0.5f, 0.0f);
    if (pKeyboard->getKeyState(this,DIK_F) == Keyboard::KeyState::HOLDPRESSED)
		translateToCamera(0.0f, -translateSpeed*0.5f, 0.0f);
	if (pKeyboard->getKeyState(this,DIK_E) == Keyboard::KeyState::HOLDPRESSED)
		rotateToWorld(0.0f, rotateSpeed, 0.0f);
    if (pKeyboard->getKeyState(this,DIK_Q) == Keyboard::KeyState::HOLDPRESSED)
		rotateToWorld(0.0, -rotateSpeed, 0.0f);
	if (pKeyboard->getKeyState(this,DIK_G) == Keyboard::KeyState::HOLDPRESSED)
		rotateToCamera(rotateSpeed, 0.0f, 0.0f);
    if (pKeyboard->getKeyState(this,DIK_T) == Keyboard::KeyState::HOLDPRESSED)
		rotateToCamera(-rotateSpeed, 0.0f, 0.0f);
	
	if (pKeyboard->getKeyState(this,DIK_O) == Keyboard::KeyState::NEWPRESSED)
	{
		toggleMode();
	}

	if (pKeyboard->getKeyState(this,DIK_C) == Keyboard::KeyState::NEWPRESSED)
	{
		makeScreenshot();
	}


	//process mouse inputs
	Mouse *pMouse = Input::instance->getMouse();
	
	//look around
	if (pMouse->getButtonState(this, Mouse::Button::LEFT) == Mouse::ButtonState::HOLDPRESSED)
	{
		//rotate up/down relative to camera coordinate system
		rotateToCamera(pMouse->getMovedY(this)/100.0f, 0.0f, 0.0f);

		//rotate left/right relative to world coordinate system
		rotateToWorld(0.0f, pMouse->getMovedX(this)/100.0f, 0.0f);
	}
}

/****************************************************************************
** Camera makeScreenshot
**
** makes a screenshot and stores it on the hard disk
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::makeScreenshotEx(std::string prefix, float aspect)
{
	screenshot.make(prefix,aspect);
}

/****************************************************************************
** Camera makeScreenshot
**
** makes a screenshot and stores it on the hard disk
** 
** Author: Matthias Buchetics
****************************************************************************/
void Camera::makeScreenshot()
{
	screenshot.make(Config::instance->getProjectName()+"_shot");
}

/****************************************************************************
** Camera setFieldOfView
**
** sets a new field of view
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::setFieldOfView(float verticalAngle)
{
	fov = verticalAngle;

	// setup the projection matrix
	D3DXMatrixPerspectiveFovLH(&projectionMatrix,
					fov,
					aspect,
				    nearClipPlane, farClipPlane);
	pD3DDevice->SetTransform(D3DTS_PROJECTION, &projectionMatrix);

	changed = TRUE;
}

/****************************************************************************
** Camera adjustPosition
**
** adjust current position to valid values
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::adjustPosition()
{
	//no lock... no corrections
	if(lock == FALSE)
		return;

	//save length of lookAt direction vector
	float length = D3DXVec3Length(&(lookAt-position));
	
	//correct position
	if (position.x < 5.0f)
		position.x = 5.0f;
	
	if (position.x > Terrain::instance->getWidth()-5.0f)
		position.x = Terrain::instance->getWidth()-5.0f;

	if (position.z < 5.0f)
		position.z = 5.0f;
	
	if (position.z > Terrain::instance->getWidth()-5.0f)
		position.z = Terrain::instance->getWidth()-5.0f;

	float minHeight;
	if (Terrain::instance->getState() == UNINITIALISED)
		minHeight = Water::instance->getHeight(position.x,position.z);
	else if (Water::instance->getState() == UNINITIALISED)
		minHeight = Terrain::instance->getHeightInterpolated(position.x, position.z);
	else if ((Water::instance->getState() == UNINITIALISED) && (Terrain::instance->getState() == UNINITIALISED))
		minHeight = 0.0f;
	else
		minHeight = MAX(Terrain::instance->getHeightInterpolated(position.x, position.z),
						Water::instance->getHeight(position.x,position.z));

	if (mode == WALK)
	{
		position.y = minHeight+1.5f;
	}
	else
	{
		if(position.y < minHeight+0.7f)
			position.y = minHeight+0.7f;
	}
	
	//calculate new lookAt position
	lookAt = position+direction*length;
}

/****************************************************************************
** Camera updateCameraSystem
**
** update camera coordinate system
** 
** Author: Dirk Plate
****************************************************************************/
void Camera::updateCameraSystem()
{
	//sqrt(2)
	const float sqrt2 = 1.414213562f;

	//calculate new orientation vectors
	//calculate new direction vector
	D3DXVec3Normalize(&direction, &(lookAt-position));

	//choose vector with bigger angle to new direction
	float upValue = D3DXVec3Length(&(up+direction));
	if (upValue > sqrt2)
		upValue = sqrt2-(upValue-sqrt2);
	float rightValue = D3DXVec3Length(&(right+direction));
	if (rightValue > sqrt2)
		rightValue = sqrt2-(rightValue-sqrt2);
	
	if (upValue > rightValue)
	{
		//calculate up and right vector with help of old up vector
		D3DXVec3Cross(&right,&up,&direction);
		right.y = 0;
		D3DXVec3Normalize(&right, &right);
		D3DXVec3Cross(&up,&direction,&right);
		up.y = fabs(up.y);
		D3DXVec3Normalize(&up, &up);
		D3DXVec3Cross(&right,&up,&direction);
	}
	else
	{
		//calculate up and right vector with help of old right vector
		D3DXVec3Cross(&up,&direction,&right);
		up.y = fabs(up.y);
		D3DXVec3Normalize(&up, &up);
		D3DXVec3Cross(&right,&up,&direction);
		right.y = 0;
		D3DXVec3Normalize(&right, &right);
		D3DXVec3Cross(&up,&direction,&right);
	}
}

/****************************************************************************
** Camera setGameTimeFactor
**
** implementation of status source (called by status line)
**
** Author: Dirk Plate
****************************************************************************/
std::string Camera::getStatusMessage()
{
	char buffer[256];

	sprintf(buffer, "Position: x:%06.2f, y:%06.2f, z:%06.2f, terrainheight:%06.2f", 
		position.x, position.y, position.z,
		Terrain::instance->getHeightInterpolated(position.x, position.z));

	std::string statusMessage(buffer);

	return statusMessage;
}





























