/****************************************************************************
** Camera
**
** basic camera class
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(H_CAMERA)
#define H_CAMERA
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>

#include "viewfrustum.h"
#include "../hud/statusline.h"
#include "screenshot.h"
#include "lensflare.h"
#include "../module.h"

#define WALK 1
#define FLY  2

class Camera : public StatusSource, public Module
{
public:
	D3DXMATRIX		matBillboardOne;		// billboard transformation matrix for one axe
	D3DXMATRIX		matBillboardTwo;		// billboard transformation matrix for two axe

	Camera();
	~Camera();

	static Camera *instance;				//the instance to the only one camera objects

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT destroyGeometry();
	HRESULT update();
	HRESULT	render(ModuleRenderType renderType);
	void reset();
	void forceUpdate();
	void translateToCamera(float x, float y, float z);
	void translateToWorld(float x, float y, float z);
	void rotateToCamera(float rotX, float rotY, float rotZ);
	void rotateToWorld(float rotX, float rotY, float rotZ);
	void setPosition(float posX, float posY, float posZ);
	void setAspect(float aspect);
	void movePosition(float startDirectionX, float startDirectionY, float startDirectionZ, 
					  float endPositionX, float endPositionY, float endPositionZ,
					  float endDirectionX, float endDirectionY, float endDirectionZ,
					  float duration);
	void setLookAt(float lookX, float lookY, float lookZ);
	void moveLookAt(float startDirectionX, float startDirectionY, float startDirectionZ, 
					float endPositionX, float endPositionY, float endPositionZ,
					float endDirectionX, float endDirectionY, float endDirectionZ,
					float duration);
	void setFieldOfView(float verticalAngle);

	void setLock(bool lock);
	void setMode(int mode);

	bool isLock() { return lock; };
	
	bool isFlyMode() 
	{ 
		if(mode == FLY) return true;
		else return false;	
	};

	bool isWalkMode()
	{ 
		if(mode == WALK) return true;
		else return false;	
	};

	void toggleMode()
	{
		if(isFlyMode())	setMode(WALK);
		else setMode(FLY);
	}

	// makes and stores a screenshot
	void makeScreenshot();
	void makeScreenshotEx(std::string prefix, float aspect);

	D3DXVECTOR3		getPosition() { return position; } 
	ViewFrustum*	getViewFrustum() { return &viewFrustum; }
	D3DXVECTOR3		getDirection() { return direction; } 
	D3DXVECTOR3		getUp() { return up; } 
	D3DXVECTOR3		getRight() { return right; } 
	D3DXMATRIX*		getViewMatrix() { return &viewMatrix; }
	D3DXMATRIX*		getProjectionMatrix() { return &projectionMatrix; }

	D3DXVECTOR3		getReflectPosition() { return reflectPosition; } 
	ViewFrustum*	getReflectViewFrustum() { return &reflectViewFrustum; }
	D3DXVECTOR3		getReflectDirection() { return reflectDirection; } 
	D3DXVECTOR3		getReflectUp() { return reflectUp; } 
	D3DXMATRIX*		getReflectViewMatrix() { return &reflectViewMatrix; }

	float			getFieldOfView() { return fov; }
	float			getAspect() { return aspect; }

	int				getScreenWidth() {return screenWidth;}
	int				getScreenHeight() {return screenHeight;}

	float			getNearClipPlane() {return nearClipPlane;}
	float			getFarClipPlane() {return farClipPlane;}

	//implementation of status source
	virtual std::string getStatusMessage();

private:
	//process inputs for camera;
	void processInput();
	//adjust current position to valid values
	void adjustPosition();
	//make one step for moving camera
	void makeMovePositionStep();
	//make one step for moving look at
	void makeMoveLookAtStep();
	//update camera coordinate system
	void updateCameraSystem();

	//parameter for normal camera view
	//camera orientation values
	D3DXVECTOR3	position;
	D3DXVECTOR3	up;
	D3DXVECTOR3 direction;
	D3DXVECTOR3 right;
	//addition var. for current direction
	D3DXVECTOR3 lookAt;	
	// view frustum extracted from the view matrix
	ViewFrustum	viewFrustum;			
	// the direct3d view matrix
	D3DXMATRIX viewMatrix;	

	//near clip plane distance
	float nearClipPlane;
	float farClipPlane;

	//screen resolution
	int screenWidth;
	int screenHeight;

	//parameter for sea reflected camera view
	//camera orientation values
	D3DXVECTOR3	reflectPosition;
	D3DXVECTOR3	reflectUp;
	D3DXVECTOR3 reflectDirection;
	//addition var. for current direction
	D3DXVECTOR3 reflectLookAt;	
	// view frustum extracted from the view matrix
	ViewFrustum	reflectViewFrustum;			
	// the direct3d view matrix
	D3DXMATRIX reflectViewMatrix;	

	// the direct3d projection matrix
	D3DXMATRIX	projectionMatrix; 
	//the current aspect ratio
	float aspect;
	//the current field of view
	float fov;

	//recalculate view frustum
	bool		changed;
	//lock inside terrain
	bool		lock;
	//walk or fly
	int			mode;
	
	//environment vars
	LPDIRECT3DDEVICE9 pD3DDevice;

	//all parameters for moving camera position or lookAt position
	struct MoveParameters
	{
		//moving in progress
		bool on;
		//start position
		D3DXVECTOR3 startPosition;
		//start direction
		D3DXVECTOR3 startDirection;
		//end position
		D3DXVECTOR3 endPosition;
		//end direction
		D3DXVECTOR3 endDirection;
		//rest duration
		float restDuration;
		//duration
		float duration;
	};
	//moving camera vars
	MoveParameters movePositionParameter;
	//moving lookAt vars
	MoveParameters moveLookAtParameter;

	//the screenshot making class
	Screenshot screenshot;

	//the lens flare of camera
	LensFlare lensFlare;
};

#endif
