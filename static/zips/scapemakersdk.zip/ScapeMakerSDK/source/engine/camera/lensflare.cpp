#include "lensflare.h"
#include "../common/enginehelpers.h"
#include "../logger/logger.h"
#include "../terrain/terrain.h"
#include "camera.h"
#include "../sky/sky.h"
#include "../common/time.h"
#include "../objects/objects.h"
#include "../clouds/clouds.h"
#include "../postprocessing/heightbasedfog.h"

//size of lens flare relative to screen height
#define LENSFLARE_SIZE 0.7f

/****************************************************************************
** LensFlare Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
LensFlare::LensFlare()
{
	pVB = NULL;
	pTexture = NULL;
	pStateBlock = NULL;
	pSavedStateBlock = NULL;
	visibility = 0.0f;
	targetVisibility = 0.0f;
	visible = false;
}

/****************************************************************************
** LensFlare Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
LensFlare::~LensFlare()
{
}

/****************************************************************************
** LensFlare createGeometry
**
** init everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT LensFlare::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//set position and size of lensflare
	maxWidth = LENSFLARE_SIZE*Camera::instance->getScreenHeight();
	maxHeight = maxWidth;
	left = 0;
	top = 0;

	//create vertex buffer (will be filled in next update)
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer(4 * sizeof(LENSFLAREVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_LENSFLAREVERTEX, D3DPOOL_DEFAULT,
										     &pVB, NULL)))
		return hr;

	LOG("Lensflare mesh created OK");

	//load lensflare texture
	std::string texturePath = "./enginefiles/lensflare.png";
	if (FAILED(hr = EngineHelpers::loadTexture( pD3DDevice, texturePath.c_str(), D3DFMT_UNKNOWN, &pTexture)))
	{
		LOG("Loading lensflare texture failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Lensflare texture loaded OK");

	//create state block for lensflare
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetTexture(0, pTexture);
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,			D3DCULL_CW);
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,	TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,			D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,			D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ZENABLE,			FALSE);
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,		FALSE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_COLOROP,D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_COLORARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAOP, D3DTOP_MODULATE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAARG2, D3DTA_TFACTOR);
		pD3DDevice->SetFVF(D3DFVF_LENSFLAREVERTEX);

		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending lensflare state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending lensflare saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("Lensflare state block created OK");

	return S_OK;
}

/****************************************************************************
** LensFlare destroyGeometry
**
** destroy everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	LensFlare::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//release lensflare
	SAFE_RELEASE(pVB);
	SAFE_RELEASE(pTexture);
	SAFE_RELEASE(pSavedStateBlock);
	SAFE_RELEASE(pStateBlock);

	return S_OK;
}

/****************************************************************************
** LensFlare update
**
** update everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	LensFlare::update()
{
	HRESULT hr;
	int sunVerticesCount;
	int i;

	//no sky = no sun... do nothing
	if (Sky::instance->getState() == UNINITIALISED)
		return S_OK;

	//no terrain... do nothing
	if (Terrain::instance->getState() == UNINITIALISED)
		return S_OK;

	//no clouds... do nothing
	if (Clouds::instance->getState() == UNINITIALISED)
		return S_OK;

	//dummy radius
	float radius = 0.0f;

	//get vertices of sun
	const D3DXVECTOR3 *pSunVertices = Sky::instance->getSun()->getVertices(&sunVerticesCount);

	//get view frustum
	ViewFrustum *pViewFrustum = Camera::instance->getViewFrustum();

	//get camera position
	D3DXVECTOR3 cameraPosition = Camera::instance->getPosition();

	//check target visibility of sun
	targetVisibility = 0.0f;
	float vertexVisibility;
	targetMeanSunVertex = D3DXVECTOR3(0.0f,0.0f,0.0f);
	float verticesVisibilityCount = 0.0;
	for (i=0;i<sunVerticesCount;i++)
	{
		vertexVisibility = 1.0f;

		//vertex outside view frustum?
		if (pViewFrustum->cullSphere(&(pSunVertices[i]),&radius) != VF_INSIDE)
			continue;

		//vertex behind terrain?
		if (Terrain::instance->intersectSunRay(pSunVertices[i],cameraPosition,NULL,false) == S_OK)
			continue;

		//vertex behind cloud?
		D3DXVECTOR3 intersections[10];
		int intersectionCount;
		float oneObjectsInvAlpha;
		D3DXVECTOR3 rayDir = pSunVertices[i]-cameraPosition;

		//camera/vertex-ray intersect with a cloud?
		if (Clouds::instance->intersectRay(&cameraPosition,&rayDir,
			&(intersections[0]),&oneObjectsInvAlpha,true))
			vertexVisibility *= oneObjectsInvAlpha;

		//vertex is not really visible
		if (vertexVisibility < SMALL_NUM)
			continue;
	
		//camera/vertex-ray intersect with a object?
		if (Objects::instance->intersectRay(&cameraPosition,&rayDir,10,
			intersections,&intersectionCount,true,&oneObjectsInvAlpha,SMALL_NUM,true))
			vertexVisibility *= oneObjectsInvAlpha;

		//vertex is not really visible
		if (vertexVisibility < SMALL_NUM)
			continue;

		//camera/vertex-ray intersect with fog?
		if (HeightBasedFog::instance->intersectRay(&cameraPosition,&rayDir,
			&oneObjectsInvAlpha,true))
			vertexVisibility *= oneObjectsInvAlpha;

		//vertex is not really visible
		if (vertexVisibility < SMALL_NUM)
			continue;

					
		targetMeanSunVertex += vertexVisibility*pSunVertices[i];
		verticesVisibilityCount += vertexVisibility;
						
		targetVisibility += vertexVisibility*1.0f/sunVerticesCount;
	}

	//obtain intensity of sun
	targetVisibility *= Sky::instance->getSun()->getIntensity();

	if ((targetVisibility < SMALL_NUM) || (verticesVisibilityCount <= 0))
	{
		visible = false;
		visibility = 0.0f;
	}
	else 
	{
		//calculate mean position of blending
		targetMeanSunVertex /= verticesVisibilityCount;

		//calculate current blend position (change slowly to target position)
		if (!visible)
		{
			meanSunVertex = targetMeanSunVertex;
			visibility = targetVisibility / 2.0f;
		}
		else 
		{
			meanSunVertex = meanSunVertex + 
			   (targetMeanSunVertex-meanSunVertex)*4.0f*Time::instance->getEngineFrameTime();
	
			//calculate current visibility (change slowly to target visibility)
			visibility = visibility + (targetVisibility-visibility)*2.0f*Time::instance->getEngineFrameTime();
		}
		visible = true;
	}
	
	//calculate size of lens flare
	width = maxWidth*(0.3f+visibility*0.7f);
	height = width;

	//set alpha of lens flare
	alpha = (visibility-0.2f)*1.0f/0.8f;
	if (alpha < 0.0f) alpha = 0.0f;
	
	//calculate current sun position on screen
	//transform sun position to screen
	D3DXVECTOR3 screenPos;
	D3DXVec3TransformCoord(&screenPos,&meanSunVertex,Camera::instance->getViewMatrix());
	D3DXVec3TransformCoord(&screenPos,&screenPos,Camera::instance->getProjectionMatrix());
	screenPos.x = (screenPos.x + 1.0f)/2.0f * Camera::instance->getScreenWidth();
	screenPos.y = (1.0f-(screenPos.y + 1.0f)/2.0f) * Camera::instance->getScreenHeight();

	//set new position of lens flare
	left = screenPos.x - width/2.0f;
	top = screenPos.y - height/2.0f;

	//calculate new vertices
	LENSFLAREVERTEX* pVertices = NULL;
	if (FAILED(hr=pVB->Lock(0, 4 * sizeof(LENSFLAREVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD)))
	{
		LOG("Locking lens flare vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//set all vertices of lens flare
	for (i=0;i<4;i++)
	{
		pVertices[0].p.x = left;
		pVertices[0].p.y = top;
		pVertices[0].p.z = 1.0f;
		pVertices[0].rhw = 1.0f;
		pVertices[0].u = 0.0f;
		pVertices[0].v = 0.0f;

		pVertices[1].p.x = left;
		pVertices[1].p.y = top+height;
		pVertices[1].p.z = 1.0f;
		pVertices[1].rhw = 1.0f;
		pVertices[1].u = 0.0f;
		pVertices[1].v = 1.0f;

		pVertices[2].p.x = left+width;
		pVertices[2].p.y = top;
		pVertices[2].p.z = 1.0f;
		pVertices[2].rhw = 1.0f;
		pVertices[2].u = 1.0f;
		pVertices[2].v = 0.0f;

		pVertices[3].p.x = left+width;
		pVertices[3].p.y = top+height;
		pVertices[3].p.z = 1.0f;
		pVertices[3].rhw = 1.0f;
		pVertices[3].u = 1.0f;
		pVertices[3].v = 1.0f;
	}

	pVB->Unlock();

	return S_OK;
}

/****************************************************************************
** LensFlare render
**
** renders everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT LensFlare::render()
{
	HRESULT hr;

	if (!visible)
		return S_OK;

	//render lens flare
	//record and set the render states
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	//set vertex stream
	pD3DDevice->SetStreamSource(0, pVB, NULL, sizeof(LENSFLAREVERTEX));
	
	//set alpha
	pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR,D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,alpha));

	//render lens flare
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering lens flare failed", Logger::LOG_CRIT);
		return hr;
	}

	//Restore the states
	pSavedStateBlock->Apply();

	return S_OK;
}
