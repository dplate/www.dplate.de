/****************************************************************************
** LensFlare
**
** manage lens flare
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_LENSFLARE)
#define H_LENSFLARE
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

struct LENSFLAREVERTEX
{
	D3DXVECTOR3 p;
	float rhw;
	float u, v;
};

#define D3DFVF_LENSFLAREVERTEX (D3DFVF_XYZRHW | D3DFVF_TEX1)

class LensFlare
{
public:
	LensFlare();
	~LensFlare();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();
	HRESULT render();
	HRESULT update();

private:
	//Direct3D device
	LPDIRECT3DDEVICE9 pD3DDevice;

	//the mesh of lens flare
	LPDIRECT3DVERTEXBUFFER9 pVB;

	//the lens flare texture
	LPDIRECT3DTEXTURE9 pTexture;

	//own state block
	LPDIRECT3DSTATEBLOCK9 pStateBlock;
	LPDIRECT3DSTATEBLOCK9 pSavedStateBlock;

	//size and position of lens flare
	int width, height, left, top;
	int maxWidth, maxHeight;

	//alpha of lensflare
	float alpha;

	//visible or not
	bool visible;

	//visibility of lens flare (between 0 and 1)
	float visibility;
	float targetVisibility;

	//position of blending in 3D
	D3DXVECTOR3 meanSunVertex;
	D3DXVECTOR3 targetMeanSunVertex;
};

#endif