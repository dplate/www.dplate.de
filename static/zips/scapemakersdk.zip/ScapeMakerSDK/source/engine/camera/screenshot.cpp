#include "screenshot.h"
#include "../common/enginehelpers.h"
#include "../logger/logger.h"
#include "../console/console.h"
#include "ximage.h"

/****************************************************************************
** Screenshot Constructor
**
** inits the variables
** 
** Author: Dirk Plate
****************************************************************************/
Screenshot::Screenshot()
{
	pSurfaceCopy = NULL;
}

/****************************************************************************
** Screenshot Destructor
**
** nothing
** 
** Author: Dirk Plate
****************************************************************************/
Screenshot::~Screenshot()
{
	SAFE_RELEASE(pSurfaceCopy);
}

/****************************************************************************
** Screenshot init
**
** set the d3ddevice
** 
** Author: Dirk Plate / Michael F�tsch
****************************************************************************/
void Screenshot::init(LPDIRECT3DDEVICE9 pD3DDevice, std::string path)
{
	this->pD3DDevice = pD3DDevice;
	this->path = path;

	//retrieve information about device
    LPDIRECT3D9 lpD3D = NULL;   // IDirect3D9 interface that created lpDevice

    // We need to know for which adapter the Direct3D device was created,
    // so that we can query the right adapter's screen dimensions.
    // Therefore, query the device's creation parameters
    D3DDEVICE_CREATION_PARAMETERS dcp;
    dcp.AdapterOrdinal = D3DADAPTER_DEFAULT;
    pD3DDevice->GetCreationParameters(&dcp);

	//init display mode to uncritical values
    displayMode.Width = displayMode.Height = 0;

    // retrieve pointer to IDirect3D interface,
    // which provides the GetAdapterDisplayMode method
    pD3DDevice->GetDirect3D(&lpD3D);
    if (lpD3D)
    {
        // query the screen dimensions of the current adapter
        lpD3D->GetAdapterDisplayMode(dcp.AdapterOrdinal, &displayMode);
        SAFE_RELEASE(lpD3D);
    }

    // create a 32-bit ARGB system-memory surface that is going to receive
    // a copy of the front buffer's contents
	SAFE_RELEASE(pSurfaceCopy);
    pD3DDevice->CreateOffscreenPlainSurface(
        displayMode.Width, displayMode.Height,
        D3DFMT_A8R8G8B8, D3DPOOL_SCRATCH,
        &pSurfaceCopy, NULL);
}

/****************************************************************************
** Screenshot getFileName
**
** find a nice screenshot name
** 
** Author: Dirk Plate / Michael F�tsch
****************************************************************************/
std::string Screenshot::getFilePath(std::string prefix)
{
    // search for first unused filename
    char buffer[MAX_PATH];
    WIN32_FIND_DATA ffd;
    HANDLE h;
    for (int i = 0; i < 1000; i++)
    {
        // prepare search mask for FindFirstFile
        wsprintf(buffer, (path + "/" + prefix + "_%03i.bmp").c_str(), i);
        // check whether this file already exists
        h = FindFirstFile(buffer, &ffd);
        // if the file exists, close the search handle and continue
        if (h != INVALID_HANDLE_VALUE)
        {   FindClose(h); }
        // if the file does not exist, exit from the loop
        else
        {   break; }
    }

    //return the found filename
	return buffer;
}

/****************************************************************************
** Screenshot makeScreenshot
**
** same as below... but with standard aspect
** 
** Author: Dirk Plate / Michael F�tsch
****************************************************************************/
HRESULT Screenshot::make(std::string namePrefix)
{
	return make(namePrefix,float(displayMode.Width)/displayMode.Height);
}


/****************************************************************************
** Screenshot makeScreenshot
**
** copy the surface to file
** 
** Author: Dirk Plate / Michael F�tsch
****************************************************************************/
HRESULT Screenshot::make(std::string namePrefix, float aspect)
{
	HRESULT hr;

	//find a nice filepath
	std::string filePath = getFilePath(namePrefix);

	//have the GetFrontBuffer method copy the contents of the front
    //buffer to our system-memory surface
    if (FAILED(hr=pD3DDevice->GetFrontBufferData(NULL, pSurfaceCopy)))
    {
		LOG("Copying front buffer failed!", Logger::LOG_CRIT);
		
        return hr;
    }

	//get the right size for the image
	int width = aspect*displayMode.Height;
	int height = displayMode.Width/aspect;
	if (width > displayMode.Width) 
		width = displayMode.Width;
	if (height > displayMode.Height) 
		height = displayMode.Height;

	//get the right position of the part
	RECT part;
	part.left = 0;
	part.top = 0;
	if (width < displayMode.Width) 
		part.left =  (displayMode.Width-width)/2;
	if (height < displayMode.Height)
		part.top = (displayMode.Height-height)/2;

	//we need the size as rect coordinate
	part.right = part.left + width;
	part.bottom = part.top + height;

	//lock the surface for reading
    D3DLOCKED_RECT lockedRect;
    if (FAILED(hr=pSurfaceCopy->LockRect(&lockedRect, &part, D3DLOCK_READONLY)))
    {
        LOG("Locking surface failed!", Logger::LOG_CRIT);
		
        return hr;
    }

	//create a new image to hold the data
	CxImage image;

	//copy pixels
	image.CreateFromArray((unsigned char*)lockedRect.pBits,width,height,32,4*displayMode.Width,true);

	//unlock surface
	pSurfaceCopy->UnlockRect();

	//save result
	image.Save(filePath.c_str(),CXIMAGE_FORMAT_BMP);

	//show message in console
	Console::instance->addMessage(std::string("Screenshot '"+filePath+"' saved!"));

	return S_OK;
}




