/****************************************************************************
** Screenshot
**
** screenshot making class
** 
** Author: Dirk Plate / Michael F�tsch
****************************************************************************/

#if !defined(H_SCREENSHOT)
#define H_SCREENSHOT
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <string>

class Screenshot
{
public:
	Screenshot();
	~Screenshot();
	void init(LPDIRECT3DDEVICE9 pD3DDevice, std::string path);
	HRESULT make(std::string namePrefix, float aspect);
	HRESULT make(std::string namePrefix);

private:
	std::string getFilePath(std::string prefix);

	LPDIRECT3DDEVICE9 pD3DDevice;
    D3DDISPLAYMODE displayMode;
	LPDIRECT3DSURFACE9 pSurfaceCopy;  
	std::string path;
};

#endif
