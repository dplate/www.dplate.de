#include "viewfrustum.h"

//-----------------------------------------------------------------------------
// Name: ViewFrustum::extractPlanes()
// Desc: Die 6 Frustum-Ebenen werden erstellt
//-----------------------------------------------------------------------------
void ViewFrustum::extractPlanes(D3DXMATRIX *pMatView, D3DXMATRIX *pMatProj)
{
	float		calc;
	D3DXMATRIX	matViewProj;
	D3DXVECTOR3	normal;

	D3DXMatrixMultiply ( &matViewProj, pMatView, pMatProj );
	
	// Linke Clipping Plane
	frustumPlanes[VF_LEFT].a = -(matViewProj._14 + matViewProj._11);
	frustumPlanes[VF_LEFT].b = -(matViewProj._24 + matViewProj._21);
	frustumPlanes[VF_LEFT].c = -(matViewProj._34 + matViewProj._31);
	frustumPlanes[VF_LEFT].d  = -(matViewProj._44 + matViewProj._41);

	// Rechte Clipping Plane
	frustumPlanes[VF_RIGHT].a = -(matViewProj._14 - matViewProj._11);
	frustumPlanes[VF_RIGHT].b = -(matViewProj._24 - matViewProj._21);
	frustumPlanes[VF_RIGHT].c = -(matViewProj._34 - matViewProj._31);
	frustumPlanes[VF_RIGHT].d  = -(matViewProj._44 - matViewProj._41);

	// Obere Clipping Plane
	frustumPlanes[VF_UP].a = -(matViewProj._14-matViewProj._12);
	frustumPlanes[VF_UP].b = -(matViewProj._24-matViewProj._22);
	frustumPlanes[VF_UP].c = -(matViewProj._34-matViewProj._32);
	frustumPlanes[VF_UP].d  = -(matViewProj._44-matViewProj._42);

	// Untere Clipping Plane
	frustumPlanes[VF_BOTTOM].a = -(matViewProj._14+matViewProj._12);
	frustumPlanes[VF_BOTTOM].b = -(matViewProj._24+matViewProj._22);
	frustumPlanes[VF_BOTTOM].c = -(matViewProj._34+matViewProj._32);
	frustumPlanes[VF_BOTTOM].d  = -(matViewProj._44+matViewProj._42);

	// Nahe Clipping Plane
	frustumPlanes[VF_NEAR].a = -(matViewProj._14+matViewProj._13);
	frustumPlanes[VF_NEAR].b = -(matViewProj._24+matViewProj._23);
	frustumPlanes[VF_NEAR].c = -(matViewProj._34+matViewProj._33);
	frustumPlanes[VF_NEAR].d  = -(matViewProj._44+matViewProj._43);

	// Ferne Clipping Plane
	frustumPlanes[VF_FAR].a = -(matViewProj._14-matViewProj._13);
	frustumPlanes[VF_FAR].b = -(matViewProj._24-matViewProj._23);
	frustumPlanes[VF_FAR].c = -(matViewProj._34-matViewProj._33);
	frustumPlanes[VF_FAR].d  = -(matViewProj._44-matViewProj._43);

	// Normalenvektoren der Ebenen normalisieren
	for (int i = 0; i < 6; i++) 
	{
		normal = D3DXVECTOR3 ( frustumPlanes[i].a, frustumPlanes[i].b, frustumPlanes[i].c );

		calc = 1.0f / sqrtf( D3DXVec3Dot( &normal, &normal ) );

		frustumPlanes[i].a *= calc;
		frustumPlanes[i].b *= calc;
		frustumPlanes[i].c *= calc;
		frustumPlanes[i].d *= calc;
	}
}

//-----------------------------------------------------------------------------
// Name: ViewFrustum::cullAABB()
// Desc: Cullen von Axis Aligned Bounding Boxes
//-----------------------------------------------------------------------------
int ViewFrustum::cullAABB( AABB *pAABB)
{
	D3DXVECTOR3 nearPoint, farPoint;
	D3DXVECTOR3	normal;
	int			clipped=FALSE;
	float		distance;

	for (int i=0; i<6; i++) 
	{
		// Initialisiere nahen Punkt unter der Annahme
		// dass alle Normalen Komponenten <= 0.0f sind
		nearPoint.x = pAABB->vecMax.x;
		nearPoint.y = pAABB->vecMax.y;
		nearPoint.z = pAABB->vecMax.z;

		farPoint.x = pAABB->vecMin.x;
		farPoint.y = pAABB->vecMin.y;
		farPoint.z = pAABB->vecMin.z;

		normal = D3DXVECTOR3 (frustumPlanes[i].a, frustumPlanes[i].b, frustumPlanes[i].c);
		distance = frustumPlanes[i].d;

		// �berpr�fe die Annahme...
		if(normal.x >= 0.0f) 
		{
			nearPoint.x = pAABB->vecMin.x;
			farPoint.x  = pAABB->vecMax.x;
		}

		if( normal.y >= 0.0f ) 
		{
			nearPoint.y = pAABB->vecMin.y;
			farPoint.y  = pAABB->vecMax.y;
		}

		if( normal.z >= 0.0f ) 
		{
			nearPoint.z = pAABB->vecMin.z;
			farPoint.z  = pAABB->vecMax.z;
		}

		// Checke ob der nahe Punkt ausserhalb liegt,
		// dann ist auch die ganze Box ausserhalb
		if ( D3DXVec3Dot( &normal, &nearPoint ) + distance > 0 )
			return VF_OUTSIDE;

		// Checke ob der ferne Punkt ausserhalb liegt
		if (D3DXVec3Dot( &normal, &farPoint ) + distance >= 0 )
			clipped = TRUE;
	} 

	// Sind wir bis hierher gekommen dann ist die Box nicht ganz
	// ausserhalb. Lag der FarPoint aber ausserhalb dann ist die
	// Box nur teilweise im View Frustrum
	if (clipped)
		return VF_CLIPPED;

	// Sonst komplett innerhalb
	return VF_INSIDE;
}

//-----------------------------------------------------------------------------
// Name: ViewFrustum::cullSphere()
// Desc: Cullen von Bounding Spheres
//-----------------------------------------------------------------------------
int ViewFrustum::cullSphere(const D3DXVECTOR3 *pSphereCenter, const float *pSphereRadius)
{
	D3DXVECTOR3	normal;
	float		distance;
	int			i;
	
	// calculate our distances to each of the planes
	for(i=0; i<6; i++) 
	{
		normal = D3DXVECTOR3(frustumPlanes[i].a, frustumPlanes[i].b, frustumPlanes[i].c);
		distance = frustumPlanes[i].d;
		
		// find the distance to this plane
		distance = D3DXVec3Dot(&normal, pSphereCenter) + distance;
				
		// if this distance is < -sphere.radius, we are outside
		if(distance > *pSphereRadius)
			return(VF_OUTSIDE);
			
		// else if the distance is between +- radius, then we intersect
		if((float)fabs(distance) < *pSphereRadius)
			return(VF_CLIPPED);
	}
	
	// otherwise we are fully in view
	return(VF_INSIDE);
}

