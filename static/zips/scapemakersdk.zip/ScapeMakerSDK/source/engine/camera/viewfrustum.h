#if !defined(H_VIEWFRUSTUM)
#define H_VIEWFRUSTUM
#pragma warning(disable:4786)

#include "../common/aabb.h"

// ViewFrustrum Seiten: 
#define VF_LEFT		0 // Linke Clipping Plane
#define VF_RIGHT	1 // Rechte Clipping Plane
#define VF_UP		2 // Obere Clipping Plane
#define VF_BOTTOM	3 // Untere Clipping Plane
#define VF_NEAR		4 // Ferne Clipping Plane
#define VF_FAR		5 // Nahe Clipping Plane

// Culling Ergebnisse:
#define VF_INSIDE  0
#define VF_OUTSIDE 1
#define VF_CLIPPED 2

class ViewFrustum
{
public:
	void extractPlanes(D3DXMATRIX *pMatView, D3DXMATRIX *pMatProj);
	D3DXPLANE *getPlanes() {return frustumPlanes;}
	int  cullAABB(AABB *pAABB);
	int  cullSphere(const D3DXVECTOR3 *pSphereCenter, const float *pSphereRadius);

private:
	D3DXPLANE	frustumPlanes[6];

};

#endif