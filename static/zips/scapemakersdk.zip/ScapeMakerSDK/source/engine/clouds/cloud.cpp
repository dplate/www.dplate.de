#include "cloud.h"

#include "../logger/logger.h"
#include "../common/enginehelpers.h"
#include "../common/submeshes.h"
#include "../sky/sky.h"
#include "../common/config.h"

/****************************************************************************
** Cloud Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Cloud::Cloud()
{
	cloudPiecesFullMarker = 0;
	cloudPieces = NULL;
	cloudPiecesSize = 0;
	cloudPiecesBlockCount = 0;

	pMesh = NULL;
	pBoundingBox = NULL;

	newCloudPieceCounter = 0.0f;

	visible = -1;
}

Cloud::~Cloud()
{
}

/****************************************************************************
** Cloud CreateGeometry
**
** initializes the cloud
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Cloud::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
							  LPD3DXMESH pMesh, 
							  D3DMATERIAL9 *pMaterial, LPDIRECT3DTEXTURE9 pTexture,
							  D3DXVECTOR3 *pStartPosition, 
							  D3DXVECTOR2 *pMoveDirection, float lifeTime,
							  int height, int length, int width)
{
	// store the vars local
	this->pD3DDevice = pD3DDevice;
	this->pMesh = pMesh;
	this->pMaterial = pMaterial;
	this->pTexture = pTexture;
	this->moveDirection = *pMoveDirection;
	this->lifeTime = lifeTime;

	alphaTexture = true;
	
	cloudPiecesMoveDirection.x = moveDirection.x*0.2f;
	cloudPiecesMoveDirection.y = 0.0f;
	cloudPiecesMoveDirection.z = moveDirection.y*0.2f;
	cloudPiecesMoveSpeed = D3DXVec2Length(&moveDirection)*0.8f;
	this->length = length;	
	this->width = width;
	this->height = height;
	dead = false;
	cloudComplete = false;

	position = *pStartPosition;

	newCloudPieceMark = 400.0f/(width*width*height);
	newCloudPieceCounter = 0.0f;

	//calculate the edges of the cloud
	//find the extrems of the cloud piece mesh
	MeshTool *meshTool = NULL;
	meshTool = new MeshTool(pMesh);
	cloudPieceRadius = 0.0f;
	for (int j=0; j<meshTool->dwNumVertices; j++)
	{
		float distance = D3DXVec3Length(&meshTool->pVertices[j].p);
		if (distance > cloudPieceRadius)
			cloudPieceRadius = distance;
	}
	SAFE_DELETE(meshTool);

	//set the edges
	D3DXVECTOR3			edges[8];		//the edges of the cloud
	edges[0] = D3DXVECTOR3(0.0f-cloudPieceRadius,  0.0f-cloudPieceRadius,  0.0f-cloudPieceRadius);
	edges[1] = D3DXVECTOR3(length+cloudPieceRadius,0.0f-cloudPieceRadius,  0.0f-cloudPieceRadius);
	edges[2] = D3DXVECTOR3(0.0f-cloudPieceRadius,  height+cloudPieceRadius,0.0f-cloudPieceRadius);
	edges[3] = D3DXVECTOR3(0.0f-cloudPieceRadius,  0.0f-cloudPieceRadius,  width+cloudPieceRadius);
	edges[4] = D3DXVECTOR3(length+cloudPieceRadius,height+cloudPieceRadius,0.0f-cloudPieceRadius);
	edges[5] = D3DXVECTOR3(0.0f-cloudPieceRadius,  height+cloudPieceRadius,width+cloudPieceRadius);
	edges[6] = D3DXVECTOR3(length+cloudPieceRadius,0.0f-cloudPieceRadius,  width+cloudPieceRadius);
	edges[7] = D3DXVECTOR3(length+cloudPieceRadius,height+cloudPieceRadius,width+cloudPieceRadius);

	//move edges to right position
	D3DXMATRIX cloudMatrix,mat2;
	D3DXMatrixRotationY(&cloudMatrix,1.5f*D3DX_PI+(float)atan2(moveDirection.x,moveDirection.y));
	D3DXMatrixTranslation(&mat2,
		position.x,
		position.y,
		position.z);
	D3DXMatrixMultiply(&cloudMatrix, &cloudMatrix, &mat2);

	//transform edges of cloud
	for (int i=0;i<8;i++)
		D3DXVec3TransformCoord(&edges[i],&edges[i],&cloudMatrix);

	//create first boundingbox
	pBoundingBox = new AABB(edges,8);

	return S_OK;
}

/****************************************************************************
** Cloud DestroyGeometry
**
** destroy the cloud, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Cloud::destroyGeometry()
{
	int j;

	//delete bounding box
	SAFE_DELETE(pBoundingBox);

	//delete position relevant data
	for (j=0;j<cloudPiecesSize;j++)
	{
		//delete dynamic pointers
		SAFE_DELETE(cloudPieces[j]->subMesh.pAlphaBlend);
		SAFE_DELETE(cloudPieces[j]->subMesh.pAlphaValue);
		SAFE_DELETE(cloudPieces[j]->subMesh.pColorValue);
		SAFE_DELETE(cloudPieces[j]->subMesh.pTransformation);
		SAFE_DELETE(cloudPieces[j]->subMesh.pCenter);
			
		SAFE_DELETE(cloudPieces[j]);
	}

	SAFE_DELETE_ARRAY(cloudPieces);
	cloudPiecesFullMarker = 0;
	cloudPiecesSize = 0;
	cloudPiecesBlockCount = 0;

	return S_OK;
}


/****************************************************************************
** Cloud Update
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Cloud::update(float elapsedTime, D3DXMATRIX *projViewMatrixSet)
{
	projViewMatrix = *projViewMatrixSet;

	//check lifetime of cloud
	lifeTime -= elapsedTime;

	//calculate move difference of cloud
	D3DXVECTOR3 moveDiff(moveDirection.x*elapsedTime,0.0f,moveDirection.y*elapsedTime);

	//move cloud
	position += moveDiff;

	//move aabb
	pBoundingBox->move(&moveDiff);

	//calc. visibility
	int visibility = Camera::instance->getViewFrustum()->cullAABB(pBoundingBox);

	//also visibility for reflection?
	if (Config::instance->isSubMeshesReflection())
	{
		int reflectionVisibility = Camera::instance->getReflectViewFrustum()->cullAABB(pBoundingBox);

		//combine both results
		if (visibility != reflectionVisibility) 
			visibility = VF_CLIPPED;
	}

	//clouds behind distance fog are invisible
	if (visibility != VF_OUTSIDE)
	{
		float minDistance;
		float maxDistance;
		pBoundingBox->getMinDistance(Camera::instance->getPosition(),&minDistance);
		pBoundingBox->getMaxDistance(Camera::instance->getPosition(),&maxDistance);
		float realFogDistanceEnd = Sky::instance->getDustEnd()+FOG_ADDDISTANCE;
		if (minDistance > realFogDistanceEnd)
			visibility = VF_OUTSIDE;
		else if (maxDistance > realFogDistanceEnd)
			visibility = VF_CLIPPED;
	}
	
	//cloud visible or not?
	if (visibility == VF_OUTSIDE)
	{
		if (visible != 0)
		{
			//make submeshes invisible
			for (int j=0;j<cloudPiecesFullMarker;j++)
				SubMeshes::instance->makeInvisible(cloudPieces[j]->subMeshIndex);
			visible = 0;
		}
	}
	else
	{
		if (visible != 1)
		{
			//make submeshes visible
			for (int j=0;j<cloudPiecesFullMarker;j++)
				SubMeshes::instance->makeVisible(cloudPieces[j]->subMeshIndex);
			visible = 1;
		}
	}

	//cloud dead or alive?
	if (((cloudPiecesFullMarker <= 0) || (visible != 1)) && (lifeTime <= 0.0f)) 
		dead = true;

	if ((visible == 0) && cloudComplete)
	{
		//move cloud pieces exact with cloud
		for (int j=0;j<cloudPiecesFullMarker;j++)
			cloudPieces[j]->positionAbs += moveDiff;
		return S_OK;
	}

	//get transformation matrix for full billboard
	billBoardTwoMatrix = Camera::instance->matBillboardTwo;
	
	//calculate properties for all cloud pieces
	for (int j=0;j<cloudPiecesFullMarker;j++)
	{
		//get new position
		cloudPieces[j]->positionAbs += cloudPiecesMoveDirection*elapsedTime;
		cloudPieces[j]->moveRange -= cloudPiecesMoveSpeed*elapsedTime;
		cloudPieces[j]->movedRange += cloudPiecesMoveSpeed*elapsedTime;

		//if move range reached -> delete piece
		if (cloudPieces[j]->moveRange < 0.0f)
		{
			if (cloudPieces[j]->movedRange >= length*0.75f)
				cloudComplete = true;
			removeCloudPiece(j);
			continue;
		}

		float minToBorder = MIN(cloudPieces[j]->moveRange,cloudPieces[j]->movedRange);
		
		//calculate alpha value
		float alpha = minToBorder/2.0f;
		if (alpha < 1.0f)
			*(cloudPieces[j]->subMesh.pAlphaValue) = alpha;
		else *(cloudPieces[j]->subMesh.pAlphaValue) = 1.0f;

		//calculate size
		float scaling = minToBorder/2.0f;
		if (scaling < 1.0f)
			cloudPieces[j]->scaling = scaling*(1.0f-CLOUDPIECEMINSCALING)+CLOUDPIECEMINSCALING;
		else cloudPieces[j]->scaling = 1.0f;

		//calculate new transformation matrices
		calculateTransformationMatrices(j);
	}

	//create new cloud pieces
	if (lifeTime > 0.0f)
	{
		newCloudPieceCounter += elapsedTime*cloudPiecesMoveSpeed;
		while (newCloudPieceCounter > newCloudPieceMark)
		{
			addCloudPiece();
			newCloudPieceCounter -= newCloudPieceMark;
		}
	}

	return S_OK;
}

/****************************************************************************
** Cloud addPosition
**
** Add a further position to this cloud (one more cloud piece will be rendered).
**
** Author: Dirk Plate
****************************************************************************/
int Cloud::addCloudPiece(D3DXVECTOR3 *pos)
{
	int index;

	//find a free position
	index = cloudPiecesFullMarker;

	//do we need to resize the array?
	if (index == cloudPiecesSize)
	{
		int newCloudPiecesSize = CLOUDPIECESBLOCKSIZE * (cloudPiecesBlockCount+1);
		CloudPieceStruct **tmp = new CloudPieceStruct*[newCloudPiecesSize];
		for (int i=0;i<cloudPiecesSize;i++)
			tmp[i] = cloudPieces[i];
		for (int j=cloudPiecesSize;j<newCloudPiecesSize;j++)
			tmp[j] = new CloudPieceStruct;
		SAFE_DELETE_ARRAY(cloudPieces);
		cloudPieces = tmp;

		cloudPiecesSize = newCloudPiecesSize;
		cloudPiecesBlockCount++;
	}
	cloudPiecesFullMarker++;

	cloudPieces[index]->scaling = CLOUDPIECEMINSCALING;

	//set cloud piece relevant pointers in submesh structur
	cloudPieces[index]->subMesh.pAlphaBlend = new bool(true);
	cloudPieces[index]->subMesh.pAlphaValue = new float(0.0f);
	cloudPieces[index]->subMesh.pColorValue = new D3DCOLOR(0xffffffff);
	cloudPieces[index]->subMesh.pTransformation = new D3DXMATRIX;
	cloudPieces[index]->subMesh.pCenter = new D3DXVECTOR3(0.0,0.0,0.0);
	
	//set additional pointers in submesh object
	cloudPieces[index]->subMesh.setD3DDevice(pD3DDevice);
	cloudPieces[index]->subMesh.pMesh = pMesh;
	cloudPieces[index]->subMesh.pMaterial = pMaterial;
	cloudPieces[index]->subMesh.pTexture = pTexture;
	cloudPieces[index]->subMesh.pAlphaTexture = &alphaTexture;
	cloudPieces[index]->subMesh.alpha = true;	
	cloudPieces[index]->subMesh.setSubMeshID(0);
	
	//if position through parameter -> take it
	D3DXVECTOR3 positionRel;
	if (pos != NULL)
		positionRel = *pos;
	//else find a new random position
	else
	{
		//find the y-position
		float randomY = ((float)rand())/((float)RAND_MAX);
		positionRel.y = (1.0f-cosf(randomY*D3DX_PI/2.0f))*height;

		//find the x-position
		float randomX = ((float)rand())/((float)RAND_MAX);
		positionRel.x = length*0.75f+(1.0f-cosf(randomX*D3DX_PI/2.0f))*length*0.25f;

		//find the z-position
		float randomZ = ((float)rand())/((float)RAND_MAX);
		positionRel.z = width/2.0f+(1.0f-cosf(randomZ*D3DX_PI/2.0f)*width/2.0f);
		if (rand()%2 == 0) positionRel.z = width-positionRel.z;
	}

	//the lifetime (move range)
	cloudPieces[index]->moveRange = (positionRel.x-length/2.0f)*2.0f;
	cloudPieces[index]->movedRange = 0.0f;

	//set the light color of the cloud piece
	float lightFactor = sqrtf(positionRel.y/height);
	*(cloudPieces[index]->subMesh.pColorValue) = Sky::instance->getAmbientColor()*(1.0f-lightFactor)+
												 Sky::instance->getDiffuseColor()*lightFactor;
	
	//calculate the first abs-position of the cloudpiece
	D3DXMATRIX	mat1,mat2;

	//calculate transformation matrix of the whole cloud
	D3DXMATRIX cloudMatrix;
	D3DXMatrixRotationY(&cloudMatrix,1.5f*D3DX_PI+(float)atan2(moveDirection.x,moveDirection.y));
	
	//rotate the position relative to cloud position
	D3DXVECTOR3 rotatedRelPosition;
	D3DXVec3TransformCoord(&rotatedRelPosition,&positionRel,&cloudMatrix);
	
	//calculate the position of the cloud piece
	cloudPieces[index]->positionAbs = rotatedRelPosition+position;

	//visibility of whole cloud unclear now
	visible = -1;

	//calculate transformation matrix
	calculateTransformationMatrices(index);

	//add to submesh list and save index
	cloudPieces[index]->subMeshIndex = SubMeshes::instance->add(cloudPieces[index]->subMesh);

	return index;
}

/****************************************************************************
** Cloud removePosition
**
** mark a position of a cloud piece so it can be overwritten
**
** Author: Dirk Plate
****************************************************************************/
void Cloud::removeCloudPiece(int cloudPieceIndex)
{
	//remove cloudpiece submesh from submeshes
	SubMeshes::instance->remove(cloudPieces[cloudPieceIndex]->subMeshIndex);

	//delete dynamic pointers
	SAFE_DELETE(cloudPieces[cloudPieceIndex]->subMesh.pAlphaBlend);
	SAFE_DELETE(cloudPieces[cloudPieceIndex]->subMesh.pAlphaValue);
	SAFE_DELETE(cloudPieces[cloudPieceIndex]->subMesh.pColorValue);
	SAFE_DELETE(cloudPieces[cloudPieceIndex]->subMesh.pTransformation);
	SAFE_DELETE(cloudPieces[cloudPieceIndex]->subMesh.pCenter);

	//swap the last cloudpiece to this index
	CloudPieceStruct *temp = cloudPieces[cloudPieceIndex];
	cloudPieces[cloudPieceIndex] = cloudPieces[cloudPiecesFullMarker-1];
	cloudPieces[cloudPiecesFullMarker-1] = temp;
	cloudPiecesFullMarker--;
}

/****************************************************************************
** Cloud calculateTransformationMatrices
**
** calculate transformation matrix for all cloud pieces
**
** Author: Dirk Plate
****************************************************************************/
void Cloud::calculateTransformationMatrices(int cloudPieceIndex)
{
	D3DXMATRIX	mat1,mat2;
	
	//scale cloud piece to right size
	D3DXMatrixScaling(&mat1,
		cloudPieces[cloudPieceIndex]->scaling,
		cloudPieces[cloudPieceIndex]->scaling,
		cloudPieces[cloudPieceIndex]->scaling);

	//rotate piece to camera
	D3DXMatrixMultiply( &mat1, &billBoardTwoMatrix, &mat1 );

	//add translation to matrix
	D3DXMatrixTranslation(&mat2,
		cloudPieces[cloudPieceIndex]->positionAbs.x,
		cloudPieces[cloudPieceIndex]->positionAbs.y,
		cloudPieces[cloudPieceIndex]->positionAbs.z);
	D3DXMatrixMultiply(&mat1, &mat1, &mat2);

	*(cloudPieces[cloudPieceIndex]->subMesh.pTransformation) = mat1;
}

/****************************************************************************
** Cloud intersectRay
**
** Determine the intersection between a ray and a cloud
**
** rayPos					Start of the ray
** rayDir					Direction (and length) of the ray
** intersection				The found intersection
** intersectionCount		The number of intersections found
** invAlpha					The alpha value at intersection
** onlySegment				Find only intersections between rayPos and rayPos+rayDir
**
** Author: Dirk Plate
****************************************************************************/

bool Cloud::intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		D3DXVECTOR3 *pIntersection, float *pInvAlpha, bool onlySegment)
{
	//check collision with bounding box
	if (!pBoundingBox->intersectRay(pRayPos,pRayDir,onlySegment))
		return false;

	//check collision with all cloud pieces
	for (int i=0;i<cloudPiecesFullMarker;i++)
	{
		//calculate distance between ray and middle of cloud piece
		float distance = EngineHelpers::rayDistance(cloudPieces[i]->positionAbs, *pRayPos, *pRayDir);
		
		if (distance > cloudPieceRadius)
			return false;

		//collision with cloud piece... add alpha value
		*pInvAlpha *= 1.0f-(*(cloudPieces[i]->subMesh.pAlphaValue));

		//enough?
		if (*pInvAlpha < SMALL_NUM)
			return true;
	}

	return true;
}