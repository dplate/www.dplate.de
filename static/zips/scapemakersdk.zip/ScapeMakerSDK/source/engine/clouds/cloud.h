/****************************************************************************
** Cloud
**
** cloud rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(CLOUD_H)
#define CLOUD_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include <math.h>
#include <vector>
#include <time.h>
#include <list>

#include "../common/enginehelpers.h"
#include "../common/dxutil.h"
#include "../common/aabb.h"	
#include "../common/submesh.h"	

#define CLOUDPIECESBLOCKSIZE 100
#define CLOUDPIECEMINSCALING 0.8f

class Cloud
{
public:
	Cloud();
	~Cloud();

	HRESULT update(float elapsedTime, D3DXMATRIX *projViewMatrixSet);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
						   LPD3DXMESH pMesh, 
						   D3DMATERIAL9 *pMaterial, LPDIRECT3DTEXTURE9 pTexture,
						   D3DXVECTOR3 *pStartPosition, 
						   D3DXVECTOR2 *pMoveDirection,  float lifeTime,
						   int height, int length, int width);
	HRESULT	destroyGeometry();

	bool isDead() {return dead;};

	bool intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		D3DXVECTOR3 *pIntersection, float *pInvAlpha, bool onlySegment);

	int polyRendered;		//some statistic data

private:
	int addCloudPiece(D3DXVECTOR3 *pos = NULL);
	void removeCloudPiece(int cloudPiecesIndex);
	void calculateTransformationMatrices(int cloudPieceIndex);

	LPD3DXMESH pMesh;							//the mesh of the cloud
	D3DMATERIAL9 *pMaterial;					//material of cloud
	LPDIRECT3DTEXTURE9 pTexture;				//texture of cloud

	AABB *pBoundingBox;					//bounding box around the cloud
	int visible;						//render or not

	//one position of the cloud pieces
	struct CloudPieceStruct
	{
		float scaling;					//the size
		D3DXVECTOR3	positionAbs;		//the position (absolute to terrain)
		float moveRange;				//how far will the piece move relative to the cloud
		float movedRange;				//how far is the piece moved relative to the cloud
		
		SubMesh subMesh;				//settings for the used submesh
		std::list<SubMesh>::iterator subMeshIndex;	//iterator to submesh in submeshlist
	};

	LPDIRECT3DDEVICE9 pD3DDevice;
	bool alphaTexture;					//the cloud texture have alpha values

	D3DXMATRIX billBoardTwoMatrix;
	CloudPieceStruct **cloudPieces;		//all positions of the cloud pieces
	int cloudPiecesFullMarker;			//a marker at the end of the last full position
	int cloudPiecesSize;				//the size of the positions
	int cloudPiecesBlockCount;			//how many blocks are reserved

	float newCloudPieceCounter;			//is this value greater newCloudMark -> create new cloud piece and set value back
	float newCloudPieceMark;			//the mark, when to create a new cloud

	//properties of the clouds
	D3DXVECTOR3 position;				//the position of the cloud
	D3DXVECTOR2 moveDirection;			//direction of the cloud
	D3DXVECTOR3 cloudPiecesMoveDirection; //the move direction of the cloud pieces
	float cloudPiecesMoveSpeed;			//the speed of the cloud pieces relative to cloud
	float cloudPieceRadius;				//the size of one cloud piece for intersection testing
	float length;						//the length of the cloud
	float width;						//the width of the cloud
	float height;						//the height of the cloud
	float lifeTime;						//how long to life
	bool dead;							//this cloud is no more :(
	bool cloudComplete;					//the cloud is complete built up

	D3DXMATRIX projViewMatrix;			//the current proj*view matrix
};

#endif









































