#include "cloudlayer.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../sky/sky.h"
#include "../terrain/terrain.h"
#include "../common/config.h"

#include <tchar.h>

/****************************************************************************
** CloudLayer Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
CloudLayer::CloudLayer()
{
	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	D3DXMatrixIdentity(&textureMatrix);
}

CloudLayer::~CloudLayer()
{
}

/****************************************************************************
** CloudLayer CreateGeometry
**
** create and initializes the cloud layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT CloudLayer::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
			int frameCount, int mutationSpeed, int movingSpeed, int repetition,float height)
{
	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;
	this->mutationSpeed = mutationSpeed;
	this->movingSpeed = movingSpeed;
	this->height = height;

	//get width of terrain
	float terrainWidth = Terrain::instance->getWidth();

	//create lightmap mesh
	meshVB = NULL;
	CLOUDLAYERVERTEX vertices[4];
	VOID* pVertices;
	int	size = sizeof(vertices);
	DWORD color = Sky::instance->getDiffuseColor();
	overSize = 2048.0f;
	width = terrainWidth+2*overSize;
	lowestX = 0.0f-overSize;
	lowestZ = 0.0f-overSize;
	
	transformFactor = repetition/width;
	
  	vertices[0].position = D3DXVECTOR3(lowestX,height,lowestZ);
	vertices[0].diffuse = color;
	vertices[0].texture1 = D3DXVECTOR2(0.0f,0.0f);

	vertices[1].position = D3DXVECTOR3(lowestX+width,height,lowestZ);
	vertices[1].diffuse = color;
	vertices[1].texture1 = D3DXVECTOR2(repetition,0.0f);

	vertices[2].position = D3DXVECTOR3(lowestX,height,lowestZ+width);
	vertices[2].diffuse = color;
	vertices[2].texture1 = D3DXVECTOR2(0.0f,repetition);

	vertices[3].position = D3DXVECTOR3(lowestX+width,height,lowestZ+width);
	vertices[3].diffuse = color;
	vertices[3].texture1 = D3DXVECTOR2(repetition,repetition);

	//create vertex buffer
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(4*sizeof(CLOUDLAYERVERTEX), D3DUSAGE_WRITEONLY, D3DFVF_CLOUDLAYERVERTEX, D3DPOOL_MANAGED, &meshVB, NULL)))
	{
		LOG("Creating vertex buffer for cloud layer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	if (FAILED(hr=meshVB->Lock(0,4*sizeof(CLOUDLAYERVERTEX),(VOID**)&pVertices,0)))
	{
		LOG("Locking vertex buffer for cloud layer failed", Logger::LOG_CRIT);
		return hr;
	}

	//copy vertices
	memcpy(pVertices, vertices, 4*sizeof(CLOUDLAYERVERTEX));

	//release memory
	meshVB->Unlock();

	//choose right textur format
	D3DFORMAT textureFormat;
	if (!Config::instance->isCloudShading()) textureFormat = D3DFMT_A8;
	else textureFormat = D3DFMT_UNKNOWN;
	
	//load all cloud layer texture
	for (int currentFrame=0; currentFrame<frameCount; currentFrame++)
	{
		char cloudlayerPath[512];
		sprintf(cloudlayerPath, "%s\\cloudlayer\\frame_%d.png", 
			Config::instance->getEnginePath().c_str(), currentFrame);

		Frame newFrame;
		
		if (FAILED(hr = EngineHelpers::loadTexture( pD3DDevice, cloudlayerPath, textureFormat, &newFrame.pTexture)))
		{
			LOG("Loading cloud layer frame texture failed", Logger::LOG_CRIT);
			return hr;
		}

		//load same texture for intersection testing
		CxImage loadedIntersectionImage(cloudlayerPath,CXIMAGE_FORMAT_PNG);

		//use only the alpha channel
		newFrame.pIntersectionImage = new CxImage();
		loadedIntersectionImage.AlphaSplit(newFrame.pIntersectionImage);
	
		//use a lower resolution
		newFrame.pIntersectionImage->Resample(INTERSECTIONIMAGESIZE,INTERSECTIONIMAGESIZE,0);

		//add frame to frame list
		frames.insert(frames.end(), newFrame);
	}

	//set first first and second texture
	firstFrame = frames.begin();
	secondFrame = firstFrame;
	secondFrame++;
	if (secondFrame == frames.end())
		secondFrame = firstFrame;

	currentFrameTime = 0.0f;

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState( D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState( D3DRS_ALPHAREF,        0x01 );
		pD3DDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		
		if (!Config::instance->isCloudShading())
			pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE );
		else 
			pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
					
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);
		//pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetTextureStageState( 1, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
	
		if (!Config::instance->isCloudShading())
		{
			pD3DDevice->SetTextureStageState( 1, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
			pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_DIFFUSE );
		}
		else
		{
			pD3DDevice->SetTextureStageState( 1, D3DTSS_COLOROP, D3DTOP_LERP );
			pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
			pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT);
			pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG0, D3DTA_TFACTOR );
		}

		pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,D3DTOP_LERP);
		//pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		//pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG2, D3DTA_CURRENT);
		pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG0, D3DTA_TFACTOR );
		//pD3DDevice->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		//pD3DDevice->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		//pD3DDevice->SetSamplerState(1, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetTextureStageState( 1, D3DTSS_TEXCOORDINDEX, 0 );

		//set fixed vertex pipeline
		pD3DDevice->SetFVF(D3DFVF_CLOUDLAYERVERTEX);

		pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

		// Enable fog blending.
		pD3DDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
		pD3DDevice->SetRenderState(D3DRS_FOGCOLOR, Sky::instance->getDustColor());
		pD3DDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_EXP2);
		float density = 0.005f;
		pD3DDevice->SetRenderState(D3DRS_FOGDENSITY, *(DWORD *)(&density));


		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** CloudLayer DestroyGeometry
**
** destroy the cloud layer, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT CloudLayer::destroyGeometry()
{
	//release mesh
	SAFE_RELEASE(meshVB);

	//release all texture
	std::list<Frame>::iterator currentFrame = frames.begin();
	while (currentFrame != frames.end())
	{
		SAFE_RELEASE(currentFrame->pTexture);
		SAFE_DELETE(currentFrame->pIntersectionImage);
		currentFrame++;
	}
	frames.clear();

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);

	return S_OK;
}

/****************************************************************************
** CloudLayer Render
**
** renders cloud layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	CloudLayer::render()
{
	HRESULT hr;

	//record and set the render states
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	//set textures
	pD3DDevice->SetTexture(0,firstFrame->pTexture);
	pD3DDevice->SetTexture(1,secondFrame->pTexture);

	//set factor for blending
	DWORD textureFactor = (unsigned char)(currentFrameTime*255.0f);
	//textureFactor = textureFactor << 24;
	textureFactor |= (textureFactor << 8);
	textureFactor |= (textureFactor << 16);
	textureFactor |= (textureFactor << 24);
	pD3DDevice->SetRenderState( D3DRS_TEXTUREFACTOR, *(DWORD *)(&textureFactor) );

	//set texture transformation
	pD3DDevice->SetTransform( D3DTS_TEXTURE0, &textureMatrix );
	pD3DDevice->SetTransform( D3DTS_TEXTURE1, &textureMatrix );

	//render cloud layer
	pD3DDevice->SetStreamSource(0, meshVB, NULL, sizeof(CLOUDLAYERVERTEX));
	if (FAILED(hr=pD3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 )))
	{
		LOG("Rendering cloud layer failed", Logger::LOG_CRIT);
		return hr;
	}

	//reset texture transformation
	D3DXMATRIX identityMatrix;
	D3DXMatrixIdentity(&identityMatrix);
	pD3DDevice->SetTransform( D3DTS_TEXTURE0, &identityMatrix );
	pD3DDevice->SetTransform( D3DTS_TEXTURE1, &identityMatrix );

	//restore state block
	pSavedStateBlock->Apply();

	return S_OK;
}

/****************************************************************************
** CloudLayer Update
**
** Animate and move cloud layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT CloudLayer::update(float elapsedTime)
{
	//calculate texture transformation matrix
	textureMatrix._31 -= elapsedTime*movingSpeed*0.0001f;
	textureMatrix._32 -= elapsedTime*movingSpeed*0.0001f;

	//calculate mutation frame
	currentFrameTime += elapsedTime*frames.size()*mutationSpeed*0.001f;

	//one frame completed?
	if (currentFrameTime >= 1.0f)
	{
		currentFrameTime -= int(currentFrameTime);

		//switch textures
		firstFrame++;
		if (firstFrame == frames.end())
			firstFrame = frames.begin();
		secondFrame++;
		if (secondFrame == frames.end())
			secondFrame = frames.begin();
	}

	return S_OK;
}

/****************************************************************************
** CloudLayer intersectRay
**
** Determine the intersection between a ray and cloud layer
**
** rayPos					Start of the ray
** rayDir					Direction (and length) of the ray
** intersection				The found intersection
** intersectionCount		The number of intersections found
** invAlpha					The alpha value at intersection
** onlySegment				Find only intersections between rayPos and rayPos+rayDir
**
** Author: Dirk Plate
****************************************************************************/

bool CloudLayer::intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		D3DXVECTOR3 *pIntersection, float *pInvAlpha, bool onlySegment)
{
	//find position in height of cloud layer
	pIntersection->y = height;
	if (!EngineHelpers::getXZCoordinateOfRay(pRayPos,pRayDir, 
		&(pIntersection->x), height,&(pIntersection->z)))
		return false;

	//checking segment?
	if (onlySegment)
	{
		D3DXVECTOR3 intersectDir = (*pIntersection)-(*pRayPos);
		float factor = (pRayDir->y)/(intersectDir.y);
		if (factor < 1.0f)
			return false;
	}

	//calculate texture coordinate for this position
	//move to extremes
	float u = pIntersection->x-lowestX;
	float v = pIntersection->z-lowestZ;
	//scale it
	u *= transformFactor;
	v *= transformFactor;
	//add moving of clouds
	u += textureMatrix._31;
	v += textureMatrix._32;
	//correct negative value
	if (u<0.0f) u += -int(u)+1.0f;
	if (v<0.0f) v += -int(v)+1.0f;
	//multiply it to texture size
	u *= INTERSECTIONIMAGESIZE;
	v *= INTERSECTIONIMAGESIZE;
	//'modulo' texture size;
	int uInt = int(u)%INTERSECTIONIMAGESIZE;
	int vInt = int(v)%INTERSECTIONIMAGESIZE;
	//switch vertical
	vInt = INTERSECTIONIMAGESIZE-vInt;

	//get alpha value at this position
	float firstAlpha = float(firstFrame->pIntersectionImage->GetPixelGray(uInt,vInt))/256.0f;
	float secondAlpha = float(secondFrame->pIntersectionImage->GetPixelGray(uInt,vInt))/256.0f;

	//calculate combined alpha
	*pInvAlpha *= (1.0f-currentFrameTime)*(1.0f-firstAlpha) + currentFrameTime*(1.0f-secondAlpha);

	return true;
}








































