/****************************************************************************
** CloudLayer
**
** cloud layer rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(CLOUDLAYER_H)
#define CLOUDLAYER_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include <list>
#include <ximage.h>

#define D3DFVF_CLOUDLAYERVERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1)
#define INTERSECTIONIMAGESIZE 128

class CloudLayer
{
public:
	CloudLayer();
	~CloudLayer();

	HRESULT update(float elapsedTime);
	HRESULT render();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
						   int frameCount, int mutationSpeed, int movingSpeed, int repetition, float height);
	HRESULT	destroyGeometry();

	bool intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		D3DXVECTOR3 *pIntersection, float *pInvAlpha, bool onlySegment);

private:
	struct CLOUDLAYERVERTEX
	{
		D3DXVECTOR3 position;
		DWORD		diffuse;
		D3DXVECTOR2 texture1;
	};

	LPDIRECT3DDEVICE9	pD3DDevice;

	int mutationSpeed;
	int movingSpeed;

	//data for real cloud layer mesh
	LPDIRECT3DVERTEXBUFFER9 meshVB;			//the mesh of the cloud layer
	LPDIRECT3DSTATEBLOCK9 pStateBlock;		//used state block for rendering cloud layer
	LPDIRECT3DSTATEBLOCK9 pSavedStateBlock; //saved old state block for rendering cloud layer

	//struct for one cloud layer texture
	struct Frame
	{
		LPDIRECT3DTEXTURE9 pTexture;		//the cloud layer textures
		CxImage* pIntersectionImage;		//data for intersection testing
		
	};
	std::list<Frame> frames;				//list with all frames

	//iterators for first and second displayed texture
	std::list<Frame>::iterator firstFrame, secondFrame;
	
	//height of cloud layer
	float height;
	//width of cloud layer
	float width;
	//size over boarders of terrain
	float overSize;
	//extremes of cloud layer
	float lowestX, lowestZ;
	//transform factor between world coordinate and texture coordinate
	float transformFactor;

	//time in current frame between 0 and 1
	float currentFrameTime;
	//texture transformation matrix
	D3DXMATRIX textureMatrix;
};

#endif