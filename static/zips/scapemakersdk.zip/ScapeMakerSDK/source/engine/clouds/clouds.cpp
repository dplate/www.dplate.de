#include "clouds.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../../common/minixml.h"
#include "../terrain/terrain.h"	
#include "../common/time.h"
#include "../common/config.h"

Clouds *Clouds::instance = NULL;

/****************************************************************************
** Clouds Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
Clouds::Clouds()
{
	Module::Module();
	name = "Clouds";

	instance = this;
}

Clouds::~Clouds()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Clouds CreateGeometry
**
** create and initializes the clouds
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Clouds::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	mesh = NULL;
	materials = NULL;
	materialCount = 0;

	//init random generator
	srand((unsigned)time(NULL));

	//load cloud piece mesh
	LPD3DXBUFFER pD3DXMtrlBuffer;
	LPD3DXMESH rawMesh;

    // Load the mesh from the specified file
    if(hr=(D3DXLoadMeshFromX("./enginefiles/cloud.x", D3DXMESH_SYSTEMMEM,
                             pD3DDevice, NULL,
                             &pD3DXMtrlBuffer, NULL, &materialCount,
                             &rawMesh)) != D3D_OK)
    {
        LOG("Loading cloud mesh from x-file failed", Logger::LOG_CRIT);
		return hr;
    }

	//optimize mesh by sorting attributes (materials).
	if(hr=(rawMesh->Optimize( D3DXMESHOPT_ATTRSORT, NULL, NULL, NULL, NULL, &mesh)) != D3D_OK)
	{
		LOG("Optimizing mesh failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(rawMesh);

    // We need to extract the material properties and texture names from the pD3DXMtrlBuffer
    D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
    materials = new D3DMATERIAL9[materialCount];
    textures  = new LPDIRECT3DTEXTURE9[materialCount];

    for( DWORD i=0; i<materialCount; i++ )
    {
        // Copy the material
        materials[i] = d3dxMaterials[i].MatD3D;

        // Set the ambient color to high value
      	materials[i].Ambient.r = 1.0f;
		materials[i].Ambient.g = 1.0f;
		materials[i].Ambient.b = 1.0f;
		materials[i].Diffuse.r = 1.0f;
		materials[i].Diffuse.g = 1.0f;
		materials[i].Diffuse.b = 1.0f;

        // Create the texture
		char texturePath[MAX_PATH];
		sprintf(texturePath, "./enginefiles/%s", d3dxMaterials[i].pTextureFilename);

		if (FAILED(hr = EngineHelpers::loadTexture( pD3DDevice, texturePath, D3DFMT_UNKNOWN, &textures[i])))
		{
			LOG("Loading cumulus cloud texture failed", Logger::LOG_CRIT);
			return hr;
		}

    }

    // Done with the material buffer
    pD3DXMtrlBuffer->Release();

	LOG("Cumulus cloud mesh loaded OK");
	
	//load the properties of clouds from file
	int cumulusDensity = 20;
	cumulusSpeed = 20;
	cumulusHeight = 8;
	cumulusLength = 30;
	cumulusWidth = 10;
	int cirrusFrames = 1;
	int cirrusMutationSpeed = 0;
	int cirrusMovingSpeed = 0;
	int cirrusRepetition = 1;
	int cirrusHeightInMeter = 5000;
	string sunPropertiesPath = Config::instance->getEnginePath()+"/clouds.txt";
	MiniXML xmlFile;
	if (xmlFile.openFile(sunPropertiesPath.c_str(),MiniXML::READ))
	{
		int value;
		if (xmlFile.readInteger("cumulusDensity",&value))
			cumulusDensity = value;
		if (xmlFile.readInteger("cumulusSpeed",&value))
			cumulusSpeed = value;
		if (xmlFile.readInteger("cumulusHeight",&value))
			cumulusHeight = value;
		if (xmlFile.readInteger("cumulusLength",&value))
			cumulusLength = value;
		if (xmlFile.readInteger("cumulusWidth",&value))
			cumulusWidth = value;
		if (xmlFile.readInteger("cirrusFrames",&value))
			cirrusFrames = value;
		if (xmlFile.readInteger("cirrusMutationSpeed",&value))
			cirrusMutationSpeed = value;
		if (xmlFile.readInteger("cirrusMovingSpeed",&value))
			cirrusMovingSpeed = value;
		if (xmlFile.readInteger("cirrusRepetition",&value))
			cirrusRepetition = value;
		if (xmlFile.readInteger("cirrusHeight",&value))
			cirrusHeightInMeter = value;
		xmlFile.closeFile();
	}

	//convert density to count
	int cloudsCount = ((Terrain::instance->getWidth()*Terrain::instance->getWidth())/(256*256))*MAXCLOUDSPERSMALLTERRAIN;
	cloudsCount = (float)cloudsCount*(float)cumulusDensity/100.0f;

	//convert cirrus height
	float cirrusHeight = Terrain::instance->transformHeightInMetersToEngineCoor(cirrusHeightInMeter,true);
	float highestHeight = Terrain::instance->getHighestHeight();
	if (cirrusHeight < highestHeight)
		cirrusHeight = highestHeight;

	LOG("Properties loaded OK");

	//create all terrain clouds
	allClouds.resize(cloudsCount);
	for (int j=0;j<allClouds.size();j++)
		addCloud(j);

	LOG("Cumulus clouds created OK");

	//create cloud layer
	if (FAILED(hr=cloudLayer.createGeometry(pD3DDevice, 
				cirrusFrames, cirrusMutationSpeed, cirrusMovingSpeed, cirrusRepetition, cirrusHeight)))
	{
		LOG("Creating cirrus cloud layer failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Cirrus cloud layer created OK");

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Clouds DestroyGeometry
**
** destroy the clouds, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Clouds::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//go through all clouds
	for (int i=0;i<allClouds.size();i++)
	{
		((Cloud*)allClouds[i])->destroyGeometry();
		SAFE_DELETE(allClouds[i]);
	}
	//clear list
	allClouds.clear();

	//release mesh
	SAFE_RELEASE(mesh);

	//release textures
	for (int j=0;j<materialCount;j++)
		SAFE_RELEASE(textures[j]);

	//delete dynamic lists
	if (materialCount > 0)
	{
		SAFE_DELETE_ARRAY(materials);
		SAFE_DELETE_ARRAY(textures);
	}

	//destroy cloud layer
	cloudLayer.destroyGeometry();

	return Module::destroyGeometry();
}

/****************************************************************************
** Clouds Render
**
** renders cloud layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Clouds::render(ModuleRenderType renderType)
{
	HRESULT hr;

	//render only cloud layer (small clouds are rendered with SubMeshes)
	if (FAILED(hr=cloudLayer.render()))
	{
		LOG("Rendering cirrus cloud layer failed", Logger::LOG_CRIT);
		return hr;
	}

	return Module::render(renderType);
}


/****************************************************************************
** Clouds Update
**
** Animate, create and delete clouds
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Clouds::update()
{
	HRESULT hr;

	//clouds using game frame time (controlable by user)
	float elapsedTime = Time::instance->getGameFrameTime();

	//update proj*view matrix
	D3DXMATRIX matView, matProj, matWorld, matTemp;

	pD3DDevice->GetTransform(D3DTS_VIEW, &matView);
	pD3DDevice->GetTransform(D3DTS_PROJECTION, &matProj);
 	matTemp = matView * matProj;
	
	//update all clouds
	for (int i=0;i<allClouds.size();i++)
	{
		(Cloud*)allClouds[i]->update(elapsedTime,&matTemp);
		
		//if cloud is dead -> create new cloud
		if ((Cloud*)allClouds[i]->isDead())
		{
			if (FAILED(hr=(((Cloud*)allClouds[i])->destroyGeometry())))
			{
				LOG("Destroying cloud geometry failed", Logger::LOG_CRIT);
				return hr;
			}
			SAFE_DELETE(allClouds[i]);
			addCloud(i);
		}
	}

	//update cloud layer
	if (FAILED(hr=cloudLayer.update(elapsedTime)))
	{
		LOG("Updating cloud layer failed", Logger::LOG_CRIT);
		return hr;
	}

	return Module::update();
}

/****************************************************************************
** Clouds addCloud
**
** Add a new cloud
**
** Author: Dirk Plate
****************************************************************************/
void Clouds::addCloud(int index)
{
	//get a random position
	//retrieve radius of sky
	float maxRadius = Terrain::instance->getWidth()*2.0f;

	//get a random radius
	float radius = ((float)rand())/((float)RAND_MAX)*maxRadius;
	//get a random angle
	float angle = ((float)rand())/((float)RAND_MAX)*2.0f*D3DX_PI;

	//calculate x and z position
	D3DXVECTOR3 position;
	position.x = cosf(angle)*radius+Terrain::instance->getWidth()/2.0f;
	position.z = sinf(angle)*radius+Terrain::instance->getWidth()/2.0f;
	position.y = Terrain::instance->getHighestHeight()+15.0f;

	//get a random lifetime
	float lifeTime = 100.0f+rand()%100;
	
	allClouds[index] = new Cloud();
	float tempValue=(float)cumulusSpeed*0.03f;
	(Cloud*)allClouds[index]->createGeometry(pD3DDevice,mesh,
		&materials[0],textures[0],
		&position,&D3DXVECTOR2(tempValue,tempValue),lifeTime, cumulusHeight, cumulusLength, cumulusWidth);
}

/****************************************************************************
** Clouds intersectRay
**
** Determine the intersection between a ray and the clouds
**
** rayPos					Start of the ray
** rayDir					Direction (and length) of the ray
** intersection				The found intersection
** intersectionCount		The number of intersections found
** invAlpha					The alpha value at intersection
** onlySegment				Find only intersections between rayPos and rayPos+rayDir
**
** Author: Dirk Plate
****************************************************************************/
bool Clouds::intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		D3DXVECTOR3 *pIntersection, float *pInvAlpha, bool onlySegment)
{
	//init alpha to invisible
	*pInvAlpha = 1.0f;

	//check intersection with cloud layer
	bool oneIntersection = cloudLayer.intersectRay(pRayPos,pRayDir,pIntersection,pInvAlpha,onlySegment);

	//intersection?
	if (oneIntersection)
	{
		//enough?
		if (*pInvAlpha < SMALL_NUM)
			return oneIntersection;
	}

	//check intersection with cumulus clouds
	for (int i=0;i<allClouds.size();i++)
	{
		oneIntersection = (Cloud*)allClouds[i]->intersectRay(pRayPos,pRayDir,pIntersection,pInvAlpha,onlySegment) || oneIntersection;

		//intersection?
		if (oneIntersection)
		{
			//enough?
			if (*pInvAlpha < SMALL_NUM)
				return oneIntersection;
		}
	}	

	return oneIntersection;
}














