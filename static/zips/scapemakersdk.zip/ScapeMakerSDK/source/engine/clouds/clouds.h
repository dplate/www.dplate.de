/****************************************************************************
** Clouds
**
** clouds management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(CLOUDS_H)
#define CLOUDS_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <vector>

#include "../camera/viewfrustum.h"
#include "cloud.h"
#include "cloudlayer.h"
#include "../module.h"

#define MAXCLOUDSPERSMALLTERRAIN 300

class Clouds : public Module
{
public:
	Clouds();
	~Clouds();

	HRESULT update();
	HRESULT render(ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();

	bool intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		D3DXVECTOR3 *pIntersection, float *pInvAlpha, bool onlySegment);


	static Clouds *instance;				//the instance to the only one clouds objects

private:
	void addCloud(int index);

	LPDIRECT3DDEVICE9	pD3DDevice;
	CloudLayer			cloudLayer;		//the cloud layer
	std::vector<Cloud*> allClouds;		//the small clouds
	int					cumulusSpeed;	//the speed of all cumulus clouds
	int					cumulusHeight;
	int					cumulusLength;
	int					cumulusWidth;

	//the mesh of a cloud piece
	LPD3DXMESH			mesh;			//the mesh of the cloudpiece
	DWORD				materialCount;	//number of materials
	D3DMATERIAL9*       materials;		//all materials
	LPDIRECT3DTEXTURE9* textures;		//the textures
};

#endif