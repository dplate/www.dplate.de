#include "AABB.h"

/*	//already defines in enginehelpers.h
#define MAX(a,b) ((a > b) ? a:b)
#define MIN(a,b) ((a  <b) ? a:b)
*/

/****************************************************************************
** AABB Constructor
**
** initialise default aabb
** 
** Author: Dirk Plate
****************************************************************************/
AABB::AABB()
{
	vecMax = D3DXVECTOR3(0.0f,0.0f,0.0f);
	vecMin = D3DXVECTOR3(0.0f,0.0f,0.0f);
	vecMiddle = D3DXVECTOR3(0.0f,0.0f,0.0f);
}

/****************************************************************************
** AABB operator+
**
** adds a bounding box to this one
** 
** Author: Dirk Plate
****************************************************************************/
AABB AABB::operator+(const AABB &param)
{
	AABB newAABB;

	//check extends
	newAABB.vecMax.x = MAX(vecMax.x,param.vecMax.x);
	newAABB.vecMax.y = MAX(vecMax.y,param.vecMax.y);
	newAABB.vecMax.z = MAX(vecMax.z,param.vecMax.z);

	newAABB.vecMin.x = MIN(vecMin.x,param.vecMin.x);
	newAABB.vecMin.y = MIN(vecMin.y,param.vecMin.y);
	newAABB.vecMin.z = MIN(vecMin.z,param.vecMin.z);

	// calculate center
	newAABB.vecMiddle = (newAABB.vecMax+newAABB.vecMin)/2.0f;

	return newAABB;
}

/****************************************************************************
** AABB Update
**
** updates the bounding box with the vertex list of the object
** 
** Author: Matthias Buchetics
****************************************************************************/
void AABB::update( D3DXVECTOR3 *pVertexlist, long nrVertices )
{
	float maxX, maxY, maxZ, minX, minY, minZ;

	maxX = minX = pVertexlist[0].x;
	maxY = minY = pVertexlist[0].y;
	maxZ = minZ = pVertexlist[0].z;
 
	for( long i = 0; i < nrVertices; i++ )
	{
		// Nach neuem Maximalwert suchen
		maxX = MAX(maxX, pVertexlist[i].x);
		maxY = MAX(maxY, pVertexlist[i].y);
		maxZ = MAX(maxZ, pVertexlist[i].z);

		// Nach neuem Minimalwert suchen
		minX = MIN(minX, pVertexlist[i].x);
		minY = MIN(minY, pVertexlist[i].y);
		minZ = MIN(minZ, pVertexlist[i].z);
	} 

	// Ausdehnung der Box speichern
	vecMax = D3DXVECTOR3( maxX, maxY, maxZ );
	vecMin = D3DXVECTOR3( minX, minY, minZ );

	// Mittelpunkt berechnen
	vecMiddle = D3DXVECTOR3((maxX + minX)/2, (maxY + minY)/2, (maxZ + minZ)/2);
}

/****************************************************************************
** AABB move
**
** move the aabb
** 
** Author: Dirk Plate
****************************************************************************/
void AABB::move(D3DXVECTOR3 *moveDiff)
{
	vecMin += *moveDiff;
	vecMax += *moveDiff;
	vecMiddle += *moveDiff;
}

/****************************************************************************
** AABB getMinDistances
**
** calculate the minimum distance to the aabb from a point
**
**      ---------
**    / 6/ 7/ 8/
**   / 3/ 4/ 5/
**  / 0/ 1/ 2/
** ---------
** 
**      ---------
**    /15/16/17/
**   /12/13/14/
**  / 9/10/11/
** ---------
**
**      ---------
**    /24/25/26/
**   /21/22/23/
**  /18/19/20/
** ---------
**
** Area no. 13 is the aabb.
**
** Author: Dirk Plate
****************************************************************************/

void AABB::getMinDistance(D3DXVECTOR3 &point, float *minDistance)
{
	//top plane
	if (point.y >= vecMax.y)
	{
		//first row
		if (point.z <= vecMin.z)
		{
			//case 0
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMax.y,vecMin.z)-point));
			//case 2
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMax.y,vecMin.z)-point));
			//case 1
			else 
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMax.y,vecMin.z)-D3DXVECTOR2(point.y,point.z)));
		}
		//third row
		else if (point.z >= vecMax.z)
		{
			//case 6
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMax.y,vecMax.z)-point));
			//case 8
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMax.y,vecMax.z)-point));
			//case 7
			else 
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMax.y,vecMax.z)-D3DXVECTOR2(point.y,point.z)));
		}
		//second row
		else 
		{
			//case 3
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMin.x,vecMax.y)-D3DXVECTOR2(point.x,point.y)));
			//case 5
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMax.x,vecMax.y)-D3DXVECTOR2(point.x,point.y)));
			//case 4
			else 
				*minDistance = (float)fabs(point.y-vecMax.y);
		}
	}
	
	//bottom plane
	else if (point.y <= vecMin.y)
	{
		//first row
		if (point.z <= vecMin.z)
		{
			//case 18
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMin.y,vecMin.z)-point));
			//case 20
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMin.y,vecMin.z)-point));
			//case 19
			else 
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMin.y,vecMin.z)-D3DXVECTOR2(point.y,point.z)));
		}
		//third row
		else if (point.z >= vecMax.z)
		{
			//case 24
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMin.y,vecMax.z)-point));
			//case 26
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMin.y,vecMax.z)-point));
			//case 25
			else 
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMin.y,vecMax.z)-D3DXVECTOR2(point.y,point.z)));
		}
		//second row
		else 
		{
			//case 3
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMin.x,vecMin.y)-D3DXVECTOR2(point.x,point.y)));
			//case 5
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMax.x,vecMin.y)-D3DXVECTOR2(point.x,point.y)));
			//case 4
			else 
				*minDistance = (float)fabs(point.y-vecMin.y);
		}
	}

	//middle plane
	else
	{
		//first row
		if (point.z <= vecMin.z)
		{
			//case 9
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMin.x,vecMin.z)-D3DXVECTOR2(point.x,point.z)));
			//case 11
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMax.x,vecMin.z)-D3DXVECTOR2(point.x,point.z)));
			//case 10
			else 
				*minDistance = (float)fabs(point.z-vecMin.z);
		}
		//third row
		else if (point.z >= vecMax.z)
		{
			//case 15
			if (point.x <= vecMin.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMin.x,vecMax.z)-D3DXVECTOR2(point.x,point.z)));
			//case 17
			else if (point.x >= vecMax.x)
				*minDistance = D3DXVec2Length(&(D3DXVECTOR2(vecMax.x,vecMax.z)-D3DXVECTOR2(point.x,point.z)));
			//case 16
			else 
				*minDistance = (float)fabs(point.z-vecMax.z);
		}
		//second row
		else 
		{
			//case 12
			if (point.x <= vecMin.x)
				*minDistance = (float)fabs(point.x-vecMin.x);
			//case 14
			else if (point.x >= vecMax.x)
				*minDistance = (float)fabs(point.x-vecMax.x);
			//case 13	(point is in the aabb)
			else 
			{
				*minDistance = 0;
				/*//get distance to all planes of aabb
				float inDistances[6];
				inDistances[0] = (float)fabs(point.x-vecMin.x);
				inDistances[1] = (float)fabs(point.x-vecMax.x);
				inDistances[2] = (float)fabs(point.y-vecMin.y);
				inDistances[3] = (float)fabs(point.y-vecMax.y);
				inDistances[4] = (float)fabs(point.z-vecMin.z);
				inDistances[5] = (float)fabs(point.z-vecMax.z);
				//choose minimal distance
				*minDistance = BIG_NUM;
				for (int i=0;i<6;i++)
					if (inDistances[i] < *minDistance)
						*minDistance = inDistances[i];*/
			}

		}
	}
}

/****************************************************************************
** AABB getMaxDistances
**
** calculate the maximum distance to the aabb from a point
**
**     ------   
**   / 2/ 3/
**  / 0/ 1/ 
** ------
** 
**     ------   
**   / 6/ 7/
**  / 4/ 5/ 
** ------
**
** Author: Dirk Plate
****************************************************************************/

void AABB::getMaxDistance(D3DXVECTOR3 &point, float *maxDistance)
{
	//top plane
	if (point.y >= vecMiddle.y)
	{
		//first row
		if (point.z <= vecMiddle.z)
		{
			//case 0
			if (point.x <= vecMiddle.x)
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMin.y,vecMax.z)-point));
			//case 1
			else
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMin.y,vecMax.z)-point));
		}
		//second row
		else
		{
			//case 2
			if (point.x <= vecMiddle.x)
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMin.y,vecMin.z)-point));
			//case 3
			else
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMin.y,vecMin.z)-point));
		}
	}
	//bottom plane
	else
	{
		//first row
		if (point.z <= vecMiddle.z)
		{
			//case 4
			if (point.x <= vecMiddle.x)
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMax.y,vecMax.z)-point));
			//case 5
			else
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMax.y,vecMax.z)-point));
		}
		//second row
		else
		{
			//case 6
			if (point.x <= vecMiddle.x)
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMax.x,vecMax.y,vecMin.z)-point));
			//case 7
			else
				*maxDistance = D3DXVec3Length(&(D3DXVECTOR3(vecMin.x,vecMax.y,vecMin.z)-point));
		}
	}
}


//! Integer representation of a floating-point value.
typedef unsigned int udword;
#define IR(x)	((udword&)x)

/****************************************************************************
** AABB intersectRay
**
** intersect a ray with the aabb
**
** Author: Dirk Plate
****************************************************************************/

bool AABB::intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, bool onlySegment)
{
	bool inside = true;
	D3DXVECTOR3 minB = vecMin;
	D3DXVECTOR3 maxB = vecMax;
	D3DXVECTOR3 maxT;
	D3DXVECTOR3 coord;
	maxT.x=maxT.y=maxT.z=-1.0f;

	// Find candidate planes.
	for(udword i=0;i<3;i++)
	{
		if((*rayPos)[i] < minB[i])
		{
			coord[i]	= minB[i];
			inside		= false;

			// Calculate T distances to candidate planes
			if(IR((*rayDir)[i])) maxT[i] = (minB[i] - (*rayPos)[i]) / (*rayDir)[i];
		}
		else if((*rayPos)[i] > maxB[i])
		{
			coord[i]	= maxB[i];
			inside		= false;

			// Calculate T distances to candidate planes
			if(IR((*rayDir)[i]))	maxT[i] = (maxB[i] - (*rayPos)[i]) / (*rayDir)[i];
		}
	}

	// Ray origin inside bounding box
	if(inside)
	{
		coord = *rayPos;
		return true;
	}

	// Get largest of the maxT's for final choice of intersection
	udword whichPlane = 0;
	if(maxT[1] > maxT[whichPlane])	whichPlane = 1;
	if(maxT[2] > maxT[whichPlane])	whichPlane = 2;

	// Check final candidate actually inside box
	if(IR(maxT[whichPlane])&0x80000000) return false;

	for(i=0;i<3;i++)
	{
		if(i!=whichPlane)
		{
			coord[i] = (*rayPos)[i] + maxT[whichPlane] * (*rayDir)[i];

			if(coord[i] < minB[i] - SMALL_NUM || coord[i] > maxB[i] + SMALL_NUM) return false;
		}
	}

	if (onlySegment)
	{
		D3DXVECTOR3 rayPosCoord = coord-*rayPos;
		float rayDirLength = D3DXVec3LengthSq(rayDir);
		float rayPosCoordLength = D3DXVec3LengthSq(&rayPosCoord);
		float sumLength = D3DXVec3LengthSq(&(*rayDir+rayPosCoord));

		if (sumLength < rayDirLength) return false;
		if (rayPosCoordLength > rayDirLength) return false;
	}

	return true;	// ray hits box
}

/****************************************************************************
** AABB includePoint
**
** is the point in the aabb?
**
** Author: Dirk Plate
****************************************************************************/
bool AABB::includePoint(D3DXVECTOR3 &point)
{
	if ((point.x >= vecMin.x) && (point.x <= vecMax.x) &&
		(point.y >= vecMin.y) && (point.y <= vecMax.y) &&
		(point.z >= vecMin.z) && (point.z <= vecMax.z))
		return true;
	else return false;
}