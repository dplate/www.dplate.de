#if !defined(H_AABB)
#define H_AABB
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include "enginehelpers.h"

class AABB // Axis Aligned Bounding Box
{
public:
	AABB();

	// creates the bounding box
	AABB(D3DXVECTOR3 *pVertexlist, int nrVertices)
	{
		update(pVertexlist, nrVertices);
	}

	//plus operator
	AABB operator+(const AABB &param);

	void update(D3DXVECTOR3 *pVertexlist, long nrVertices);
	void move(D3DXVECTOR3 *moveDiff);
	void getMinDistance(D3DXVECTOR3 &point, float *minDistance);
	void getMaxDistance(D3DXVECTOR3 &point, float *maxDistance);
	bool intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, bool onlySegment);
	bool includePoint(D3DXVECTOR3 &point);

	D3DXVECTOR3 vecMin;		// min vector of the bounding box
	D3DXVECTOR3 vecMax;		// max vector of the bounding box
	D3DXVECTOR3 vecMiddle;	// middle
};

#endif