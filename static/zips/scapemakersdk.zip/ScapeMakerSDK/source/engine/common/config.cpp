#include "config.h"
#include "../logger/logger.h"
#include "../../common/minixml.h"
#include "shaderconsts.h"
#include "../terrain/terrain.h"
#include "../sky/sky.h"

Config *Config::instance = NULL;

/****************************************************************************
** Config Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Config::Config()
{
	instance = this;

	//set to default values
	terrainLOD = 1;
	detailTexture = false;
	cloudShading = true;
	waterReflection = false;
	skyReflection = false;
	terrainReflection = false;
	subMeshesReflection = false;
	heightBasedFog = false;
}

/****************************************************************************
** Config Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Config::~Config()
{
	instance = NULL;
}

/****************************************************************************
** Config init
**
** init and load the config
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Config::init(const char* projectPath)
{
	//build engine path
	enginePath = string(projectPath)+"/engine/";

	//extract landscape name
	projectName = projectPath;
	//remove / at end
	long lastNotSlash = projectName.find_last_not_of('/');
	if (lastNotSlash != string::npos)
	{
		projectName = projectName.substr(0,lastNotSlash+1);
		//find next slash from end
		long lastSlash = projectName.find_last_of('/');
		projectName = projectName.substr(lastSlash+1, projectName.size());
	}

	//load engine config file
	MiniXML	xmlFile;	
	if (xmlFile.openFile("./enginefiles/config.txt",MiniXML::READ))
	{
		bool bValue;
		int value;

		if (xmlFile.readInteger("terrainLOD",&value))
			terrainLOD = value;

		if (xmlFile.readBoolean("detailTexture",&bValue))
			detailTexture = bValue;

		if (xmlFile.readBoolean("heightBasedFog",&bValue))
			heightBasedFog = bValue;

		if (xmlFile.readBoolean("cloudShading",&bValue))
			cloudShading = bValue;

		if (xmlFile.readBoolean("waterReflection",&bValue))
			waterReflection = bValue;

		if (waterReflection)
		{
			if (xmlFile.readBoolean("skyReflection",&bValue))
				skyReflection = bValue;

			if (xmlFile.readBoolean("terrainReflection",&bValue))
				terrainReflection = bValue;

			if (xmlFile.readBoolean("subMeshesReflection",&bValue))
				subMeshesReflection = bValue;
		}

		xmlFile.closeFile();
	}


	//load sea properties
	if (waterReflection)
	{
		string seaPropertiesPath = enginePath+"/sea.txt";
		if (xmlFile.openFile(seaPropertiesPath.c_str(),MiniXML::READ))
		{
			int value;

			if (xmlFile.readInteger("height",&value))
			{
				//if sea height = 0, no reflection at all
				if (value == 0)
				{
					skyReflection = false;
					terrainReflection = false;
					subMeshesReflection = false;
				}
			}
			
			xmlFile.closeFile();
		}
	}
	else
	{
		skyReflection = false;
		terrainReflection = false;
		subMeshesReflection = false;
	}

	return S_OK;
}

