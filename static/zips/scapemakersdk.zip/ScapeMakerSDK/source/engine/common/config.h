/****************************************************************************
** Config
**
** manage all configs
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_CONFIG)
#define H_CONFIG
#pragma warning(disable:4786)

#include <d3dx9.h>
#include <string>

class Config
{
public:
	Config();
	~Config();

	//init object
	HRESULT init(const char* projectPath);

	//access function
	std::string getEnginePath() {return enginePath;}
	std::string getProjectName() {return projectName;}
	int getTerrainLOD() {return terrainLOD;}
	bool isDetailTexture() {return detailTexture;}
	bool isHeightBasedFog() {return heightBasedFog;}
	bool isCloudShading() {return cloudShading;}
	bool isWaterReflection() {return waterReflection;}
	bool isSkyReflection() {return skyReflection;}
	bool isTerrainReflection() {return terrainReflection;}
	bool isSubMeshesReflection() {return subMeshesReflection;}

	static Config *instance;				//the instance to the only one config object

private:

	//path to project/engine directory
	std::string enginePath;

	//name of project
	std::string projectName;

	//terrain detail level
	int terrainLOD;

	//detail texture on or of
	bool detailTexture;

	//cloud shading on or of
	bool cloudShading;

	//height based fog on or of
	bool heightBasedFog;

	//water reflection on or of
	bool waterReflection;
	//reflection of sky enabled
	bool skyReflection;
	//reflection of terrain enabled
	bool terrainReflection;
	//reflection of sub meshes enabled
	bool subMeshesReflection;
};

#endif