/****************************************************************************
** DirectX Font
**
** copied from the book 
** "Real Time Rendering Tricks & Techniques with DirectX"
****************************************************************************/

#if !defined(DIRECTXFONT_H)
#define DIRECTXFONT_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>

struct FONTVERTEX 
{ 
	float x, y, z, rhw;
	DWORD color;
	float u, v;
};

#define D3DFVF_FONTVERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)

class CDirectXFont  
{
public:
	void FillCharacter(TCHAR Character, FONTVERTEX **ppVertices,
		               float XStartPosition, float *pXPosition,
					   float *pYPosition, DWORD Color);
	void DestroyStaticText(LPDIRECT3DVERTEXBUFFER9 pBuffer);
	void DrawStaticText(LPDIRECT3DVERTEXBUFFER9 pStaticText, long StartChar,
		                long NumChars);
	HRESULT CreateFont(LPDIRECT3DDEVICE9 pDevice, TCHAR *pFontName, long FontSize);
	void DestroyFont();

	void DrawText(float XPosition, float YPosition, const TCHAR *pText, DWORD Color);

	LPDIRECT3DVERTEXBUFFER9 CreateStaticText(float XPosition, float YPosition,
		                                     const TCHAR *pText, DWORD Color,
											 float *pWidth = NULL, float *pHeight = NULL);

	void FillVertex(FONTVERTEX *pVertex, float x, float y, float u,
		            float v, DWORD color);
	void DrawDebug(float XPosition, float YPosition);
	CDirectXFont();
	virtual ~CDirectXFont();

	//Used for sizing and uv coordinates
	long m_TextureSize;
    float m_TexCoords[96][4];

    //The basic building blocks
	LPDIRECT3DTEXTURE9      m_pTexture;
	LPDIRECT3DVERTEXBUFFER9 m_pVertexBuffer;
	LPDIRECT3DDEVICE9       m_pDevice;

	//State block handles
	LPDIRECT3DSTATEBLOCK9 m_TextStates;
	LPDIRECT3DSTATEBLOCK9 m_SavedStates;
};

#endif
