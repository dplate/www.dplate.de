#include "enginehelpers.h"
#include "../logger/logger.h"
#include "../camera/camera.h"
#include "../common/config.h"
#include "../common/shaderconsts.h"

/****************************************************************************
** pointRotate
**
** rotate a point in 2D around the origin
**
** Author: Dirk Plate
****************************************************************************/

D3DXVECTOR2 EngineHelpers::pointRotate(D3DXVECTOR2 *origPunkt, float degree)
{
	D3DXVECTOR2 newPunkt;
	double radius;
	double absDegree;

	radius = sqrt(origPunkt->x*origPunkt->x+origPunkt->y*origPunkt->y);
	absDegree = atan2(origPunkt->y,origPunkt->x)+degree;

	newPunkt.x = float(radius*cos(absDegree));
	newPunkt.y = float(radius*sin(absDegree));

	return newPunkt;
}

/****************************************************************************
** pointRotateY
**
** rotate a point in 3D around the origin
**
** Author: Dirk Plate
****************************************************************************/

D3DXVECTOR3 EngineHelpers::pointRotateY(D3DXVECTOR3 *origPunkt, float degree)
{
	D3DXVECTOR3 newPunkt;
	double radius;
	double absDegree;

	radius = sqrt(origPunkt->x*origPunkt->x+origPunkt->z*origPunkt->z);
	absDegree = atan2(origPunkt->z,origPunkt->x)+degree;

	newPunkt.x = float(radius*cos(absDegree));
	newPunkt.y = origPunkt->y;
	newPunkt.z = float(radius*sin(absDegree));

	return newPunkt;
}

/****************************************************************************
** getHeightOfRay
**
** Get the height of a ray, if you have the x and z coordinate
**
** Author: Dirk Plate
****************************************************************************/

float EngineHelpers::getHeightOfRay(const D3DXVECTOR3* p,const D3DXVECTOR3* d, const float x, const float z)
{
	float tmp;

	//get the factor
	if (fabs(d->x) > fabs(d->z)) tmp = (x-p->x)/d->x;
	else tmp = (z-p->z)/d->z;

	//return the height
	return p->y+tmp*d->y;
}

/****************************************************************************
** getXZCoordinateOfRay
**
** Get the x and z coordinate of a ray, if you have the height (d->y must be != 0)
**
** Author: Dirk Plate
****************************************************************************/

bool EngineHelpers::getXZCoordinateOfRay(const D3DXVECTOR3* p,const D3DXVECTOR3* d, float *x, const float y,float *z)
{
	float tmp;

	if (d->y == 0) return false;

	//get the factor
	tmp = (y-p->y)/d->y;

	//calc. the x-coordinate
	*x = p->x+tmp*d->x;
	//and the z-coordinate
	*z = p->z+tmp*d->z;

	return true;
}

// dot product (3D) which allows vector operations in arguments
#define dot(u,v)   ((u).x * (v).x + (u).y * (v).y + (u).z * (v).z)

/****************************************************************************
** intersectRayTriangle
**
** intersect a ray with a triangle
**
** Author: Dirk Plate
****************************************************************************/

bool EngineHelpers::intersectRayTriangle( const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir,
						   const D3DXVECTOR3 *t0, const D3DXVECTOR3 *t1, const D3DXVECTOR3 *t2,
						   bool sectionCheck, D3DXVECTOR3 *point )
{
    D3DXVECTOR3		u, v, n;		 // triangle vectors
    D3DXVECTOR3		w0, w;			 // ray vectors
    float			r, a, b;         // params to calc ray-plane intersect

    // get triangle edge vectors and plane normal
    u = *t1 - *t0;
    v = *t2 - *t0;
    D3DXVec3Cross(&n,&u,&v);	// cross product
    if (n == D3DXVECTOR3(0,0,0)) return false;    // triangle is degenerate

    w0 = *rayPos - *t0;
    a = dot(n,w0);
    b = dot(n,*rayDir);
    if (fabs(b) < SMALL_NUM) return false;   // ray is parallel to triangle plane

    // get intersect point of ray with triangle plane
    r = -a / b;

	if (sectionCheck && ((r < 0) || (r > 1))) return false;	  //intersect point not in segment of ray

    *point = *rayPos + r * *rayDir;           // intersect point of ray and plane

    // is point inside triangle?
    float    uu, uv, vv, wu, wv, d;
    uu = dot(u,u);
    uv = dot(u,v);
    vv = dot(v,v);
    w = *point - *t0;
    wu = dot(w,u);
    wv = dot(w,v);
    d = uv * uv - uu * vv;

    // get and test barycentric coords
    float s, t;
    s = (uv * wv - vv * wu) / d;
    if (s < 0.0 || s > 1.0) return false; // point is outside triangle

    t = (uv * wu - uu * wv) / d;
    if (t < 0.0 || (s + t) > 1.0) return false; // point is outside triangle

	return true;
}

/****************************************************************************
** intersectRayTriangle2
**
** intersect a ray with a triangle (from pick.cpp of DxSDK)
**
** Author: Dirk Plate
****************************************************************************/

BOOL EngineHelpers::intersectRayTriangle2(const D3DXVECTOR3& orig,const D3DXVECTOR3& dir,
						   D3DXVECTOR3& v0,D3DXVECTOR3& v1, D3DXVECTOR3& v2,
                           FLOAT* t, FLOAT* u, FLOAT* v )
{
    // Find vectors for two edges sharing vert0
    D3DXVECTOR3 edge1 = v1 - v0;
    D3DXVECTOR3 edge2 = v2 - v0;

    // Begin calculating determinant - also used to calculate U parameter
    D3DXVECTOR3 pvec;
    D3DXVec3Cross( &pvec, &dir, &edge2 );

    // If determinant is near zero, ray lies in plane of triangle
    FLOAT det = D3DXVec3Dot( &edge1, &pvec );

    D3DXVECTOR3 tvec;
    if( det > 0 )
    {
        tvec = orig - v0;
    }
    else
    {
        tvec = v0 - orig;
        det = -det;
    }

    if( det < 0.0001f )
        return FALSE;

    // Calculate U parameter and test bounds
    *u = D3DXVec3Dot( &tvec, &pvec );
    if( *u < 0.0f || *u > det )
        return FALSE;

    // Prepare to test V parameter
    D3DXVECTOR3 qvec;
    D3DXVec3Cross( &qvec, &tvec, &edge1 );

    // Calculate V parameter and test bounds
    *v = D3DXVec3Dot( &dir, &qvec );
    if( *v < 0.0f || *u + *v > det )
        return FALSE;

    // Calculate t, scale parameters, ray intersects triangle
    *t = D3DXVec3Dot( &edge2, &qvec );
    FLOAT fInvDet = 1.0f / det;
    *t *= fInvDet;
    *u *= fInvDet;
    *v *= fInvDet;

    return TRUE;
}

/****************************************************************************
** intersectPointTriangle
**
** Determine if a point (k) is inside a triangle (a,b,c)
**
** Author: Dirk Plate
****************************************************************************/

bool EngineHelpers::intersectPointTriangle(const D3DXVECTOR2 *a,
								   const D3DXVECTOR2 *b,
								   const D3DXVECTOR2 *c,
								   const D3DXVECTOR2 *k)
{
	float denom;
	float q1,q2;
	//transform origin to a
	D3DXVECTOR2 p1 = *b-*a;
	D3DXVECTOR2 p2 = *c-*a;
	D3DXVECTOR2 q  = *k-*a;

	if (p1.x*p2.y > p2.x*p1.y)
	{
		denom = p1.x*p2.y-p2.x*p1.y;
		q1 = (q.x*p2.y-q.y*p2.x)/denom;
		q2 = (q.y*p1.x-q.x*p1.y)/denom;
	}
	else
	{
		denom = p2.x*p1.y-p1.x*p2.y;
		q1 = (q.x*p1.y-q.y*p1.x)/denom;
		q2 = (q.y*p2.x-q.x*p2.y)/denom;
	}

	if ((q1 >= 0) && (q2 >= 0) && ((q1+q2) <= 1.0/*denom*/)) return true;
	else return false;
}

/****************************************************************************
** halfAngelVector2D
**
** Get the normalized half angle vector of two 2D vectors
**
** Author: Dirk Plate
****************************************************************************/

void EngineHelpers::halfAngelVector2D(const D3DXVECTOR2 *a, const D3DXVECTOR2 *b, D3DXVECTOR2 *w, bool sameDir)
{
	D3DXVECTOR2 normA,normB,tmpW;

	D3DXVec2Normalize(&normA,a);
	D3DXVec2Normalize(&normB,b);

	if (normA == -normB)		//if both vectors parallel
	{
		tmpW.x = -normA.y;		//take the vertical line
		tmpW.y = normA.x;
	}
	else tmpW = normA+normB;	//else calculate the half angle
	D3DXVec2Normalize(w,&tmpW);

	if (sameDir)				//all vectors should point in the same direction
		if (D3DXVec2CCW(w,&normB) < 0) *w *= -1; //mirror the vector
}

/****************************************************************************
** getNormalVector
**
** Get the normalized normal vector triangle
**
** Author: Dirk Plate
****************************************************************************/

void EngineHelpers::getNormalVector(const D3DXVECTOR3 *p1New,
							const D3DXVECTOR3 *p2New,
							const D3DXVECTOR3 *p3New,
							D3DXVECTOR3 *v)
{
	D3DXPLANE plane;
	D3DXVECTOR3 p1,p2,p3;

	//make a plane to through point 0,0,0
	p1 = *p1New-*p1New;
	p2 = *p2New-*p1New;
	p3 = *p3New-*p1New;

	//make a plane from the points
	D3DXPlaneFromPoints(&plane,&p1,&p2,&p3);
	D3DXPlaneNormalize(&plane,&plane);

	//get the normal on the plane
	v->x = plane.a;
	v->y = plane.b;
	v->z = plane.c;

	//the normal should always point above
	if (v->y < 0) *v *= -1.0f;
}

/****************************************************************************
** rayDistance
**
** Calculate the distance between a point and a ray
**
** Author: Dirk Plate
****************************************************************************/

float EngineHelpers::rayDistance(const D3DXVECTOR3 &point, const D3DXVECTOR3 &rayOrig, const D3DXVECTOR3 &rayDir)
{
	D3DXVECTOR3 diff = point - rayOrig;
	float		fT	 = D3DXVec3Dot(&diff, &rayDir);

	if( fT <= 0.0f )
		fT = 0.0f;
	else
	{
		fT /= D3DXVec3LengthSq( &rayDir );
		diff -= fT * rayDir;
	}

	return( D3DXVec3Length( &diff ));
}

/****************************************************************************
** raySphereIntersection
**
** test ray-sphere intersection
**
** Author: Dirk Plate
****************************************************************************/

bool EngineHelpers::raySphereIntersection(const D3DXVECTOR3 &rayOrig, const D3DXVECTOR3 &rayDir, const D3DXVECTOR3 &sphereCenter, const float radius)
{
	float distance = rayDistance( sphereCenter, rayOrig, rayDir );

	if( distance <= radius )
		return TRUE;
	else
		return FALSE;
}

/****************************************************************************
** pointSphereDistance
**
** calculate the min and max distance to a sphere
**
** Author: Dirk Plate
****************************************************************************/

void EngineHelpers::pointSphereDistance(const D3DXVECTOR3 &point, const D3DXVECTOR3 &center, const float radius,
								float *minDistance, float *middleDistance, float *maxDistance)
{
	*middleDistance = D3DXVec3Length(&(center-point));
	*minDistance = *middleDistance-radius;
	*maxDistance = *middleDistance+radius;
}

/****************************************************************************
** sphereAroundSpheres
**
** calculate the sphere around other spheres (not the minimum one!)
**
** Author: Dirk Plate
****************************************************************************/

void EngineHelpers::sphereAroundSpheres(D3DXVECTOR3 *center, float *radius, int count,
								D3DXVECTOR3 *newCenter, float *newRadius)
{
	float *radius3 = new float[count];
	float sumRadius3;
	int i;
	float tempRadius;

	//calculate new center
	sumRadius3=0;
	*newCenter = D3DXVECTOR3(0,0,0);
	for (i=0;i<count;i++)
	{
		radius3[i] = radius[i]*radius[i]*radius[i];
		sumRadius3 += radius3[i];

		*newCenter += radius3[i]*center[i];
	}
	*newCenter /= sumRadius3;
	delete radius3;

	//calculate new radius
	*newRadius = 0;
	for (i=0;i<count;i++)
	{
		tempRadius = D3DXVec3Length(&(center[i]-*newCenter))+radius[i];
		if (tempRadius > *newRadius)
			*newRadius = tempRadius;
	}
}

/****************************************************************************
** getTextureCoordinates
**
** transform a 3D-coordinate to the texture-coordinate
**
** Author: Dirk Plate
****************************************************************************/
BOOL EngineHelpers::getTextureCoordinates(D3DXVECTOR3 *orgP1,D3DXVECTOR3 *orgP2,D3DXVECTOR3 *orgP3,
								  D3DXVECTOR2 *t1,   D3DXVECTOR2 *t2,   D3DXVECTOR2 *t3,
								  D3DXVECTOR3 *orgP4,D3DXVECTOR2 *t4)
{
	D3DXVECTOR3 p1,p2,p3; // the transformed coordinates of the 3 edges of the triangle
	D3DXVECTOR3 p4;		  // the transformed point in the middle of the triangle

	float r,s,l1,l2;
	D3DXVECTOR3 p3Diffp2;
	D3DXVECTOR3 sDiff;
	D3DXVECTOR3 sDiffAbs;
	D3DXVECTOR3 p3Abs;
	D3DXVECTOR3 p2Abs;
	D3DXVECTOR2 t5,t6;

	//its a good triangle?
	if ((orgP1 == orgP2) && (orgP2 == orgP3)) return false;

	//transform the p1 to 0,0,0
	p2 = *orgP2-*orgP1;
	p3 = *orgP3-*orgP1;
	p4 = *orgP4-*orgP1;

	p3Diffp2 = p3-p2;
	sDiff.x = p2.y*p3.z-p3.y*p2.z;
	sDiff.y = p2.x*p3.z-p3.x*p2.z;
	sDiff.z = p2.x*p3.y-p3.x*p2.y;
	sDiffAbs.x = (float)fabs(sDiff.x);
	sDiffAbs.y = (float)fabs(sDiff.y);
	sDiffAbs.z = (float)fabs(sDiff.z);

	if (((sDiffAbs.x >= sDiffAbs.y) &&
		 (sDiffAbs.x >  sDiffAbs.z)) ||
		((sDiffAbs.x >  sDiffAbs.y) &&
		 (sDiffAbs.x >= sDiffAbs.z)))
	{
		l1 = (p4.y*p3.z-p4.z*p3.y)/sDiff.x;
		l2 = (p4.y*p2.z-p4.z*p2.y)/sDiff.x;
	}
	else if (((sDiffAbs.y >= sDiffAbs.x) &&
		 (sDiffAbs.y >  sDiffAbs.z)) ||
		((sDiffAbs.y >  sDiffAbs.x) &&
		 (sDiffAbs.y >= sDiffAbs.z)))
	{
		l1 = (p4.x*p3.z-p4.z*p3.x)/sDiff.y;
		l2 = (p4.x*p2.z-p4.z*p2.x)/sDiff.y;
	}
	else
	{
		l1 = (p4.x*p3.y-p4.y*p3.x)/sDiff.z;
		l2 = (p4.x*p2.y-p4.y*p2.x)/sDiff.z;
	}

	p3Abs.x = (float)fabs(p3.x);
	p3Abs.y = (float)fabs(p3.y);
	p3Abs.z = (float)fabs(p3.z);
	p2Abs.x = (float)fabs(p2.x);
	p2Abs.y = (float)fabs(p2.y);
	p2Abs.z = (float)fabs(p2.z);

	if (((p3Abs.x >= p3Abs.y) &&
		 (p3Abs.x >  p3Abs.z)) ||
		((p3Abs.x >  p3Abs.y) &&
		 (p3Abs.x >= p3Abs.z)))
		r = (p4.x+l1*(p3Diffp2.x))/p3.x;
	else if (((p3Abs.y >= p3Abs.x) &&
		      (p3Abs.y >  p3Abs.z)) ||
		     ((p3Abs.y >  p3Abs.x) &&
		      (p3Abs.y >= p3Abs.z)))
		r = (p4.y+l1*(p3Diffp2.y))/p3.y;
	else
		r = (p4.z+l1*(p3Diffp2.z))/p3.z;

	if (((p2Abs.x >= p2Abs.y) &&
		 (p2Abs.x >  p2Abs.z)) ||
		((p2Abs.x >  p2Abs.y) &&
		 (p2Abs.x >= p2Abs.z)))
		s = (p4.x+l2*(p3Diffp2.x))/p2.x;
	else if (((p2Abs.y >= p2Abs.x) &&
		      (p2Abs.y >  p2Abs.z)) ||
		     ((p2Abs.y >  p2Abs.x) &&
		      (p2Abs.y >= p2Abs.z)))
		s = (p4.y+l2*(p3Diffp2.y))/p2.y;
	else
		s = (p4.z+l2*(p3Diffp2.z))/p2.z;

	t5 = *t1+r*(*t3-*t1);
	t6 = *t1+s*(*t2-*t1);
	if (fabs(l1) < SMALL_NUM) *t4 = t5;
	else *t4 = t5+(l1/((float)fabs(l1)+(float)fabs(l2)))*(t6-t5);

	return true;
}

/****************************************************************************
** getTextureCoordinates2
**
** get the texture-coordinate from u and v parameters
**
** Author: Dirk Plate
****************************************************************************/
void EngineHelpers::getTextureCoordinates2(D3DXVECTOR2 *t1, D3DXVECTOR2 *t2, D3DXVECTOR2 *t3,
								   float u, float v,D3DXVECTOR2 *t4)
{
	FLOAT dtu1 = t2->x - t1->x;
    FLOAT dtu2 = t3->x - t1->x;
    FLOAT dtv1 = t2->y - t1->y;
    FLOAT dtv2 = t3->y - t1->y;
	t4->x = t1->x + u * dtu1 + v * dtu2;
	t4->y = t1->y + u * dtv1 + v * dtv2;
}

//------------------------------------------------------------------------------
// Name:	CreateVSFromFile
// Desc:	loads a *.vsh file and creates a vertex shader
//------------------------------------------------------------------------------
HRESULT EngineHelpers::createVSFromFile (IDirect3DDevice9* pD3DDevice,
								 D3DVERTEXELEMENT9 * decl,
								 TCHAR* strVSPath,
								 IDirect3DVertexShader9 **pVS, IDirect3DVertexDeclaration9 **pDecl)
{
	TCHAR        strShaderPath[512];
	LPD3DXBUFFER pCode;                  // Buffer with the assembled shader code
	LPD3DXBUFFER pErrorMsgs;             // Buffer with error messages
	HRESULT hr;
	char* pErrorStr;

//	DXUtil_FindMediaFile(strShaderPath, strVSPath);
	strcpy(strShaderPath, strVSPath);

	if (FAILED(hr = D3DXAssembleShaderFromFile(strShaderPath, NULL, NULL, 0, &pCode, &pErrorMsgs)))
	{
		if(pErrorMsgs != NULL)
		{
			pErrorStr = (char *)pErrorMsgs->GetBufferPointer();
			OutputDebugString(pErrorStr);
		}
		return hr;
	}

	if (FAILED(hr = pD3DDevice->CreateVertexDeclaration(decl, pDecl)))
		return hr;

	if (FAILED(hr = pD3DDevice->CreateVertexShader((DWORD*)pCode->GetBufferPointer(), pVS)))
		return hr;

	SAFE_RELEASE(pCode);
	SAFE_RELEASE(pErrorMsgs);

	return S_OK;
}

//------------------------------------------------------------------------------
// Name:	CreatePSFromFile
// Desc:	loads a binary *.psh file and creates a pixel shader
//------------------------------------------------------------------------------
HRESULT EngineHelpers::createPSFromFile (IDirect3DDevice9* pD3DDevice,
								 TCHAR* strPSPath,
								 IDirect3DPixelShader9 **pPS)
{
	TCHAR        strShaderPath[512];
	LPD3DXBUFFER pCode;                  // Buffer with the assembled shader code
	LPD3DXBUFFER pErrorMsgs;             // Buffer with error messages
	char* pErrorStr;
	HRESULT hr;

	//DXUtil_FindMediaFile(strShaderPath, strPSPath);
	strcpy(strShaderPath, strPSPath);

	if (FAILED(hr = D3DXAssembleShaderFromFile(strShaderPath, NULL, NULL, 0, &pCode, &pErrorMsgs)))
	{
		if(pErrorMsgs != NULL)
		{
			pErrorStr = (char *)pErrorMsgs->GetBufferPointer();
			OutputDebugString(pErrorStr);
		}
		return hr;
	}

	if (FAILED(hr = pD3DDevice->CreatePixelShader((DWORD*)pCode->GetBufferPointer(), pPS)))
	{
		return hr;
	}

	SAFE_RELEASE(pCode);
	SAFE_RELEASE(pErrorMsgs);

	return S_OK;
}

/****************************************************************************
** setDefaultRenderStates
**
** set all render states to uncritical values (for error searching)
**
** Author: Dirk Plate
****************************************************************************/

void EngineHelpers::setDefaultRenderStates(LPDIRECT3DDEVICE9 pD3DDevice)
{
	pD3DDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	pD3DDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	pD3DDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);
	pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, true);
	pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_LASTPIXEL, true);
	pD3DDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	pD3DDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ZERO);
	pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	pD3DDevice->SetRenderState(D3DRS_ZFUNC,D3DCMP_LESSEQUAL);
	pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0x00000000);
	pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_ALWAYS);
	pD3DDevice->SetRenderState(D3DRS_DITHERENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_FOGENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_SPECULARENABLE, true);
	pD3DDevice->SetRenderState(D3DRS_FOGCOLOR, 0x00000000);
	pD3DDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_NONE);
	pD3DDevice->SetRenderState(D3DRS_FOGSTART, 0);
	pD3DDevice->SetRenderState(D3DRS_FOGEND, 1);
	pD3DDevice->SetRenderState(D3DRS_FOGDENSITY, 1);
	pD3DDevice->SetRenderState(D3DRS_RANGEFOGENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_STENCILENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_STENCILFAIL, D3DSTENCILOP_KEEP);
	pD3DDevice->SetRenderState(D3DRS_STENCILZFAIL, D3DSTENCILOP_KEEP);
	pD3DDevice->SetRenderState(D3DRS_STENCILPASS, D3DSTENCILOP_KEEP);
	pD3DDevice->SetRenderState(D3DRS_STENCILFUNC, D3DCMP_ALWAYS);
	pD3DDevice->SetRenderState(D3DRS_STENCILREF, 0x00000000);
	pD3DDevice->SetRenderState(D3DRS_STENCILMASK, 0xFFFFFFFF);
	pD3DDevice->SetRenderState(D3DRS_STENCILWRITEMASK, 0xFFFFFFFF);
	pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR, 0xFFFFFFFF);
	pD3DDevice->SetRenderState(D3DRS_WRAP0, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP1, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP2, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP3, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP4, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP5, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP6, NULL);
	pD3DDevice->SetRenderState(D3DRS_WRAP7, NULL);
	pD3DDevice->SetRenderState(D3DRS_CLIPPING, true);
	pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);
	pD3DDevice->SetRenderState(D3DRS_AMBIENT, 0x00202020);
	pD3DDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_NONE);
	pD3DDevice->SetRenderState(D3DRS_COLORVERTEX, true);
	pD3DDevice->SetRenderState(D3DRS_LOCALVIEWER, true);
	pD3DDevice->SetRenderState(D3DRS_NORMALIZENORMALS, false);
	pD3DDevice->SetRenderState(D3DRS_DIFFUSEMATERIALSOURCE, D3DMCS_COLOR1);
	pD3DDevice->SetRenderState(D3DRS_SPECULARMATERIALSOURCE, D3DMCS_COLOR2);
	pD3DDevice->SetRenderState(D3DRS_AMBIENTMATERIALSOURCE, D3DMCS_MATERIAL);
	pD3DDevice->SetRenderState(D3DRS_EMISSIVEMATERIALSOURCE, D3DMCS_MATERIAL);
	pD3DDevice->SetRenderState(D3DRS_VERTEXBLEND, D3DVBF_DISABLE);
	pD3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, 0x00000000);
	pD3DDevice->SetRenderState(D3DRS_POINTSIZE, 1);
	pD3DDevice->SetRenderState(D3DRS_POINTSIZE_MIN, 0);
	pD3DDevice->SetRenderState(D3DRS_POINTSPRITEENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_POINTSCALEENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_POINTSCALE_A, 1);
	pD3DDevice->SetRenderState(D3DRS_POINTSCALE_B, 0);
	pD3DDevice->SetRenderState(D3DRS_POINTSCALE_C, 0);
	pD3DDevice->SetRenderState(D3DRS_MULTISAMPLEANTIALIAS, true);
	pD3DDevice->SetRenderState(D3DRS_MULTISAMPLEMASK, 0xFFFFFFFF);
	pD3DDevice->SetRenderState(D3DRS_PATCHEDGESTYLE, D3DPATCHEDGE_DISCRETE);
	pD3DDevice->SetRenderState(D3DRS_POINTSIZE_MAX, 256);
	pD3DDevice->SetRenderState(D3DRS_INDEXEDVERTEXBLENDENABLE, false);
	pD3DDevice->SetRenderState(D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_RED|D3DCOLORWRITEENABLE_GREEN|D3DCOLORWRITEENABLE_BLUE | D3DCOLORWRITEENABLE_ALPHA);
	pD3DDevice->SetRenderState(D3DRS_TWEENFACTOR, 0);
	pD3DDevice->SetRenderState(D3DRS_BLENDOP, D3DBLEND_ZERO);
}

/****************************************************************************
** getCubeMapViewMatrix
**
** return the view matrix for cube map generation
**
** Author: Microsoft
****************************************************************************/

D3DXMATRIX EngineHelpers::getCubeMapViewMatrix( DWORD dwFace, D3DXVECTOR3 eyePosition)
{
	D3DXVECTOR3 vEyePt   = D3DXVECTOR3( eyePosition);
    D3DXVECTOR3 vLookDir;
    D3DXVECTOR3 vUpDir;

    switch( dwFace )
    {
        case D3DCUBEMAP_FACE_POSITIVE_X:
            vLookDir = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_X:
            vLookDir = D3DXVECTOR3(-1.0f, 0.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_POSITIVE_Y:
            vLookDir = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_Y:
            vLookDir = D3DXVECTOR3( 0.0f,-1.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
            break;
        case D3DCUBEMAP_FACE_POSITIVE_Z:
            vLookDir = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_Z:
            vLookDir = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
    }

    // Set the view transform for this cubemap surface
    D3DXMATRIX matView;
    D3DXMatrixLookAtLH(&matView, &vEyePt, &(vEyePt+vLookDir), &vUpDir);
    return matView;
}

/****************************************************************************
** loadTexture
**
** load a texture from path, uncompressed or not
**
** Author: Dirk Plate
****************************************************************************/

HRESULT EngineHelpers::loadTexture( LPDIRECT3DDEVICE9 pD3DDevice, const char *pPath, D3DFORMAT format, LPDIRECT3DTEXTURE9 *pTexture)
{
	HRESULT hr;

	if(FAILED(hr = (D3DXCreateTextureFromFileEx(pD3DDevice,
		pPath,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		0,
		0,
		format,
		D3DPOOL_MANAGED,
		D3DX_DEFAULT,
		D3DX_DEFAULT,
		0,
		NULL,
		NULL,
		pTexture))))
	{
		return hr;
	}

	//check opened format
	D3DSURFACE_DESC desc;
	if (FAILED(hr=(*pTexture)->GetLevelDesc(0,&desc)))
		return hr;
	if ((format != D3DFMT_UNKNOWN) && (format != desc.Format))
		return E_FAIL;

	return S_OK;
}

/****************************************************************************
** convertTextureCoordinate
**
** convert a relative texture coordinate to an absolute pixel coordinate
** correctionType = 0  -> no correction
** correctionType = 1  -> clamp (cut to big or small coordinates)
** correctionType = 2  -> modulo
**
** Author: Dirk Plate
****************************************************************************/
void EngineHelpers::convertTextureCoordinate(const D3DXVECTOR2 &relTextureCoord,
									  LPDIRECT3DTEXTURE9 *pTexture,
									  int &absTextureCoordX,
									  int &absTextureCoordY,
									  int correctionType)
{
	D3DSURFACE_DESC	surfaceDesc;
	(*pTexture)->GetLevelDesc(0,&surfaceDesc);

	convertTextureCoordinate(relTextureCoord, surfaceDesc.Width, surfaceDesc.Height,
							 absTextureCoordX, absTextureCoordY, correctionType); 
}

void EngineHelpers::convertTextureCoordinate(const D3DXVECTOR2 &relTextureCoord, 
										int textureWidth,
										int textureHeight,
										int &absTextureCoordX, 
										int &absTextureCoordY, 
										int correctionType)
{
	absTextureCoordX = int(relTextureCoord.x*textureWidth);
	absTextureCoordY = int(relTextureCoord.y*textureHeight);

	if (correctionType == 1)
	{
		if (absTextureCoordX>=textureWidth)  absTextureCoordX=textureWidth-1;
		if (absTextureCoordY>=textureHeight) absTextureCoordY=textureHeight-1;
		if (absTextureCoordX<0) absTextureCoordX=0;
		if (absTextureCoordY<0) absTextureCoordY=0;
	}
	else if (correctionType == 2)
	{
		while (absTextureCoordX<0) absTextureCoordX += textureWidth;
		while (absTextureCoordY<0) absTextureCoordY += textureHeight;
		absTextureCoordX %= textureWidth;
		absTextureCoordY %= textureHeight;
	}
}


/****************************************************************************
** getPixelFromTexture
**
** get a pixel from a texture
**
** Author: Dirk Plate
****************************************************************************/
DWORD EngineHelpers::getPixelFromTexture( unsigned long x, unsigned long y, D3DLOCKED_RECT *pLockedRect)
{
	//Reading the pixel from texture
	const DWORD* colorMap = (const DWORD*)pLockedRect->pBits;
	DWORD value;

	//get the color
	unsigned long lineLength = pLockedRect->Pitch>>2;
	value = colorMap[x+y*lineLength];

	return value;
}

/****************************************************************************
** checkSubMeshAlpha
**
** checks, if a submesh have a texture with alpha
**
** Author: Dirk Plate
****************************************************************************/
HRESULT EngineHelpers::checkSubMeshAlpha( LPD3DXMESH pMesh, LPD3DXATTRIBUTERANGE pAttrib, CxImage *pTexture, bool *pIsAlpha)
{
	*pIsAlpha = false;
	int textureWidth = pTexture->GetWidth();
	int textureHeight = pTexture->GetHeight();

	//retrieve performance buffer
	bool *pPerfBuffer = new bool[textureWidth*textureHeight];
	for (unsigned int i=0; i<textureWidth*textureHeight; i++)
		pPerfBuffer[i] = false;

	//retrieve mesh data
	MeshTool *pMeshData = new MeshTool(pMesh);

	//go through all faces of submesh
	for (DWORD j=pAttrib->FaceStart; j<pAttrib->FaceStart+pAttrib->FaceCount; j++)
	{
		//get texture coordinates of triangle
		D3DXVECTOR2 t1 = pMeshData->pVertices[pMeshData->pIndices[3*j+0]].t;
		D3DXVECTOR2 t2 = pMeshData->pVertices[pMeshData->pIndices[3*j+1]].t;
		D3DXVECTOR2 t3 = pMeshData->pVertices[pMeshData->pIndices[3*j+2]].t;

		//calculate real texture coordinates
		int t1pX, t1pY;
		convertTextureCoordinate(t1, textureWidth, textureHeight, t1pX, t1pY, 0);

		int t2pX, t2pY;
		convertTextureCoordinate(t2, textureWidth, textureHeight, t2pX, t2pY, 0);

		int t3pX, t3pY;
		convertTextureCoordinate(t3, textureWidth, textureHeight, t3pX, t3pY, 0);

		//get bounding rectangle around triangle
		int left = MIN(t1pX, t2pX);
		left = MIN(left, t3pX);
		int right = MAX(t1pX, t2pX);
		right = MAX(right, t3pX);
		int top = MIN(t1pY, t2pY);
		top = MIN(top, t3pY);
		int bottom = MAX(t1pY, t2pY);
		bottom = MAX(bottom, t3pY);

		//ignore one pixel at border
		left++;
		right--;
		top++;
		bottom--;

		//go through all pixels of the rectangle
		for (int x=left; x<=right; x++)
			 for (int y=top; y<=bottom; y++)
		{
			//calculate right coordinate (modulo) of this point
			int xMod = x;
			int yMod = y;
			while (xMod<0) xMod += textureWidth;
			while (yMod<0) yMod += textureHeight;
			xMod %= textureWidth;
			yMod %= textureHeight;

			//only go on, if not already checked
			if (!pPerfBuffer[yMod*textureWidth+xMod])
			{
				//check if point is in rectangle
				if (intersectPointTriangle(&D3DXVECTOR2((float)t1pX,(float)t1pY),
										   &D3DXVECTOR2((float)t2pX,(float)t2pY),
										   &D3DXVECTOR2((float)t3pX,(float)t3pY),
										   &D3DXVECTOR2((float)x,(float)y)))
				{
					//retrieve alpha value
					int alpha = pTexture->GetPixelGray(xMod,yMod);

					//if alpha not completely visible
					if (alpha < 255-MIN_ALPHA)
					{
						*pIsAlpha = true;
					}
					else
					{
						pPerfBuffer[yMod*textureWidth+xMod] = true;
					}
				}
			}
		}

		//one pixel with alpha is enough
		if (*pIsAlpha) break;
	}

	//release mesh
	SAFE_DELETE(pMeshData);

	//delete performance buffer
	SAFE_DELETE_ARRAY(pPerfBuffer);

	return S_OK;
}

/****************************************************************************
** initInterpolationStrengths
**
** init the interpolationstrength array (precalculating)
**
** Author: Dirk Plate
****************************************************************************/

EngineHelpers::InterpolationStrengths *EngineHelpers::interpolationStrengths = NULL;
int EngineHelpers::interpolationStrengthsQuality = 0;

void EngineHelpers::initInterpolationStrengths(int quality)
{
	//delete old array 
	SAFE_DELETE_ARRAY(interpolationStrengths);

	//create array
	interpolationStrengths = new EngineHelpers::InterpolationStrengths[quality*quality];

	//fill array
	for (int iX=0; iX<quality; iX++)
		for (int iY=0; iY<quality; iY++)
	{
		//get distances from edges
		float distanceX = (float)iX/quality;
		float distanceY = (float)iY/quality;
		
		float distanceLeftTop = sqrtf(distanceX*distanceX+distanceY*distanceY);
		distanceX = 1.0f - distanceX;
		float distanceRightTop = sqrtf(distanceX*distanceX+distanceY*distanceY);
		distanceY = 1.0f - distanceY;
		float distanceRightBottom = sqrtf(distanceX*distanceX+distanceY*distanceY);
		distanceX = 1.0f - distanceX;
		float distanceLeftBottom = sqrtf(distanceX*distanceX+distanceY*distanceY);
		
		//get strength from edges
		float strengthLeftTop = 1.0f-distanceLeftTop;
		if (strengthLeftTop < 0.0f) strengthLeftTop = 0.0f;
		float strengthRightTop = 1.0f-distanceRightTop;
		if (strengthRightTop < 0.0f) strengthRightTop = 0.0f;
		float strengthLeftBottom = 1.0f-distanceLeftBottom;
		if (strengthLeftBottom < 0.0f) strengthLeftBottom = 0.0f;
		float strengthRightBottom = 1.0f-distanceRightBottom;
		if (strengthRightBottom < 0.0f) strengthRightBottom = 0.0f;
		
		//normalize strength
		float tmp = strengthLeftTop + strengthRightTop + strengthLeftBottom + strengthRightBottom;
		strengthLeftTop /= tmp;
		strengthRightTop /= tmp;
		strengthLeftBottom /= tmp;
		strengthRightBottom /= tmp;

		//save strength
		interpolationStrengths[iY*quality+iX].strengthLeftTop = strengthLeftTop;
		interpolationStrengths[iY*quality+iX].strengthRightTop = strengthRightTop;
		interpolationStrengths[iY*quality+iX].strengthLeftBottom = strengthLeftBottom;
		interpolationStrengths[iY*quality+iX].strengthRightBottom = strengthRightBottom;
	}

	interpolationStrengthsQuality = quality;
}

/****************************************************************************
** getInterpolationStrengths
**
** calculate the strength of all int edges around a float point for
** interpolation purposes
**
** Author: Dirk Plate
****************************************************************************/
void EngineHelpers::getInterpolationStrengths(float x, float y,
									  float *pStrengthLeftTop, float *pStrengthRightTop,
									  float *pStrengthLeftBottom, float *pStrengthRightBottom)
{
	//calculate index for cache array
	int iX = int((x-int(x))*interpolationStrengthsQuality);
	int iY = int((y-int(y))*interpolationStrengthsQuality);
	InterpolationStrengths *pIndex = interpolationStrengths+iY*interpolationStrengthsQuality+iX;
	
	*pStrengthLeftTop = pIndex->strengthLeftTop;
	*pStrengthRightTop = pIndex->strengthRightTop;
	*pStrengthLeftBottom = pIndex->strengthLeftBottom;
	*pStrengthRightBottom = pIndex->strengthRightBottom;
}

/****************************************************************************
** floatCalculator
**
** calculate the result for the term. the term can include numbers, *, /, + and -, no ( )
**
** Author: Dirk Plate
****************************************************************************/
bool EngineHelpers::floatCalculator(const std::string &term, float &result)
{
	long splitPosition;
	std::string leftPart;
	std::string rightPart;
	float leftResult;
	float rightResult;

	//special cases
	if (term.size() <= 0)
	{
		result = 0;
		return true;
	}

	//find first add character
	splitPosition = term.find_first_of("+");
	//found a multiplier
	if (splitPosition < term.size())
	{
		//split string in two parts	
		leftPart = term.substr(0, splitPosition);
		rightPart = term.substr(splitPosition+1, term.size());

		//calculate both parts
		if (!floatCalculator(leftPart,leftResult))
			return false;
		if (!floatCalculator(rightPart,rightResult))
			return false;
		
		//calculate result
		result = leftResult+rightResult;

		//success
		return true;
	}

	//find first subtract character
	splitPosition = term.find_first_of("-");
	//found a multiplier
	if (splitPosition < term.size())
	{
		//split string in two parts	
		leftPart = term.substr(0, splitPosition);
		rightPart = term.substr(splitPosition+1, term.size());

		//calculate both parts
		if (!floatCalculator(leftPart,leftResult))
			return false;
		if (!floatCalculator(rightPart,rightResult))
			return false;
		
		//calculate result
		result = leftResult-rightResult;

		//success
		return true;
	}

	//find first mulitplier character
	splitPosition = term.find_first_of("*");
	//found a multiplier
	if (splitPosition < term.size())
	{
		//split string in two parts	
		leftPart = term.substr(0, splitPosition);
		rightPart = term.substr(splitPosition+1, term.size());

		//calculate both parts
		if (!floatCalculator(leftPart,leftResult))
			return false;
		if (!floatCalculator(rightPart,rightResult))
			return false;
		
		//calculate result
		result = leftResult*rightResult;

		//success
		return true;
	}

	//find first divider character
	splitPosition = term.find_first_of("/");
	//found a multiplier
	if (splitPosition < term.size())
	{
		//split string in two parts	
		leftPart = term.substr(0, splitPosition);
		rightPart = term.substr(splitPosition+1, term.size());

		//calculate both parts
		if (!floatCalculator(leftPart,leftResult))
			return false;
		if (!floatCalculator(rightPart,rightResult))
			return false;
		
		//calculate result
		result = leftResult/rightResult;

		//success
		return true;
	}

	//delete all ' ' at beginning and end
	long firstNotBlank = term.find_first_not_of(' ');
	//only blanks?
	if (firstNotBlank == string::npos)
	{
		result = 0;
		return true;
	}
	std::string cleanTerm = term.substr(firstNotBlank, term.size());
	long lastNotBlank = cleanTerm.find_last_not_of(' ');
	//only blanks (shouldn't be, or not)?
	if (lastNotBlank == string::npos)
	{
		result = 0;
		return true;
	}
	cleanTerm = cleanTerm.substr(0,lastNotBlank+1);

	//constants?
	//camera positions?
	Camera *pCamera = Camera::instance;
	if ((cleanTerm == "px") && (pCamera != NULL))
		result = pCamera->getPosition().x;
	else if ((cleanTerm == "py") && (pCamera != NULL))
		result = pCamera->getPosition().y;
	else if ((cleanTerm == "pz") && (pCamera != NULL))
		result = pCamera->getPosition().z;
	else
	{
		//its comes up to here... then it have to be a single number
		try
		{
			result = atof(cleanTerm.c_str());
		}
		catch(...)
		{
			return false;
		}
	}

	return true;
}

/****************************************************************************
** stringCalculator
**
** calculate the result for the term. the term can include strings, +, no ( )
**
** Author: Dirk Plate
****************************************************************************/
bool EngineHelpers::stringCalculator(const std::string &term, std::string &result)
{
	long splitPosition;
	std::string leftPart;
	std::string rightPart;
	std::string leftResult;
	std::string rightResult;

	//special cases
	if (term.size() <= 0)
	{
		result = "";
		return true;
	}

	//find first add character not included in "..."
	bool inString = false;
	splitPosition = term.size();
	for (int i=0; i<term.size(); i++)
	{
		if ((term.at(i) == '+') && (!inString))
		{
			splitPosition = i;
			break;
		}
		if (term.at(i) == '\"')
			inString = !inString;
	}
	//found a multiplier
	if (splitPosition < term.size())
	{
		//split string in two parts	
		leftPart = term.substr(0, splitPosition);
		rightPart = term.substr(splitPosition+1, term.size());

		//calculate both parts
		if (!stringCalculator(leftPart,leftResult))
			return false;
		if (!stringCalculator(rightPart,rightResult))
			return false;
		
		//calculate result
		result = leftResult+rightResult;

		//success
		return true;
	}

	//delete all ' ' at beginning and end
	long firstNotBlank = term.find_first_not_of(' ');
	//only blanks?
	if (firstNotBlank == string::npos)
	{
		result = "";
		return true;
	}
	std::string cleanTerm = term.substr(firstNotBlank, term.size());
	long lastNotBlank = cleanTerm.find_last_not_of(' ');
	//only blanks (shouldn't be, or not)?
	if (lastNotBlank == string::npos)
	{
		result = "";
		return true;
	}
	cleanTerm = cleanTerm.substr(0,lastNotBlank+1);

	//constants?
	//landscape name?
	Config *pConfig = Config::instance;
	if ((cleanTerm == "project") && (pConfig != NULL))
		result = pConfig->getProjectName();
	else
	{
		//its comes up to here... then it have to be a single string
		//string have to begin with " and end with "
		if ((cleanTerm.at(0) != '\"') || (cleanTerm.at(cleanTerm.size()-1) != '\"'))
			return false;
		//to short
		if (cleanTerm.size() < 2)
			return false;
		//empty
		if (cleanTerm.size() == 2)
		{
			result = "";
			return true;
		}
		//return string between "..."
		result = cleanTerm.substr(1, cleanTerm.size()-2);
	}

	return true;
}

/****************************************************************************
** setWorldTransform
**
** set a new world transformation (update vertex shader constants as well)
**
** Author: Dirk Plate
****************************************************************************/
HRESULT EngineHelpers::setWorldTransform(LPDIRECT3DDEVICE9 pD3DDevice, D3DXMATRIX *pMatrix, bool setVertexConsts)
{
	pD3DDevice->SetTransform(D3DTS_WORLD,pMatrix);
	if (setVertexConsts)
	{
		D3DXMATRIX matTemp;

		//set world matrix for shaders
		D3DXMatrixTranspose( &matTemp, pMatrix);
		pD3DDevice->SetVertexShaderConstantF( CV_WORLD_0, matTemp, 4 );
	
		//update world view projection matrix
		D3DXMATRIX matView, matProj;
		pD3DDevice->GetTransform(D3DTS_VIEW, &matView);
		pD3DDevice->GetTransform(D3DTS_PROJECTION, &matProj);
 		D3DXMATRIX matViewProj = matView * matProj;
		D3DXMATRIX worldViewProj = *pMatrix * matViewProj;

		D3DXMatrixTranspose( &matTemp, &worldViewProj);
		pD3DDevice->SetVertexShaderConstantF( CV_WORLDVIEWPROJ_0, matTemp, 4 );
	}

	return S_OK;
}

/****************************************************************************
** initInterpolationStrengths
**
** delete the interpolationstrength array
**
** Author: Dirk Plate
****************************************************************************/
void EngineHelpers::deInitInterpolationStrengths()
{
	//delete array
	SAFE_DELETE_ARRAY(interpolationStrengths);
}

/****************************************************************************
** getRandomInInterval
**
** get a random value between min and max
**
** Author: Dirk Plate
****************************************************************************/
float EngineHelpers::getRandomInInterval(float min, float max)
{
	return (max-min)/RAND_MAX*rand()+min;
}

/****************************************************************************
** Constructor
**
** lock vertex and index buffer
**
** Author: Dirk Plate
****************************************************************************/
MeshTool::MeshTool( LPD3DXMESH pMesh )
{
	HRESULT hr;

	this->pMesh = pMesh;
    dwNumVertices = pMesh->GetNumVertices();
	if (FAILED(hr=pMesh->LockVertexBuffer(D3DLOCK_READONLY,(VOID**)&pVertices)))
	{
		LOG("Locking vertex buffer failed!", Logger::LOG_CRIT);
	}
	if (FAILED(hr=pMesh->LockIndexBuffer(D3DLOCK_READONLY,(VOID**)&pIndices)))
	{
		LOG("Locking index buffer failed!", Logger::LOG_CRIT);
	}
}

/****************************************************************************
** Destructor
**
** unlock vertex and index buffer
**
** Author: Dirk Plate
****************************************************************************/
MeshTool::~MeshTool()
{
	pMesh->UnlockVertexBuffer();
	pMesh->UnlockIndexBuffer();
}

