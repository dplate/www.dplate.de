#if !defined(H_ENGINEHELPERS)
#define H_ENGINEHELPERS
#pragma warning(disable:4786)

#define MAX(a,b) ((a > b) ? a:b)
#define MIN(a,b) ((a < b) ? a:b)

#define SQR(a) (a*a)

//a small number (to test float against 0)
#define SMALL_NUM 0.00001f		
//a big number
#define BIG_NUM	10000000.0f	
//minimal alpha (below its completely transparent)
#define MIN_ALPHA 0x04
//earth gravity
#define EARTH_GRAVITIY 9.81f
//fog needs some less distance, because there is less fog at the sides of the camera
#define FOG_ADDDISTANCE 10.0f
//maximum visible terrain distance (undependent of terrain size)
#define MAX_VIEWDISTANCE 2048.0f

#include <d3d9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <fstream>
#include <ximage.h>
#include "dxutil.h"

class EngineHelpers
{
public:
	static D3DXVECTOR2 pointRotate(D3DXVECTOR2 *origPunkt, float degree);
	static D3DXVECTOR3 pointRotateY(D3DXVECTOR3 *origPunkt, float degree);
	static float getHeightOfRay(const D3DXVECTOR3* p,const D3DXVECTOR3* d, const float x, const float z);
	static bool getXZCoordinateOfRay(const D3DXVECTOR3* p,const D3DXVECTOR3* d, float *x, const float y,float *z);
	static bool intersectRayTriangle( const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
			   const D3DXVECTOR3 *t0, const D3DXVECTOR3 *t1, const D3DXVECTOR3 *t2, 
			   bool sectionCheck, D3DXVECTOR3 *point );
	static BOOL intersectRayTriangle2(const D3DXVECTOR3& orig,const D3DXVECTOR3& dir, 
			   D3DXVECTOR3& v0,D3DXVECTOR3& v1, D3DXVECTOR3& v2,
                    FLOAT* t, FLOAT* u, FLOAT* v );
	static bool intersectPointTriangle(const D3DXVECTOR2 *a,
					   const D3DXVECTOR2 *b,
					   const D3DXVECTOR2 *c,
					   const D3DXVECTOR2 *k);
	static void halfAngelVector2D(const D3DXVECTOR2 *a, const D3DXVECTOR2 *b, D3DXVECTOR2 *w, bool sameDir);
	static void getNormalVector(const D3DXVECTOR3 *p1New,
				const D3DXVECTOR3 *p2New,
				const D3DXVECTOR3 *p3New,
				D3DXVECTOR3 *v);
	static float rayDistance(const D3DXVECTOR3 &point, const D3DXVECTOR3 &rayOrig, const D3DXVECTOR3 &rayDir);
	static bool raySphereIntersection(const D3DXVECTOR3 &rayOrig, const D3DXVECTOR3 &rayDir, const D3DXVECTOR3 &sphereCenter, const float radius);
	static void pointSphereDistance(const D3DXVECTOR3 &point, const D3DXVECTOR3 &center, const float radius, 
					float *minDistance, float *middleDistance, float *maxDistance);
	static void sphereAroundSpheres(D3DXVECTOR3 *center, float *radius, int count, 
					D3DXVECTOR3 *newCenter, float *newRadius);
	static BOOL getTextureCoordinates(D3DXVECTOR3 *orgP1,D3DXVECTOR3 *orgP2,D3DXVECTOR3 *orgP3,
					  D3DXVECTOR2 *t1,   D3DXVECTOR2 *t2,   D3DXVECTOR2 *t3,
					  D3DXVECTOR3 *orgP4,D3DXVECTOR2 *t4);
	static void getTextureCoordinates2(D3DXVECTOR2 *t1, D3DXVECTOR2 *t2, D3DXVECTOR2 *t3,
					   float u, float v,D3DXVECTOR2 *t4);
	static HRESULT createVSFromFile (IDirect3DDevice9* pD3DDevice, 
					 D3DVERTEXELEMENT9 * decl,
					 TCHAR* strVSPath, 
					 IDirect3DVertexShader9 **pVS, IDirect3DVertexDeclaration9 **pDecl);
	static HRESULT createPSFromFile (IDirect3DDevice9* pD3DDevice, 
					 TCHAR* strPSPath, 
					 IDirect3DPixelShader9 **pPS);
	static void setDefaultRenderStates(LPDIRECT3DDEVICE9 pD3DDevice);
	static D3DXMATRIX getCubeMapViewMatrix( DWORD dwFace, D3DXVECTOR3 eyePosition);
	static HRESULT loadTexture( LPDIRECT3DDEVICE9 pD3DDevice, const char *pPath, D3DFORMAT format, LPDIRECT3DTEXTURE9 *pTexture);
	static void convertTextureCoordinate( const D3DXVECTOR2 &relTextureCoord, 
						  LPDIRECT3DTEXTURE9 *pTexture, 
						  int &absTextureCoordX, 
						  int &absTextureCoordY, 
						  int correctionType);
	static void convertTextureCoordinate( const D3DXVECTOR2 &relTextureCoord, 
						  int textureWidth,
						  int textureHeight,
						  int &absTextureCoordX, 
						  int &absTextureCoordY, 
						  int correctionType);
	static DWORD getPixelFromTexture( unsigned long x, unsigned long y, D3DLOCKED_RECT *pLockedRect);
	static HRESULT checkSubMeshAlpha( LPD3DXMESH pMesh, LPD3DXATTRIBUTERANGE pAttrib, CxImage *pTexture, bool *pIsAlpha);
	static void initInterpolationStrengths(int quality);
	static void getInterpolationStrengths(float x, float y, 
									  float *pStrengthLeftTop, float *pStrengthRightTop,
									  float *pStrengthLeftBottom, float *pStrengthRightBottom);
	static void deInitInterpolationStrengths();	
	static float getRandomInInterval(float min, float max);
	static bool floatCalculator(const std::string &term, float &result);
	static bool stringCalculator(const std::string &term, std::string &result);
	static HRESULT setWorldTransform(LPDIRECT3DDEVICE9 pD3DDevice, D3DXMATRIX *pMatrix, bool setVertexConsts);
	
private:	
	struct InterpolationStrengths
	{
		float strengthLeftTop;
		float strengthRightTop;
		float strengthLeftBottom;
		float strengthRightBottom;
	};
	static InterpolationStrengths *interpolationStrengths;
	static int interpolationStrengthsQuality;
};


class MeshTool
{
public:
	struct VERTEX { D3DXVECTOR3 p, n; D3DXVECTOR2 t; }; 

	VERTEX* pVertices;					//locked vertices of object
	WORD*	pIndices;					//locked indices of object

    DWORD	   dwNumVertices;
	LPD3DXMESH pMesh;
    
    MeshTool( LPD3DXMESH pMesh );
    ~MeshTool();
};

#endif