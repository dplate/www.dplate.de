#define CV_WORLDVIEWPROJ_0		 0
#define CV_WORLDVIEWPROJ_1		 1
#define CV_WORLDVIEWPROJ_2		 2
#define CV_WORLDVIEWPROJ_3		 3

#define CV_WORLD_0				 4
#define CV_WORLD_1				 5
#define CV_WORLD_2				 6
#define CV_WORLD_3				 7

#define CV_CAMERA_POS            10

#define CV_DEPTH_TO_TEX_SCALE    22

#define CV_WATER_MOVE			 30
#define CV_WATER_ROTATION		 31

// Pixel shader defines
#define CP_HEIGHT_FOG_COLOR     0
#define CP_ADDITIONAL_ALPHA     1

#define CP_TEX_TO_DEPTH_SCALE   3

#define CP_WATER_COLOR			4
#define CP_WATER_REFLECTION		5


