#include "submesh.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../camera/camera.h"

/****************************************************************************
** SubMesh Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
SubMesh::SubMesh()
{
	list = FREE;

	//set all variables
	pD3DDevice = NULL;
	pMesh = NULL;
	pMaterial = NULL;
	pTexture = NULL;
	pTransformation = NULL;
	pAlphaBlend = NULL;
	pAlphaValue = NULL;
	pAlphaTexture = NULL;
	pColorValue = NULL;
	pCenter = NULL;
	
	subMeshID = -1;
	cameraDistance = 0.0f;
	alpha = false;
}

SubMesh::~SubMesh()
{
}


/****************************************************************************
** SubMesh Render
**
** renders all submesh
**
** Author: Dirk Plate
****************************************************************************/

HRESULT	SubMesh::render(ModuleRenderType renderType, SubMesh *pLastElement, D3DXMATRIX *pViewProj)
{
	D3DXMATRIX matTemp;

	//settings for blending
	if (*pAlphaBlend)
	{
		if ((pLastElement->pAlphaValue == NULL) ||
			(*(pLastElement->pAlphaValue) != *pAlphaValue))
		{
			pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_COLORVALUE(0, 0, 0,*pAlphaValue));
			pD3DDevice->SetPixelShaderConstantF(CP_ADDITIONAL_ALPHA, D3DXCOLOR(0,0,0,*pAlphaValue), 1 );
		}
	}
	else
	{
		if ((pLastElement->pAlphaBlend == NULL) ||
			*(pLastElement->pAlphaBlend))
		{
			pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_COLORVALUE(0, 0, 0, 1.0f));
			pD3DDevice->SetPixelShaderConstantF(CP_ADDITIONAL_ALPHA, D3DXCOLOR(0,0,0,1.0f), 1 );
		}
	}
	
	//set world to this submesh
	if (pLastElement->pTransformation != pTransformation)
	{
		pD3DDevice->SetTransform(D3DTS_WORLD,pTransformation);

		if (renderType == DEPTH)
		{
			//set world matrix for shaders
			D3DXMatrixTranspose( &matTemp, pTransformation);
			pD3DDevice->SetVertexShaderConstantF( CV_WORLD_0, matTemp, 4 );
		
			//update world view projection matrix
			worldViewProj = *pTransformation * *pViewProj;

			D3DXMatrixTranspose( &matTemp, &worldViewProj);
			pD3DDevice->SetVertexShaderConstantF( CV_WORLDVIEWPROJ_0, matTemp, 4 );
		}
	}

	//coloring object
	if ((pLastElement->pColorValue == NULL) ||
		((*(pLastElement->pColorValue) != *pColorValue)))
	{
		pD3DDevice->SetRenderState(D3DRS_AMBIENT,*pColorValue);
	}

	//set the material and texture for this subset
	if (pLastElement->pMaterial != pMaterial)
		pD3DDevice->SetMaterial(pMaterial);
	if (((renderType != DEPTH) || alpha) && (pLastElement->pTexture != pTexture))
		pD3DDevice->SetTexture(0,pTexture);

	// Draw the mesh subset
	pMesh->DrawSubset(subMeshID);

	return S_OK;
}

/****************************************************************************
** SubMesh Update
**
** prepare rendering
**
** Author: Dirk Plate
****************************************************************************/
HRESULT SubMesh::update()
{
	D3DXVECTOR3 transformedVector;

	//transform center to position
	D3DXVec3TransformCoord(&transformedVector, pCenter, pTransformation);

	//calculate length of diffvector
	cameraDistance = D3DXVec3Length(&(Camera::instance->getPosition()-transformedVector));
	
	return S_OK;
}
