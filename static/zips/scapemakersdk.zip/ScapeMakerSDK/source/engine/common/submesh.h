/****************************************************************************
** SubMesh
**
** submesh rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(SUBMESH_H)
#define SUBMESH_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <vector>

#include "../camera/camera.h"
#include "../module.h"

class SubMesh
{
public:
	SubMesh();
	~SubMesh();
	bool operator<(const SubMesh &element) {return cameraDistance > element.cameraDistance;}

	HRESULT update();
	HRESULT render(ModuleRenderType renderType, SubMesh *pLastElement, D3DXMATRIX *pViewProj);
	
	//access functions
	inline void	setD3DDevice(LPDIRECT3DDEVICE9 pD3DDeviceSet) {pD3DDevice = pD3DDeviceSet;}
	inline void	setSubMeshID(int subMeshIDSet) {subMeshID = subMeshIDSet;}

	enum{FREE, VISIBLE_ALPHA, VISIBLE_NORMAL ,INVISIBLE} list;			//current list (visible or invisible)
	float					cameraDistance;		//distance from camera (for z-sorting)											

	//pointers (can be changed from outside)
	LPD3DXMESH				pMesh;				//the wireframe (which include the submesh)
	D3DMATERIAL9			*pMaterial;			//the material of the submesh
	LPDIRECT3DTEXTURE9		pTexture;			//the textrue of the submesh
	D3DXMATRIX				*pTransformation;	//transformationmatrix for the submesh
	bool					*pAlphaBlend;		//blending into transparency? 
	float					*pAlphaValue;		//how visible is the object (additional to texture alpha)
	D3DCOLOR				*pColorValue;		//for additional coloring of the submesh
	D3DXVECTOR3				*pCenter;			//untransformed center of submesh
	bool					*pAlphaTexture;		//this submesh has an texture with alpha channel
	bool					alpha;				//this submesh is semitransparent (texture or alphablend)

private:
	LPDIRECT3DDEVICE9		pD3DDevice;			//the 3d device
	int						subMeshID;			//id of the submesh in mesh
	D3DXMATRIX				worldViewProj;		//the current world/view/projection matrix
};

#endif