#include "submeshes.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../common/config.h"

SubMeshes *SubMeshes::instance = NULL;

/****************************************************************************
** SubMeshes Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
SubMeshes::SubMeshes()
{
	Module::Module();
	name = "SubMeshes";

	pD3DDevice = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	//create the two bins for radix sort
	pBinA = new std::list<SubMesh>[256];
	pBinB = new std::list<SubMesh>[256];

	instance = this;
}

SubMeshes::~SubMeshes()
{
	//clear lists
	visibleAlpha.clear();
	visibleNormal.clear();
	invisible.clear();
	free.clear();

	//delete the two bins for radix sort
	SAFE_DELETE_ARRAY(pBinA);
	SAFE_DELETE_ARRAY(pBinB);

	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** SubMeshes createGeometry
**
** initializes everything
**
** Author: Dirk Plate
****************************************************************************/

HRESULT SubMeshes::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	//delete submeshes list
	visibleAlpha.clear();
	visibleNormal.clear();
	invisible.clear();
	free.clear();

	//create state blocks to change the render states
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}
		
		//needed for color keying
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, MIN_ALPHA );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
		
		//needed for lightening objects
		pD3DDevice->SetRenderState(D3DRS_LIGHTING, true);
		pD3DDevice->SetRenderState(D3DRS_DIFFUSEMATERIALSOURCE,D3DMCS_MATERIAL);
		pD3DDevice->SetRenderState(D3DRS_AMBIENT,0xA0A0A0A0);
		//pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_MODULATE);
		//pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
		
		//needed for blending
		//pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_TFACTOR);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
		
		//needed for right texture mapping
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSW, D3DTADDRESS_MIRROR );

		//set fixed vertex function
		pD3DDevice->SetFVF( D3DFVF_DEFAULTVERTEX );
		pD3DDevice->SetVertexShader(NULL);
		pD3DDevice->SetPixelShader(NULL);

		pD3DDevice->SetRenderState(D3DRS_CULLMODE,	D3DCULL_CCW);
				
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("State block created OK");

	//must be disabled at beginning
	enabled = false;

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** SubMeshes destroyGeometry
**
** destroy all directx stuff
**
** Author: Dirk Plate
****************************************************************************/

HRESULT SubMeshes::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//delete submeshes list
	visibleAlpha.clear();
	visibleNormal.clear();
	invisible.clear();
	free.clear();

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);

	return Module::destroyGeometry();
}

/****************************************************************************
** SubMeshes Render
**
** renders all submeshes
**
** Author: Dirk Plate
****************************************************************************/

HRESULT	SubMeshes::render(ModuleRenderType renderType)
{
	if (!enabled) return S_OK;

	SubMesh dummyElement;
	SubMesh *pLastElement = &dummyElement;

	//calc proj*view matrix
	D3DXMATRIX matView, matProj, matViewProj;
	pD3DDevice->GetTransform(D3DTS_VIEW, &matView);
	pD3DDevice->GetTransform(D3DTS_PROJECTION, &matProj);
 	matViewProj = matView * matProj;
	
	//record and set the render states
	if (renderType != DEPTH)
	{
		pSavedStateBlock->Capture();
		pStateBlock->Apply();
	}
	else pD3DDevice->SetRenderState(D3DRS_CULLMODE,	D3DCULL_CCW);
	
	//render all non semitransparent sub meshes
	std::list<SubMesh>::iterator i = visibleNormal.begin();
	while (i != visibleNormal.end())
	{
		i->render(renderType, pLastElement, &matViewProj);
		pLastElement = &(*i);
		i++;
	}

	//render semitransparent sub meshes without z-buffer writing
	pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, false);

	//render all semitransparent sub meshes
	i = visibleAlpha.begin();
	while (i != visibleAlpha.end())
	{
		i->render(renderType, pLastElement, &matViewProj);
		pLastElement = &(*i);
		i++;
	}

	//reset z-buffer
	pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, true);

	//Restore the states
	if (renderType != DEPTH) pSavedStateBlock->Apply();
	else 
	{
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,	D3DCULL_CCW);
		pD3DDevice->SetTexture(0,NULL);
	}
	pD3DDevice->SetPixelShaderConstantF(CP_ADDITIONAL_ALPHA, D3DXCOLOR(0,0,0,1.0f), 1 );

	return Module::render(renderType);
}

/****************************************************************************
** SubMeshes Update
**
** sort submeshes and prepare rendering
**
** Author: Dirk Plate
****************************************************************************/

HRESULT SubMeshes::update()
{
	if (!enabled) return S_OK;

	//update and z sort alpha elements
	radixSort();

	return Module::update();
}

/****************************************************************************
** SubMeshes add
**
** add a submesh to submeshes list, returns index of new submesh
**
** Author: Dirk Plate
****************************************************************************/

std::list<SubMesh>::iterator SubMeshes::add(SubMesh &subMesh)
{
	std::list<SubMesh>::iterator newElement;

	//free elements available?
	if (free.size() > 0)
	{
		//use one element from this list (dont allocate a new one)
		newElement = free.begin();
		if (subMesh.alpha)
		{
			*newElement = subMesh;
			newElement->list = SubMesh::VISIBLE_ALPHA;
			visibleAlpha.splice(visibleAlpha.end(),free,newElement);
		}
		else
		{
			visibleNormal.splice(visibleNormal.end(),free,newElement);
			*newElement = subMesh;
			newElement->list = SubMesh::VISIBLE_NORMAL;
		}
	}
	else
	{
		//allocate new element
		if (subMesh.alpha)
		{
			newElement = visibleAlpha.insert(visibleAlpha.begin(), subMesh);
			newElement->list = SubMesh::VISIBLE_ALPHA;
		}
		else
		{
			newElement = visibleNormal.insert(visibleNormal.end(), subMesh);
			newElement->list = SubMesh::VISIBLE_NORMAL;
		}
	}

	return newElement;
}

/****************************************************************************
** SubMeshes remove
**
** delete a submesh
**
** Author: Dirk Plate
****************************************************************************/
void SubMeshes::remove(std::list<SubMesh>::iterator element)
{
	//move it from right list to free list
	switch(element->list)
	{
	case SubMesh::VISIBLE_ALPHA:
		free.splice(free.end(),visibleAlpha,element);
		element->list = SubMesh::FREE;
		break;
	case SubMesh::VISIBLE_NORMAL:
		free.splice(free.end(),visibleNormal,element);
		element->list = SubMesh::FREE;
		break;
	case SubMesh::INVISIBLE:
		free.splice(free.end(),invisible,element);
		element->list = SubMesh::FREE;
		break;
	}
}

/****************************************************************************
** SubMeshes makeInvisible
**
** move a submesh from visible to invisible
**
** Author: Dirk Plate
****************************************************************************/
void SubMeshes::makeInvisible(std::list<SubMesh>::iterator element)
{
	switch(element->list)
	{
	case SubMesh::VISIBLE_ALPHA:
		invisible.splice(invisible.end(),visibleAlpha,element);
		element->list = SubMesh::INVISIBLE;
		break;
	case SubMesh::VISIBLE_NORMAL:
		invisible.splice(invisible.end(),visibleNormal,element);
		element->list = SubMesh::INVISIBLE;
		break;

	}
}

/****************************************************************************
** SubMeshes makeVisible
**
** move a submesh from invisible to visible
**
** Author: Dirk Plate
****************************************************************************/
void SubMeshes::makeVisible(std::list<SubMesh>::iterator element)
{
	switch(element->list)
	{
	case SubMesh::INVISIBLE:
		if (element->alpha)
		{
			element->list = SubMesh::VISIBLE_ALPHA;
			visibleAlpha.splice(visibleAlpha.end(),invisible,element);
		}
		else
		{
			visibleNormal.splice(visibleNormal.end(),invisible,element);
			element->list = SubMesh::VISIBLE_NORMAL;
		}
		break;
	}
}


/****************************************************************************
** SubMeshes makeNormal
**
** move a submesh from visible alpha to visible normal
**
** Author: Dirk Plate
****************************************************************************/
void SubMeshes::makeNormal(std::list<SubMesh>::iterator element)
{
	switch(element->list)
	{
	case SubMesh::VISIBLE_ALPHA:
		visibleNormal.splice(visibleNormal.end(),visibleAlpha,element);
		element->list = SubMesh::VISIBLE_NORMAL;
		element->alpha = false;
		break;
	}
}

/****************************************************************************
** SubMeshes makeAlpha
**
** move a submesh from visible normal to visible alpha
**
** Author: Dirk Plate
****************************************************************************/
void SubMeshes::makeAlpha(std::list<SubMesh>::iterator element)
{
	switch(element->list)
	{
	case SubMesh::VISIBLE_NORMAL:
		element->list = SubMesh::VISIBLE_ALPHA;
		element->alpha = true;
		visibleAlpha.splice(visibleAlpha.end(),visibleNormal,element);
		break;
	}
}

/****************************************************************************
** SubMeshes radixSort
**
** use radix sort to update and sort alpha list
**
** Author: Dirk Plate
****************************************************************************/
void SubMeshes::radixSort()
{
	//move alpha list in bin A (sort last byte)
	std::list<SubMesh>::iterator l = visibleAlpha.begin();
	while (l!=visibleAlpha.end())
	{
		//update element (calculate cameraDistance)
		l->update();

		//get first byte of float distance
		byte *c=((BYTE *)&(l->cameraDistance))+0;

		//copy in right byte bin
		std::list<SubMesh>::iterator m = l;
		l++;
		pBinA[*c].splice(pBinA[*c].end(),visibleAlpha,m);
	}

	//sort rest of bytes
	for (int j=1;j<4;j++)
	{
		//go through all byte types
		for (int i=0;i<256;i++)
		{
			//go through all elements in this byte
			std::list<SubMesh>::iterator k = pBinA[i].begin();
			while (k!=pBinA[i].end())
			{
				//get next byte
				byte *c=((BYTE *)&(k->cameraDistance))+j;
				
				//move in right destination byte bin
				std::list<SubMesh>::iterator m = k;
				k++;
				pBinB[*c].splice(pBinB[*c].end(), pBinA[i], m);
			}
		}

		//toggle bins
		std::list<SubMesh> *pTmp = pBinA;
		pBinA = pBinB;
		pBinB = pTmp;
	}

	//copy back to list
	for (int i=0;i<256;i++)
	{
		std::list<SubMesh>::iterator k = pBinA[i].begin();
		while (k!=pBinA[i].end())
		{
			std::list<SubMesh>::iterator m = k;
			k++;
			visibleAlpha.splice(visibleAlpha.begin(), pBinA[i], m);
		}
	}
}

/****************************************************************************
** SubMeshes getStatusMessage
**
** implementation of status source (called by status line)
**
** Author: Dirk Plate
****************************************************************************/
std::string SubMeshes::getStatusMessage()
{
	char buffer[256];

	sprintf(buffer, "Submeshes vis-a: %05d, vis-nona: %05d, invis: %05d", 
		SubMeshes::instance->getVisibleAlphaCount(), SubMeshes::instance->getVisibleNormalCount(),SubMeshes::instance->getInvisibleCount());
	
	std::string statusMessage(buffer);

	return statusMessage;
}