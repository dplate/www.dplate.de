/****************************************************************************
** SubMeshes
**
** submeshes rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(SUBMESHES_H)
#define SUBMESHES_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <list>
#include <algorithm>

#include "submesh.h"
#include "../module.h"
#include "../camera/camera.h"
#include "../hud/statusline.h"

#define D3DFVF_DEFAULTVERTEX (D3DFVF_XYZ | D3DFVF_TEX1)
#define MAXZSEARCHLENGTH 100

class SubMeshes : public Module, public StatusSource
{
public:
	SubMeshes();
	~SubMeshes();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT destroyGeometry();
	HRESULT update();
	HRESULT render(ModuleRenderType renderType);

	//enable all submeshes (update and render)
	void enable() {enabled = true;}
	//disable all submeshes (dont update and render)
	void disable() {enabled = false;}

	//add a submesh to visible list
	std::list<SubMesh>::iterator add(SubMesh &subMesh);

	//remove a submesh from visible or invisible list
	void remove(std::list<SubMesh>::iterator element);

	//move a submesh from visible to invisible
	void makeInvisible(std::list<SubMesh>::iterator element);

	//move a submesh from invisible to visible
	void makeVisible(std::list<SubMesh>::iterator element);

	//move a submesh from visible alpha to visible normal
	void makeNormal(std::list<SubMesh>::iterator element);

	//move a submesh from visible normal to visible alpha
	void makeAlpha(std::list<SubMesh>::iterator element);

	//statistic data access
	int getFreeCount() {return free.size();}
	int getVisibleAlphaCount() {return visibleAlpha.size();}
	int getVisibleNormalCount() {return visibleNormal.size();}
	int getInvisibleCount() {return invisible.size();}

	//implementation of status source
	virtual std::string getStatusMessage();

	static SubMeshes *instance;				//the instance to the only one submeshes objects

private:
	//updates and sorts all visible alpha submeshes
	void radixSort();

	LPDIRECT3DDEVICE9		pD3DDevice;			//the 3d device
	bool					enabled;			//submeshes en- or disabled

	LPDIRECT3DSTATEBLOCK9	pStateBlock;		//used state block for rendering
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;	//saved old state block

	std::list<SubMesh>		free;				//list with all free submeshes (avoid reallocation)
	std::list<SubMesh>		visibleAlpha;		//list with all visible semitransparent submeshes
	std::list<SubMesh>		visibleNormal;		//list with all visible non semitransparent submeshes
	std::list<SubMesh>		invisible;			//list with all invisible submeshes

	//two bins for radix sort
	std::list<SubMesh> *pBinA;
	std::list<SubMesh> *pBinB;
};

#endif

