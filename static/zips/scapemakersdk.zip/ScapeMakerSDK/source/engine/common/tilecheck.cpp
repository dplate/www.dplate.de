#include "tilecheck.h"

#include "../logger/logger.h"
#include "../common/config.h"
#include "../camera/camera.h"
#include "../sky/sky.h"

/****************************************************************************
** TileCheck Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
TileCheck::TileCheck()
{
	//no quadtree
	quadTree.leaf = true;
	quadTree.size = 0;

	repeatTiles = false;
	mirroredTiles = false;
}

TileCheck::~TileCheck()
{
	destroyQuadTree(&quadTree);
}

/****************************************************************************
** TileCheck setTiles
**
** set the tiles for checking (initialize everything, build trees...)
**
** Author: Dirk Plate
****************************************************************************/
void TileCheck::setTiles(Tile** pTiles, int size, int heightMapWidth, bool repeatTiles, bool mirroredTiles)
{
	this->repeatTiles = repeatTiles;
	this->mirroredTiles = mirroredTiles;

	//calculate transformations for all parts
	calculateTransformations(heightMapWidth);

	//destroy all quadtree
	destroyQuadTree(&quadTree);

	//init main node
	//add all tiles to main node
	for (int i=0;i<size*size;i++)
	{
		quadTree.tiles.push_back(pTiles[i]);
	}
	quadTree.size = size;

	//build rest of tree
	buildQuadTree(&quadTree);
}

/****************************************************************************
** TileCheck update
**
** updates the visibility lists
**
** Author: Dirk Plate
****************************************************************************/
void TileCheck::update()
{
	D3DXMATRIX transformedView;
	ViewFrustum transformedViewFrustum;
	D3DXVECTOR3 transformedPosition;
	D3DXMATRIX invTransformation;

	commonVisible.clear();

	//update all parts
	for (int part=0;part<9;part++)
	{
		if ((!repeatTiles) && (part != PART_CENTER))
			continue;

		//clear old visibilities
		visible[part].clear();

		if (mirroredTiles)
		{
			//transform view frustum
			transformedView = transformation[part]*(*Camera::instance->getViewMatrix());
			transformedViewFrustum.extractPlanes(&transformedView, Camera::instance->getProjectionMatrix());

			//transform camera position
			transformedPosition = Camera::instance->getPosition();
			D3DXVec3TransformCoord(&transformedPosition,&transformedPosition,&(transformation[part]));
		}
		else
		{
			//use inversed transformation
			D3DXMatrixInverse(&invTransformation, NULL, &(transformation[part]));
		
			//transform camera position
			transformedPosition = Camera::instance->getPosition();
			D3DXVec3TransformCoord(&transformedPosition,&transformedPosition,&invTransformation);

			//create new transformed view matrix
			D3DXMatrixLookAtLH(&transformedView, &transformedPosition, 
				&(transformedPosition+Camera::instance->getDirection()), &Camera::instance->getUp());
			transformedViewFrustum.extractPlanes(&transformedView, Camera::instance->getProjectionMatrix());
		}

		//check quad tree
		checkQuadTree(&quadTree, &transformedViewFrustum, &transformedPosition, part);

		//also visibility for reflection?
		if (Config::instance->isTerrainReflection())
		{
			if (mirroredTiles)
			{
				//transform view frustum
				transformedView = transformation[part]*(*Camera::instance->getReflectViewMatrix());
				transformedViewFrustum.extractPlanes(&transformedView, Camera::instance->getProjectionMatrix());

				//transform camera position
				transformedPosition = Camera::instance->getReflectPosition();
				D3DXVec3TransformCoord(&transformedPosition,&transformedPosition,&(transformation[part]));
			}
			else
			{
				//use inversed transformation
				D3DXMatrixInverse(&invTransformation, NULL, &(transformation[part]));
			
				//transform camera position
				transformedPosition = Camera::instance->getReflectPosition();
				D3DXVec3TransformCoord(&transformedPosition,&transformedPosition,&invTransformation);

				//create new transformed view matrix
				D3DXMatrixLookAtLH(&transformedView, &transformedPosition, 
					&(transformedPosition+Camera::instance->getReflectDirection()), &Camera::instance->getReflectUp());
				transformedViewFrustum.extractPlanes(&transformedView, Camera::instance->getProjectionMatrix());
			}

			//check quad tree
			checkQuadTree(&quadTree, &transformedViewFrustum, &transformedPosition, part);
		}
	}
}

/****************************************************************************
** TileCheck isVisible
**
** returns true, if tile is visible (call behind update!)
**
** Author: Dirk Plate
****************************************************************************/
bool TileCheck::isVisible(Tile* pTile, int part)
{
	if ((!repeatTiles) && (part != PART_CENTER))
		return false;

	if (visible[part].find(pTile) != visible[part].end())
		return true;
	else return false;
}

/****************************************************************************
** TileCheck isVisible
**
** returns true, if tile is in any part visible (call behind update!)
**
** Author: Dirk Plate
****************************************************************************/
bool TileCheck::isVisible(Tile* pTile)
{
	if (commonVisible.find(pTile) != commonVisible.end())
		return true;
	else return false;
}

/****************************************************************************
** TileCheck buildQuadTree
**
** build up quad tree (recursive)
**
** Author: Dirk Plate
****************************************************************************/
void TileCheck::buildQuadTree(QuadTreeStruct *node)
{
	//leaf?
	if (node->tiles.size() <= 1)
	{
		node->leaf = true;

		//only one left, so it has the same bounding box as this tile
		node->boundingBox = *((*(node->tiles.begin()))->getBoundingBox());
	}
	//4 childs
	else
	{
		node->leaf = false;

		int nextSize = node->size/2;

		//create the 4 childs
		for (int i=0;i<4;i++)
		{
			node->pChilds[i] = new QuadTreeStruct();
			node->pChilds[i]->size = nextSize;
		}

		//copy all tiles to right childs
		std::list<Tile*>::iterator currentTile = node->tiles.begin();
		int x=0;
		int y=0;
		while (currentTile != node->tiles.end())
		{
			//calculate index of child
			int tmpX = x/nextSize;
			int tmpY = y/nextSize;
			int child = tmpX+tmpY;
			if (tmpY >= 1) child++;

			//add tile
			node->pChilds[child]->tiles.push_back(*currentTile);

			//calculate next coordinate
			x++;
			if (x>=node->size)
			{
				x=0;
				y++;
			}
			currentTile++;
		}
		
		for (i=0;i<4;i++)
		{
			//build all child trees
			buildQuadTree(node->pChilds[i]);
		}

		//set child bounding boxes to own one
		node->boundingBox = node->pChilds[0]->boundingBox +
							node->pChilds[1]->boundingBox +
							node->pChilds[2]->boundingBox +
							node->pChilds[3]->boundingBox;
	}
}

/****************************************************************************
** TileCheck destroyQuadTree
**
** destroy quad tree (recursive)
**
** Author: Dirk Plate
****************************************************************************/
void TileCheck::destroyQuadTree(QuadTreeStruct *node)
{
	if (!node->leaf)
	{
		//destroy the 4 childs
		for (int i=0;i<4;i++)
		{
			destroyQuadTree(node->pChilds[i]);
			delete(node->pChilds[i]);
		}
	}
	node->leaf = true;
	node->size = 0;
	node->tiles.clear();
	node->boundingBox = AABB();
}

/****************************************************************************
** TileCheck checkQuadTree
**
** checks the visibility of quadtree (recursive)
**
** Author: Dirk Plate
****************************************************************************/
void TileCheck::checkQuadTree(QuadTreeStruct *node, ViewFrustum *pViewFrustum, D3DXVECTOR3 *pPosition, int part)
{
	//check visibility of the node
	int visibility = pViewFrustum->cullAABB(&node->boundingBox);

	//tiles behind distance fog are invisible
	if (visibility != VF_OUTSIDE)
	{
		float minDistance;
		float maxDistance;
		node->boundingBox.getMinDistance(*pPosition,&minDistance);
		node->boundingBox.getMaxDistance(*pPosition,&maxDistance);
		float realFogDistanceEnd = Sky::instance->getDustEnd()+FOG_ADDDISTANCE;
		if (minDistance > realFogDistanceEnd)
			visibility = VF_OUTSIDE;
		else if (maxDistance > realFogDistanceEnd)
			visibility = VF_CLIPPED;
	}

	//completely visible
	if (visibility == VF_INSIDE)
	{
		//put all to visible list
		std::list<Tile*>::iterator currentTile = node->tiles.begin();
		while (currentTile != node->tiles.end())
		{
			visible[part].insert(*currentTile);
			commonVisible.insert(*currentTile);
			currentTile++;
		}
	}
	//completely invisible?
	else if (visibility == VF_OUTSIDE)
	{
		//do nothing
	}
	//some tiles visible... some not
	else 
	{
		//if not leaf... call visibility of childs
		if (!node->leaf)
		{
			for (int i=0;i<4;i++)
			{
				checkQuadTree(node->pChilds[i],pViewFrustum,pPosition,part);
			}
		}
		//leaf... then tile is visible
		else 
		{
			visible[part].insert(*(node->tiles.begin()));
			commonVisible.insert(*(node->tiles.begin()));
		}
	}
}

/****************************************************************************
** TileCheck calculateTransformations
**
** calculates transformations matrices for all parts
**
** Author: Dirk Plate
****************************************************************************/
void TileCheck::calculateTransformations(int heightMapWidth)
{
	D3DXPLANE reflectPlane;
	D3DXMATRIX tmp;

	if (repeatTiles)
	{
		if (mirroredTiles)
		{
			//left/top... mirrored at 0/*/0
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,0.0f),
									 &D3DXVECTOR3(0.0f,0.0f,1.0f));
			D3DXMatrixReflect(&tmp,&reflectPlane);
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,0.0f),
									 &D3DXVECTOR3(1.0f,0.0f,0.0f));
			D3DXMatrixReflect(&(transformation[PART_TOPLEFT]),&reflectPlane);
			transformation[PART_TOPLEFT] *= tmp;

			//top... mirrored at */*/0
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,0.0f),
									 &D3DXVECTOR3(0.0f,0.0f,1.0f));
			D3DXMatrixReflect(&(transformation[PART_TOP]),&reflectPlane);

			//right/top... mirrored at terrainWidth/*/0
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(heightMapWidth,0.0f,0.0f),
									 &D3DXVECTOR3(0.0f,0.0f,1.0f));
			D3DXMatrixReflect(&tmp,&reflectPlane);
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(heightMapWidth,0.0f,0.0f),
									 &D3DXVECTOR3(-1.0f,0.0f,0.0f));
			D3DXMatrixReflect(&(transformation[PART_TOPRIGHT]),&reflectPlane);
			transformation[PART_TOPRIGHT] *= tmp;

			//left... mirrored at */*/0
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,0.0f),
									 &D3DXVECTOR3(1.0f,0.0f,0.0f));
			D3DXMatrixReflect(&(transformation[PART_LEFT]),&reflectPlane);
		}
		else
		{
			//left/top... 
			D3DXMatrixTranslation(&(transformation[PART_TOPLEFT]),-heightMapWidth,0.0f,-heightMapWidth);
			
			//top... 
			D3DXMatrixTranslation(&(transformation[PART_TOP]),0.0f,0.0f,-heightMapWidth);

			//right/top... 
			D3DXMatrixTranslation(&(transformation[PART_TOPRIGHT]),+heightMapWidth,0.0f,-heightMapWidth);

			//left...
			D3DXMatrixTranslation(&(transformation[PART_LEFT]),-heightMapWidth,0.0f,0.0f);
		}
	}

	//center... identity
	D3DXMatrixIdentity(&(transformation[PART_CENTER]));

	if (repeatTiles)
	{
		if (mirroredTiles)
		{
			//right... mirrored at terrainWidth/*/*
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(heightMapWidth,0.0f,0.0f),
									 &D3DXVECTOR3(+1.0f,0.0f,0.0f));
			D3DXMatrixReflect(&(transformation[PART_RIGHT]),&reflectPlane);

			//left/bottom... mirrored at 0/*/terrainWidth
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,heightMapWidth),
									 &D3DXVECTOR3(0.0f,0.0f,-1.0f));
			D3DXMatrixReflect(&tmp,&reflectPlane);
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,heightMapWidth),
									 &D3DXVECTOR3(1.0f,0.0f,0.0f));
			D3DXMatrixReflect(&(transformation[PART_BOTTOMLEFT]),&reflectPlane);
			transformation[PART_BOTTOMLEFT] *= tmp;

			//bottom... mirrored at */*/terrainWidth
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(0.0f,0.0f,heightMapWidth),
									 &D3DXVECTOR3(0.0f,0.0f,-1.0f));
			D3DXMatrixReflect(&(transformation[PART_BOTTOM]),&reflectPlane);

			//bottom/right... mirrored at terrainWidth/*/terrainWidth
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(heightMapWidth,0.0f,heightMapWidth),
									 &D3DXVECTOR3(0.0f,0.0f,-1.0f));
			D3DXMatrixReflect(&tmp,&reflectPlane);
			D3DXPlaneFromPointNormal(&reflectPlane,
									 &D3DXVECTOR3(heightMapWidth,0.0f,heightMapWidth),
									 &D3DXVECTOR3(-1.0f,0.0f,0.0f));
			D3DXMatrixReflect(&(transformation[PART_BOTTOMRIGHT]),&reflectPlane);
			transformation[PART_BOTTOMRIGHT] *= tmp;
		}
		else
		{
			//right... 
			D3DXMatrixTranslation(&(transformation[PART_RIGHT]),heightMapWidth,0.0f,0.0f);
			
			//bottom/left... 
			D3DXMatrixTranslation(&(transformation[PART_BOTTOMLEFT]),-heightMapWidth,0.0f,heightMapWidth);

			//bottom... 
			D3DXMatrixTranslation(&(transformation[PART_BOTTOM]),0.0f,0.0f,heightMapWidth);

			//bottom/right...
			D3DXMatrixTranslation(&(transformation[PART_BOTTOMRIGHT]),heightMapWidth,0.0f,heightMapWidth);

		}
	}
}

/****************************************************************************
** TileCheck getCullingMode
**
** return the correct culling mode for this part
**
** Author: Dirk Plate
****************************************************************************/
D3DCULL TileCheck::getCullingMode(int part)
{
	if (!mirroredTiles)
		return D3DCULL_CCW;	

	switch (part)
	{
	case PART_TOPLEFT: case PART_TOPRIGHT: case PART_CENTER: case PART_BOTTOMLEFT: case PART_BOTTOMRIGHT:
		return D3DCULL_CCW;
		break;
	default: 
		return D3DCULL_CW;
	}
}
