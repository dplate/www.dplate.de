/****************************************************************************
** TileCheck
**
** check the visibility of terrain/sea/river tiles
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(TILECHECK_H)
#define TILECHECK_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include "aabb.h"
#include <set>
#include <list>
#include "../camera/viewfrustum.h"

//basic class for all tiles which this class can check
class Tile
{
public:
	Tile() {pBoundingBox = NULL;}
	virtual AABB* getBoundingBox() {return pBoundingBox;}
protected:
	AABB* pBoundingBox;

};

static const int PART_TOPLEFT     = 0;
static const int PART_TOP         = 1;
static const int PART_TOPRIGHT    = 2;
static const int PART_LEFT	      = 3;
static const int PART_CENTER      = 4;
static const int PART_RIGHT	      = 5;
static const int PART_BOTTOMLEFT  = 6;
static const int PART_BOTTOM      = 7;
static const int PART_BOTTOMRIGHT = 8;

class TileCheck
{
public:
	TileCheck();
	~TileCheck();

	//set the tiles for checking (initialising)
	void setTiles(Tile** pTiles, int size, int heightMapWidth, bool repeatTiles, bool mirroredTiles);

	//updates the visibility lists
	void update();

	//returns true, if tile is in part visible (call behind update!)
	bool isVisible(Tile* pTile, int part);

	//returns true, if tile is in any part visible (call behind update!)
	bool isVisible(Tile* pTile);

	//returns if terrain tiles are mirrored around terrain
	bool areMirroredTiles() {return mirroredTiles;}

	//returns a transformation for one part
	D3DXMATRIX* getTransformation(int part) {return &(transformation[part]);}

	//return the correct culling mode for this part
	D3DCULL getCullingMode(int part);

private:
	struct QuadTreeStruct
	{
		QuadTreeStruct* pChilds[4]; //all childs of these area
		std::list<Tile*> tiles;		//all tiles in this area
		AABB boundingBox;			//the bounding box around this objects
		int size;					//count of tiles in one direction
		bool leaf;					//this is a leaf node (no childs)
	} quadTree;

	//build up quad tree (recursive)
	void buildQuadTree(QuadTreeStruct *node);
	//delete the quad tree (recursive)
	void destroyQuadTree(QuadTreeStruct *node);
	//checks the visibility of quadtree (recursive)
	void checkQuadTree(QuadTreeStruct *node, ViewFrustum *pViewFrustum, D3DXVECTOR3 *pPosition, int part);

	//the tiles should also visible outside terrain (mirrored or not)
	bool repeatTiles;

	//the repeates tile should be mirrored
	bool mirroredTiles;

	//calculates transformations matrices for all part
	void calculateTransformations(int heightMapWidth);

	//set with all visible tiles (for all parts)
	std::set<Tile*> visible[9];

	//visibility of a tile in any part
	std::set<Tile*> commonVisible;

	//transformation matrices for all parts
	D3DXMATRIX transformation[9];
};

#endif

