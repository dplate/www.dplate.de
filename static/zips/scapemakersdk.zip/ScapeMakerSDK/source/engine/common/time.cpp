#include "time.h"
#include "../logger/logger.h"
#include "enginehelpers.h"

Time *Time::instance = NULL;

#define GAME_AVERAGE_COUNT 20
#define ENGINE_AVERAGE_COUNT 20

/****************************************************************************
** Time Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Time::Time()
{
	instance = this;
}

/****************************************************************************
** Time Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Time::~Time()
{
	instance = NULL;
}

/****************************************************************************
** Time init
**
** init all times
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Time::init()
{
	engineAbsTime = 0.0f;
	gameAbsTime = 0.0f;
	engineFrameTime = 0.0f;
	gameFrameTime = 0.0f;
	engineAverageFrameTime = 0.0f;
	gameAverageFrameTime = 0.0f;
	engineMaxFrameTime = 0.0f;
	engineMinFrameTime = 0.0f;
	gameTimeFactor = 1.0f;
	engineFrameTimes.clear();
	gameFrameTimes.clear();

	DXUtil_Timer(TIMER_RESET);
	DXUtil_Timer(TIMER_GETELAPSEDTIME);

	return S_OK;
}

/****************************************************************************
** Time update
**
** add and save last frame time
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Time::update()
{
	//update engine time
	engineFrameTime = DXUtil_Timer(TIMER_GETELAPSEDTIME);
	engineAbsTime += engineFrameTime;

	//add to frame time list
	engineFrameTimes.push_back(engineFrameTime);
	//to many values... delete first one
	if (engineFrameTimes.size() > ENGINE_AVERAGE_COUNT)
		engineFrameTimes.pop_front();

	//find minimum, maximum and average
	engineMaxFrameTime = 0.0f;
	engineMinFrameTime = BIG_NUM;
	engineAverageFrameTime = 0.0f;
	std::list<float>::iterator currentEngineFrameTime = engineFrameTimes.begin();
	while(currentEngineFrameTime != engineFrameTimes.end())
	{
		if (*currentEngineFrameTime > engineMaxFrameTime)
			engineMaxFrameTime = *currentEngineFrameTime;
		if (*currentEngineFrameTime < engineMinFrameTime)
			engineMinFrameTime = *currentEngineFrameTime;
		engineAverageFrameTime += *currentEngineFrameTime;

		currentEngineFrameTime++;
	}
	engineAverageFrameTime /= engineFrameTimes.size();

	//update game time
	gameFrameTime = engineFrameTime*gameTimeFactor;
	gameAbsTime += gameFrameTime;

	//add to frame time list
	gameFrameTimes.push_back(gameFrameTime);
	//to many values... delete first one
	if (gameFrameTimes.size() > GAME_AVERAGE_COUNT)
		gameFrameTimes.pop_front();

	//find average
	gameAverageFrameTime = 0.0f;
	std::list<float>::iterator currentGameFrameTime = gameFrameTimes.begin();
	while(currentGameFrameTime != gameFrameTimes.end())
	{
		gameAverageFrameTime += *currentGameFrameTime;

		currentGameFrameTime++;
	}
	gameAverageFrameTime /= gameFrameTimes.size();

	return S_OK;
}

/****************************************************************************
** Time setGameTimeFactor
**
** set game time factor a value (greater or equal than 0)
**
** Author: Dirk Plate
****************************************************************************/
void Time::setGameTimeFactor(float gameTimeFactor)
{
	if (gameTimeFactor < 0.0f)
		gameTimeFactor = 0.0f;

	this->gameTimeFactor = gameTimeFactor;
}

/****************************************************************************
** Time setGameTimeFactor
**
** implementation of status source (called by status line)
**
** Author: Dirk Plate
****************************************************************************/
std::string Time::getStatusMessage()
{
	char buffer[256];

	sprintf(buffer, "fps: %03.0f, avgFps: %03.0f, minFps: %03.0f, maxFps: %03.0f", 
		1.0f/engineFrameTime,1.0f/engineAverageFrameTime,
		1.0f/engineMaxFrameTime,1.0f/engineMinFrameTime);

	std::string statusMessage(buffer);

	return statusMessage;
}
