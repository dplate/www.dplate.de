/****************************************************************************
** Time
**
** manage all times
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_TIME)
#define H_TIME
#pragma warning(disable:4786)

#include <d3dx9.h>
#include <list>
#include "../hud/statusline.h"

class Time : public StatusSource
{
public:
	Time();
	~Time();

	//init object
	HRESULT init();

	//add and save last frame time
	HRESULT update();

	//set game time factor a value (greater or equal than 0)
	void setGameTimeFactor(float gameTimeFactor);

	//access function
	float getEngineFrameTime() {return engineFrameTime;}
	float getGameFrameTime() {return gameFrameTime;}
	float getEngineAbsTime() {return engineAbsTime;}
	float getGameAbsTime() {return gameAbsTime;}
	float getEngineAverageFrameTime() {return engineAverageFrameTime;}
	float getGameAverageFrameTime() {return gameAverageFrameTime;}
	float getEngineMaxFrameTime() {return engineMaxFrameTime;}
	float getEngineMinFrameTime() {return engineMinFrameTime;}
	float getGameTimeFactor() {return gameTimeFactor;}

	//implementation of status source
	virtual std::string getStatusMessage();

	static Time *instance;				//the instance to the only one time object

private:
	//time for last frame (engine)
	float engineFrameTime;

	//time for last frame (game)
	float gameFrameTime;

	//absolute time from beginning (engine)
	float engineAbsTime;

	//absolute time from beginning (game)
	float gameAbsTime;

	//average frame time (engine)
	float engineAverageFrameTime;

	//average frame time (game)
	float gameAverageFrameTime;

	//minimum frame time (engine)
	float engineMinFrameTime;

	//maximum frame time (engine)
	float engineMaxFrameTime;

	//the factor for game time (relative to engine time)
	float gameTimeFactor;

	//memory for the last n frame times (engine)
	std::list<float> engineFrameTimes;

	//memory for the last n frame times (game)
	std::list<float> gameFrameTimes;
};

#endif