#include "console.h"
#include "../common/enginehelpers.h"
#include "../logger/logger.h"
#include "../input/input.h"
#include "../common/time.h"

//height of console
#define CONSOLE_HISTORY_HEIGHT 175.0f
//number of visible lines in history
#define CONSOLE_LINE_COUNT 8
//height of one line
#define CONSOLE_LINE_HEIGHT 15
//border size
#define CONSOLE_BORDER_WIDTH 10

Console *Console::instance = NULL;

/****************************************************************************
** Console Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Console::Console()
{
	pHistoryVB = NULL;
	pHistoryBackgroundVB = NULL;
	pTipVB = NULL;
	pTipBackgroundVB = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	instance = this;
}

/****************************************************************************
** Console Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Console::~Console()
{
	instance = NULL;
}

/****************************************************************************
** Console createGeometry
**
** init everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Console::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;
	this->pKeyboard = Input::instance->getKeyboard();

	//create font
	font.CreateFont(pD3DDevice, "Times New Roman", 12);

	//no command written
	command = "";
	
	//no chars in history
	messages.clear();
	scrollPosition = 0;
	pHistoryVB = NULL;
	historyCharCount = 0;

	//create the history background vertex buffer
	pHistoryBackgroundVB = createRectangle(pHistoryBackgroundVB, 0.0f, 0.0f, 600.0f, CONSOLE_HISTORY_HEIGHT);

	//no last commands
	lastCommands.clear();
	currentLastCommand = lastCommands.end();

	//no chars in tip
	tips.clear();
	pTipVB = NULL;
	tipCharCount = 0;

	//create state blocks to change the render states
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetTexture(0, NULL);
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,			D3DCULL_CW);
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,	TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,			D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,			D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ZENABLE,			FALSE);
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,		FALSE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);
		//pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		//pD3DDevice->SetTextureStageState(0,					D3DTSS_COLOROP, D3DTOP_MODULATE);
		//pD3DDevice->SetTextureStageState(0,					D3DTSS_COLORARG2, D3DTA_DIFFUSE);
		pD3DDevice->SetFVF(D3DFVF_CONSOLEVERTEX);
				
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("State block created OK");

	//cursor unvisible
	cursor = false;
	cursorTime = 0.0f;

	//console is not open by default
	openFlag = false;

	return S_OK;
}

/****************************************************************************
** Console destroyGeometry
**
** destroy everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Console::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//no more exlusive control
	pKeyboard->setExclusiveMode(this, false);

	//delete history vertex buffer
	if (pHistoryVB != NULL)
	{
		font.DestroyStaticText(pHistoryVB);
		pHistoryVB = NULL;
	}

	//delete history background vertex buffer
	if (pHistoryBackgroundVB)
		SAFE_RELEASE(pHistoryBackgroundVB);

	//delete tip vertex buffer
	if (pTipVB != NULL)
	{
		font.DestroyStaticText(pTipVB);
		pTipVB = NULL;
	}

	//delete tip background vertex buffer
	if (pTipBackgroundVB)
		SAFE_RELEASE(pTipBackgroundVB);
		
	//delete state blocks
	if(pStateBlock)
		SAFE_RELEASE(pStateBlock);
		
	if (pSavedStateBlock)
		SAFE_RELEASE(pSavedStateBlock);
		
	//delete list
	messages.clear();

	//destroy font
	font.DestroyFont();

	return S_OK;
}

/****************************************************************************
** Console update
**
** update everything
**
** Author: Dirk Plate
****************************************************************************/
std::string	Console::update()
{
	//this command will be returned
	std::string commandToCall = "";

	//check key inputs
	
	//console open/close pressed
	if (pKeyboard->getKeyState(this,DIK_GRAVE) == Keyboard::KeyState::NEWPRESSED)
	{
		//toggle to open?
		if (!openFlag)
		{
			open();
		}
		else
		{
			close();
		}

		return "";
	}

	if (openFlag)
	{
		//add time for cursor blinking
		cursorTime += Time::instance->getEngineFrameTime();
		if (int(cursorTime*3)%2 == 0)
			cursor = false;
		else cursor = true;

		//create new tips or not
		bool recreateTips = false;
		//create new history or not
		bool recreateHistory = false;

		//check written characters
		std::string character = pKeyboard->getASCII(this);
		if (character != "")
		{
			//add characters to command
			command += character;
			recreateTips = true;
		}
		//Backspace
		else if (pKeyboard->getKeyState(this,DIK_BACKSPACE) == Keyboard::KeyState::NEWPRESSED)
		{
			//delete character
			if (command.size() > 0)
			{
				command = command.substr(0, command.size()-1);
				recreateTips = true;
			}
		}
		//Return
		else if ((pKeyboard->getKeyState(this,DIK_RETURN) == Keyboard::KeyState::NEWPRESSED) || 
				 (pKeyboard->getKeyState(this,DIK_NUMPADENTER) == Keyboard::KeyState::NEWPRESSED))
		{
			if (command != "")
			{
				//send command to script
				commandToCall = command;
				
				//save command in lastCommands
				lastCommands.push_back(command);
				currentLastCommand = lastCommands.end();

				//clear command
				command = "";
				recreateTips = true;
			}
		}
		//Tab
		else if (pKeyboard->getKeyState(this,DIK_TAB) == Keyboard::KeyState::NEWPRESSED)
		{
			//take longest identical part of tips as command
			if (tips.size() > 0)
			{
				command = findLongestIdenticalTipPart();
				recreateTips = true;
			}
		}
		//Arrow up
		else if (pKeyboard->getKeyState(this,DIK_UP) == Keyboard::KeyState::NEWPRESSED)
		{
			//set command to prior last command
			if ((lastCommands.size()>0) && (currentLastCommand != lastCommands.begin()))
			{
				currentLastCommand--;
				command = *currentLastCommand;
				recreateTips = true;
			}
		}
		//Arrow down
		else if (pKeyboard->getKeyState(this,DIK_DOWN) == Keyboard::KeyState::NEWPRESSED)
		{
			//set command to prior last command
			if (currentLastCommand != lastCommands.end())
			{
				currentLastCommand++;
				if (currentLastCommand == lastCommands.end())
					command = "";
				else
					command = *currentLastCommand;
				recreateTips = true;
			}
		}
		//Page up
		else if (pKeyboard->getKeyState(this,DIK_PGUP) == Keyboard::KeyState::NEWPRESSED)
		{
			//scroll up (if not top)
			if (scrollPosition > 0)
			{
				scrollPosition--;
				recreateHistory = true;
			}
		}
		//Page down
		else if (pKeyboard->getKeyState(this,DIK_PGDN) == Keyboard::KeyState::NEWPRESSED)
		{
			//scroll down (if not bottom)
			if (scrollPosition < ((int)messages.size()-CONSOLE_LINE_COUNT))
			{
				scrollPosition++;
				recreateHistory = true;
			}
		}

		//generate new tips
		if (recreateTips)
			createTips(command);

		//generate new history
		if (recreateHistory)
			rebuildHistory();
	}
	
	return commandToCall;
}

/****************************************************************************
** Console render
**
** renders everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Console::render()
{
	HRESULT hr;

	//if not open... do nothing
	if (!openFlag)
		return S_OK;

	//record and set the render states
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	if (pHistoryBackgroundVB != NULL)
	{
		//set vertex stream
		pD3DDevice->SetStreamSource(0, pHistoryBackgroundVB, NULL, sizeof(CONSOLEVERTEX));
		//render history background
		if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			LOG("Rendering history background failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//render tip
	if (pTipBackgroundVB != NULL)
	{
		//set vertex stream
		pD3DDevice->SetStreamSource(0, pTipBackgroundVB, NULL, sizeof(CONSOLEVERTEX));
		//render tip background
		if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			LOG("Rendering tip background failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//Restore the states
	pSavedStateBlock->Apply();

	//render history
	if (pHistoryVB != NULL)
	{
		font.DrawStaticText(pHistoryVB, 0, historyCharCount);
	}

	//draw current command
	std::string commandWithCursor = command;
	if (cursor) commandWithCursor += "_";
	font.DrawText(CONSOLE_BORDER_WIDTH, 
		          CONSOLE_HISTORY_HEIGHT-CONSOLE_BORDER_WIDTH-CONSOLE_LINE_HEIGHT, 
				  commandWithCursor.c_str(), 0x00000000);

	//render tip
	if (pTipVB != NULL)
	{
		font.DrawStaticText(pTipVB, 0, tipCharCount);
	}
	
	return S_OK;
}

/****************************************************************************
** Console addMessage
**
** adds a message to console history
**
** Author: Dirk Plate
****************************************************************************/
void Console::addMessage(std::string &message)
{
	//add it to list
	messages.push_back(message);

	//scroll down
	scrollPosition = (int)messages.size()-CONSOLE_LINE_COUNT;
	if (scrollPosition < 0) 
		scrollPosition = 0;

	//rebuild history
	rebuildHistory();
}

/****************************************************************************
** Console rebuildHistory
**
** rebuild history vertex buffer
**
** Author: Dirk Plate
****************************************************************************/
void Console::rebuildHistory()
{
	//whole history in one string
	std::string historyString;

	//calculate empty line before text
	int emptyLines = CONSOLE_LINE_COUNT-messages.size();

	//add right count of empty line to beginning
	for (int line = 0; line < emptyLines; line++)
		historyString += "\n";
	
	//add all messages in history
	historyCharCount = 0;
	int index = 0;
	for (std::list<std::string>::iterator i = messages.begin(); i != messages.end(); i++)
	{
		//add only lines in visible range
		if ((index >= scrollPosition) && (index < scrollPosition+CONSOLE_LINE_COUNT))
		{
			//add it
			historyString += *i + "\n";
			historyCharCount += i->size();
		}
		index++;
	}

	//delete old vertex buffer
	if (pHistoryVB != NULL)
		font.DestroyStaticText(pHistoryVB);

	//create vertex buffer
	pHistoryVB = font.CreateStaticText(CONSOLE_BORDER_WIDTH, CONSOLE_BORDER_WIDTH, historyString.c_str(), 0x00000000);
}

/****************************************************************************
** Console createTipList
**
** creates the tips list
**
** Author: Dirk Plate
****************************************************************************/
void Console::createTips(std::string commandPart)
{
	//delete old tip list
	tips.clear();

	//prefix already written?
	int pointPos = commandPart.find_first_of(".",0);
	
	//no . -> no prefix
	if (pointPos >= commandPart.size())
	{
		//get part of prefix
		std::string prefixPart = commandPart.substr(0, commandPart.size());

		//search for a nice prefix
		for (int i=0; i<COMMANDS_COUNT; i++)
		{
			//get prefix
			std::string prefixTest(commands[i].prefix);
			
			//prefix begins with command part?
			std::string prefixPartTest = prefixTest.substr(0,prefixPart.size());
			if (prefixPartTest == prefixPart)
			{
				//add to list
				tips.push_back(prefixTest + ".");
			}
		}
	}
	//prefix written
	else
	{
		//get prefix
		std::string prefix = commandPart.substr(0, pointPos);
		//get part of method
		std::string methodPart = commandPart.substr(pointPos+1, commandPart.size());

		//prefix already written?
		int bracketPos = methodPart.find_first_of("(",0);

		//no ( -> no method
		if (bracketPos >= methodPart.size())
		{
			//search for a nice method
			for (int i=0; i<COMMANDS_COUNT; i++)
			{
				//only methods with right prefix
				if (prefix == std::string(commands[i].prefix))
				{
					//get method
					std::string methodTest(commands[i].method);

					//method begins with method part
					std::string methodPartTest = methodTest.substr(0,methodPart.size());
					if (methodPart == methodPartTest)
					{
						//add to list
						tips.push_back(prefix + "." + methodTest + "(");
					}
				}
			}
		}
		//method written
		else
		{
			//get method
			std::string method = methodPart.substr(0, bracketPos);

			//search for nice parameter info
			for (int i=0; i<COMMANDS_COUNT; i++)
			{
				//only methods with right prefix
				if (prefix == std::string(commands[i].prefix))
				{
					//only methods with right method
					if (method == std::string(commands[i].method))
					{
						//add parameter info to list
						tips.push_back(prefix + "." + method + std::string(commands[i].parameter));
					}
				}
			}
		}
	}

	//sort list
	tips.sort();
	
	//remove duplicates
	tips.unique();

	//rebuild vertexbuffer
	//whole tips in one string
	std::string tipString;

	//add all messages in history
	tipCharCount = 0;
	for (std::list<std::string>::iterator i = tips.begin(); i != tips.end(); i++)
	{
		//add it
		tipString += *i + "\n";
		tipCharCount += i->size();
	}

	//delete old vertex buffer
	if (pTipVB != NULL)
	{
		font.DestroyStaticText(pTipVB);
		pTipVB = NULL;
	}

	//release old background vertex buffer
	SAFE_RELEASE(pTipBackgroundVB);

	//create new tip... if something in tips
	if (tips.size() > 0)
	{
		//create vertex buffer
		float width, height;
		pTipVB = font.CreateStaticText(CONSOLE_BORDER_WIDTH, CONSOLE_HISTORY_HEIGHT, 
			tipString.c_str(), 0x00000000, &width, &height);

		//create nice background
		pTipBackgroundVB = createRectangle(pTipBackgroundVB, 
			CONSOLE_BORDER_WIDTH/2, 
			CONSOLE_HISTORY_HEIGHT - CONSOLE_BORDER_WIDTH/2,
			CONSOLE_BORDER_WIDTH/2 + width + CONSOLE_BORDER_WIDTH,
			CONSOLE_HISTORY_HEIGHT + height + CONSOLE_BORDER_WIDTH/2);
	}
}

/****************************************************************************
** Console createRectangle
**
** creates a rectangle vertex buffer
**
** Author: Dirk Plate
****************************************************************************/
LPDIRECT3DVERTEXBUFFER9 Console::createRectangle(LPDIRECT3DVERTEXBUFFER9 pVB, float left, float top, float right, float bottom)
{
	//release old vertex buffer
	SAFE_RELEASE(pVB);
	
	//create the history background vertex buffer
	if(FAILED(pD3DDevice->CreateVertexBuffer(4 * sizeof(CONSOLEVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_CONSOLEVERTEX, D3DPOOL_DEFAULT,
										     &pVB, NULL)))
		return NULL;

	//fill history background vertex buffer
	CONSOLEVERTEX* pVertices = NULL;
	pVB->Lock(0, 4 * sizeof(CONSOLEVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD);

	pVertices[0].x = left;
	pVertices[0].y = top;
	pVertices[0].z = 1.0f;
	pVertices[0].rhw = 1.0f;
	pVertices[0].color = 0xA0A0A0A0;
	
	pVertices[1].x = left;
	pVertices[1].y = bottom;
	pVertices[1].z = 1.0f;
	pVertices[1].rhw = 1.0f;
	pVertices[1].color = 0xA0A0A0A0;
	
	pVertices[2].x = right;
	pVertices[2].y = top;
	pVertices[2].z = 1.0f;
	pVertices[2].rhw = 1.0f;
	pVertices[2].color = 0xA0A0A0A0;
	
	pVertices[3].x = right;
	pVertices[3].y = bottom;
	pVertices[3].z = 1.0f;
	pVertices[3].rhw = 1.0f;
	pVertices[3].color = 0xA0A0A0A0;

	pVB->Unlock();

	return pVB;
}

/****************************************************************************
** Console open
**
** opens console
**
** Author: Dirk Plate
****************************************************************************/
bool Console::open()
{
	//set boolean
	openFlag = true;

	//delete command
	command = "";
	
	//generate new tips
	createTips(command);
	
	//exclusive control now
	pKeyboard->setExclusiveMode(this, true);

	return true;
}

/****************************************************************************
** Console close
**
** closes console
**
** Author: Dirk Plate
****************************************************************************/
bool Console::close()
{
	//set boolean
	openFlag = false;

	//no more exclusive control
	pKeyboard->setExclusiveMode(this, false);

	return true;
}

/****************************************************************************
** Console findLongestIdenticalTipPart
**
** find longest part of tip, which identical in all tips
**
** Author: Dirk Plate
****************************************************************************/
std::string Console::findLongestIdenticalTipPart()
{
	std::list<std::string>::iterator currentTip;
	int currentLength = 0;
	std::string tipPart = "";
	std::string testTipPart1;
	std::string testTipPart2;
	bool allRight;

	//add a char until only one tip math
	while(1)
	{
		//get first tip
		currentTip = tips.begin();

		//add a char
		currentLength++;

		//first tip not enough characters?
		if (currentLength > currentTip->size())
			break;

		//copy part
		testTipPart1 = currentTip->substr(0,currentLength);

		//check other tips
		allRight = true;
		while(currentTip != tips.end())
		{
			//tip not enough characters?
			if (currentLength > currentTip->size())
			{
				allRight = false;
				break;
			}

			//copy part
			testTipPart2 = currentTip->substr(0,currentLength);

			//if different... break
			if (testTipPart1 != testTipPart2)
			{
				allRight = false;
				break;
			}

			//check next tip
			currentTip++;
		}

		//all right?
		if (allRight)
		{
			//save new part
			tipPart = testTipPart1;
		}
		//not all right?
		else
		{
			//stop searching
			break;
		}
	}

	return tipPart;
}