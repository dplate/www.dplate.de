/****************************************************************************
** Console
**
** manage console
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_CONSOLE)
#define H_CONSOLE
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <list>
#include <string>

#include "../scripts/commands.h"
#include "../common/DirectXFont.h"
#include "../input/keyboard.h"

struct CONSOLEVERTEX 
{ 
	float x, y, z, rhw;
	DWORD color;
};

#define D3DFVF_CONSOLEVERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE)

class Console
{
public:
	Console();
	~Console();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();
	HRESULT render();
	std::string update();

	//adds a message to console
	void addMessage(std::string &message);

	//opens console
	bool open();
	//closes console
	bool close();

	static Console *instance;				//the instance to the only one console objects

private:
	//rebuild history vertex buffer
	void rebuildHistory();

	//creates a rectangle vertex buffer
	LPDIRECT3DVERTEXBUFFER9 createRectangle(LPDIRECT3DVERTEXBUFFER9 pVB, float left, float top, float right, float bottom);

	//creates the list with tips
	void createTips(std::string commandPart);

	//find longest part of tip, which identical in all tips
	std::string findLongestIdenticalTipPart();

	//history
	//all messages in history
	std::list<std::string> messages;
	//current scroll position in history
	int scrollPosition;
	//current history vertex buffer (all texts)
	LPDIRECT3DVERTEXBUFFER9 pHistoryVB;
	//number of chars in history
	int historyCharCount;
	//background of history
	LPDIRECT3DVERTEXBUFFER9 pHistoryBackgroundVB;

	//tip
	//all current lip lines
	std::list<std::string> tips;
	//current tip vertex buffer (all texts)
	LPDIRECT3DVERTEXBUFFER9 pTipVB;
	//number of chars in tip
	int tipCharCount;
	//background of tip
	LPDIRECT3DVERTEXBUFFER9 pTipBackgroundVB;

	//Direct3D device
	LPDIRECT3DDEVICE9 pD3DDevice;

	//the keyboard input access object
	Keyboard *pKeyboard;

	//font class for writing things out
	CDirectXFont font;

	//own state block
	LPDIRECT3DSTATEBLOCK9 pStateBlock;
	LPDIRECT3DSTATEBLOCK9 pSavedStateBlock;

	//console is open or not
	bool openFlag;

	//current written command
	std::string command;

	//all last commands
	std::list<std::string> lastCommands;
	std::list<std::string>::iterator currentLastCommand;

	//show cursor or not (blink)
	bool cursor;
	float cursorTime;
};

#endif