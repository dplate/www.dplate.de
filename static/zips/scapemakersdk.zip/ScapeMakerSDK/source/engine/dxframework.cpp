/****************************************************************************
** DirectX Framework
**
** handles all the basic DirectX stuff (initialization ...)
** 
** Author: Matthias Buchetics
****************************************************************************/

#include "DxFramework.h"
#include "./common/dxutil.h"
#include <dxerr9.h>
#include "./logger/logger.h"

/****************************************************************************
** DirectX Framework Constructor
**
** inits the member variables (later some of these should be set with an
** .ini file
** 
** Author: Matthias Buchetics
****************************************************************************/
DxFramework::DxFramework()
{
	LOGFUNC("DxFramework()");
	
	// set window size
	windowWidth  = 640;
	windowHeight = 480;
	fullscreenWidth  = 640;
	fullscreenHeight = 480;
	fullscreenRefresh = 60;
	backBufferFormat = D3DFMT_R5G6B5;

	// set fullscreen size and refresh rate (e.g. 60 hz)
	MiniXML xmlFile;
	string configPath = "./enginefiles/config.txt";
	if (xmlFile.openFile(configPath.c_str(),MiniXML::READ))
	{
		int iValue;
		if (xmlFile.readInteger("width",&iValue))
			fullscreenWidth = iValue;
		if (xmlFile.readInteger("height",&iValue))
			fullscreenHeight = iValue;
		if (xmlFile.readInteger("refreshRate",&iValue))
			fullscreenRefresh = iValue;
		if (xmlFile.readInteger("format",&iValue))
			backBufferFormat = D3DFORMAT(iValue);
		if (xmlFile.readInteger("antialiasing",&iValue))
			fullscreenAntialiasing = D3DMULTISAMPLE_TYPE(iValue);
		
		xmlFile.closeFile();
	}

	// software or hardware (requires a T&L card) vertex processing?
	//check of capability later in setPresentParameters!
	behavior = D3DCREATE_HARDWARE_VERTEXPROCESSING;

	// init the variables
	keyboardEnabled = TRUE;
	mouseEnabled = TRUE;
}

/****************************************************************************
** DirectX Framework Update
**
** the update function is called every frame and calls the important 
** engine functions (prerender, render, postrender ...).
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::update(char* pKeyBuffer, int keyCount, UpdateReturns *pReturnValues)
{	
	HRESULT hr;

	// call PreRender first
	preRender();

	// call the main render function
	if (FAILED(hr=render()))
	{
		LOG("Rendering failed", Logger::LOG_CRIT);
		return hr;
	}

	// present the back buffer contents to the display
	if (FAILED(hr=postRender()))
	{
		//if we lose the device, let the device class get it back
		if (hr == D3DERR_DEVICELOST)
		{
			// do any pre-cleanup
			if (FAILED(hr=preReset()))
			{
				LOG("Pre-resetting failed", Logger::LOG_CRIT);
				return hr;
			}

			// clean up the font
			fpsFont.DestroyFont();

			//if fullscreen... close fullscreen window
			if (!windowed)
			{
				CloseWindow(hWndFullscreen);
			}
			
			// let the device class reset the device
			if (FAILED(hr=restoreDevice()))
			{
				LOG("Restoring device failed", Logger::LOG_CRIT);
				return hr;
			}

			//if fullscreen... show fullscreen window
			if (!windowed)
			{
				ShowWindow(hWndFullscreen,SW_RESTORE);
			}

			// tell the rest of the app that this has happened
			if (FAILED(hr=postReset()))
			{
				LOG("Post-resetting failed", Logger::LOG_CRIT);
				return hr;
			}

			// rebuild the font
			fpsFont.CreateFont(pD3DDevice, "Times New Roman", 12);
		}
		else
		{
			LOG("Post-rendering failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	return S_OK;
}

/****************************************************************************
** DirectX Framework Terminate
**
** destroys the created objects and d3d device.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::terminate()
{
	HRESULT hr;

	LOGFUNC("terminate()");

	try
	{
		// call the PreTerminate function in case there is any 
		// pre-cleanup to do.
		if (FAILED(hr=preTerminate()))
		{
			LOG("Pre-terminating failed", Logger::LOG_CRIT);
			return hr;
		}

		// destroy the font
		fpsFont.DestroyFont();

		// destroy the Device
		if (FAILED(hr=destroyDevice()))
		{
			LOG("Destroying device failed", Logger::LOG_CRIT);
			return hr;
		}

		if (FAILED(hr=terminateDI()))
		{
			LOG("Terminating direct input failed", Logger::LOG_CRIT);
			return hr;
		}

		// call the PostTerminate function in case there is any 
		// post-cleanup to do.
		if (FAILED(hr=postTerminate()))
		{
			LOG("Post-terminating failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	//catch unhandled errors
	catch(...)
	{
		LOG("Unhandled error", Logger::LOG_CRIT);
		return E_FAIL;
	}

	return S_OK;
}

/****************************************************************************
** DirectX Framework Start
**
** is called once and creates the d3d object and device. called from
** the main function of the app.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::start(HWND hWndWindowed, HWND hWndFullscreen, HWND hWndTop, bool windowed)
{
	LOGFUNC("start()");

	HRESULT hr;

	try
	{
		// stores the window handles
		this->hWndWindowed = hWndWindowed;
		this->hWndFullscreen = hWndFullscreen;
		this->hWndTop = hWndTop;

		// call the PreInitialize function to allow any children
		// to preset anything
		if (FAILED (hr = preInitialize()))
		{
			LOG(DXGetErrorDescription9(hr), Logger::LOG_CRIT);
			return hr;
		}

		// initialize the D3D object
		if (FAILED (hr = initializeD3D()))
		{
			LOG(DXGetErrorDescription9(hr), Logger::LOG_CRIT);
			return hr;
		}

		// initialize the DI object
		if (FAILED (hr = initializeDI()))
		{
			LOG(DXGetErrorDescription9(hr), Logger::LOG_CRIT);
			return hr;
		}

		//init render target
		if (FAILED (hr = setupRenderTarget(windowed)))
		{
			LOG(DXGetErrorDescription9(hr), Logger::LOG_CRIT);
			return hr;
		}

		// call the PostIinitialize function to allow any children
		// to continue initializing anything
		if (FAILED (hr = postInitialize()))
		{
			LOG(DXGetErrorDescription9(hr), Logger::LOG_CRIT);
			return hr;
		}

		// initialize the font
		fpsFont.CreateFont(pD3DDevice, "Times New Roman", 12);

		//save size of window
		RECT windowRect;
		GetClientRect(hWndWindowed, &windowRect);
		windowWidth = windowRect.right - windowRect.left;
		windowHeight = windowRect.bottom - windowRect.top;
	}
	//catch all unhandled errors
	catch(...)
	{
		LOG("Unhandled error", Logger::LOG_CRIT);
		return E_FAIL;
	}

	return S_OK;
}

/****************************************************************************
** DirectX Framework PreRender
**
** handles everything that happens before rendering, such as clearing the
** buffers. the function must call BeginScene.
** 
** Author: Matthias Buchetics
****************************************************************************/
void DxFramework::preRender()
{
	//Call BeginScene to set up the device
	pD3DDevice->BeginScene();
		
	return;
}

/****************************************************************************
** DirectX Framework PostRender
**
** is called after the rendering process and therefore must call EndScene.
** returns the result of PreSent so that the device restoration functions
** knows what do to (e.g. restore the device if it is lost).
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::postRender()
{
	// End the scene
	pD3DDevice->EndScene();

	return pD3DDevice->Present(NULL, NULL, NULL, NULL);
}

/****************************************************************************
** DirectX Framework Destructor
**
** over and out, releases the d3d object. and winks goodbye.
** 
** Author: Matthias Buchetics
****************************************************************************/
DxFramework::~DxFramework()
{
	LOGFUNC("~DxFramework()");
	
	// release the D3D object
	if (pD3D)
	{
		int references = pD3D->Release();
	}

	pD3D = NULL;
}

/****************************************************************************
** DirectX Framework InitializeD3D
**
** create the d3d object, nothing else.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::initializeD3D()
{
	LOGFUNC("initializeD3D()");
	
	// create the actual D3D object.
	pD3D = Direct3DCreate9(D3D_SDK_VERSION);

	// set the default device value to NULL
	pD3DDevice = NULL;

	LOG("D3D9 Object Created");

	// return a default value
	return S_OK;
}

/****************************************************************************
** DirectX Framework InitializeDI
**
** create the direct input objects and devices
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::initializeDI()
{
	LOGFUNC("initializeDI()");
	
	HRESULT hr; 
 
    // Create the DirectInput object. 
    if (FAILED (hr = DirectInput8Create(GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                            IID_IDirectInput8, (void**)&pDI, NULL)))    
		return hr; 
 
    // Retrieve a pointer to an IDirectInputDevice8 interface 
    if (FAILED (hr = pDI->CreateDevice(GUID_SysKeyboard, &pDIKeyDevice, NULL)))
    { 
        terminateDI(); 
        return hr; 
    } 

	if (FAILED (hr = pDI->CreateDevice(GUID_SysMouse, &pDIMouseDevice, NULL)))
	{
		terminateDI(); 
		return hr;
	}
 
    // Now that you have an IDirectInputDevice8 interface, get 
    // it ready to use. 
 
    // Set the data format using the predefined keyboard data 
    // format provided by the DirectInput object for keyboards. 
    
    if (FAILED (hr = pDIKeyDevice->SetDataFormat(&c_dfDIKeyboard)))
    { 
        terminateDI(); 
        return hr; 
    } 

	if (FAILED (hr = pDIMouseDevice->SetDataFormat(&c_dfDIMouse2)))
	{
		terminateDI();
		return hr;
	}

 
    // Set the cooperative level 
    if (FAILED (hr = pDIKeyDevice->SetCooperativeLevel(hWndTop, 
                             DISCL_BACKGROUND  | DISCL_NONEXCLUSIVE)))
    { 
        terminateDI(); 
        return hr; 
    } 

	// Set the cooperative level 
    if (FAILED (hr = pDIMouseDevice->SetCooperativeLevel(hWndTop, 
                             DISCL_BACKGROUND  | DISCL_NONEXCLUSIVE)))
    { 
        terminateDI(); 
        return hr; 
    } 
 
    // Get access to the input device. 
    if (FAILED (hr = pDIKeyDevice->Acquire()))
    { 
		terminateDI(); 
        return hr; 
    } 

	 // Get access to the input device. 
    if (FAILED (hr = pDIMouseDevice->Acquire()))
    { 
		terminateDI(); 
        return hr; 
    } 

	LOG("DI Object Created");

	// return a default value
	return S_OK;
}

/****************************************************************************
** DirectX Framework TerminateDI
**
** destroys the direct input objects
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::terminateDI()
{
	if (pDI) 
    { 
        if (pDIKeyDevice) 
        { 
			// Always unacquire device before calling Release(). 
            pDIKeyDevice->Unacquire(); 
            pDIKeyDevice->Release();
            pDIKeyDevice = NULL; 
        } 

		if (pDIMouseDevice) 
        {  
            pDIMouseDevice->Unacquire(); 
            pDIMouseDevice->Release();
            pDIMouseDevice = NULL; 
        } 

        pDI->Release();
        pDI = NULL; 
    } 

	
	return S_OK;
}

/****************************************************************************
** DirectX Framework CreateDevice
**
** creates the d3d device with the given parameters, called by the
** easy create windowed and fullscreen functions.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::createDevice(
			D3DDEVICE_CREATION_PARAMETERS *pCreateParms,
			D3DPRESENT_PARAMETERS         *pPresentParms)
{
	LOGFUNC("createDevice()");
	
	//Save the parameter blocks
	memcpy(&creationParameters, pCreateParms, 
		   sizeof(D3DDEVICE_CREATION_PARAMETERS));
	memcpy(&presentParameters, pPresentParms,
		   sizeof(D3DPRESENT_PARAMETERS));

	//Create the device
	return pD3D->CreateDevice(pCreateParms->AdapterOrdinal, 
		                        pCreateParms->DeviceType,
						        pCreateParms->hFocusWindow,
						        pCreateParms->BehaviorFlags,
						        pPresentParms,
						        &pD3DDevice);
}

/****************************************************************************
** DirectX Framework DestroyDevice
**
** we created it, now we destroy it.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::destroyDevice()
{
	LOGFUNC("destroyDevice()");
	
	// release the D3D Device
	if (pD3DDevice)
	{
		int references = pD3DDevice->Release();
	}

	pD3DDevice = NULL;

	// return a default value
	return S_OK;
}

/****************************************************************************
** DirectX Framework RestoreDevice
**
** restore the device, if it was lost.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::restoreDevice()
{
	LOGFUNC("restoreDevice()");
	
	HRESULT result = pD3DDevice->TestCooperativeLevel();

	//If the device is lost, enter a loop waiting for
	//it to be restored.
	while(result == D3DERR_DEVICELOST)
	{
		//Keep testing the level until it says we 
		//can reset.
		while(result != D3DERR_DEVICENOTRESET)
		{
			//Give up control to other applications
			Sleep(1000);

			//Pump messages in order to respond to messages
			//that may lead to restoration.
			MSG message;
			PeekMessage(&message, 0, 0, 0, PM_REMOVE);
			TranslateMessage(&message);
			DispatchMessage(&message);

			//Check to see if things are ready to be reset
			result = pD3DDevice->TestCooperativeLevel();
		}

		//Reset the device using the saved parameters
		if (FAILED(pD3DDevice->Reset(&presentParameters)))
			result = D3DERR_DEVICELOST;
	}	

	return S_OK;
}

/****************************************************************************
** DirectX Framework EasyCreateWindowed
**
** create the device to render into an window.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::easyCreateWindowed()
{
	LOGFUNC("easyCreateWindowed()");

	HRESULT hr;

	//set present parameters
	if (FAILED(hr=setPresentParameters(true)))
	{
		return hr;
	}
	
	creationParameters.AdapterOrdinal = D3DADAPTER_DEFAULT;
	creationParameters.DeviceType     = D3DDEVTYPE_HAL;
	creationParameters.hFocusWindow   = hWndTop;
	creationParameters.BehaviorFlags  = behavior;
	
	if (FAILED(hr=createDevice(&creationParameters, &presentParameters)))
	{
		//retry creation (maybe back buffer count is corrected
		if (FAILED(hr=createDevice(&creationParameters, &presentParameters)))
		{
			LOG("Window device creation failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	
	LOG("Windowed device created");
	
	return S_OK;
}

/****************************************************************************
** DirectX Framework EasyCreateFullScreen
**
** create the device to render into a fullscreen window.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::easyCreateFullScreen()
{
	LOGFUNC("easyCreateFullScreen()");

	HRESULT hr;

	//set present parameters
	if (FAILED(hr=setPresentParameters(false)))
	{
		return hr;
	}

	creationParameters.AdapterOrdinal = D3DADAPTER_DEFAULT;
	creationParameters.DeviceType     = D3DDEVTYPE_HAL;
	creationParameters.hFocusWindow   = hWndTop;
	creationParameters.BehaviorFlags  = behavior;
	
	if (FAILED(hr = createDevice(&creationParameters, &presentParameters)))
	{
		//retry creation (maybe back buffer count is corrected
		if (FAILED(hr=createDevice(&creationParameters, &presentParameters)))
		{
			LOG("Fullscreen device creation failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	
	LOG("Fullscreen device created");
	
	return S_OK;
}

/****************************************************************************
** DirectX Framework SetupRenderTarget
**
** calls the create window or fullscreen functions, called at app start.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::setupRenderTarget(BOOL windowed)
{	
	LOGFUNC("setupRenderTarget()");

	HRESULT hr;
	
	// store if we render into window or fullscreen
	this->windowed = windowed;

	// create a windowed device
	if(windowed)
	{
		if (FAILED(hr=easyCreateWindowed()))
		{
			LOG("Creating window mode failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	// we render fullscreen, yipee
	else
	{
		if (FAILED(hr=easyCreateFullScreen()))
		{
			LOG("Creating full screen mode failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	// everything went fine, continue with interesting stuff
	return S_OK;
}

/****************************************************************************
** DirectX Framework SwitchRenderTarget
**
** switch from window to fullscreen or vice versa. resets the device.
** 
** Author: Matthias Buchetics
****************************************************************************/
HRESULT DxFramework::switchRenderTarget()
{
	LOGFUNC("switchRenderTarget()");
	HRESULT hr;
	
	// destroy all device dependend objects (textures, vertex buffer, fonts ...)
	if (FAILED(hr=preReset()))
	{
		LOG("Pre-resetting failed", Logger::LOG_CRIT);
		return hr;
	}
	fpsFont.DestroyFont();
	
	// SWITCH TO FULLSCREEN
	if(windowed)
	{
		LOG("Switching to fullscreen...", Logger::LOG_INFO);

		if (FAILED(hr=setPresentParameters(false)))
			return hr;
	}

	// SWITCH TO WINDOWED
	else
	{
		LOG("Switching to window...", Logger::LOG_INFO);

		if (FAILED(hr=setPresentParameters(true)))
			return hr;
	}


	// reset the device, fails if not all device depended objects
	// were destroyed
	if (FAILED(hr=pD3DDevice->Reset(&presentParameters)))
	{
		LOG("Switching render target failed", Logger::LOG_CRIT);
		return hr;
	}

	// re-create all the objects we destroyed before resetting the device
	if (FAILED(hr=postReset()))
	{
		LOG("Post-resetting failed", Logger::LOG_CRIT);
		return hr;
	}

	//rebuild the font
	fpsFont.CreateFont(pD3DDevice, "Times New Roman", 12);

	LOG("Switching render target OK");
	return S_OK;
}

/****************************************************************************
** DirectX Framework setPresentParameters
**
** Set present parameter to right value for windowed or fullscreen mode
** 
** Author: Dirk Plate
****************************************************************************/
HRESULT DxFramework::setPresentParameters(bool windowMode)
{
	HRESULT hr;

	//set best vertex processing mode
	D3DCAPS9 caps;
	// Check the capabilities...store into "caps"...
	if FAILED(hr=pD3D->GetDeviceCaps( 0, D3DDEVTYPE_HAL, &caps ) )
	{
		LOG("Retrieving caps failed", Logger::LOG_CRIT);
		return hr;
	}
	// check if hardware TnL is supported...
	if ((caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT ) != 0)
		behavior = D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else behavior = D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	//check depth buffer support.
	D3DFORMAT newDepthBufferFormat = D3DFMT_D24S8;
	if (FAILED(hr=pD3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,backBufferFormat, 
                                          D3DUSAGE_DEPTHSTENCIL,D3DRTYPE_SURFACE,newDepthBufferFormat)))
	{
		LOG("Depth buffer format not supported, switching to 16bit", Logger::LOG_WARN);
		newDepthBufferFormat = D3DFMT_D16;
	}
	//check stencil buffer support
	else if (FAILED(hr=pD3D->CheckDepthStencilMatch(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,backBufferFormat,
											   backBufferFormat,D3DFMT_D24S8)))
	{
		LOG("Stencil buffer format not supported, switching to 16bit", Logger::LOG_WARN);
		newDepthBufferFormat = D3DFMT_D16;
	}

	//check device type compatibility
	if (windowMode)
	{
		D3DDISPLAYMODE currentMode;
		if (FAILED(hr=pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&currentMode)))
		{
			LOG("Retrieving adapter display mode failed", Logger::LOG_CRIT);
			return hr;
		}
		
		if (FAILED(hr=pD3D->CheckDeviceType(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,
											currentMode.Format,	backBufferFormat,true)))
		{
			LOG("Device not supported", Logger::LOG_CRIT);
			return hr;
		}
	}
	else
	{
		if (FAILED(hr=pD3D->CheckDeviceType(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,
											backBufferFormat,	backBufferFormat,true)))
		{
			LOG("Device not supported", Logger::LOG_CRIT);
			return hr;
		}
	}

	if(!windowMode)
	{
		windowed = FALSE;

		ZeroMemory(&presentParameters, sizeof(D3DPRESENT_PARAMETERS));
		presentParameters.Windowed = FALSE;
		presentParameters.SwapEffect = D3DSWAPEFFECT_DISCARD;
		presentParameters.BackBufferWidth = fullscreenWidth;
		presentParameters.BackBufferHeight = fullscreenHeight;
		presentParameters.BackBufferFormat = backBufferFormat;
		presentParameters.BackBufferCount = 1;
		presentParameters.MultiSampleType = fullscreenAntialiasing;
		presentParameters.MultiSampleQuality = 0;
		presentParameters.FullScreen_RefreshRateInHz = fullscreenRefresh;
		presentParameters.EnableAutoDepthStencil = TRUE;
		presentParameters.AutoDepthStencilFormat = newDepthBufferFormat;
		presentParameters.hDeviceWindow = hWndFullscreen;
		presentParameters.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
	}
	else
	{
		windowed = TRUE;

		ZeroMemory(&presentParameters, sizeof(D3DPRESENT_PARAMETERS));
		presentParameters.Windowed = TRUE;
		presentParameters.SwapEffect = D3DSWAPEFFECT_DISCARD;
		presentParameters.BackBufferFormat = backBufferFormat; 
		presentParameters.BackBufferCount = 1;
		presentParameters.MultiSampleType = D3DMULTISAMPLE_NONE;
		presentParameters.MultiSampleQuality = 0;
		presentParameters.EnableAutoDepthStencil = TRUE;
		presentParameters.AutoDepthStencilFormat = newDepthBufferFormat;
		presentParameters.hDeviceWindow = hWndWindowed;
		presentParameters.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
	}

	return S_OK;
}

// implemented by the engine class
HRESULT DxFramework::render(){return S_OK;}
HRESULT DxFramework::preInitialize(){return S_OK;}
HRESULT DxFramework::preTerminate(){return S_OK;}
HRESULT DxFramework::postInitialize(){return S_OK;}
HRESULT DxFramework::postTerminate(){return S_OK;}
HRESULT DxFramework::preReset(){return S_OK;}
HRESULT DxFramework::postReset(){return S_OK;}
HRESULT	DxFramework::processKeyInput(){return S_OK;}
HRESULT	DxFramework::processMouseInput(){return S_OK;}