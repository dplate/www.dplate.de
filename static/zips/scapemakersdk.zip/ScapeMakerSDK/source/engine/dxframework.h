/****************************************************************************
** DirectX Framework
**
** handles all the basic DirectX stuff (initialization ...)
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(DXFRAMEWORK_H)
#define DXFRAMEWORK_H
#pragma warning(disable:4786)

#define DIRECTINPUT_VERSION 0x0800
#include <d3d9.h>
#include <d3dx9.h>
#include <dinput.h>
#include <stdio.h>

#include "./common/DirectXFont.h"
#include "../common/minixml.h"

// profiler display options
enum Display_Quantity {
    SELF_TIME = 0,
    HIERARCHICAL_TIME,
    SELF_STDEV,
    HIERARCHICAL_STDEV
};

struct UpdateReturns
{
	//please toggle from window mode to fullscreen (or from fullscreen to window mode)
	bool switchRenderTarget;
	//please terminate the engine
	bool terminate;
};

class DxFramework  
{
public:
	DxFramework();
	virtual ~DxFramework();

	// start up and run!
	HRESULT			start (HWND hWndWindowed, HWND hWndFullscreen, HWND hWndTop, bool windowed);
	virtual HRESULT update(char* pKeyBuffer, int keyCount, UpdateReturns *pReturnValues);
	HRESULT			terminate();
	
	// switch between window or fullscreen render target
	HRESULT	switchRenderTarget();

	//enables input
	void enableKeyboard(bool keyboardEnable) 
	{
		keyboardEnabled = keyboardEnable;
	}
	void enableMouse(bool mouseEnable)
	{
		mouseEnabled = mouseEnable;
	}

	//access functions
	int getFullscreenWidth() {return fullscreenWidth;}
	int getFullscreenHeight() {return fullscreenHeight;}

	BOOL	windowed;			// render to window or fullscreen?

protected:
	// these new functions cover all aspects of device management
	HRESULT initializeD3D();
	HRESULT createDevice(D3DDEVICE_CREATION_PARAMETERS *pCreateParms,
						 D3DPRESENT_PARAMETERS         *pPresentParms);
	HRESULT easyCreateWindowed();
	HRESULT easyCreateFullScreen();
	HRESULT restoreDevice();
	HRESULT destroyDevice();

	HRESULT	setupRenderTarget(BOOL windowed);

	HRESULT initializeDI();
	HRESULT terminateDI();

	HRESULT setPresentParameters(bool windowMode);

	// these functions are called for any set up before the app
	// initializes, renders, or terminates
	virtual HRESULT preInitialize();
	virtual HRESULT preTerminate();
	virtual void	preRender();

	// these functions are called for any cleanup after the app
	// initializes, renders, or terminates
	virtual HRESULT postInitialize();
	virtual HRESULT postTerminate();
	virtual HRESULT postRender();

	// these functions allow the child class the respond to 
	// certain important events.
	virtual HRESULT preReset();
	virtual HRESULT postReset();
	virtual HRESULT render();

	// direct input process functions
	virtual HRESULT processKeyInput();
	virtual HRESULT processMouseInput();

	HWND	hWndWindowed;			// window handle for windowed mode
	HWND	hWndFullscreen;			// window handle for fullscreen mode
	HWND	hWndTop;				// top window (for DI)

	int		windowWidth;			// window width
	int		windowHeight;			// window height

	int		fullscreenWidth;		// fullscreen width
	int		fullscreenHeight;		// fullscreen height
	int		fullscreenRefresh;		// refresh rate (in hz)
	D3DMULTISAMPLE_TYPE fullscreenAntialiasing; // antialiasing for fullscreen mode

	D3DFORMAT backBufferFormat;		// format of back buffer
	DWORD	behavior;				// software or hardware vertex processing

	LPDIRECT3DDEVICE9 pD3DDevice;	// pointer to the D3D device
	LPDIRECT3D9       pD3D;			// the pointer to our D3D object

	LPDIRECTINPUT8        pDI; 
	LPDIRECTINPUTDEVICE8  pDIKeyDevice; 
	LPDIRECTINPUTDEVICE8  pDIMouseDevice; 

	BOOL	keyboardEnabled;		// boolean for en- or disable keyboard
	bool	mouseEnabled;			// boolean for en- or disable mouse

	// these members are saved copied of the device creation
	// parameters.
	D3DPRESENT_PARAMETERS         presentParameters;
	D3DDEVICE_CREATION_PARAMETERS creationParameters;

	CDirectXFont fpsFont;			// font to draw the frame rate

};

#endif
