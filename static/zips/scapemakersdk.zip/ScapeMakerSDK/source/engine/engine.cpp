/****************************************************************************
** Engine
**
** the graphic engine base class, calls functions to draw the objects,
** terrain ...
** works together with the dx framework
**
** Author: Matthias Buchetics
****************************************************************************/

#include "Engine.h"
#include "./logger/logger.h"
#include "./common/shaderconsts.h"

/****************************************************************************
** Engine Constructor
**
** Author: Matthias Buchetics
****************************************************************************/
Engine::Engine()
{
	//create all modules
	Module *pCamera = new Camera();
	Module *pTerrain = new Terrain();
	Module *pParticles = new Particles();
	Module *pSubMeshes = new SubMeshes();
	Module *pSky = new Sky();
	Module *pHud = new Hud();
	Module *pWater = new Water();
	Module *pClouds = new Clouds();
	Module *pObjects = new Objects();
	Module *pHeightBasedFog = new HeightBasedFog();
	Module *pDepth = new Depth();

	//add all modules to module lists
	modulesCreateOrder.push_back(pCamera);		//first
	modulesCreateOrder.push_back(pDepth);		//before all depth using modules
	modulesCreateOrder.push_back(pSubMeshes);	//before all submeshes using modules
	modulesCreateOrder.push_back(pParticles);	//before all particles using modules
	modulesCreateOrder.push_back(pTerrain);
	modulesCreateOrder.push_back(pHud);			//behind terrain because minimap
	modulesCreateOrder.push_back(pSky);			//behind terrain
	modulesCreateOrder.push_back(pHeightBasedFog); //behind terrain and camera, but before objects
	modulesCreateOrder.push_back(pClouds);
	modulesCreateOrder.push_back(pObjects);		//the last module which adds elements to submeshes
	modulesCreateOrder.push_back(pWater);		//behind all water reflection modules
	
	modulesUpdateOrder.push_back(pCamera);		//first
	modulesUpdateOrder.push_back(pTerrain);
	modulesUpdateOrder.push_back(pSky);
	modulesUpdateOrder.push_back(pClouds);
	modulesUpdateOrder.push_back(pObjects);
	modulesUpdateOrder.push_back(pParticles);	//behind all particles using modules
	modulesUpdateOrder.push_back(pSubMeshes);	//behind all submeshes using modules
	modulesUpdateOrder.push_back(pWater);		//behind all other terrain elements (because reflection)
	modulesUpdateOrder.push_back(pDepth);		//behind all depth affected modules
	modulesUpdateOrder.push_back(pHeightBasedFog); //behind all height based fog affected modules (and behind depth)
	modulesUpdateOrder.push_back(pHud);

	modulesRenderOrder.push_back(pSky);
	modulesRenderOrder.push_back(pClouds);
	modulesRenderOrder.push_back(pTerrain);
	modulesRenderOrder.push_back(pWater);
	modulesRenderOrder.push_back(pSubMeshes);
	modulesRenderOrder.push_back(pHeightBasedFog); //behind all height based fog affected modules
	modulesRenderOrder.push_back(pCamera);		//behind everything, but before hud (lensflare)
	modulesRenderOrder.push_back(pHud);

	modulesDestroyOrder.push_back(pWater);
	modulesDestroyOrder.push_back(pObjects);
	modulesDestroyOrder.push_back(pClouds);
	modulesDestroyOrder.push_back(pSky);
	modulesDestroyOrder.push_back(pHud);
	modulesDestroyOrder.push_back(pTerrain);
	modulesDestroyOrder.push_back(pSubMeshes);
	modulesDestroyOrder.push_back(pHeightBasedFog);
	modulesDestroyOrder.push_back(pDepth);
	modulesDestroyOrder.push_back(pCamera);

	//connect the different objects to statusline
	Hud::instance->getStatusLine()->addSource(&time);
	Hud::instance->getStatusLine()->addSource(Camera::instance);
	Hud::instance->getStatusLine()->addSource(Terrain::instance);
	Hud::instance->getStatusLine()->addSource(SubMeshes::instance);
}

/****************************************************************************
** Engine Destructor
**
** Author: Matthias Buchetics
****************************************************************************/
Engine::~Engine()
{
	//delete all modules
	std::list<Module*>::iterator currentModule = modulesCreateOrder.begin();
	while (currentModule != modulesCreateOrder.end())
	{
		Module *pModule = (*currentModule);
		delete (*currentModule);
			
		currentModule++;
	}
}

/****************************************************************************
** Engine PreInitialize
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::preInitialize()
{
	return S_OK;
}

/****************************************************************************
** Engine PostInitialize
**
** after direct3d is initialized, we setup the render target, device stuff,
** texture stages and create our geometry.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::postInitialize()
{
	LOGFUNC("postInitialize()");

	HRESULT hr;

	if (FAILED(hr = setupDevice()))
	{
		LOG("Setting up device failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr = setupTextureStages()))
	{
		LOG("Setting up texture stages failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr = createGeometry()))
	{
		LOG("Creating geometry failed", Logger::LOG_CRIT);
		return hr;
	}

	return S_OK;
}

/****************************************************************************
** Engine SetupDevice
**
** set the view and projection matrices.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::setupDevice()
{
	LOGFUNC("setupDevice()");

	float aspect;

	if(windowed)
	{
		RECT windowRect;
		GetClientRect(hWndWindowed, &windowRect);
		windowWidth = windowRect.right - windowRect.left;
		windowHeight = windowRect.bottom - windowRect.top;
		aspect = (float)windowWidth/(float)windowHeight;
	}
	else
	{
		aspect = (float)fullscreenWidth/(float)fullscreenHeight;
	}
	
	Camera::instance->setAspect(aspect);
	
	return S_OK;
}

/****************************************************************************
** Engine SetupTextureStages
**
** set texture and render stages.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::setupTextureStages()
{
	LOGFUNC("setupTextureStages()");

	// set up the default texture states
    //pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    //pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
    //pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );

    //pD3DDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE );
	//pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    //pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT );
    //pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );
	//pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );

	pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP );

	pD3DDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC);
    pD3DDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_ANISOTROPIC);
    pD3DDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_POINT);

	pD3DDevice->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC);
    pD3DDevice->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_ANISOTROPIC);
    pD3DDevice->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_POINT);

    //pD3DDevice->SetRenderState( D3DRS_DITHERENABLE, FALSE );
    //pD3DDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );

    // turn off D3D lighting, since we are providing our own vertex colors
    pD3DDevice->SetRenderState( D3DRS_LIGHTING,     FALSE);

    // turn off culling, so we see all of the triangle
    pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	//no shader
	pD3DDevice->SetVertexShader(NULL);
	pD3DDevice->SetPixelShader(NULL);

	return S_OK;
}

/****************************************************************************
** Engine loadModules
**
** Thread-function to load all modules in background
**
** Author: Dirk Plate
****************************************************************************/
bool Engine::loadModules() 
{ 
	HRESULT hr;

	//call createGeometry of all elements in list
	std::list<Module*>::iterator currentModule = modulesCreateOrder.begin();
	while (currentModule != modulesCreateOrder.end())
	{
		if ((*currentModule)->getState() == UNINITIALISED)
		{
			//open console for state messages
			console.open();

			try
			{
				if(FAILED(hr = (*currentModule)->createGeometry(pD3DDevice)))
				{
					console.addMessage(std::string("Failed! Error: ")+DXGetErrorString9(hr)+"("+DXGetErrorDescription9(hr)+")");
					console.addMessage(std::string("Check log file for details."));
					console.addMessage(std::string("Loading module ")+(*currentModule)->getName()+" FAILED");
					LOG(std::string("Loading ")+(*currentModule)->getName()+" failed", Logger::LOG_CRIT);
					return false;
				}
			}

			//handle unhandled errors
			catch(...)
			{
				LOG("Unhandled error", Logger::LOG_CRIT);
				console.addMessage(std::string("Loading module ")+(*currentModule)->getName()+" FAILED");
				return false;
			}

			console.addMessage(std::string("Loading module ")+(*currentModule)->getName()+" OK");
			return true;
		}
		
		currentModule++;
	}

	return false;
} 


/****************************************************************************
** Engine Constructor
**
** create the vertex buffer and fill it with the quad data, just for
** testing purpose :)
** later here the terrain creation functions will be called and also the
** 3d models will be loaded.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::createGeometry()
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	//init all basics
	config.init(projectPath);
	time.init();
	input.init(pDIKeyDevice, pDIMouseDevice);
	scripts.init();

	if(FAILED(hr = console.createGeometry(pD3DDevice)))
	return hr;

	//now all modules are unloaded
	allModulesLoaded = false;
	
	return S_OK;
}


/****************************************************************************
** Engine DestroyGeometry
**
** destroy the vertex buffers, textures to get a clean device which we
** can destroy or reset (to switch between render targets).
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::destroyGeometry()
{
	HRESULT hr;
	
	LOGFUNC("destroyGeometry()");
	
	//call createGeometry of all elements in list
	std::list<Module*>::iterator currentModule = modulesDestroyOrder.begin();
	while (currentModule != modulesDestroyOrder.end())
	{
		if ((*currentModule)->getState() == INITIALISED)
		{
			if(FAILED(hr = (*currentModule)->destroyGeometry()))
			{
				LOG(std::string("Destroying module ")+(*currentModule)->getName()+" failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		
		currentModule++;
	}

	if (FAILED(hr=console.destroyGeometry()))
		return hr;

	return S_OK;
}

/****************************************************************************
** Engine Update
**
** is called every frame before rendering. update all necessary game
** objects, e.g. camera. also visible detection, collision code and so on
** will be called here.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::update(char* pKeyBuffer, int keyCount, UpdateReturns *pReturnValues)
{
	HRESULT hr;

	if (!allModulesLoaded)
	{
		//load unloaded modules (only one per call)
		if (!loadModules())
		{
			//now all modules are loaded
			allModulesLoaded = true;

			//done... close console
			console.close();
		}
	}

	try
	{
		//init return values
		pReturnValues->switchRenderTarget = false;
		pReturnValues->terminate = false;

		//update time (must be first!)
		if (FAILED(hr=time.update()))
		{
			LOG("Updating time failed", Logger::LOG_CRIT);
			return hr;
		}

		//Update input (must be second)
		if (FAILED(hr=input.update(pKeyBuffer, keyCount)))
		{
			LOG("Updating input failed", Logger::LOG_CRIT);
			return hr;
		}

		//check engine special keys
		Keyboard *pKeyboard = input.getKeyboard();

		//fullscreen toggles
		if ((pKeyboard->getKeyState(this,DIK_LMENU) == Keyboard::KeyState::HOLDPRESSED) &&
			(pKeyboard->getKeyState(this,DIK_RETURN) == Keyboard::KeyState::NEWPRESSED))
			pReturnValues->switchRenderTarget = true;
		if (pKeyboard->getKeyState(this,DIK_ESCAPE) == Keyboard::KeyState::NEWPRESSED)
			pReturnValues->terminate = true;

		//update console
		std::string command = console.update();
		//if user make a command... send it to script
		if (command != "")
			scripts.callMethod(command);

		//do script actions
		scripts.update();

		//call createGeometry of all elements in list
		std::list<Module*>::iterator currentModule = modulesUpdateOrder.begin();
		while (currentModule != modulesUpdateOrder.end())
		{
			if ((*currentModule)->getState() == INITIALISED)
			{
				if(FAILED(hr = (*currentModule)->update()))
				{
					LOG(std::string("Updating module ")+(*currentModule)->getName()+" failed", Logger::LOG_CRIT);
					return hr;
				}
			}
			
			currentModule++;
		}

		// call the framework update function, IMPORTANT, don't forget!
		if (FAILED(hr=DxFramework::update(pKeyBuffer,keyCount,pReturnValues)))
		{
			LOG("Updating basis class failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	//handle unhandled errors
	catch(...)
	{
		LOG("Unhandled error", Logger::LOG_CRIT);
		return E_FAIL;
	}

	return S_OK;
}

/****************************************************************************
** Engine Render
**
** render everything that should be visible. later this function should only
** call the terrain rendering functions or the one from the 3d models.
** now we only render the quad to show how it is used.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::render()
{
	HRESULT hr;

	//make a nice backgroundcolor
	pD3DDevice->Clear(0, NULL,
					D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER/* | D3DCLEAR_STENCIL*/,
					0xFF000000, 1.0f, 0);

	D3DXMATRIX worldMatrix;			// world matrix
	D3DXMatrixIdentity(&worldMatrix);
	pD3DDevice->SetTransform(D3DTS_WORLD, &worldMatrix);

	//set world view transformation matrix as constant
	D3DXMATRIX matView, matProj, matWorld, matTemp;

 	pD3DDevice->GetTransform(D3DTS_WORLD, &matWorld);
	pD3DDevice->GetTransform(D3DTS_VIEW, &matView);
	pD3DDevice->GetTransform(D3DTS_PROJECTION, &matProj);
 	D3DXMatrixTranspose( &matTemp, &(matWorld * matView * matProj));
	pD3DDevice->SetVertexShaderConstantF( CV_WORLDVIEWPROJ_0, matTemp, 4 );

	//set world matrix as constant
	D3DXMatrixTranspose( &matTemp, &matWorld);
	pD3DDevice->SetVertexShaderConstantF(CV_WORLD_0, matTemp, 4);

	//set camera position as constant
	pD3DDevice->SetVertexShaderConstantF(CV_CAMERA_POS, Camera::instance->getPosition(), 1);

	//call createGeometry of all elements in list
	std::list<Module*>::iterator currentModule = modulesRenderOrder.begin();
	while (currentModule != modulesRenderOrder.end())
	{
		std::string test = (*currentModule)->getName();

		if ((*currentModule)->getState() == INITIALISED)
		{
			if(FAILED(hr = (*currentModule)->render(DEFAULT)))
			{
				LOG(std::string("Rendering module ")+(*currentModule)->getName()+" failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		
		currentModule++;
	}

	if(FAILED(hr=console.render()))
	{
		LOG("Rendering console failed", Logger::LOG_CRIT);
		return hr;
	}

	return S_OK;
}

/****************************************************************************
** Engine PreReset
**
** before the device can be reset, we have to destroy the geometry bound
** to it. see the destroy function.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::preReset()
{
	HRESULT hr;
	
	LOGFUNC("preReset()");

	// destroy our geometry.
	if (FAILED(hr=destroyGeometry()))
		return hr;

	return S_OK;
}

/****************************************************************************
** Engine PostReset
**
** the reset was successful, now rebuild everything.
** attention: don't reset the camera or any game specific stuff, just the
** device dependent objects which we had to destroy.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::postReset()
{
	LOGFUNC("postReset()");

	HRESULT hr;

	if (FAILED(hr=setupDevice()))
	{
		LOG("Setting up device failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=setupTextureStages()))
	{
		LOG("Setting up texture staged failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=createGeometry()))
	{
		LOG("Creating geometry failed", Logger::LOG_CRIT);
		return hr;
	}

	return S_OK;
}

/****************************************************************************
** Engine PreTerminate
**
** before exiting the app, we have to clean up and destroy our geometry.
** just call the functions.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::preTerminate()
{
	HRESULT hr;

	LOGFUNC("preTerminate()");

	if (FAILED(hr=destroyGeometry()))
		return hr;

	return S_OK;
}

/****************************************************************************
** Engine PostTerminate
**
** anything to do, after we destroyed the d3d objects? in most cases not,
** but nobody knows.
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Engine::postTerminate()
{
	return S_OK;
}

// just sets the project path
void Engine::setProjectPath(const char *path)
{
	strcpy(projectPath, path);
}

/****************************************************************************
** Engine enableKeyboard
**
** enables keyboard
**
** Author: Dirk Plate
****************************************************************************/
void Engine::enableKeyboard(bool keyboardEnable)
{
	//call superclass
	DxFramework::enableKeyboard(keyboardEnable);

	//disable keyboard class
	input.getKeyboard()->enable(keyboardEnable);
}

/****************************************************************************
** Engine enableMouse
**
** enables mouse
**
** Author: Dirk Plate
****************************************************************************/
void Engine::enableMouse(bool mouseEnable)
{
	//call superclass
	DxFramework::enableMouse(mouseEnable);

	//disable mouse class
	input.getMouse()->enable(mouseEnable);
}

















