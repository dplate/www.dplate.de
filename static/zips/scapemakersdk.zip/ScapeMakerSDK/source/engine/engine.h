/****************************************************************************
** Engine
**
** the graphic engine base class, calls functions to draw the objects, 
** terrain ...
** works together with the dx framework
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(ENGINE_H)
#define ENGINE_H
#pragma warning(disable:4786)

#include "DxFramework.h"
#include "./camera/Camera.h"
#include "./terrain/Terrain.h"
#include "./objects/Objects.h"
#include "./sky/Sky.h"
#include "./clouds/clouds.h"
#include "./water/water.h"
#include "./common/submeshes.h"
#include "./scripts/scripts.h"
#include "./console/console.h"
#include "./particles/particles.h"
#include "./input/input.h"
#include "./common/time.h"
#include "./common/config.h"
#include "./hud/hud.h"
#include "./postprocessing/heightbasedfog.h"
#include "./postprocessing/depth.h"

class PreviewGUI;

class Engine : public DxFramework 
{
public:
	Engine();
	virtual ~Engine();

	// every frame the update function is called
	HRESULT update(char* pKeyBuffer, int keyCount, UpdateReturns *pReturnValues);
	void	setProjectPath(const char *path);

	//enables input
	void enableKeyboard(bool keyboardEnable);
	void enableMouse(bool mouseEnable);

private:
	// these functions are called for any set up before the app
	// initializes, renders, or terminates
	HRESULT preInitialize();
	HRESULT preTerminate();

	// these functions are called for any cleanup after the app
	// initializes, renders, or terminates
	HRESULT postInitialize();
	HRESULT postTerminate();

	// these functions allow the child class the respond to 
	// certain important events.
	HRESULT preReset();
	HRESULT postReset();
	HRESULT render();

	// setup functions
	HRESULT setupDevice();
	HRESULT setupTextureStages();

	// create and destroy the geometry
	HRESULT createGeometry();
	HRESULT destroyGeometry();

	//loading function for all modules 
	bool loadModules();

	Config		config;
	Time		time;	
	Scripts		scripts;
	Console		console;
	Input		input;

	//list with all active modules
	std::list<Module*> modulesCreateOrder;
	std::list<Module*> modulesUpdateOrder;
	std::list<Module*> modulesRenderOrder;
	std::list<Module*> modulesDestroyOrder;

	char		projectPath[512];
	bool		allModulesLoaded; //turn true if all modules are loaded
};

#endif 
