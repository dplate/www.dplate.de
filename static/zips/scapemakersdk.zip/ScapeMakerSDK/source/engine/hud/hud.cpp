#include "hud.h"
#include "../common/enginehelpers.h"
#include "../logger/logger.h"
#include "../input/input.h"

Hud *Hud::instance = NULL;

/****************************************************************************
** Hud Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Hud::Hud()
{
	Module::Module();
	name = "Hud";

	instance = this;
	visible = true;
}

/****************************************************************************
** Hud Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Hud::~Hud()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Hud createGeometry
**
** init everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Hud::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//shown by default
	visible = true;

	//init elements of hud
	if (FAILED(hr=miniMap.createGeometry(pD3DDevice)))
		return hr;

	if (FAILED(hr=statusLine.createGeometry(pD3DDevice)))
		return hr;

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Hud destroyGeometry
**
** destroy everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Hud::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	HRESULT hr;

	if (FAILED(hr=miniMap.destroyGeometry()))
		return hr;

	if (FAILED(hr=statusLine.destroyGeometry()))
		return hr;

	return Module::destroyGeometry();
}

/****************************************************************************
** Hud update
**
** update everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Hud::update()
{
	HRESULT hr;

	//if not visible... do nothing
	if (!visible)
		return S_OK;

	//update elements
	if (FAILED(hr=miniMap.update()))
		return hr;

	if (FAILED(hr=statusLine.update()))
		return hr;

	return Module::update();
}

/****************************************************************************
** Hud render
**
** renders everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Hud::render(ModuleRenderType renderType)
{
	HRESULT hr;

	//if not visible... do nothing
	if (!visible)
		return S_OK;

	//render elements
	if (FAILED(hr=miniMap.render()))
		return hr;

	if (FAILED(hr=statusLine.render()))
		return hr;

	return Module::render(renderType);
}

