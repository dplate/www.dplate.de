/****************************************************************************
** Hud
**
** manage hud (minimap and so on)
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_HUD)
#define H_HUD
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

#include "minimap.h"
#include "statusline.h"
#include "../module.h"

class Hud : public Module
{
public:
	Hud();
	~Hud();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();
	HRESULT render(ModuleRenderType renderType);
	HRESULT update();

	//show hud
	void show() {visible = true;}
	//hide hud
	void hide() {visible = false;}

	//access functions
	StatusLine* getStatusLine() {return &statusLine;}

	static Hud *instance;				//the instance to the only one console objects

private:
	//Direct3D device
	LPDIRECT3DDEVICE9 pD3DDevice;

	//hud is shown or hidden
	bool visible;

	//the minimap
	MiniMap miniMap;

	//the statusline
	StatusLine statusLine;
};

#endif