#include "minimap.h"
#include "../common/enginehelpers.h"
#include "../logger/logger.h"
#include "../input/input.h"
#include "../camera/camera.h"
#include "../common/config.h"
#include "../terrain/terrain.h"

//size of minimap relative to screen height
#define MINIMAP_SIZE 0.25f

//size of arrow relative to screen height
#define MINIMAP_ARROW_SIZE 0.05f

/****************************************************************************
** MiniMap Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
MiniMap::MiniMap()
{
	pMapVB = NULL;
	pMapTexture = NULL;
	pMapStateBlock = NULL;
	pMapSavedStateBlock = NULL;

	pArrowVB = NULL;
	pArrowTexture = NULL;
	pArrowStateBlock = NULL;
	pArrowSavedStateBlock = NULL;

	//minimap is visible on hud by default
	visible = false;
}

/****************************************************************************
** MiniMap Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
MiniMap::~MiniMap()
{
}

/****************************************************************************
** MiniMap createGeometry
**
** init everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT MiniMap::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//set position and size of minimap
	width = MINIMAP_SIZE*Camera::instance->getScreenHeight();
	height = width;
	left = Camera::instance->getScreenWidth()-width-10;
	top = Camera::instance->getScreenHeight()-height-10;

	//calculate the transformation factor from terrain to minimap
	terrainToMiniMapFactor = float(width)/Terrain::instance->getWidth();

	//create map vertex buffer
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer(4 * sizeof(MINIMAPVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_MINIMAPVERTEX, D3DPOOL_DEFAULT,
										     &pMapVB, NULL)))
		return hr;

	//fill map vertex buffer
	MINIMAPVERTEX* pVertices = NULL;
	pMapVB->Lock(0, 4 * sizeof(MINIMAPVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD);

	pVertices[0].p.x = left;
	pVertices[0].p.y = top;
	pVertices[0].p.z = 1.0f;
	pVertices[0].rhw = 1.0f;
	pVertices[0].u = 0.0f;
	pVertices[0].v = 0.0f;
	
	pVertices[1].p.x = left;
	pVertices[1].p.y = top+height;
	pVertices[1].p.z = 1.0f;
	pVertices[1].rhw = 1.0f;
	pVertices[1].u = 0.0f;
	pVertices[1].v = 1.0f;

	
	pVertices[2].p.x = left+width;
	pVertices[2].p.y = top;
	pVertices[2].p.z = 1.0f;
	pVertices[2].rhw = 1.0f;
	pVertices[2].u = 1.0f;
	pVertices[2].v = 0.0f;
	
	pVertices[3].p.x = left+width;
	pVertices[3].p.y = top+height;
	pVertices[3].p.z = 1.0f;
	pVertices[3].rhw = 1.0f;
	pVertices[3].u = 1.0f;
	pVertices[3].v = 1.0f;

	pMapVB->Unlock();

	LOG("Map mesh created OK");

	//load minimap texture
	std::string texturePath = Config::instance->getEnginePath()+"/minimap.jpg";
	if (FAILED(hr = EngineHelpers::loadTexture( pD3DDevice, texturePath.c_str(), D3DFMT_UNKNOWN, &pMapTexture)))
	{
		texturePath = Config::instance->getEnginePath()+"/heightmap.png";
		if (FAILED(hr = EngineHelpers::loadTexture( pD3DDevice, texturePath.c_str(), D3DFMT_UNKNOWN, &pMapTexture)))
		{
			LOG("Loading minimap texture failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	LOG("Map texture loaded OK");

	//create state block for map
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetTexture(0, pMapTexture);
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,			D3DCULL_CW);
		pD3DDevice->SetRenderState(D3DRS_ZENABLE,			FALSE);
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,		FALSE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_COLOROP,D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_COLORARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAOP,D3DTOP_DISABLE);
		pD3DDevice->SetFVF(D3DFVF_MINIMAPVERTEX);
				
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pMapStateBlock)))
			{
				LOG("Ending map state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pMapSavedStateBlock)))
			{
				LOG("Ending map saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("Map state block created OK");

	//create arrow vertex buffer
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer(4 * sizeof(MINIMAPVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_MINIMAPVERTEX, D3DPOOL_DEFAULT,
										     &pArrowVB, NULL)))
		return hr;

	//fill arrow vertex buffer
	arrowHalfWidth = MINIMAP_ARROW_SIZE*Camera::instance->getScreenHeight()/2.0f;
	pVertices = NULL;
	pArrowVB->Lock(0, 4 * sizeof(MINIMAPVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD);

	pVertices[0].p.x = arrowVertices[0].p.x = -arrowHalfWidth;
	pVertices[0].p.y = arrowVertices[0].p.y = -arrowHalfWidth;
	pVertices[0].p.z = arrowVertices[0].p.z = 1.0f;
	pVertices[0].rhw = arrowVertices[0].rhw = 1.0f;
	pVertices[0].u   = arrowVertices[0].u   = 0.0f;
	pVertices[0].v   = arrowVertices[0].v   = 0.0f;
	
	pVertices[1].p.x = arrowVertices[1].p.x = -arrowHalfWidth;
	pVertices[1].p.y = arrowVertices[1].p.y = +arrowHalfWidth;
	pVertices[1].p.z = arrowVertices[1].p.z = 1.0f;
	pVertices[1].rhw = arrowVertices[1].rhw = 1.0f;
	pVertices[1].u   = arrowVertices[1].u   = 0.0f;
	pVertices[1].v   = arrowVertices[1].v   = 1.0f;
	
	pVertices[2].p.x = arrowVertices[2].p.x = arrowHalfWidth;
	pVertices[2].p.y = arrowVertices[2].p.y = -arrowHalfWidth;
	pVertices[2].p.z = arrowVertices[2].p.z = 1.0f;
	pVertices[2].rhw = arrowVertices[2].rhw = 1.0f;
	pVertices[2].u   = arrowVertices[2].u   = 1.0f;
	pVertices[2].v   = arrowVertices[2].v   = 0.0f;
	
	pVertices[3].p.x = arrowVertices[3].p.x = arrowHalfWidth;
	pVertices[3].p.y = arrowVertices[3].p.y = arrowHalfWidth;
	pVertices[3].p.z = arrowVertices[3].p.z = 1.0f;
	pVertices[3].rhw = arrowVertices[3].rhw = 1.0f;
	pVertices[3].u   = arrowVertices[3].u   = 1.0f;
	pVertices[3].v   = arrowVertices[3].v   = 1.0f;

	pArrowVB->Unlock();

	LOG("Arrow mesh created OK");

	//load arrow texture
	if (FAILED(hr = EngineHelpers::loadTexture( pD3DDevice, "./enginefiles/minimap_arrow.png", D3DFMT_UNKNOWN, &pArrowTexture)))
	{
		LOG("Loading minimap texture failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Arrow texture loaded OK");

	//create state block for map
	for (block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetTexture(0, pArrowTexture);
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,			D3DCULL_CW);
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,	TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,			D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,			D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ZENABLE,			FALSE);
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,		FALSE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_COLOROP,D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_COLORARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		pD3DDevice->SetFVF(D3DFVF_MINIMAPVERTEX);
				
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pArrowStateBlock)))
			{
				LOG("Ending arrow state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pArrowSavedStateBlock)))
			{
				LOG("Ending arrow saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("Arrow state block created OK");

	return S_OK;
}

/****************************************************************************
** MiniMap destroyGeometry
**
** destroy everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	MiniMap::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//release map
	SAFE_RELEASE(pMapVB);
	SAFE_RELEASE(pMapTexture);
	SAFE_RELEASE(pMapSavedStateBlock);
	SAFE_RELEASE(pMapStateBlock);

	//release arrow
	SAFE_RELEASE(pArrowVB);
	SAFE_RELEASE(pArrowTexture);
	SAFE_RELEASE(pArrowSavedStateBlock);
	SAFE_RELEASE(pArrowStateBlock);

	return S_OK;
}

/****************************************************************************
** MiniMap update
**
** update everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	MiniMap::update()
{
	HRESULT hr;

	//check key inputs

	//minimap visible or not
	if (Input::instance->getKeyboard()->getKeyState(this,DIK_M) == Keyboard::KeyState::NEWPRESSED)
	{
		//toggle to visible?
		visible = !visible;
	}

	//only if visible
	if (visible)
	{
		//rotate arrow
		D3DXVECTOR3 direction = Camera::instance->getDirection();
		float angle = atan2(direction.x,direction.z);
		D3DXMatrixRotationZ(&arrowTransformation,angle);

		//calculate new arrow transformation
		D3DXMATRIX matTemp;
		D3DXMatrixTranslation(&matTemp,
			left+Camera::instance->getPosition().x*terrainToMiniMapFactor,
			top+height-Camera::instance->getPosition().z*terrainToMiniMapFactor,
			0.0f);

		//combine rotation with translation
		arrowTransformation = arrowTransformation*matTemp;

		//update vertexbuffer of arrow
		if (FAILED(hr=updateArrowVertexBuffer()))
			return hr;
	}

	return S_OK;
}

/****************************************************************************
** MiniMap render
**
** renders everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT MiniMap::render()
{
	HRESULT hr;

	//if not visible... do nothing
	if (!visible)
		return S_OK;

	//render map
	//record and set the render states
	pMapSavedStateBlock->Capture();
	pMapStateBlock->Apply();

	//set vertex stream
	pD3DDevice->SetStreamSource(0, pMapVB, NULL, sizeof(MINIMAPVERTEX));
	//render map
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering map failed", Logger::LOG_CRIT);
		return hr;
	}

	//Restore the states
	pMapSavedStateBlock->Apply();


	//render arrow
	//record and set the render states
	pArrowSavedStateBlock->Capture();
	pArrowStateBlock->Apply();

	//set vertex stream
	pD3DDevice->SetStreamSource(0, pArrowVB, NULL, sizeof(MINIMAPVERTEX));
	//render map
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering arrow failed", Logger::LOG_CRIT);
		return hr;
	}

	//Restore the states
	pArrowSavedStateBlock->Apply();

	return S_OK;
}

/****************************************************************************
** MiniMap updateArrowVertexBuffer
**
** update vertex buffer of arrow for current position and direction
**
** Author: Dirk Plate
****************************************************************************/
HRESULT MiniMap::updateArrowVertexBuffer()
{
	HRESULT hr;

	MINIMAPVERTEX* pVertices = NULL;
	if (FAILED(hr=pArrowVB->Lock(0, 4 * sizeof(MINIMAPVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD)))
	{
		LOG("Locking arrow vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//transform all vertices of arrow
	for (int i=0;i<4;i++)
	{
		D3DXVECTOR3 transformedVertex;
		D3DXVec3TransformCoord(&transformedVertex,&(arrowVertices[i].p),&arrowTransformation);
		pVertices[i].p = transformedVertex;
		pVertices[i].rhw = arrowVertices[i].rhw;
		pVertices[i].u = arrowVertices[i].u;
		pVertices[i].v = arrowVertices[i].v;
	}

	pArrowVB->Unlock();

	return S_OK;
}