/****************************************************************************
** MiniMap
**
** manage minimap
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_MINIMAP)
#define H_MINIMAP
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

struct MINIMAPVERTEX
{
	D3DXVECTOR3 p;
	float rhw;
	float u, v;
};

#define D3DFVF_MINIMAPVERTEX (D3DFVF_XYZRHW | D3DFVF_TEX1)

class MiniMap
{
public:
	MiniMap();
	~MiniMap();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();
	HRESULT render();
	HRESULT update();

private:
	HRESULT updateArrowVertexBuffer();

	//Direct3D device
	LPDIRECT3DDEVICE9 pD3DDevice;

	//minimap visible or not
	bool visible;

	//the transformation factor from terrain to minimap
	float terrainToMiniMapFactor;

	//map properties
	//the mesh of map
	LPDIRECT3DVERTEXBUFFER9 pMapVB;

	//the map texture
	LPDIRECT3DTEXTURE9 pMapTexture;

	//own state block
	LPDIRECT3DSTATEBLOCK9 pMapStateBlock;
	LPDIRECT3DSTATEBLOCK9 pMapSavedStateBlock;

	//position of minimap
	int left, top, width, height;

	//arrow properties
	//the untransformed vertices of the arrow
	MINIMAPVERTEX arrowVertices[4];

	//the mesh of arrow
	LPDIRECT3DVERTEXBUFFER9 pArrowVB;

	//the arrow texture
	LPDIRECT3DTEXTURE9 pArrowTexture;

	//the arrow transformation matrix
	D3DXMATRIX arrowTransformation;

	//the half width (and height) of the arrow
	float arrowHalfWidth;

	//own state block
	LPDIRECT3DSTATEBLOCK9 pArrowStateBlock;
	LPDIRECT3DSTATEBLOCK9 pArrowSavedStateBlock;
};

#endif