#include "statusline.h"
#include "../common/enginehelpers.h"
#include "../logger/logger.h"
#include "../input/input.h"
#include "../camera/camera.h"

//height of statusline
#define STATUSLINE_HEIGHT 20.0f
#define STATUSLINE_WIDTH 350.0f

/****************************************************************************
** StatusLine Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
StatusLine::StatusLine()
{
	pBackgroundVB = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	//status line not visible by default
	visible = false;

	//no source displayed at beginning
	displayedSource = sources.end();
}

/****************************************************************************
** StatusLine Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
StatusLine::~StatusLine()
{
	//remove sources
	std::list<StatusLine::OneStatusSource*>::iterator currentSource = sources.begin();
	while (currentSource != sources.end())
	{
		//its already in list!
		delete (*currentSource);
		currentSource++;
	}

	//delete list
	sources.clear();
}

/****************************************************************************
** StatusLine createGeometry
**
** init everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT StatusLine::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;
	this->pKeyboard = Input::instance->getKeyboard();

	//create font
	font.CreateFont(pD3DDevice, "Times New Roman", 12);

	//create the background vertex buffer
	if(FAILED(pD3DDevice->CreateVertexBuffer(4 * sizeof(STATUSLINEVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_STATUSLINEVERTEX, D3DPOOL_DEFAULT,
										     &pBackgroundVB, NULL)))
		return NULL;

	//fill background vertex buffer
	STATUSLINEVERTEX* pVertices = NULL;
	pBackgroundVB->Lock(0, 4 * sizeof(STATUSLINEVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD);

	pVertices[0].x = 10;
	pVertices[0].y = Camera::instance->getScreenHeight()-STATUSLINE_HEIGHT-10;
	pVertices[0].z = 1.0f;
	pVertices[0].rhw = 1.0f;
	pVertices[0].color = 0xA0A0A0A0;

	pVertices[1].x = 10;
	pVertices[1].y = Camera::instance->getScreenHeight()-10;
	pVertices[1].z = 1.0f;
	pVertices[1].rhw = 1.0f;
	pVertices[1].color = 0xA0A0A0A0;

	pVertices[2].x = STATUSLINE_WIDTH+10;
	pVertices[2].y = Camera::instance->getScreenHeight()-STATUSLINE_HEIGHT-10;
	pVertices[2].z = 1.0f;
	pVertices[2].rhw = 1.0f;
	pVertices[2].color = 0xA0A0A0A0;

	pVertices[3].x = STATUSLINE_WIDTH+10;
	pVertices[3].y = Camera::instance->getScreenHeight()-10;
	pVertices[3].z = 1.0f;
	pVertices[3].rhw = 1.0f;
	pVertices[3].color = 0xA0A0A0A0;

	pBackgroundVB->Unlock();

	//create state blocks to change the render states
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetTexture(0, NULL);
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,			D3DCULL_CW);
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,	TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,			D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,			D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ZENABLE,			FALSE);
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,		FALSE);
		pD3DDevice->SetTextureStageState(0,					D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);
		pD3DDevice->SetFVF(D3DFVF_STATUSLINEVERTEX);

		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("State block created OK");

	return S_OK;
}

/****************************************************************************
** StatusLine destroyGeometry
**
** destroy everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	StatusLine::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");


	//delete history background vertex buffer
	if (pBackgroundVB)
		SAFE_RELEASE(pBackgroundVB);

	//delete state blocks
	if(pStateBlock)
		SAFE_RELEASE(pStateBlock);

	if (pSavedStateBlock)
		SAFE_RELEASE(pSavedStateBlock);

	//destroy font
	font.DestroyFont();

	return S_OK;
}

/****************************************************************************
** StatusLine update
**
** update everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT StatusLine::update()
{
	//check visibility
	if (pKeyboard->getKeyState(this,DIK_N) == Keyboard::KeyState::NEWPRESSED)
	{
		visible = !visible;
	}

	if (!visible)
		return S_OK;

	//check source switching
	if (pKeyboard->getKeyState(this,DIK_B) == Keyboard::KeyState::NEWPRESSED)
	{
		if (displayedSource != sources.end())
			displayedSource++;
		if (displayedSource == sources.end())
			displayedSource = sources.begin();
	}

	//retrieve current message
	if (displayedSource != sources.end())
		(*displayedSource)->message = (*displayedSource)->pObject->getStatusMessage();

	return S_OK;
}

/****************************************************************************
** StatusLine render
**
** renders everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT StatusLine::render()
{
	if (!visible)
		return S_OK;

	HRESULT hr;

	//record and set the render states
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	if (pBackgroundVB != NULL)
	{
		//set vertex stream
		pD3DDevice->SetStreamSource(0, pBackgroundVB, NULL, sizeof(STATUSLINEVERTEX));
		//render background
		if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			LOG("Rendering background failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//Restore the states
	pSavedStateBlock->Apply();

	//draw message
	if (displayedSource != sources.end())
	{
		font.DrawText(13, Camera::instance->getScreenHeight()-10-STATUSLINE_HEIGHT+2,
				  (*displayedSource)->message.c_str(), 0x00000000);
	}

	return S_OK;
}

/****************************************************************************
** StatusLine addSource
**
** add a message source for status line
**
** Author: Dirk Plate
****************************************************************************/
void StatusLine::addSource(StatusSource* pObject)
{
	//no object... no souce
	if (pObject == NULL) 
		return;

	//check if object already a source
	std::list<StatusLine::OneStatusSource*>::iterator currentSource = sources.begin();
	while (currentSource != sources.end())
	{
		//its already in list!
		if ((*currentSource)->pObject == pObject)
			return;
		currentSource++;
	}

	//create a new message source
	OneStatusSource *pNewSource = new OneStatusSource();
	pNewSource->pObject = pObject;
	pNewSource->message = "";
	sources.push_back(pNewSource);

	//no source displayed? then display this new one
	if (displayedSource == sources.end())
		displayedSource--;
}

/****************************************************************************
** StatusLine removeSource
**
** remove a message source for status line
**
** Author: Dirk Plate
****************************************************************************/
void StatusLine::removeSource(StatusSource* pObject)
{
	//find entry in list
	std::list<StatusLine::OneStatusSource*>::iterator currentSource = sources.begin();
	while (currentSource != sources.end())
	{
		//found
		if ((*currentSource)->pObject == pObject)
		{
			//fix displayedSource (if deleting this one)
			if (displayedSource == currentSource)
			{
				displayedSource++;
				if ((displayedSource == sources.end()) &&
					(currentSource != sources.begin()))
					displayedSource = sources.begin();
			}

			//delete content
			delete (*currentSource);

			//delete entry
			sources.erase(currentSource);
		}
		currentSource++;
	}
}
