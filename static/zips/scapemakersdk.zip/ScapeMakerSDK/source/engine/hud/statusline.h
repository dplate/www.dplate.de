/****************************************************************************
** StatusLine
**
** manage the status line
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_STATUSLINE)
#define H_STATUSLINE
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <list>
#include <string>

#include "../common/DirectXFont.h"
#include "../input/keyboard.h"

struct STATUSLINEVERTEX
{
	float x, y, z, rhw;
	DWORD color;
};

#define D3DFVF_STATUSLINEVERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE)

//interface for all source of status messages
class StatusSource
{
public:
	virtual std::string getStatusMessage() = 0;
};

class StatusLine
{
public:
	StatusLine();
	~StatusLine();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();
	HRESULT render();
	HRESULT update();

	//add a message source for status line
	void addSource(StatusSource* pObject);
	//remove a message source for status line
	void removeSource(StatusSource* pObject);

private:
	struct OneStatusSource
	{
		StatusSource *pObject;
		std::string message;
	};

	//mini map visible or not
	bool visible;

	//all sources for status messages
	std::list<OneStatusSource*> sources;

	//current source to display
	std::list<OneStatusSource*>::iterator displayedSource;
	
	//background of status line
	LPDIRECT3DVERTEXBUFFER9 pBackgroundVB;

	//Direct3D device
	LPDIRECT3DDEVICE9 pD3DDevice;

	//the keyboard input access object
	Keyboard *pKeyboard;

	//font class for writing things out
	CDirectXFont font;

	//own state block
	LPDIRECT3DSTATEBLOCK9 pStateBlock;
	LPDIRECT3DSTATEBLOCK9 pSavedStateBlock;
};

#endif