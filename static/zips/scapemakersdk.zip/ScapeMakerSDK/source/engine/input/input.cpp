#include "input.h"
#include "../logger/logger.h"

Input *Input::instance = NULL;

/****************************************************************************
** Input Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Input::Input()
{
	instance = this;
}

/****************************************************************************
** Input Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Input::~Input()
{
	instance = NULL;
}

/****************************************************************************
** Input init
**
** init all input devices
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Input::init(LPDIRECTINPUTDEVICE8  pDIKeyDevice, LPDIRECTINPUTDEVICE8  pDIMouseDevice)
{
	keyboard.init(pDIKeyDevice);
	mouse.init(pDIMouseDevice);

	return S_OK;
}

/****************************************************************************
** Input update
**
** update everything
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Input::update(char *pKeyBuffer, int keyCount)
{
	HRESULT hr;

	//update keyboard inputs
	if (FAILED(hr=keyboard.update(pKeyBuffer, keyCount)))
	{
		LOG("Updating keyboard failed", Logger::LOG_CRIT);
		return hr;
	}

	//update mouse inputs
	if (FAILED(hr=mouse.update()))
	{
		LOG("Updating mouse failed", Logger::LOG_CRIT);
		return hr;
	}

	return S_OK;
}

