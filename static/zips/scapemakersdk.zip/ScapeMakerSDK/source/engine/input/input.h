/****************************************************************************
** Input
**
** manage all inputs
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_INPUT)
#define H_INPUT
#pragma warning(disable:4786)

#define DIRECTINPUT_VERSION 0x0800

#include <d3dx9.h>
#include <stdio.h>
#include <dinput.h>
#include "keyboard.h"
#include "mouse.h"

class Input
{
public:
	Input();
	~Input();

	//init object
	HRESULT init(LPDIRECTINPUTDEVICE8 pDIKeyDevice, LPDIRECTINPUTDEVICE8 pDIMouseDevice);

	//retrieve all inputs
	HRESULT update(char *pKeyBuffer, int keyCount);

	//access function for all input devices
	Keyboard* getKeyboard() {return &keyboard;}
	Mouse* getMouse() {return &mouse;}

	static Input *instance;				//the instance to the only one input object

private:
	//the keyboard managing class
	Keyboard keyboard;

	//the mouse managing class
	Mouse mouse;
};

#endif