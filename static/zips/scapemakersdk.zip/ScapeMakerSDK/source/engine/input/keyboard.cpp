#include "keyboard.h"
#include "../logger/logger.h"

/****************************************************************************
** Keyboard Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Keyboard::Keyboard()
{

}

/****************************************************************************
** Keyboard Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Keyboard::~Keyboard()
{
}

/****************************************************************************
** Keyboard init
**
** init keyboard device
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Keyboard::init(LPDIRECTINPUTDEVICE8  pDIKeyDevice)
{
	//save device pointer local
	this->pDIKeyDevice = pDIKeyDevice;

	//init all keys
	for (int i=0; i<256; i++)
	{
		currentKey[i] = UNKNOWN;
	}

	enabled = true;
	exclusive = false;
	pExclusiveObject = NULL;

	return S_OK;
}

/****************************************************************************
** Keyboard update
**
** update all inputs
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Keyboard::update(char *pKeyBuffer, int keyCount)
{
    HRESULT  hr; 
    char     buffer[256]; 
	int		 i;

	//save written characters from outside (not DirectInput-Characters)
	ascii = "";
	for (i=0;i<keyCount;i++)
	{
		//only real characters
		if ((pKeyBuffer[i] >= 32) && (pKeyBuffer[i] <= 126) &&
			(pKeyBuffer[i] != 94))
			ascii += pKeyBuffer[i];
	}

	//get current state of all keys 
	if (FAILED(hr = pDIKeyDevice->GetDeviceState(sizeof(buffer),(LPVOID)&buffer)))
	{      
		// If input is lost then acquire and keep trying 
		do 
		{ 
			LOG("Acquiring keyboard failed... retrying...", Logger::LOG_WARN);
			
			hr = pDIKeyDevice->Acquire(); 
		} 
		while(hr == DIERR_INPUTLOST);
	}

	//update all key
	for (i=0; i<256; i++)
	{
		//if key down
	    if (KEYDOWN(buffer, i))
		{
			//key was already pressed?
			if ((currentKey[i] == HOLDPRESSED) ||
				(currentKey[i] == NEWPRESSED))
			{
				//key is hold pressed
				currentKey[i] = HOLDPRESSED;
			}
			//Key was not pressed?
			else
			{
				//key is new pressed
				currentKey[i] = NEWPRESSED;
			}
		}
		//key is up
		else
		{
			//key was already released?
			if ((currentKey[i] == HOLDRELEASED) ||
				(currentKey[i] == NEWRELEASED))
			{
				//key is hold released
				currentKey[i] = HOLDRELEASED;
			}
			//Key was not released?
			else
			{
				//key is new released
				currentKey[i] = NEWRELEASED;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Keyboard setExclusiveMode
**
** only this object will receive key states!
**
** Author: Dirk Plate
****************************************************************************/
void Keyboard::setExclusiveMode(void *pObject, bool enable)
{
	//enable exclusive mode
	if (enable)
	{
		exclusive = true;
		pExclusiveObject = pObject;
	}
	//disable exclusive mode
	else
	{
		//only objects which enabled it can disable it
		if (pObject == pExclusiveObject)
		{
			exclusive = false;
			pExclusiveObject = NULL;
		}
	}
}

/****************************************************************************
** Keyboard getKeyState
**
** access state of one key
**
** Author: Dirk Plate
****************************************************************************/
Keyboard::KeyState Keyboard::getKeyState(void *pObject, int key)
{
	//if disabled or exclusive mode with false object -> return unknown
	if ((!enabled) ||
		((exclusive) && (pObject != pExclusiveObject)))
		return KeyState::UNKNOWN;

	//return state
	return currentKey[key];
}

/****************************************************************************
** Keyboard getASCII
**
** get last written ascii keys
**
** Author: Dirk Plate
****************************************************************************/
std::string Keyboard::getASCII(void *pObject)
{
	//if disabled or exclusive mode with false object -> return ""
	if ((!enabled) ||
		((exclusive) && (pObject != pExclusiveObject)))
		return "";

	//return ascii
	return ascii;
}