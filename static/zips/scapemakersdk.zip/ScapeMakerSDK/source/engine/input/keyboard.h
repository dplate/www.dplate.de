/****************************************************************************
** Keyboard
**
** manage keyboard inputs
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_KEYBOARD)
#define H_KEYBOARD
#pragma warning(disable:4786)

#define DIRECTINPUT_VERSION 0x0800
#define KEYDOWN(name, key) (name[key] & 0x80) 

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <dinput.h>
#include <string>

class Keyboard
{
public:
	Keyboard();
	~Keyboard();

	//init object
	HRESULT init(LPDIRECTINPUTDEVICE8  pDIKeyDevice);

	//retrieve all inputs
	HRESULT update(char *pKeyBuffer, int keyCount);

	//enum with all key states
	enum KeyState {UNKNOWN, HOLDPRESSED, NEWPRESSED, HOLDRELEASED, NEWRELEASED};

	//access state of one key
	KeyState getKeyState(void *pObject, int key);

	//get last written ascii keys
	std::string getASCII(void *pObject);

	//en- or disable keyboard
	void enable(bool enable) {enabled = enable;}

	//only this object will receive key states!
	void setExclusiveMode(void *pObject, bool enable);

	
private:
	//the directx device
	LPDIRECTINPUTDEVICE8  pDIKeyDevice;

	//state of all keys in current frame
	KeyState currentKey[256];
	
	//ascii characters written in last frame
	std::string ascii;

	//en- or disabled
	bool enabled;

	//exclusive mode
	bool exclusive;
	void *pExclusiveObject;
};

#endif