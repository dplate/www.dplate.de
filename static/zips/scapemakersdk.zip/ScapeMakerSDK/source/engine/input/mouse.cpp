#include "mouse.h"
#include "../logger/logger.h"

/****************************************************************************
** Mouse Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Mouse::Mouse()
{

}

/****************************************************************************
** Mouse Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Mouse::~Mouse()
{
}

/****************************************************************************
** Mouse init
**
** init keyboard device
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Mouse::init(LPDIRECTINPUTDEVICE8  pDIMouseDevice)
{
	//save device pointer local
	this->pDIMouseDevice = pDIMouseDevice;

	//init all buttons
	for (int i=0; i<3; i++)
	{
		currentButton[i] = UNKNOWN;
	}

	movedX = 0;
	movedY = 0;

	enabled = true;
	exclusive = false;
	pExclusiveObject = NULL;

	return S_OK;
}

/****************************************************************************
** Mouse update
**
** update all inputs
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Mouse::update()
{
    HRESULT  hr;

    //directInput mouse state structure
	DIMOUSESTATE2 dims2;
	ZeroMemory( &dims2, sizeof(dims2) );

	//get current state of all keys
	if (FAILED(hr = pDIMouseDevice->GetDeviceState(sizeof(DIMOUSESTATE2), &dims2)))
	{
		// If input is lost then acquire and keep trying
		do 
		{ 
			LOG("Acquiring mouse failed... retrying...", Logger::LOG_CRIT);

			hr = pDIMouseDevice->Acquire(); 
		} 
		while(hr == DIERR_INPUTLOST);
	}

	//update all buttons
	for (int i=0; i<3; i++)
	{
		//if button down
	    if (BUTTONDOWN(dims2.rgbButtons, i))
		{
			//button was already pressed?
			if ((currentButton[i] == HOLDPRESSED) ||
				(currentButton[i] == NEWPRESSED))
			{
				//button is hold pressed
				currentButton[i] = HOLDPRESSED;
			}
			//button was not pressed?
			else
			{
				//button is new pressed
				currentButton[i] = NEWPRESSED;
			}
		}
		//button is up
		else
		{
			//button was already released?
			if ((currentButton[i] == HOLDRELEASED) ||
				(currentButton[i] == NEWRELEASED))
			{
				//button is hold released
				currentButton[i] = HOLDRELEASED;
			}
			//button was not released?
			else
			{
				//button is new released
				currentButton[i] = NEWRELEASED;
			}
		}
	}

	//save moving of mouse
	movedX = dims2.lX;
	movedY = dims2.lY;

	return S_OK;
}

/****************************************************************************
** Mouse setExclusiveMode
**
** only this object will receive key states!
**
** Author: Dirk Plate
****************************************************************************/
void Mouse::setExclusiveMode(void *pObject, bool enable)
{
	//enable exclusive mode
	if (enable)
	{
		exclusive = true;
		pExclusiveObject = pObject;
	}
	//disable exclusive mode
	else
	{
		//only objects which enabled it can disable it
		if (pObject == pExclusiveObject)
		{
			exclusive = false;
			pExclusiveObject = NULL;
		}
	}
}

/****************************************************************************
** Mouse getButtonState
**
** access state of one button
**
** Author: Dirk Plate
****************************************************************************/
Mouse::ButtonState Mouse::getButtonState(void *pObject, Button button)
{
	//if disabled or exclusive mode with false object -> return unknown
	if ((!enabled) ||
		((exclusive) && (pObject != pExclusiveObject)))
		return ButtonState::UNKNOWN;

	//return state
	return currentButton[button];
}

/****************************************************************************
** Mouse getMovedX
**
** access x moving of mouse
**
** Author: Dirk Plate
****************************************************************************/
long Mouse::getMovedX(void *pObject)
{
	//if disabled or exclusive mode with false object -> return 0
	if ((!enabled) ||
		((exclusive) && (pObject != pExclusiveObject)))
		return 0;

	return movedX;
}

/****************************************************************************
** Mouse getMovedY
**
** access y moving of mouse
**
** Author: Dirk Plate
****************************************************************************/
long Mouse::getMovedY(void *pObject)
{
	//if disabled or exclusive mode with false object -> return 0
	if ((!enabled) ||
		((exclusive) && (pObject != pExclusiveObject)))
		return 0;

	return movedY;
}