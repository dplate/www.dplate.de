/****************************************************************************
** Mouse
**
** manage mouse inputs
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_MOUSE)
#define H_MOUSE
#pragma warning(disable:4786)

#define DIRECTINPUT_VERSION 0x0800
#define BUTTONDOWN(name, button) (name[button] & 0x80)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <dinput.h>

class Mouse
{
public:
	Mouse();
	~Mouse();

	//init object
	HRESULT init(LPDIRECTINPUTDEVICE8  pDIMouseDevice);

	//retrieve all inputs
	HRESULT update();

	//enum with all button states
	enum ButtonState {UNKNOWN, HOLDPRESSED, NEWPRESSED, HOLDRELEASED, NEWRELEASED};
	enum Button {LEFT = 0, RIGHT = 1, MIDDLE = 2};

	//access state of one button
	ButtonState getButtonState(void *pObject, Button button);

	//access x moving of mouse
	long getMovedX(void *pObject);

	//access y moving of mouse
	long getMovedY(void *pObject);

	//en- or disable mouse
	void enable(bool enable) {enabled = enable;}

	//only this object will receive mouse actions!
	void setExclusiveMode(void *pObject, bool enable);


private:
	//the directx device
	LPDIRECTINPUTDEVICE8  pDIMouseDevice;

	//state of all buttons in current frame
	ButtonState currentButton[3];

	//moved in last frame
	long movedX, movedY;

	//en- or disabled
	bool enabled;

	//exclusive mode
	bool exclusive;
	void *pExclusiveObject;
};

#endif