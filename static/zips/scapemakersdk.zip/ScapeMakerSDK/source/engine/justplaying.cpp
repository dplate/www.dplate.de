#include "justplaying.h"

#include "logger/logger.h"

//-----------------------------------------------------------------------------
// Defines, constants, and global variables for the sample quad
//-----------------------------------------------------------------------------
//a quad
#define NUM_VERTS 4
#define NUM_TRIS  2

// A structure for our custom vertex type
struct CUSTOMVERTEX
{
    D3DXVECTOR3 position; // The position.
    D3DCOLOR    color;    // The color.
    FLOAT       tu, tv;   // The texture coordinates.
};


// Our custom FVF, which describes our custom vertex structure
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)

// Initialize vertices for a QUAD
CUSTOMVERTEX vertices[4];

JustPlaying::JustPlaying()
{

}

JustPlaying::~JustPlaying()
{

}

HRESULT JustPlaying::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	this->pD3DDevice = pD3DDevice;

	vertices[0].position	= D3DXVECTOR3(-4.0f, -4.0f, 0.0f);
	vertices[0].color		= 0xffffffff;
	vertices[0].tu			= 0.0f;
	vertices[0].tv			= 1.0f;

	vertices[1].position	= D3DXVECTOR3( 4.0f, -4.0f, 0.0f);
	vertices[1].color		= 0xffffffff;
	vertices[1].tu			= 1.0f;
	vertices[1].tv			= 1.0f;

	vertices[2].position	= D3DXVECTOR3( 4.0f,  6.0f, 0.0f);
	vertices[2].color		= 0xffffffff;
	vertices[2].tu			= 1.0f;
	vertices[2].tv			= 0.0f;

	vertices[3].position	= D3DXVECTOR3(-4.0f,  6.0f, 0.0f);
	vertices[3].color		= 0xffffffff;
	vertices[3].tu			= 0.0f;
	vertices[3].tv			= 0.0f;

	if( FAILED( D3DXCreateTextureFromFile( pD3DDevice, "basetexture.bmp",
                                       &pBaseTexture ) ) )
    {
		LOG("Load Texture failed", Logger::LOG_CRIT);
		return E_FAIL;
    }

    if (FAILED( pD3DDevice->CreateVertexBuffer( NUM_VERTS*sizeof(CUSTOMVERTEX),
                                                  D3DUSAGE_WRITEONLY, D3DFVF_CUSTOMVERTEX,
                                                  D3DPOOL_DEFAULT, &pVB, NULL ) ) )
	{
		LOG("Create Vertex Buffer failed", Logger::LOG_CRIT);
        return E_FAIL;
	}

    VOID* pVertices;

    if (FAILED( pVB->Lock( 0, sizeof(vertices), (VOID**)&pVertices, D3DLOCK_DISCARD ) ) )
    {
		LOG("Vertex Buffer Lock failed", Logger::LOG_CRIT);
        return E_FAIL;
	}

    memcpy( pVertices, vertices, sizeof(vertices) );
	pVB->Unlock();
	
	LOG("Quad created OK");

	return S_OK;
}

HRESULT JustPlaying::destroyGeometry()
{
	if(pVB)
	{
		pVB->Release();
		pVB = NULL;
	}

	if(pBaseTexture)
	{
		pBaseTexture->Release();
		pBaseTexture = NULL;
	}
	
	return S_OK;
}

HRESULT JustPlaying::render()
{
	pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );

	pD3DDevice->SetTexture( 0, pBaseTexture );
	
	pD3DDevice->SetStreamSource( 0, pVB, NULL, sizeof(CUSTOMVERTEX) );
	pD3DDevice->SetVertexShader( NULL );
	pD3DDevice->SetFVF( D3DFVF_CUSTOMVERTEX );

	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	pD3DDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, 0, NUM_TRIS );

	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW );
	
	return S_OK;
}

HRESULT JustPlaying::update()
{
	return S_OK;
}