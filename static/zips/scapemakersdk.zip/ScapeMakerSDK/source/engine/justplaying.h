/****************************************************************************
** JustPlaying
**
** trying stuff, rendering ...
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(JUSTPLAYING_H)
#define JUSTPLAYING_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>

#include "./common/DirectXFont.h"

class JustPlaying
{
public:
	JustPlaying();
	~JustPlaying();

	HRESULT update();
	HRESULT render();
	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT destroyGeometry();
	
	D3DXMATRIX *pWorldMatrix;

private:
	LPDIRECT3DVERTEXBUFFER9 pVB;		
	LPDIRECT3DTEXTURE9		pBaseTexture;

	LPDIRECT3DDEVICE9		pD3DDevice;
};

#endif 
