// --------------------------------------------------------------------------------------------------------------------------------
// Copyright 2000, Paul Nettle. All rights reserved.
//
// Logger.cpp - Log file class
//
// [NOTE] This file is best viewed in 132 column mode with 8-character tabs
//
// THIS FILE HAS BEEN ENTERED INTO THE PUBLIC DOMAIN BY THE AUTHOR
// --------------------------------------------------------------------------------------------------------------------------------

#include <time.h>
#include <stdarg.h>

#include "logger.h"

// --------------------------------------------------------------------------------------------------------------------------------
// The global logger
// --------------------------------------------------------------------------------------------------------------------------------

Logger	*logger;

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::start()
{
	if (logStarted()) return;
	_logStarted = true;

	// Get the time

	time_t	t = time(NULL);
	string	ts = asctime(localtime(&t));
	ts[ts.length() - 1] = 0;

	ofstream of(logFile().c_str(), ios::out/*|ios::app*/);
	if (of.is_open())
	{
		of << "---------------------------------------------- Log begins on " << ts << " ----------------------------------------------" << endl;
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::stop()
{
	// Automatic One time only startup

	if (!logStarted()) return;

	// Get the time

	time_t	t = time(NULL);
	string	ts = asctime(localtime(&t));
	ts[ts.length() - 1] = 0;

	// Start the log

	ofstream of(logFile().c_str(), ios::out|ios::app);
	if (of.is_open())
	{
		of << "----------------------------------------------- Log ends on " << ts << " -----------------------------------------------" << endl << endl << endl << endl << endl;
	}

	_logStarted = false;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::logTex(const string &s, const LogFlags logBits)
{
	// If the bits don't match the mask, then bail

	if (!(logBits & logMask())) return;

	// Open the file

	ofstream of(logFile().c_str(), ios::out|ios::app);
	if (!of.is_open()) return;

	// Output to the log file

	of << headerString(logBits) << s << endl;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::logRaw(const string &s)
{
	// Open the file

	ofstream of(logFile().c_str(), ios::out|ios::app);
	if (!of.is_open()) return;

	// Log the output

	of << s;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::logHex(const char *buffer, const unsigned int count, const LogFlags logBits)
{
	// No input? No output

	if (!buffer) return;

	// If the bits don't match the mask, then bail

	if (!(logBits & logMask())) return;

	// Open the file

	ofstream of(logFile().c_str(), ios::out|ios::app);
	if (!of.is_open()) return;

	// Log the output

	unsigned int	logged = 0;
	while(logged < count)
	{
		// One line at a time...

		string		line;

		// The number of characters per line

		unsigned int	hexLength = 20;

		// Default the buffer

		for (unsigned int i = 0; i < hexLength; i++)
		{
			line += "-- ";
		}

		for (i = 0; i < hexLength; i++)
		{
			line += ".";
		}

		// Fill it in with real data

		for (i = 0; i < hexLength && logged < count; i++, logged++)
		{
			unsigned char	byte = buffer[logged];
			unsigned int	index = i * 3;

			// The hex characters

			const char	*hexlist="0123456789ABCDEF";
			line[index+0] = hexlist[byte >> 4];
			line[index+1] = hexlist[byte & 0xf];

			// The ascii characters

			if (byte < 0x20 || byte > 0x7f) byte = '.';
			line[(hexLength*3)+i+0] = byte;
		}

		// Write it to the log file

		of << headerString(logBits) << line << endl;
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::indent(const string &s, const LogFlags logBits)
{
	// If the bits don't match the mask, then bail

	if (!(logBits & logMask())) return;

	// Open the file

	ofstream of(logFile().c_str(), ios::out|ios::app);
	if (!of.is_open()) return;

	// Log the output

	if (lineCharsFlag())	of << headerString(logBits) << " \xDA " << s << endl;
	else			of << headerString(logBits) << " +- " << s << endl;

	// Indent...

	_indentCount += _indentChars;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Logger::undent(const string &s, const LogFlags logBits)
{
	// If the bits don't match the mask, then bail

	if (!(logBits & logMask())) return;

	// Undo the indentation

	_indentCount -= _indentChars;
	if (_indentCount < 0) _indentCount = 0;

	// Open the file

	ofstream of(logFile().c_str(), ios::out|ios::app);
	if (!of.is_open()) return;

	// Log the output

	if (lineCharsFlag())	of << headerString(logBits) << " \xC0 " << s << endl;
	else			of << headerString(logBits) << " +- " << s << endl;
}

// --------------------------------------------------------------------------------------------------------------------------------

const	string	&Logger::headerString(const LogFlags logBits) const
{
	static	string	headerString;
	headerString.erase();

	// Get the string that represents the bits

	switch(logBits)
	{
		case LOG_INDENT : headerString += "> "; break;
		case LOG_UNDENT : headerString += "< "; break;
		case LOG_ALL    : headerString += "A "; break;
		case LOG_CRIT   : headerString += "! "; break;
		case LOG_DATA   : headerString += "D "; break;
		case LOG_ERR    : headerString += "E "; break;
		case LOG_FLOW   : headerString += "F "; break;
		case LOG_INFO   : headerString += "I "; break;
		case LOG_WARN   : headerString += "W "; break;
		default:          headerString += "  "; break;
	}

	// File string (strip out the path)

	char	temp[1024];
	int	ix = sourceFile().rfind('\\');
	ix = ix == string::npos ? 0: ix+1;
	sprintf(temp, "%20s[%04d]", sourceFile().substr(ix).c_str(), sourceLine());
	headerString += temp;

	// Time string (specially formatted to save room)

	time_t	t = time(NULL);
	struct	tm *tme = localtime(&t);
	sprintf(temp, "%02d/%02d %02d:%02d ", tme->tm_mon + 1, tme->tm_mday, tme->tm_hour, tme->tm_min);
	headerString += temp;

	// Spaces for indentation

	memset(temp, ' ', sizeof(temp));
	temp[_indentCount] = '\0';

	// Add the indentation markers

	int	count = 1;
	while(count < _indentCount)
	{
		if (lineCharsFlag())	temp[count] = '\xB3';
		else			temp[count] = '|';
		count += _indentChars;
	}
	headerString += temp;

	return headerString;
}

// --------------------------------------------------------------------------------------------------------------------------------
// Logger - End of file
// --------------------------------------------------------------------------------------------------------------------------------

