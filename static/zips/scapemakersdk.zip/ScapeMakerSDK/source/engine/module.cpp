#include "module.h"

/****************************************************************************
** Module Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Module::Module()
{
	state = UNINITIALISED;
}

Module::~Module()
{
}

/****************************************************************************
** Module CreateGeometry
**
** initializes the objects
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Module::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	state = INITIALISED;
	return S_OK;
}

/****************************************************************************
** Module DestroyGeometry
**
** destroy the objects, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Module::destroyGeometry()
{
	state = UNINITIALISED;
	return S_OK;
}

/****************************************************************************
** Module Update
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Module::update()
{
	return S_OK;
}

/****************************************************************************
** Module Render
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Module::render(ModuleRenderType renderType)
{
	return S_OK;
}

















