/****************************************************************************
** Module
**
** basic class for all elements (modules) of engine
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(MODULE_H)
#define MODULE_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <string>

enum ModuleState {UNINITIALISED,INITIALISED};
enum ModuleRenderType {DEFAULT,REFLECTION,DEPTH};

class Module
{
public:
	Module();
	virtual ~Module();

	virtual HRESULT update();
	virtual HRESULT render(ModuleRenderType renderType);
	virtual HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	virtual HRESULT	destroyGeometry();

	ModuleState getState() {return state;}
	std::string getName() {return name;}

protected:
	ModuleState state;
	std::string name;
};

#endif