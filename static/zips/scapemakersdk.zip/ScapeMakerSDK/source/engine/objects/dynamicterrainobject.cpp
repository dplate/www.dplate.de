#include "dynamicterrainobject.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../terrain/terrain.h"
#include "ximage.h"
#include "../common/config.h"

/****************************************************************************
** DynamicTerrainObject Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
DynamicTerrainObject::DynamicTerrainObject()
{
	probabilities = NULL;
	probabilitiesSize = 0;

	area = NULL;
	areaSize = 0;
	offsetX = 0;
	offsetY = 0;
}

DynamicTerrainObject::~DynamicTerrainObject()
{
}

/****************************************************************************
** TileStruct Constructor
**
** initialise
**
** Author: Dirk Plate
****************************************************************************/
DynamicTerrainObject::TileStruct::TileStruct()
{
	pBoundingBox = NULL;
	currentVisible = -1;
	count = 0;
}

DynamicTerrainObject::TileStruct::~TileStruct()
{
	SAFE_DELETE(pBoundingBox);
}


/****************************************************************************
** DynamicTerrainObject CreateGeometry
**
** initializes the dynamic terrain object (calls all the loading functions)
**
** Author: Dirk Plate
****************************************************************************/
HRESULT DynamicTerrainObject::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
											 const char* objectPath, 
											 bool forShadowGen)
{
	HRESULT hr;

	//call function of super class first
	if (FAILED(hr=Object::createGeometry(pD3DDevice,objectPath,forShadowGen)))
	{
		LOG("Creating object base class failed", Logger::LOG_CRIT);
		return hr;
	}

	//read settings
	MiniXML xmlFile;
	//read settings
	string settingsFilePath = string(objectPath)+"\\settings.txt";
	if (xmlFile.openFile(settingsFilePath.c_str(),MiniXML::READ))
	{
		char string[512];
		bool bValue;
		float fValue;

		if (xmlFile.readString("file",string,512))
		{
			//add lod to mesh list
			int lodIndex;
			if (FAILED(hr=addLOD(string,&lodIndex)))
			{
				LOG("Loading object lod failed", Logger::LOG_CRIT);
				return hr;
			}
			if (lodIndex != -1) 
			{
				//billboard or not?
				if (xmlFile.readBoolean("billBoard",&bValue))
					meshes[lodIndex].billBoard = bValue;

				//read the maxdistance value
				if (xmlFile.readFloat("maxDistance",&fValue))
					meshes[lodIndex].maxDistance = fValue;

				//set mindistance
				meshes[lodIndex].minDistance = 0.0f;
			}
		}
		xmlFile.closeFile();
	}

	//calculate neccessary border around tiles
	MeshTool *mesh = NULL;
	//get the intern mesh structure of the mesh
	mesh = new MeshTool(meshes[0].mesh);
	
	//find the extremes
	float max = 0.0f;
	for(int j=0; j<mesh->dwNumVertices; j++)
	{
		float absX,absY,absZ;
		
		absX = fabs(mesh->pVertices[j].p.x);
		absY = fabs(mesh->pVertices[j].p.y);
		absZ = fabs(mesh->pVertices[j].p.z);

		max = MAX(max,absX);
		max = MAX(max,absY);
		max = MAX(max,absZ);	
	}
	//delete opened mesh
	SAFE_DELETE(mesh);
	tileBorderSize = D3DXVECTOR3(max,max,max);


	//load probability map
	CxImage positionsBitmap;
	string positionsBmpFilePath = string(objectPath)+"\\positions.jpg";
	
	if (positionsBitmap.Load(positionsBmpFilePath.c_str(), CXIMAGE_FORMAT_JPG))
	{
		//size is size of terrain
		probabilitiesSize = Terrain::instance->getWidth();

		// allocate the array
		probabilities = new float*[probabilitiesSize];
		for (int i=0;i<probabilitiesSize;i++)
			probabilities[i] = new float[probabilitiesSize];

		//save probability on each pixel of bitmap
		for (int y=0; y<probabilitiesSize; y++)
			for (int x=0; x<probabilitiesSize; x++)
		{
			// store it in the array
			if (x>=positionsBitmap.GetWidth() || y>=positionsBitmap.GetHeight())
				probabilities[x][y] = 0.0f;
			else
				probabilities[x][y] = ((float)positionsBitmap.GetPixelGray(x,y))/255.0f;
		}
	}
	

	//load the addition position information (scale range....)
	minimalScale = 1.0f;
	maximalScale = 1.0f;
	string positionsFilePath = string(objectPath)+"\\positions.txt";
	if (xmlFile.openFile(positionsFilePath.c_str(),MiniXML::READ))
	{
		float value;

		if (xmlFile.readFloat("minimalScale",&value))
			minimalScale = value;

		if (xmlFile.readFloat("maximalScale",&value))
			maximalScale = value;

		xmlFile.closeFile();
	}

	
	//calculate area size
	//the area size is the maximum visible range in both directions (front and back) 
	areaSize = (meshes[0].maxDistance+tileBorderSize.x)*2;
	//create and initialise area (and temparea)
	int x,y;
	area = new TileStruct**[areaSize];
	tempArea = new TileStruct**[areaSize];
	for (x=0;x<areaSize;x++)
	{
		area[x] = new TileStruct*[areaSize];
		for (y=0;y<areaSize;y++)
			area[x][y] = NULL;

		tempArea[x] = new TileStruct*[areaSize];
		for (y=0;y<areaSize;y++)
			tempArea[x][y] = NULL;
	}
				

	return S_OK;
}

/****************************************************************************
** DynamicTerrainObject DestroyGeometry
**
** destroy the dynamic terrain object, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT DynamicTerrainObject::destroyGeometry()
{
	int i,x,y;

	//call function of super class first
	Object::destroyGeometry();

	//delete probability array
	for (i=0;i<probabilitiesSize;i++)
		SAFE_DELETE_ARRAY(probabilities[i]);
	SAFE_DELETE_ARRAY(probabilities);

	//delete area
	for (x=0;x<areaSize;x++)
	{
		for (y=0;y<areaSize;y++)
			SAFE_DELETE(area[x][y]);
		SAFE_DELETE_ARRAY(area[x]);

		for (y=0;y<areaSize;y++)
			SAFE_DELETE(tempArea[x][y]);
		SAFE_DELETE_ARRAY(tempArea[x]);
	}
	SAFE_DELETE_ARRAY(area);
	SAFE_DELETE_ARRAY(tempArea);

	return S_OK;
}

/****************************************************************************
** DynamicTerrainObject Update
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT DynamicTerrainObject::update()
{
	//call function of super class first
	Object::update();

	//update area
	updateArea();
	
	return S_OK;
}

/****************************************************************************
** DynamicTerrainObject updateArea
**
** Update the tiles in the area around camera
**
**
** Author: Dirk Plate
****************************************************************************/
void DynamicTerrainObject::updateArea()
{
	int newX,newY,oldX,oldY;
	int newOffsetX,newOffsetY;
	int offsetDiffX,offsetDiffY;
	TileStruct ***tmp1;
	TileStruct *tmp2;
	int terrainSize = Terrain::instance->getWidth();

	//calculate the new offset
	newOffsetX = Camera::instance->getPosition().x-areaSize/2;
	newOffsetY = Camera::instance->getPosition().z-areaSize/2;

	//calculate the difference between new and old offset
	offsetDiffX = newOffsetX-offsetX;
	offsetDiffY = newOffsetY-offsetY;

	//move area if offset changed
	if ((offsetDiffX != 0) || (offsetDiffY != 0))
	{
		//switch area to tempArea
		tmp1 = tempArea;
		tempArea = area;
		area = tmp1;
	
		//go through all tiles of the new area
		for (newX=0;newX<areaSize;newX++)
			for (newY=0;newY<areaSize;newY++)
		{
			//if new tile of area outside terrain (+security) -> continue with next one
			if ((newOffsetX+newX < 1) || (newOffsetX+newX >= terrainSize-2) ||
				(newOffsetY+newY < 1) || (newOffsetY+newY >= terrainSize-2))
			{
				area[newX][newY] = NULL;
				continue;
			}

			//calculate the position in the old area
			oldX = offsetDiffX+newX;
			oldY = offsetDiffY+newY;

			//if old position not in old area -> create a new tile
			//or if not a tile defined in old area -> create a new tile
			if ((oldX < 0) || (oldX >= areaSize) ||
				(oldY < 0) || (oldY >= areaSize) || 
				(tempArea[oldX][oldY] == NULL))
			{
				//fill the tile
				createTile(newX,newY,newOffsetX+newX,newOffsetY+newY);
			}
			//there is a tile defined in old area -> copy the tile from temporary array
			else
			{
				tmp2 = tempArea[oldX][oldY];
				area[newX][newY] = tmp2;
				tempArea[oldX][oldY] = NULL;
			}
		}

		//save new offset
		offsetX = newOffsetX;
		offsetY = newOffsetY;
	}

	//update all tiles
	for (newX=0;newX<areaSize;newX++)
		for (newY=0;newY<areaSize;newY++)
	{
		if (area[newX][newY] != NULL)
			updateTile(newX,newY);
	}

	//go through all tiles of the old area
	for (oldX=0;oldX<areaSize;oldX++)
		for (oldY=0;oldY<areaSize;oldY++)
	{
		//delete the tiles, which were not moved (they are outside the new area)
		if (tempArea[oldX][oldY] != NULL)
		{
			//delete all positions
			for (int i=0;i<tempArea[oldX][oldY]->count;i++)
				removePosition(tempArea[oldX][oldY]->objects[i]);
			SAFE_DELETE(tempArea[oldX][oldY]);
		}
	}
}

/****************************************************************************
** DynamicTerrainObject updateTile
**
** update a tile (visibility and blending)
**
** Author: Dirk Plate
****************************************************************************/
void DynamicTerrainObject::updateTile(int tileX,int tileY)
{
	int i;
	float minDistance,maxDistance, middleDistance;
	float difference;

	//update visibility
	//make tiles behind you invisible
	int visibility = Camera::instance->getViewFrustum()->cullAABB(area[tileX][tileY]->pBoundingBox);
	
	//also visibility for reflection?
	if (Config::instance->isSubMeshesReflection())
	{
		int reflectionVisibility = Camera::instance->getReflectViewFrustum()->cullAABB(area[tileX][tileY]->pBoundingBox);

		//combine both results
		if (visibility != reflectionVisibility) 
			visibility = VF_CLIPPED;
	}
		
	//mark objects as invisible
	if (visibility == VF_OUTSIDE)
	{
		if (area[tileX][tileY]->currentVisible != 0)
		{	
			for (i=0;i<area[tileX][tileY]->count;i++)
			{
				//make completely invisible
				setPositionLODVisible(area[tileX][tileY]->objects[i]);
			}
		}
		area[tileX][tileY]->currentVisible = 0;
		return;
	}

	//make objects to far away invisible
	//find min+max distance to bounding box
	area[tileX][tileY]->pBoundingBox->getMinDistance(Camera::instance->getPosition(),&minDistance);
	area[tileX][tileY]->pBoundingBox->getMaxDistance(Camera::instance->getPosition(),&maxDistance);

	//if tile complete to far away -> make all objects invisible
	if (minDistance > meshes[0].maxDistance)
	{
		if (area[tileX][tileY]->currentVisible != 0)
		{	
			for (i=0;i<area[tileX][tileY]->count;i++)
			{
				//make completly invisible
				setPositionLODVisible(area[tileX][tileY]->objects[i]);
			}
		}
		area[tileX][tileY]->currentVisible = 0;
		return;
	}
	//if tile on the border of max distance (maybe in, maybe out) -> check all objects of tile
	else if (((minDistance > meshes[0].maxDistance-DYNAMICTERRAINOBJECTBLENDDISTANCE) &&
			  (minDistance < meshes[0].maxDistance)) ||
			 ((maxDistance > meshes[0].maxDistance-DYNAMICTERRAINOBJECTBLENDDISTANCE) &&
			  (maxDistance < meshes[0].maxDistance)))
	{
		for (i=0;i<area[tileX][tileY]->count;i++)
		{
			//find distance to object
			middleDistance = D3DXVec3Length(&(positions[area[tileX][tileY]->objects[i]].position-
											Camera::instance->getPosition()));
			if (middleDistance > meshes[0].maxDistance)
			{
				//make completly invisible
				setPositionLODVisible(area[tileX][tileY]->objects[i]);
			}
			else
			{
				//update transformation matrix
				if (meshes[0].billBoard)
				{
					calcTransformationMatrix(area[tileX][tileY]->objects[i],true,
						positions[area[tileX][tileY]->objects[i]].lod[0].pTransformation);
				}
				
				//blending required?
				difference = meshes[0].maxDistance-middleDistance;
				if (difference <= DYNAMICTERRAINOBJECTBLENDDISTANCE)
				{
					//enable blending
					setPositionLODAlpha(area[tileX][tileY]->objects[i],0,
						difference/DYNAMICTERRAINOBJECTBLENDDISTANCE);
				}
				else 
				{
					//disable blending
					setPositionLODAlpha(area[tileX][tileY]->objects[i]);
				}

				//make completly visible
				setPositionLODVisible(area[tileX][tileY]->objects[i],0);
			}
		}
		area[tileX][tileY]->currentVisible = -1;
		return;
	}
	//all objects are complete visible
	else
	{
		if (area[tileX][tileY]->currentVisible != 1)
		{
			for (i=0;i<area[tileX][tileY]->count;i++)
			{
				//disable blending
				setPositionLODAlpha(area[tileX][tileY]->objects[i]);

				//make completly visible
				setPositionLODVisible(area[tileX][tileY]->objects[i],0);
			}
		}
		area[tileX][tileY]->currentVisible = 1;

		//update transformation matrix
		if (meshes[0].billBoard)
		{
			for (i=0;i<area[tileX][tileY]->count;i++)
			{
				calcTransformationMatrix(area[tileX][tileY]->objects[i],true,
					positions[area[tileX][tileY]->objects[i]].lod[0].pTransformation);
			}
		}
		
		return;
	}
}

/****************************************************************************
** DynamicTerrainObject createTile
**
** fill a tile of area with positions for this object
**
** Author: Dirk Plate
****************************************************************************/
void DynamicTerrainObject::createTile(int areaX,int areaY, int terrainX, int terrainY)
{
	float terrainXFloat = (float)terrainX;
	float terrainYFloat = (float)terrainY;
	float positionX,positionY;
	float propability;
	float randValue;
	float rotation;
	float scale;
	
	//create new tile struct
	area[areaX][areaY] = new TileStruct;

	//calculate boundingbox for this tile
	D3DXVECTOR3 extremes[2];
	extremes[0].x = terrainX;
	extremes[0].z = terrainY;
	extremes[0].y = Terrain::instance->getHeight(terrainX,terrainY);
	extremes[0].y = MIN(extremes[0].y,Terrain::instance->getHeight(terrainX+1,terrainY));
	extremes[0].y = MIN(extremes[0].y,Terrain::instance->getHeight(terrainX,terrainY+1));
	extremes[0].y = MIN(extremes[0].y,Terrain::instance->getHeight(terrainX+1,terrainY+1));
	extremes[0] -= tileBorderSize;

	extremes[1].x = terrainX+1;
	extremes[1].z = terrainY+1;
	extremes[1].y = Terrain::instance->getHeight(terrainX,terrainY);
	extremes[1].y = MAX(extremes[1].y,Terrain::instance->getHeight(terrainX+1,terrainY));
	extremes[1].y = MAX(extremes[1].y,Terrain::instance->getHeight(terrainX,terrainY+1));
	extremes[1].y = MAX(extremes[1].y,Terrain::instance->getHeight(terrainX+1,terrainY+1));
	extremes[1] += tileBorderSize;

	area[areaX][areaY]->pBoundingBox = new AABB(extremes,2);


	//fill tile with positions
	float floatRandMax = (float)RAND_MAX;
	area[areaX][areaY]->count = 0;
	for (int i=0;i<DYNAMICTERRAINOBJECTMAXTRIES;i++)
	{
		//get a random position
		positionX = ((float)rand())/floatRandMax+terrainXFloat;
		positionY = ((float)rand())/floatRandMax+terrainYFloat;

		//get propability for this terrain
		propability = getInterpolatedProbability(terrainX,terrainY,terrainX+1,terrainY+1,positionX,positionY);

		randValue = rand();
		if (randValue < propability*floatRandMax)
		{
			//make a random rotation
			rotation = ((float)rand())/floatRandMax*2*D3DX_PI;

			//make a random scale
			scale = minimalScale+((float)rand())/floatRandMax*(maximalScale-minimalScale);

			//add object
			area[areaX][areaY]->objects[area[areaX][areaY]->count] = 
				addPosition(D3DXVECTOR2(positionX,positionY),scale,0.0f,rotation,0.0f,true,false);
			area[areaX][areaY]->count++;
		}
	}
}

/****************************************************************************
** DynamicTerrainObject getInterpolatedProbability
**
** Calculate the probability of a terrainpoint between edges
** 
** Author: Dirk Plate
****************************************************************************/
float DynamicTerrainObject::getInterpolatedProbability(int luX, int luY, int rdX, int rdY, float pointX, float pointY) 
{
/*
	P3(x1,y2,z3) ----- P4 (x2,y2,z4)
			     |\  |
			     | \ |
			     |  \|
    P1(x1,y1,z1) ----- P2 (x2,y1,z2)
*/

	float a = (float)(pointX-luX)/(float)(rdX - luX);
	float b = 1.0f-(float)(pointY-luY)/(float)(rdY - luY);

	// look at the drawing above
	int x1 = luX;	
	int y1 = rdY;
	int x2 = rdX;			
	int y2 = luY;
	
	if ((a+b) < 1.0f) //point in the lower triangle?
	{
		//get the probability of the triangle edges
		float z1 = probabilities[x1][y1];
		float z2 = probabilities[x2][y1];
		float z3 = probabilities[x1][y2];

		return (z1-(z1-z2)*a-(z1-z3)*b); //calc. the propability
	}
	else //then point in the upper triangle
	{
		//get the probability of the triangle edges
		float z2 = probabilities[x2][y1];
		float z3 = probabilities[x1][y2];
		float z4 = probabilities[x2][y2];

		return (z3-z4+z2-(z3-z4)*a-(z2-z4)*b); //calc. the propability		
	}
}

/****************************************************************************
** DynamicTerrainObject getObjectColor
**
** return the color of the object at this position (ambient or diffuse)
**
** Author: Dirk Plate
****************************************************************************/

D3DCOLOR DynamicTerrainObject::getObjectColor(int positionIndex)
{
	//take the color from the lightmap at this position
	return Terrain::instance->getLightColor(positions[positionIndex].position.x,positions[positionIndex].position.z);
}


