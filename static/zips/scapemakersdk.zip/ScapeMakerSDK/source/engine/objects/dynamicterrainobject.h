/****************************************************************************
** DynamicTerrainObject
**
** dynamic terrain objects (like grass) rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(DYNAMICTERRAINOBJECT_H)
#define DYNAMICTERRAINOBJECT_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>

#include "../camera/viewfrustum.h"
#include "object.h"
#include "../common/AABB.h"
#include "../../common/minixml.h"

#define DYNAMICTERRAINOBJECTBLENDDISTANCE 4.0f
#define DYNAMICTERRAINOBJECTMAXTRIES 15

class DynamicTerrainObject : public Object
{
public:
	DynamicTerrainObject();
	~DynamicTerrainObject();

	virtual HRESULT update();

	virtual HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
								   const char* objectPath,	
								   bool forShadowGen=false);
	virtual HRESULT	destroyGeometry();

protected:
	virtual D3DCOLOR getObjectColor(int positionIndex);

private:
	void updateArea();
	void updateTile(int tileX,int tileY);
	void createTile(int areaX,int areaY, int terrainX, int terrainY);
	float getInterpolatedProbability(int luX, int luY, int rdX, int rdY, float pointX, float pointY);
	
	float **probabilities;	//the probability for this object between 0 and 1 for each edge of the landscape
	int probabilitiesSize;	//how big is the probabilities 2D array? (Its not sure its so big as the terrain)

	float minimalScale;		//the minimal scale of the object
	float maximalScale;		//the maximal scale of the object

	//the properties of one terrain tile
	struct TileStruct
	{
		TileStruct();
		~TileStruct();
		int objects[DYNAMICTERRAINOBJECTMAXTRIES];	//list of all objects on this tile (const. size, so we don't need to reallocate)
		int count;			//the number of objects on this tile
		AABB *pBoundingBox;	//the bounding box around this tile (only for visibility testing)
		int currentVisible;	//visiblity of all objects in this area (if different visibilities -> -1, visible = 1, invisible = 0)
	};

	TileStruct ***area;		//the current area around camera
	TileStruct ***tempArea;	//a temporary pointer to a second area (for copying)
	int areaSize;			//the height/width of the current area
	int offsetX,offsetY;	//the offset of the current area

	D3DXVECTOR3 tileBorderSize;	//the size of the border around a tile to include all objects
};

#endif