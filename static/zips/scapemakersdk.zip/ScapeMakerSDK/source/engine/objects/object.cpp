#include "object.h"

#include "../logger/logger.h"
#include "../common/enginehelpers.h"
#include "../common/shaderconsts.h"
#include "../../common/minixml.h"
#include "../common/submeshes.h"
#include "../terrain/terrain.h"

/****************************************************************************
** Object Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Object::Object()
{
	meshCount = 0;
	collisionMesh = NULL;
	positionsCompleteFullMarker = 0;
	positionsFullMarker = 0;
	positions = NULL;
	positionsSize = 0;
	positionsBlockCount = 0;	

	pIntersectionMesh = NULL;
	pLockedIntersectionMesh = NULL;
}

Object::~Object()
{
}

/****************************************************************************
** Object CreateGeometry
**
** initializes the object (calls all the loading functions)
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Object::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
							   const char* objectPath, 
							   bool forShadowGen)
{
	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	strcpy(this->objectPath,objectPath);

	//its for shadowgen?
	shadowGenMode = forShadowGen;

	return S_OK;
}

/****************************************************************************
** Object DestroyGeometry
**
** destroy the object, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Object::destroyGeometry()
{
	int i,j,k;

	//go through all meshes
	for (i=0;i<meshCount;i++)
	{
		//destroy data for intersection testing
		if ((i==0))
		{
			SAFE_DELETE(pLockedIntersectionMesh);
			SAFE_RELEASE(pIntersectionMesh);
			SAFE_DELETE_ARRAY(facesIntersected);
			
			//delete octree
			deleteOctTree(&octTree);
		}

		//release mesh
		SAFE_RELEASE(meshes[i].mesh);
	
		//release textures
		for (j=0;j<meshes[i].materialCount;j++)
			SAFE_RELEASE(meshes[i].textures[j]);
		
		//delete dynamic lists
		if (meshes[i].materialCount > 0)
		{
			SAFE_DELETE_ARRAY(meshes[i].materials);
			SAFE_DELETE_ARRAY(meshes[i].textures);
			SAFE_DELETE_ARRAY(meshes[i].pIntersectionTextures);
		}

		//delete submeshes data
		SAFE_DELETE_ARRAY(meshes[i].pSubMeshAttribTable);
		SAFE_DELETE_ARRAY(meshes[i].pSubMeshCenters);
		SAFE_DELETE_ARRAY(meshes[i].pSubMeshAlphas);
	}
	meshCount = 0;

	//delete position relevant data
	for (j=0;j<positionsFullMarker;j++)
	{
		SAFE_DELETE(positions[j].pBoundingBox);
		
		for (k=0; k<meshCount; k++)
		{
			SAFE_DELETE(positions[j].lod[k].pTransformation);
			SAFE_DELETE(positions[j].lod[k].pColorValue);
			SAFE_DELETE(positions[j].lod[k].pAlphaBlend);
			SAFE_DELETE(positions[j].lod[k].pAlphaValue);
		}
	}
	SAFE_DELETE_ARRAY(positions);

	//delete collision mesh
	SAFE_RELEASE(collisionMesh);

	positionsCompleteFullMarker = 0;
	positionsFullMarker = 0;
	positionsSize = 0;
	positionsBlockCount = 0;	

	return S_OK;
}

/****************************************************************************
** Object Update
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Object::update()
{
	return S_OK;
}

/****************************************************************************
** Object addLOD
**
** Load a object from file and put it to the end of the mesh list of this 
** object
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Object::addLOD(const char* meshFile, int *pNewMeshID)
{
	LPD3DXBUFFER pD3DXMtrlBuffer;
	HRESULT hr;
	LPD3DXMESH rawMesh1, rawMesh2;
	DWORD i;
	
	//if file name empty... break (compatibility to ScapeMaker <= v.1.1 objects)
	if (strcmp(meshFile, "") == 0)
	{
		*pNewMeshID = -1;
		return S_OK;
	}

	//set default values
	meshes[meshCount].minDistance = 0.0;
	meshes[meshCount].maxDistance = BIG_NUM;
	meshes[meshCount].billBoard = false;

	char meshPath[MAX_PATH];
	sprintf(meshPath, "%s\\%s", objectPath, meshFile);	

    // Load the mesh from the specified file
    if(FAILED(hr=(D3DXLoadMeshFromX(meshPath, D3DXMESH_SYSTEMMEM, 
                         pD3DDevice, NULL, 
                         &pD3DXMtrlBuffer, NULL, &meshes[meshCount].materialCount, 
                         &rawMesh1))))
    {
        LOG("Loading mesh from x-file failed", Logger::LOG_CRIT);
		return hr;
    }

	//convert mesh to right fvf
	if (FAILED(hr=(rawMesh1->CloneMeshFVF(D3DXMESH_SYSTEMMEM,
						D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1,
						pD3DDevice,&rawMesh2))))
    {
        LOG("Converting mesh to default FVF failed", Logger::LOG_CRIT);
		return hr;
    }
	SAFE_RELEASE(rawMesh1);

	//optimize mesh by sorting attributes (materials).
	if(FAILED(hr=rawMesh2->Optimize(D3DXMESHOPT_ATTRSORT|D3DXMESH_SYSTEMMEM, 
		NULL, NULL, NULL, NULL, &meshes[meshCount].mesh)))
	{
		LOG("Optimizing mesh failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(rawMesh2);

    // We need to extract the material properties and texture names from the pD3DXMtrlBuffer
    D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();

	//create dynamic lists with right size
    meshes[meshCount].materials = new D3DMATERIAL9[meshes[meshCount].materialCount];
    meshes[meshCount].textures  = new LPDIRECT3DTEXTURE9[meshes[meshCount].materialCount];
	meshes[meshCount].pIntersectionTextures  = new CxImage[meshes[meshCount].materialCount];

    for( i=0; i<meshes[meshCount].materialCount; i++ )
    {
        // Copy the material
        meshes[meshCount].materials[i] = d3dxMaterials[i].MatD3D;

        // Set the ambient and diffuse color to high value
      	meshes[meshCount].materials[i].Ambient.r = 1.0f;
		meshes[meshCount].materials[i].Ambient.g = 1.0f;
		meshes[meshCount].materials[i].Ambient.b = 1.0f;
		meshes[meshCount].materials[i].Diffuse.r = 1.0f;
		meshes[meshCount].materials[i].Diffuse.g = 1.0f;
		meshes[meshCount].materials[i].Diffuse.b = 1.0f;
	
        // Create the texture
		char texturePath[MAX_PATH];
		sprintf(texturePath, "%s\\%s", objectPath, d3dxMaterials[i].pTextureFilename);	
		
		//load texture from file
		if(FAILED(hr = EngineHelpers::loadTexture(pD3DDevice, texturePath, D3DFMT_UNKNOWN, &meshes[meshCount].textures[i])))
		{
			LOG("Loading object texture failed", Logger::LOG_CRIT);
			return hr;
		}

		//load texture uncompressed for intersection testing
		LPDIRECT3DTEXTURE9 pUncompressedTexture;
		if(FAILED(hr = EngineHelpers::loadTexture(pD3DDevice, texturePath, D3DFMT_A8R8G8B8, &pUncompressedTexture)))
		{
			LOG("Loading object texture (uncompressed) failed", Logger::LOG_CRIT);
			return hr;
		}

		//convert to cxImage
		//lock texture
		D3DLOCKED_RECT lockedRect;
		if (FAILED(hr=pUncompressedTexture->LockRect(0,&lockedRect,NULL,D3DLOCK_READONLY)))
		{
			LOG("Locking of uncompressed texture for intersecting testing failed", Logger::LOG_CRIT);
			return hr;
		}
		//convert
		CxImage loadedIntersectionTexture;
		D3DSURFACE_DESC	surfaceDesc;
		pUncompressedTexture->GetLevelDesc(0,&surfaceDesc);
		if (!loadedIntersectionTexture.CreateFromArray((unsigned char*)lockedRect.pBits,
								surfaceDesc.Width, surfaceDesc.Height, 
								32, lockedRect.Pitch, true))
		{
			LOG("Converting object texture for intersection failed", Logger::LOG_CRIT);
			return E_FAIL;
		}

		//release texture
		SAFE_RELEASE(pUncompressedTexture);

		//use only the alpha channel
		if (!loadedIntersectionTexture.AlphaSplit(&(meshes[meshCount].pIntersectionTextures[i])))
		{
			//cant get alpha... use small image with alpha 255
			meshes[meshCount].pIntersectionTextures[i].Create(1,1,8);
			meshes[meshCount].pIntersectionTextures[i].SetPixelIndex(0,0,255);
		}
    }

    // Done with the material buffer
    pD3DXMtrlBuffer->Release();

	//extract submeshes from mesh
	//get the submeshes-table
	if (FAILED(hr=meshes[meshCount].mesh->GetAttributeTable(NULL,&meshes[meshCount].subMeshCount)))
	{
		LOG("Retrieving attribute table (1) failed", Logger::LOG_CRIT);
		return hr;
	}
	meshes[meshCount].pSubMeshAttribTable = new D3DXATTRIBUTERANGE[meshes[meshCount].subMeshCount];
	if (FAILED(hr=meshes[meshCount].mesh->GetAttributeTable(meshes[meshCount].pSubMeshAttribTable,&meshes[meshCount].subMeshCount)))
	{
		LOG("Retrieving attribute table (2) failed", Logger::LOG_CRIT);
		return hr;
	}

	//calculate submeshes relevant data
	meshes[meshCount].pSubMeshCenters = new D3DXVECTOR3[meshes[meshCount].subMeshCount];
	meshes[meshCount].pSubMeshAlphas = new bool[meshes[meshCount].subMeshCount];
	for (DWORD subMeshID=0; subMeshID<meshes[meshCount].subMeshCount; subMeshID++)
	{
		//retrieve meshdata
		MeshTool *pMesh = new MeshTool(meshes[meshCount].mesh);
		
		//calculate center by adding all vertexes
		D3DXVECTOR3 center = D3DXVECTOR3(0,0,0);
		for(int j=meshes[meshCount].pSubMeshAttribTable[subMeshID].VertexStart; 
		        j<meshes[meshCount].pSubMeshAttribTable[subMeshID].VertexStart+
				  meshes[meshCount].pSubMeshAttribTable[subMeshID].VertexCount; j++)
		{
			//add vertex
			center += ((pMesh->pVertices)[j]).p;
		}
		//devide through vertex count
		center /= meshes[meshCount].pSubMeshAttribTable[subMeshID].VertexCount;

		//save center
		meshes[meshCount].pSubMeshCenters[subMeshID] = center;

		//release mesh
		SAFE_DELETE(pMesh);

		//submesh uses a texture with alpha?
		if (FAILED(hr=EngineHelpers::checkSubMeshAlpha(meshes[meshCount].mesh,
						  &(meshes[meshCount].pSubMeshAttribTable[subMeshID]),
						  &(meshes[meshCount].pIntersectionTextures[meshes[meshCount].pSubMeshAttribTable[subMeshID].AttribId]),
						  &(meshes[meshCount].pSubMeshAlphas[subMeshID]))))
		{
			LOG("Checking alpha of submesh failed", Logger::LOG_CRIT);
			return hr;			
		}
	}

	// do things for shadow generation and collision checking
	if ((meshCount == 0))
	{
		//clone mesh
		if (FAILED(hr=(meshes[meshCount].mesh->CloneMeshFVF(D3DXMESH_SYSTEMMEM,
				D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1,pD3DDevice,&pIntersectionMesh))))
		{
			LOG("Cloning mesh for intersection preparing failed", Logger::LOG_CRIT);
			return hr;
		}

		//lock the object mesh
		pLockedIntersectionMesh = new MeshTool(pIntersectionMesh);
		
		//create bounding box around mesh
		//create array for all vertices
		D3DXVECTOR3 *allVertices = new D3DXVECTOR3[pLockedIntersectionMesh->dwNumVertices];
		for(int j=0; j<pLockedIntersectionMesh->dwNumVertices; j++)
		{
			//add vertex to array
			allVertices[j] = ((pLockedIntersectionMesh->pVertices)[j]).p;
		}
		//create bounding box out of this vertices
		octTree.pBoundingBox = new AABB(allVertices,pLockedIntersectionMesh->dwNumVertices);

		SAFE_DELETE_ARRAY(allVertices);
	
		//build octree of mesh
		facesIntersectedCount = buildOctTree(&octTree,0);
		facesIntersectedCount++;

		//create flag array
		facesIntersected = new bool[facesIntersectedCount];

		//check octtree
		checkOctTree(&octTree);
	}
	else
	{
		//release intersection texture if not needed anymore
		SAFE_DELETE_ARRAY(meshes[meshCount].pIntersectionTextures);
	}

	*pNewMeshID = meshCount;
	meshCount++;
	
	return S_OK;;
}

/****************************************************************************
** Object setCollisionMesh
**
** Load a collision mesh from file 
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Object::setCollisionMesh(const char* meshFile)
{
	HRESULT hr;
	LPD3DXMESH rawMesh1;

	//reset collision mesh?
	if (strcmp(meshFile,"") == 0)
	{
		collisionMesh = NULL;
		return S_OK;
	}

	char meshPath[MAX_PATH];
	sprintf(meshPath, "%s\\%s", objectPath, meshFile);	

    // Load the collision mesh from the specified file
    if(hr=(D3DXLoadMeshFromX(meshPath, D3DXMESH_SYSTEMMEM, 
                             pD3DDevice, NULL, 
                             NULL, NULL, NULL,
                             &rawMesh1)) != D3D_OK)
    {
        LOG("Load collision mesh from x-file failed", Logger::LOG_CRIT);
		return hr;
    }

	//convert mesh to right fvf
	if (FAILED(hr=(rawMesh1->CloneMeshFVF(D3DXMESH_SYSTEMMEM,
						D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1,
						pD3DDevice,&collisionMesh))))
    {
        LOG("Converting collision mesh to default FVF failed", Logger::LOG_CRIT);
		return hr;
    }
	SAFE_RELEASE(rawMesh1);

	return S_OK;
}

/****************************************************************************
** Object addPosition
**
** Add a further position to this object (one more will be rendered).
** The height of this position will be the height of the terrain at the coor.
**
** Author: Dirk Plate
****************************************************************************/
int Object::addPosition(D3DXVECTOR2 position2D,float scaling,float rotationX,float rotationY,float rotationZ, bool findColor, bool createBoundingBox)
{
	D3DXVECTOR3 position;

	//calculate the height of the terrain at this coordinates
	position.x = position2D.x;
	position.z = position2D.y;
	position.y = Terrain::instance->getHeightInterpolated(position.x,position.z);
	
	//now add this position
	return addPosition(position,scaling,rotationX,rotationY,rotationZ,findColor,createBoundingBox);
}
	
/****************************************************************************
** Object addPosition
**
** Add a further position to this object (one more will be rendered).
**
** Author: Dirk Plate
****************************************************************************/
int Object::addPosition(D3DXVECTOR3 position,float scaling,float rotationX,float rotationY,float rotationZ, bool findColor, bool createBoundingBox)
{
	int index;
	int lodID;

	//find a free position
	for (index=positionsCompleteFullMarker;index<positionsFullMarker;index++)
		if (positions[index].free) break;
	if (index == positionsFullMarker)
	{
		//do we need to resize the array?
		if (index == positionsSize)
		{
			int newPositionsSize = POSITIONSBLOCKSIZE * (positionsBlockCount+1);
			PositionStruct *tmp = new PositionStruct[newPositionsSize];
			for (int i=0;i<positionsSize;i++)
				tmp[i] = positions[i];
			SAFE_DELETE_ARRAY(positions);
			positions = tmp;
			
			positionsSize = newPositionsSize;
			positionsBlockCount++;
		}

		positionsFullMarker++;
	}

	positions[index].free = false;
	positions[index].pBoundingBox = NULL;

	//create lod settings for all lods
	for (lodID=0; lodID < meshCount; lodID++)
	{
		//get settings from mesh and object
		positions[index].lod[lodID].setD3DDevice(pD3DDevice);
		positions[index].lod[lodID].pMesh = meshes[lodID].mesh;

		positions[index].lod[lodID].pAlphaBlend = new bool(false);
		positions[index].lod[lodID].pAlphaValue = new float(1.0f);
		positions[index].lod[lodID].pColorValue = new D3DCOLOR(0xffffffff);
		positions[index].lod[lodID].pTransformation = new D3DXMATRIX;
	}
	
	setPosition(index,position,scaling,rotationX,rotationY,rotationZ,true);
	positionsCompleteFullMarker = index+1;

	if (createBoundingBox)
	{
		//create bounding box
		D3DXVECTOR3 originalVector,transformedVector;
		D3DXVECTOR3 *allVertices;
		MeshTool *mesh = NULL;

		//if we have a collision mesh -> use this for building bounding box
		if (collisionMesh != NULL)
			mesh = new MeshTool(collisionMesh);
		else //get the intern mesh structure of the heighest detail mesh
			mesh = new MeshTool(meshes[0].mesh);
	
		//create array for all vertices
		allVertices = new D3DXVECTOR3[mesh->dwNumVertices];
	
		//get the transformation matrix for this position
		D3DXMATRIX *pMatrix = positions[index].lod[0].pTransformation;
		for(int j=0; j<mesh->dwNumVertices; j++)
		{
			//transform vector to right position
			D3DXVec3TransformCoord(&transformedVector, &mesh->pVertices[j].p, pMatrix);
			
			//add vertex to array
			allVertices[j] = transformedVector;
		}
		//create bounding box out of this vertices
		positions[index].pBoundingBox = new AABB(allVertices,mesh->dwNumVertices);

		//if using lod 0 and this is a billboard, we must expand bounding box in all directions
		if ((collisionMesh == NULL) && (meshes[0].billBoard))
		{
			positions[index].pBoundingBox->vecMin.x = positions[index].pBoundingBox->vecMin.z = 
				MIN(positions[index].pBoundingBox->vecMin.x, positions[index].pBoundingBox->vecMin.z);
			positions[index].pBoundingBox->vecMax.x = positions[index].pBoundingBox->vecMax.z = 
				MAX(positions[index].pBoundingBox->vecMax.x, positions[index].pBoundingBox->vecMax.z);
		}

		//delete allVertices
		SAFE_DELETE(allVertices);

		//delete opened mesh
		SAFE_DELETE(mesh);
	}

	//find color?
	if (findColor)
	{
		D3DCOLOR color = getObjectColor(index);

		//set all lods to this color
		for (int lodID=0; lodID<meshCount; lodID++)
			*positions[index].lod[lodID].pColorValue = color;
	}

	//add submeshes to submesh list
	if (!shadowGenMode)
	{
		//add all submeshes of all lods
		for(int j=0; j<meshCount; j++)
		{
			for(int i=0; i<meshes[j].subMeshCount; i++)
			{
				//retrieve attrib id
				int attribID = meshes[j].pSubMeshAttribTable[i].AttribId;

				//set additional values in submesh object
				positions[index].lod[j].pMaterial = &(meshes[j].materials[attribID]);
				positions[index].lod[j].pTexture = meshes[j].textures[attribID];
				positions[index].lod[j].pCenter = &(meshes[j].pSubMeshCenters[i]);
				positions[index].lod[j].pAlphaTexture = &(meshes[j].pSubMeshAlphas[i]);
				positions[index].lod[j].alpha = meshes[j].pSubMeshAlphas[i];	
				positions[index].lod[j].setSubMeshID(i);
				
				//add to submesh list and save index
				std::list<SubMesh>::iterator subMeshIndex = SubMeshes::instance->add(positions[index].lod[j]);
				positions[index].subMeshIndex[j].push_back(subMeshIndex);
			}
		}
	}

	return index;
}

/****************************************************************************
** Object removePosition
**
** mark a position so it can be overwritten
**
** Author: Dirk Plate
****************************************************************************/
void Object::removePosition(int positionIndex)
{
	int i;

	//mark submeshes as free
	for (int lodID=0; lodID<meshCount; lodID++)
	{
		for (i=0;i<positions[positionIndex].subMeshIndex[lodID].size();i++)
		{
			SubMeshes::instance->remove(positions[positionIndex].subMeshIndex[lodID][i]);
		}
		positions[positionIndex].subMeshIndex[lodID].clear();
	}

	positions[positionIndex].free = true;
	SAFE_DELETE(positions[positionIndex].pBoundingBox);
	for (i=0; i<meshCount; i++)
	{
		SAFE_DELETE(positions[positionIndex].lod[i].pTransformation);
		SAFE_DELETE(positions[positionIndex].lod[i].pColorValue);
		SAFE_DELETE(positions[positionIndex].lod[i].pAlphaBlend);
		SAFE_DELETE(positions[positionIndex].lod[i].pAlphaValue);
	}

	if (positionIndex < positionsCompleteFullMarker)
		positionsCompleteFullMarker = positionIndex;
	
	if (positionIndex == positionsFullMarker)
	{
		for (i=positionIndex; i>=0; i--)
			if (!positions[i].free) break;
		positionsFullMarker = i+1;
	}
}


/****************************************************************************
** Object setPosition
**
** Change a position of a object
**
** Author: Dirk Plate
****************************************************************************/
void Object::setPosition(int positionIndex,D3DXVECTOR3 position,float scaling,float rotationX,float rotationY,float rotationZ,bool ignoreBillboard)
{
	positions[positionIndex].position = position;
	positions[positionIndex].scaling = scaling;
	positions[positionIndex].rotationX = rotationX;
	positions[positionIndex].rotationY = rotationY;
	positions[positionIndex].rotationZ = rotationZ;

	//calculate new transformation matrix all lods
	for (int i=0;i<meshCount;i++)
	{
		calcTransformationMatrix(positionIndex,
			meshes[i].billBoard,positions[positionIndex].lod[i].pTransformation, ignoreBillboard);
	}
}


/****************************************************************************
** Object calcTransformationMatrix
**
** get the transformations matrix for the specified position
**
** Author: Dirk Plate
****************************************************************************/
void Object::calcTransformationMatrix(int positionIndex, bool billBoard, D3DXMATRIX *pTransformation, bool ignoreBillboard)
{
	D3DXMATRIX	mat2;

	D3DXMatrixScaling(pTransformation, 
		positions[positionIndex].scaling, 
		positions[positionIndex].scaling, 
		positions[positionIndex].scaling);
	
	if (billBoard && !ignoreBillboard)
	{
		D3DXMatrixMultiply( pTransformation, &Camera::instance->matBillboardOne, pTransformation );
	}
	else
	{
		D3DXMatrixRotationX(&mat2, positions[positionIndex].rotationX);
		D3DXMatrixMultiply(pTransformation, pTransformation, &mat2);
		D3DXMatrixRotationY(&mat2, positions[positionIndex].rotationY);
		D3DXMatrixMultiply(pTransformation, pTransformation, &mat2);
		D3DXMatrixRotationZ(&mat2, positions[positionIndex].rotationZ);
		D3DXMatrixMultiply(pTransformation, pTransformation, &mat2);
	}
	D3DXMatrixTranslation(&mat2, 
		positions[positionIndex].position.x,
		positions[positionIndex].position.y,
		positions[positionIndex].position.z);
	D3DXMatrixMultiply(pTransformation, pTransformation, &mat2);
}

/****************************************************************************
** Object intersectRay
**
** Determine the intersection between a ray and objects.
**
** Author: Dirk Plate
****************************************************************************/

bool Object::intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject, int ignorePosition)
{
	return false;
}

/****************************************************************************
** Object intersectObject
**
** Determine the intersection between a ray and one object (at one position).
**
** Author: Dirk Plate
****************************************************************************/

bool Object::intersectObject(int positionIndex, const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment)
{
	//transform ray to coordinate system of tree
	D3DXMATRIX invMatrix;
	D3DXMatrixInverse(&invMatrix,NULL,positions[positionIndex].lod[0].pTransformation);
	D3DXVECTOR3 transRayPos;
	D3DXVec3TransformCoord(&transRayPos,rayPos,&invMatrix);
	D3DXVECTOR3 transRayEnd;
	D3DXVec3TransformCoord(&transRayEnd,&(*rayPos+*rayDir),&invMatrix);
	D3DXVECTOR3 transRayDir = transRayEnd-transRayPos;

	memset(facesIntersected, 0, facesIntersectedCount);

	return intersectOctTree(&octTree,positionIndex,
		&transRayPos,&transRayDir,maxIntersectionCount,intersections,
		intersectionCount,useAlphaMaps,invAlpha,minInvAlpha,onlySegment);	
}

/****************************************************************************
** Object buildOctTree
**
** build octtree from this root (recursive function!)
** returns maxFaceIndex
**
** Author: Dirk Plate
****************************************************************************/

int Object::buildOctTree(OctTreeStruct *node, int depth)
{
	int maxFaceIndex = 0;

	//get all faces in own bounding box
	//go through all submeshes of the object
	DWORD facesIn = 0;		//number of vertices in boundingbox
	for (DWORD s=0;s<meshes[0].subMeshCount;s++)
	{
		//go through all triangles of the submesh
		for (DWORD j=meshes[0].pSubMeshAttribTable[s].FaceStart;
			 j<meshes[0].pSubMeshAttribTable[s].FaceStart+meshes[0].pSubMeshAttribTable[s].FaceCount;
			 j++)
		{
			//get coordinates of triangle
			D3DXVECTOR3 p1Vertex = pLockedIntersectionMesh->pVertices[pLockedIntersectionMesh->pIndices[3*j+0]].p;
			D3DXVECTOR3 p2Vertex = pLockedIntersectionMesh->pVertices[pLockedIntersectionMesh->pIndices[3*j+1]].p;
			D3DXVECTOR3 p3Vertex = pLockedIntersectionMesh->pVertices[pLockedIntersectionMesh->pIndices[3*j+2]].p;

			//check if point in bounding box
			bool p1In = node->pBoundingBox->includePoint(p1Vertex);
			bool p2In = node->pBoundingBox->includePoint(p2Vertex);
			bool p3In = node->pBoundingBox->includePoint(p3Vertex);

			//if one vertex of triangle in bounding box -> put face to own list
			if (p1In || p2In || p3In)
			{
				node->faces.push_back(OctTreeStruct::Face(j,s));

				maxFaceIndex = MAX(maxFaceIndex,j);
			}

			//if two vertices of face in bounding box -> count it
			if (((p1In) && (p2In)) || ((p1In) && (p3In)) || ((p2In) && (p3In)))
				facesIn++;
		}
	}

	//if min faces in this bounding box -> we dont need childs -> leaf and exit
	if ((facesIn <= OCTTREEMINFACES) || (depth >= OCTTREEMAXDEPTH))
	{
		node->leaf = true;
		return maxFaceIndex;
	}
	else
	{
		//delete faces
		node->faces.clear();
		node->faces.resize(0);
		//it has childs
		node->leaf = false;
	}

	//create childs
	for (int i=0;i<8;i++)
	{
		OctTreeStruct *child = NULL;
		child = new OctTreeStruct();
		if (child == NULL)
		{
			LOG("Creating child failed", Logger::LOG_CRIT);
			break;
		}
				
		//get boundings of the child
		D3DXVECTOR3 childMinMax[2];
		switch(i)
		{
		case OctTreeStruct::UPPERLEFTFRONT:
			childMinMax[0].x = node->pBoundingBox->vecMin.x;
			childMinMax[0].y = node->pBoundingBox->vecMin.y;
			childMinMax[0].z = node->pBoundingBox->vecMin.z;
			childMinMax[1].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[1].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[1].z = node->pBoundingBox->vecMiddle.z;
			break;
		case OctTreeStruct::UPPERRIGHTFRONT:
			childMinMax[0].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[0].y = node->pBoundingBox->vecMin.y;
			childMinMax[0].z = node->pBoundingBox->vecMin.z;
			childMinMax[1].x = node->pBoundingBox->vecMax.x;
			childMinMax[1].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[1].z = node->pBoundingBox->vecMiddle.z;
			break;
		case OctTreeStruct::LOWERLEFTFRONT:
			childMinMax[0].x = node->pBoundingBox->vecMin.x;
			childMinMax[0].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[0].z = node->pBoundingBox->vecMin.z;
			childMinMax[1].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[1].y = node->pBoundingBox->vecMax.y;
			childMinMax[1].z = node->pBoundingBox->vecMiddle.z;
			break;
		case OctTreeStruct::LOWERRIGHTFRONT:
			childMinMax[0].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[0].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[0].z = node->pBoundingBox->vecMin.z;
			childMinMax[1].x = node->pBoundingBox->vecMax.x;
			childMinMax[1].y = node->pBoundingBox->vecMax.y;
			childMinMax[1].z = node->pBoundingBox->vecMiddle.z;
			break;
		case OctTreeStruct::UPPERLEFTBACK:
			childMinMax[0].x = node->pBoundingBox->vecMin.x;
			childMinMax[0].y = node->pBoundingBox->vecMin.y;
			childMinMax[0].z = node->pBoundingBox->vecMiddle.z;
			childMinMax[1].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[1].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[1].z = node->pBoundingBox->vecMax.z;
			break;
		case OctTreeStruct::UPPERRIGHTBACK:
			childMinMax[0].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[0].y = node->pBoundingBox->vecMin.y;
			childMinMax[0].z = node->pBoundingBox->vecMiddle.z;
			childMinMax[1].x = node->pBoundingBox->vecMax.x;
			childMinMax[1].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[1].z = node->pBoundingBox->vecMax.z;
			break;
		case OctTreeStruct::LOWERLEFTBACK:
			childMinMax[0].x = node->pBoundingBox->vecMin.x;
			childMinMax[0].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[0].z = node->pBoundingBox->vecMiddle.z;
			childMinMax[1].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[1].y = node->pBoundingBox->vecMax.y;
			childMinMax[1].z = node->pBoundingBox->vecMax.z;
			break;
		case OctTreeStruct::LOWERRIGHTBACK:
			childMinMax[0].x = node->pBoundingBox->vecMiddle.x;
			childMinMax[0].y = node->pBoundingBox->vecMiddle.y;
			childMinMax[0].z = node->pBoundingBox->vecMiddle.z;
			childMinMax[1].x = node->pBoundingBox->vecMax.x;
			childMinMax[1].y = node->pBoundingBox->vecMax.y;
			childMinMax[1].z = node->pBoundingBox->vecMax.z;
			break;
		}

		//calculate bounding box
		child->pBoundingBox = NULL;
		child->pBoundingBox = new AABB(childMinMax,2);
		if (child->pBoundingBox == NULL)
		{
			LOG("Creating child boundingbox failed", Logger::LOG_CRIT);
			break;
		}
		
		//build subtree of the child
		maxFaceIndex = MAX(maxFaceIndex,buildOctTree(child,depth+1));
		
		//add to this node
		(node->pChilds)[i] = child;
	}
	return maxFaceIndex;
}

/****************************************************************************
** Object deleteOctTree
**
** delete quadtree from this root (recursive function!)
**
** Author: Dirk Plate
****************************************************************************/
void Object::deleteOctTree(OctTreeStruct *node)
{
	//delete AABB
	SAFE_DELETE(node->pBoundingBox);

	//delete child sub trees
	if (!node->leaf)
	{
		for (int i=0;i<8;i++)
		{
			deleteOctTree(node->pChilds[i]);
			SAFE_DELETE(node->pChilds[i]);
		}
	}
}

/****************************************************************************
** Object intersectOctTree
**
** intersect octtree from this root (recursive function!)
**
** Author: Dirk Plate
****************************************************************************/
bool Object::intersectOctTree(OctTreeStruct *node, int positionIndex,
		D3DXVECTOR3 *transRayPos, D3DXVECTOR3 *transRayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment)
{
	//if max intersection reached -> stop
	if (*intersectionCount >= maxIntersectionCount)
		return false;

	//if minimal visibility reached... stop
	if (*invAlpha < minInvAlpha)
		return false;

	//check intersection with own bounding box
	if (!node->pBoundingBox->intersectRay(transRayPos,transRayDir,onlySegment))
		return false;

	bool oneIntersectionFound = false;

	//if childs... then do intersection testing with them
	if (!node->leaf)
	{
		for (int i=0;i<8;i++)
		{
			if (intersectOctTree((node->pChilds)[i], positionIndex,
				transRayPos,transRayDir,
				maxIntersectionCount,intersections,intersectionCount,
				useAlphaMaps,invAlpha,minInvAlpha,
				onlySegment))
				oneIntersectionFound = true;
		}
	}
	//else intersect with all faces of this leaf
	else
	{
		for (int i=0;i<node->faces.size();i++)
		{
			//if max intersection reached -> stop
			if (*intersectionCount >= maxIntersectionCount)
				return oneIntersectionFound;
			
			//if minimal visibility reached... stop
			if (*invAlpha < minInvAlpha)
				return oneIntersectionFound;

			//not, if we checked this triangle already
			if (facesIntersected[(node->faces)[i].index])
				continue;

			//get coordinates of triangle
			DWORD p1 = pLockedIntersectionMesh->pIndices[3*(node->faces)[i].index+0];
			DWORD p2 = pLockedIntersectionMesh->pIndices[3*(node->faces)[i].index+1];
			DWORD p3 = pLockedIntersectionMesh->pIndices[3*(node->faces)[i].index+2];
			D3DXVECTOR3 p1Vertex = pLockedIntersectionMesh->pVertices[p1].p;
			D3DXVECTOR3 p2Vertex = pLockedIntersectionMesh->pVertices[p2].p;
			D3DXVECTOR3 p3Vertex = pLockedIntersectionMesh->pVertices[p3].p;
		
			//mark this face as intersected
			facesIntersected[(node->faces)[i].index] = true;

			//check intersection with triangle
			D3DXVECTOR3 intersectionCoor;
			float t,u,v;
			if (EngineHelpers::intersectRayTriangle2(*transRayPos,*transRayDir,p1Vertex,p2Vertex,p3Vertex,&t,&u,&v))
			{
				//check segment
				if (onlySegment && ((t > 1.0f) || (t < 0.0f)))
					continue;
				
				//calculate intersection position
				intersectionCoor = *transRayPos + t*(*transRayDir);
				D3DXVec3TransformCoord(&intersectionCoor,&intersectionCoor,positions[positionIndex].lod[0].pTransformation);

				//check transparency of texture?
				if (useAlphaMaps)
				{
					DWORD textureID = meshes[0].pSubMeshAttribTable[node->faces[i].subMeshIndex].AttribId;	
					CxImage *pCurrentTexture = &(meshes[0].pIntersectionTextures[textureID]);	

					//check the transparency of the texture-pixel at this position
					//calculate the texture coordinate
					D3DXVECTOR2 intersectionTCoor;

					EngineHelpers::getTextureCoordinates2(&(pLockedIntersectionMesh->pVertices[p1].t),
						                   &(pLockedIntersectionMesh->pVertices[p2].t),
										   &(pLockedIntersectionMesh->pVertices[p3].t),
										   u,v,&intersectionTCoor);

					//get the pixel at this texture-coordinate
					//Reading the pixel from texture
					int value;
					int x,y;
					int textureWidth = pCurrentTexture->GetWidth();
					int textureHeight = pCurrentTexture->GetHeight();
					
					//calculating the real coordinates from relative coordinates
					x = int(intersectionTCoor.x*textureWidth);
					y = int(intersectionTCoor.y*textureHeight);
					if (x>=textureWidth)  x=textureWidth-1;
					if (y>=textureHeight) y=textureHeight-1;
					if (x<0) x=0;
					if (y<0) y=0;

					//get the color
					value = pCurrentTexture->GetPixelGray(x,y);

					//multiply with alpha-value
					float alpha = (float(value)/255.0f);
					*invAlpha *= 1.0f-alpha;

					if (alpha > SMALL_NUM)
					{
						oneIntersectionFound = true;
						intersections[*intersectionCount] = intersectionCoor;
						(*intersectionCount)++;
					}
				}
				//hit on polygon is enough
				else
				{
					oneIntersectionFound = true;
					intersections[*intersectionCount] = intersectionCoor;
					(*intersectionCount)++;
				}
			}
		}
	}

	return oneIntersectionFound;
}

void Object::checkOctTree(OctTreeStruct *node)
{
	//LOG("Debug: checking oct tree", Logger::LOG_INFO);

	//every node need a boundingbox!
	if (node->pBoundingBox == NULL)
	{
		LOG("Node has no bounding box!", Logger::LOG_CRIT);
	}

	//if node has childs ... check all childs
	if (!node->leaf)
	{
		for (int i=0;i<8;i++)
		{
			//all child must be defined
			if (node->pChilds[i] == NULL)
			{
				LOG("Not all child of node are defined!", Logger::LOG_CRIT);
			}

			//check child
			checkOctTree(node->pChilds[i]);
		}
	}
	//a leaf needs a good array of faces
	else
	{
		for (int i=0;i<node->faces.size();i++)
		{
			//face-number must be smaller than max face
			if (node->faces[i].index >= facesIntersectedCount)
			{
				LOG("Face number of node to high!", Logger::LOG_CRIT);
			}
		}
	}
}

/****************************************************************************
** Object setColorForAllPositions
**
** sets the color for all positions
**
** Author: Dirk Plate
****************************************************************************/

void Object::findColorForAllPositions()
{
	//go through all positions
	for (int index=0; index<positionsFullMarker; index++)
	{
		//only used positions
		if (!positions[index].free)
		{
			//find color
			D3DCOLOR color = getObjectColor(index);

			//set all lods to this color
			for (int lodID=0; lodID<meshCount; lodID++)
				*positions[index].lod[lodID].pColorValue = color;
		}
	}
}

/****************************************************************************
** Object getObjectColor
**
** return the color of the object at this position (ambient or diffuse)
**
** Author: Dirk Plate
****************************************************************************/

inline D3DCOLOR Object::getObjectColor(int positionIndex)
{
	return 0xffffffff;
}

/****************************************************************************
** Object setPositionLODVisible
**
** set visibility for lods at one position
**
** Author: Dirk Plate
****************************************************************************/

void Object::setPositionLODVisible(int positionIndex, int firstLOD, int secondLOD)
{
	int i;
	std::vector<std::list<SubMesh>::iterator> *pSubMeshList;

	//set all lods to right false
	for (int lod=0; lod<meshCount; lod++)
	{
		//get pointer to submesh list
		pSubMeshList = &positions[positionIndex].subMeshIndex[lod]; 

		if ((firstLOD == lod) || (secondLOD == lod))
		{
			//make all submeshes really visible
			for (i=0;i<pSubMeshList->size();i++)
			{
				SubMeshes::instance->makeVisible((*pSubMeshList)[i]);
			}
		}
		else
		{
			//make all submeshes really invisible
			for (i=0;i<pSubMeshList->size();i++)
			{
				SubMeshes::instance->makeInvisible((*pSubMeshList)[i]);
			}
		}
	}
}

/****************************************************************************
** Object setPositionLODAlpha
**
** set alpha for lods at one position
**
** Author: Dirk Plate
****************************************************************************/

void Object::setPositionLODAlpha(int positionIndex, int firstLOD, float firstAlpha, int secondLOD, float secondAlpha)
{
	int i;
	std::vector<std::list<SubMesh>::iterator> *pSubMeshList;

	//set all lods to right alpha
	for (int lod=0; lod<meshCount; lod++)
	{
		//get pointer to submesh list
		pSubMeshList = &positions[positionIndex].subMeshIndex[lod]; 

		if (firstLOD == lod)
		{
			*positions[positionIndex].lod[lod].pAlphaBlend = true;
			*positions[positionIndex].lod[lod].pAlphaValue = firstAlpha;
			
			//make all submeshes really to right alpha
			for (i=0;i<pSubMeshList->size();i++)
			{
				SubMeshes::instance->makeAlpha((*pSubMeshList)[i]);
			}
		}
		else if (secondLOD == lod)
		{
			*positions[positionIndex].lod[lod].pAlphaBlend = true;
			*positions[positionIndex].lod[lod].pAlphaValue = secondAlpha;
			//make all submeshes really to right alpha
			for (i=0;i<pSubMeshList->size();i++)
			{
				SubMeshes::instance->makeAlpha((*pSubMeshList)[i]);
			}

		}
		else 
		{
			if (*positions[positionIndex].lod[lod].pAlphaBlend == true)
			{
				*positions[positionIndex].lod[lod].pAlphaBlend = false;
				//make all submeshes really to right alpha
				for (i=0;i<pSubMeshList->size();i++)
				{
					if (*((*pSubMeshList)[i]->pAlphaTexture))
					{
						SubMeshes::instance->makeAlpha((*pSubMeshList)[i]);
					}
					else
					{
						SubMeshes::instance->makeNormal((*pSubMeshList)[i]);
					}
				}
			}
		}
	}
}



