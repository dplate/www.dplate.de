/****************************************************************************
** Object
**
** object management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(OBJECT_H)
#define OBJECT_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include <math.h>
#include <vector>
#include <list>
#include <ximage.h>
#include "../common/dxutil.h"
#include "../common/enginehelpers.h"
#include "../common/aabb.h"	
#include "../common/submesh.h"

#define MAXLODS 10
#define POSITIONSBLOCKSIZE 1000	
#define OCTTREEMINFACES 10
#define OCTTREEMAXDEPTH 5

class Object
{
public:
	Object();
	~Object();

	virtual HRESULT update();

	virtual HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
								   const char* objectPath,	
								   bool forShadowGen=false);
	virtual HRESULT	destroyGeometry();

	virtual bool intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject = NULL, int ignorePosition = -1);

	HRESULT addLOD(const char* meshPath, int *pNewMeshID);
	HRESULT setCollisionMesh(const char* meshPath);

	int addPosition(D3DXVECTOR2 position2D,float scaling,float rotationX,float rotationY,float rotationZ, bool findColor = true, bool createBoundingBox = true);
	int addPosition(D3DXVECTOR3 position,float scaling,float rotationX,float rotationY,float rotationZ, bool findColor = true, bool createBoundingBox = true);
	void setPosition(int positionIndex,D3DXVECTOR3 position,float scaling,float rotationX,float rotationY,float rotationZ,bool ignoreBillboard=false);
	void removePosition(int positionIndex);
	void findColorForAllPositions();
	void setPositionLODVisible(int positionIndex, int firstLOD=-1, int secondLOD=-1);
	void setPositionLODAlpha(int positionIndex, int firstLOD=-1, float firstAlpha=1.0f, int secondLOD=-1, float secondAlpha=1.0f);

protected:
	void calcTransformationMatrix(int positionIndex, bool billBoard, D3DXMATRIX *pTransformation,bool ignoreBillboard=false);
	virtual D3DCOLOR getObjectColor(int positionIndex);
	bool intersectObject(int positionIndex, const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment);

	//struct for intersection testing
	struct OctTreeStruct
	{
		struct Face
		{
			Face(){};
			Face(DWORD indexSet,DWORD subMeshIndexSet) 
			{
				index = indexSet;
				subMeshIndex = subMeshIndexSet;
			};
			DWORD index;
			DWORD subMeshIndex;
		};

		AABB* pBoundingBox;			//the position of this area
		const enum{UPPERLEFTFRONT,UPPERRIGHTFRONT,LOWERLEFTFRONT,LOWERRIGHTFRONT,
				   UPPERLEFTBACK,UPPERRIGHTBACK,LOWERLEFTBACK,LOWERRIGHTBACK};
		OctTreeStruct* pChilds[8];	//all childs of these area
		bool leaf;					//this is a leaf node (no childs)
		std::vector<Face> faces;	//index of all triangles in this area
	} octTree;

	int buildOctTree(OctTreeStruct *node, int depth);
	void deleteOctTree(OctTreeStruct *node);
	bool intersectOctTree(OctTreeStruct *node, int positionIndex,
		D3DXVECTOR3 *transRayPos, D3DXVECTOR3 *transRayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment);

	void checkOctTree(OctTreeStruct *node);

	
	//one mesh (one lod) of the object
	struct MeshStruct
	{
		LPD3DXMESH			mesh;			//the wireframe
		DWORD				materialCount;	//count of materials
		D3DMATERIAL9*       materials;		//all materials
		LPDIRECT3DTEXTURE9* textures;		//the textures
		float				minDistance;	//this mesh is visible from this distance
		float				maxDistance;	//to this distance
		bool				billBoard;		//its a billboard (rotate to camera)
		CxImage*			pIntersectionTextures;	//list with all textures for intersection testing
		
		DWORD				subMeshCount;	//count of submeshes
		LPD3DXATTRIBUTERANGE pSubMeshAttribTable;	//table with all attributes of the submeshes
		D3DXVECTOR3*		pSubMeshCenters; //the centers for all submeshes of this object	
		bool*				pSubMeshAlphas; //alpha or not for all submeshes of this object	
	} meshes[MAXLODS];

	//one position of the object
	struct PositionStruct
	{
		D3DXVECTOR3	position;	//the position
		float scaling;			//the size
		float rotationX;		//the rotation around x 
		float rotationY;		//the rotation around y
		float rotationZ;		//the rotation around z
		bool free;				//this position can be used for a new position
		AABB *pBoundingBox;		//bounding box around this position
			
		SubMesh lod[MAXLODS];	//settings for all lods at this position
		std::vector<std::list<SubMesh>::iterator> subMeshIndex[MAXLODS];		//iterator of all submeshes
	};

	int meshCount;						//how many meshes (lods)
	char objectPath[512];
	LPD3DXMESH	collisionMesh;			//the wireframe of object for fast collision testings (and bounding box generations)
	LPDIRECT3DDEVICE9 pD3DDevice;
	PositionStruct *positions;			//all positions of this object
	int positionsCompleteFullMarker;	//a marker which shows the position in positionsfield, where no free fields before
	int positionsFullMarker;			//a marker at the end of the last full position
	int positionsSize;					//the size of the positions
	int positionsBlockCount;			//how many blocks are reserved

	bool shadowGenMode;					//this object is in a mode for shadow generation

	LPD3DXMESH pIntersectionMesh;		//the mesh for intersection testing
	MeshTool *pLockedIntersectionMesh;	//the locked mesh for intersection testing
	bool* facesIntersected;				//list of all faces (true = intersection checked)
	int facesIntersectedCount;			//the size of the array above
};

#endif









































