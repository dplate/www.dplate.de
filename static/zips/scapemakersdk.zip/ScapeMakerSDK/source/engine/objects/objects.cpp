#include "objects.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../common/config.h"

Objects *Objects::instance = NULL;

/****************************************************************************
** Objects Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Objects::Objects()
{
	Module::Module();
	name = "Objects";

	instance = this;
}

Objects::~Objects()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Objects CreateGeometry
**
** same as below with standard parameters
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Objects::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	HRESULT hr;

	if (FAILED(hr=createGeometry(pD3DDevice,false)))
		return hr;

	//this is the last module which adds elements to submeshes... now it can be activated
	SubMeshes::instance->enable();

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Objects CreateGeometry
**
** initializes the objects (calls all the loading functions)
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Objects::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
								bool forShadowGen)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	//create all terrain objects
	if (FAILED(hr=createTerrainObjects(forShadowGen)))
	{
		LOG("Creating terrain objects failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Terrain objects created OK");

	return S_OK;
}

/****************************************************************************
** Objects DestroyGeometry
**
** destroy the objects, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Objects::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//go through all objects
	for (int i=0;i<allObjects.size();i++)
	{
		(Object*)allObjects[i]->destroyGeometry();
		delete (Object*)allObjects[i];
	}
	//clear list
	allObjects.clear();

	return Module::destroyGeometry();
}

/****************************************************************************
** Objects Update
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Objects::update()
{
	HRESULT hr;

	//update all objects
	for (int i=0;i<allObjects.size();i++)
	{
		if (FAILED(hr=((Object*)allObjects[i])->update()))
		{
			LOG("Updating object failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	
	return Module::update();
}

/****************************************************************************
** Objects createTerrainObjects
**
** Load all objects in the engine/objects directory and create the right 
** object
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Objects::createTerrainObjects(bool forShadowGen)
{
	HRESULT hr;

	//find all directories in engine/objects
	string dirPath = Config::instance->getEnginePath()+"/objects/*.*";

	WIN32_FIND_DATA findData; 
	HANDLE searchHandle = FindFirstFile(dirPath.c_str(), &findData);
    if (searchHandle != INVALID_HANDLE_VALUE) 
    { 
        do
        { 
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) 
            { 
                string name = findData.cFileName;
				if (!(name == "." || name == ".."))
				{
					//now we have a potential object

					//determine if its a dynamic or static object
					MiniXML xmlFile;
					int type = -1;

					//read settings
					string settingsFilePath = Config::instance->getEnginePath()+"/objects/"+name+"/settings.txt";
					if (xmlFile.openFile(settingsFilePath.c_str(),MiniXML::READ))
					{
						xmlFile.readInteger("type",&type);
						
						xmlFile.closeFile();
					}
					
					//its a static object
					if (type == 0)
					{
						//create new static object
						StaticTerrainObject *newObject = new StaticTerrainObject();
						string objectPath = Config::instance->getEnginePath()+"/objects/"+name;

						if (FAILED(hr=newObject->createGeometry(pD3DDevice,objectPath.c_str(),forShadowGen)))
						{
							LOG("Creating static object failed", Logger::LOG_CRIT);
							return hr;
						}

						//add object to list
						allObjects.insert(allObjects.begin());
						allObjects[0] = newObject;

						LOG("Static object created OK");
					}
					//its a dynamic object
					else if (type == 1)
					{
						//don't initialise dynamic objects for shadow gen
						if (!forShadowGen)
						{
							//create new dynamic object
							DynamicTerrainObject *newObject = new DynamicTerrainObject();
							string objectPath = Config::instance->getEnginePath()+"/objects/"+name;

							if (FAILED(hr=newObject->createGeometry(pD3DDevice,
									objectPath.c_str(),false)))
							{
								LOG("Creating dynamic object failed", Logger::LOG_CRIT);
								return hr;
							}

							//add object to list
							int index = allObjects.size();
							allObjects.resize(index+1);
							allObjects[index] = newObject; 

							LOG("Dynamic object created OK");
						}
					}
					//its not a valid object (ignore)
					else continue;
                   
				}
			}
		} 
		while(FindNextFile(searchHandle, &findData)) ;
        FindClose(searchHandle); 


		//set color for all positions of all objects
		//here is the earliest moment, because of shadow from other objects
		for (int i=0;i<allObjects.size();i++)
			allObjects[i]->findColorForAllPositions();
	}
	
	return S_OK;
}

/****************************************************************************
** Objects intersectRay
**
** Determine the intersection between a ray and objects.
**
** rayPos					Start of the ray
** rayDir					Direction (and length) of the ray
** maxIntersectionCount		Find maximum this count of intersections
** intersections			Array with all found intersections (have to be big enough)
** intersectionCount		The number of intersections found
** useAlphaMaps				Use alpha maps of objects to determine if intersectionpoint is visible
** invAlpha					The overall alpha value (multiplied alpha at all intersections)
** onlySegment				Find only intersections between rayPos and rayPos+rayDir
** ignoreObject				Object to ignore intersections (NULL ignore no object)
** ignorePosition			Position to ignore intersection (-1 ignore all positions of ignoreObject)
**
** Author: Dirk Plate
****************************************************************************/

bool Objects::intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject, int ignorePosition)
{
	bool oneIntersectionFound = false;

	//init alpha to invisible
	*invAlpha = 1.0f;

	//init intersectionCount
	*intersectionCount = 0;

	//check intersection for all objects
	for (int i=0;i<allObjects.size();i++)
	{
		//if max intersections found... stop
		if (*intersectionCount >= maxIntersectionCount)
			return oneIntersectionFound;

		//if minimal visibility reached... stop
		if (*invAlpha < minInvAlpha)
			return oneIntersectionFound;

		//ignore this object completely?
		if ((allObjects[i] == ignoreObject) && (ignorePosition == -1))
			continue;

		//check intersection with object
		if ((Object*)allObjects[i]->intersectRay(rayPos,rayDir,
				maxIntersectionCount,intersections,intersectionCount,
				useAlphaMaps,invAlpha,minInvAlpha,
				onlySegment,ignoreObject,ignorePosition))
		{
			oneIntersectionFound = true;
		}
	}
	
	return oneIntersectionFound;
}




















