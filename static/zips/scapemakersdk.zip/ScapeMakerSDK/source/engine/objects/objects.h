/****************************************************************************
** Objects
**
** objects management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(OBJECTS_H)
#define OBJECTS_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <vector>

#include "../camera/viewfrustum.h"
#include "object.h"
#include "staticterrainobject.h"
#include "dynamicterrainobject.h"
#include "../camera/camera.h"
#include "../common/submeshes.h"
#include "../module.h"

class Objects : public Module
{
public:
	Objects();
	~Objects();

	HRESULT update();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, bool forShadowGen);
	HRESULT	destroyGeometry();

	bool intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject = NULL, int ignorePosition = -1);

	static Objects *instance;				//the instance to the only one objects object

private:
	HRESULT createTerrainObjects(bool forShadowGen = false);

	LPDIRECT3DDEVICE9 pD3DDevice;
	std::vector<Object*> allObjects;
};

#endif