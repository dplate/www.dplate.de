#include "staticterrainobject.h"

#include "../logger/logger.h"

#include "../terrain/terrain.h"
#include "../sky/sky.h"
#include "../postprocessing/heightbasedfog.h"
#include "../common/shaderconsts.h"
#include "../common/config.h"
#include "objects.h"

/****************************************************************************
** StaticTerrainObject Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
StaticTerrainObject::StaticTerrainObject()
{
}

StaticTerrainObject::~StaticTerrainObject()
{
}

/****************************************************************************
** StaticTerrainObject::QuadTreeStruct Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
StaticTerrainObject::QuadTreeStruct::QuadTreeStruct()
{
	posTop = 0;
	posLeft = 0;
	posRight = 0;
	posBottom = 0;
	pBoundingBox = NULL;
	leaf = false;
	visible = -1;
	lod	= -1;
	for (int i=0;i<4;i++) pChilds[i] = NULL;
}

StaticTerrainObject::QuadTreeStruct::~QuadTreeStruct()
{
	if (objects.size() > 0)
	{
		SAFE_DELETE(pBoundingBox);
	}
}

/****************************************************************************
** StaticTerrainObject CreateGeometry
**
** initializes the staticTerrainObject (calls all the loading functions)
**
** Author: Dirk Plate
****************************************************************************/
HRESULT StaticTerrainObject::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
											const char* objectPath,	
											bool forShadowGen)
{
	HRESULT hr;

	//call function of super class first
	if (FAILED(hr=Object::createGeometry(pD3DDevice,objectPath,forShadowGen)))
	{
		LOG("Creating object base class failed", Logger::LOG_CRIT);
		return hr;
	}

	//read settings
	MiniXML xmlFile;
	//read settings
	string settingsFilePath = string(objectPath)+"\\settings.txt";
	if (xmlFile.openFile(settingsFilePath.c_str(),MiniXML::READ))
	{
		char string[512];

		//load collision mesh
		if (xmlFile.readString("collisionFile",string,512))
			setCollisionMesh(string);

		//load lods
		if (xmlFile.startReadList("lods"))
		{
			float lastDistance = 0;
			bool bValue;
			float fValue;
					
			int i=0;
			while (xmlFile.startReadListElement(i))
			{	
				if (xmlFile.readString("file",string,512))
				{
					//add lod to mesh list
					int lodIndex;
					if (FAILED(hr=addLOD(string, &lodIndex)))
					{
						LOG("Loading object lod failed", Logger::LOG_CRIT);
						return hr;
					}
					if (lodIndex != -1) 
					{
						//billboard or not?
						if (xmlFile.readBoolean("billBoard",&bValue))
							meshes[lodIndex].billBoard = bValue;

						//read the maxdistance value
						if (xmlFile.readFloat("maxDistance",&fValue))
							meshes[lodIndex].maxDistance = fValue;

						//set mindistance
						meshes[lodIndex].minDistance = lastDistance;

						//save distance for last round
						lastDistance = meshes[lodIndex].maxDistance;
					}
				}

				xmlFile.endReadListElement();
				i++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	LOG("LODs loaded OK", Logger::LOG_INFO);
	
	//add all positions
	string positionsFilePath = string(objectPath)+"\\positions.txt";
	if (xmlFile.openFile(positionsFilePath.c_str(),MiniXML::READ))
	{
		if (xmlFile.startReadList("positions"))
		{
			D3DXVECTOR2 position;
			float rotationY;
			float scaling;
			float value;
			int i=0;
			int positionIndex;
			
			while (xmlFile.startReadListElement(i))
			{	
				position.x = 0.0f;
				position.y = 0.0f;
				rotationY = 0.0f;
				scaling = 1.0f;

				if (xmlFile.readFloat("positionX",&value))
					position.x = value;

				if (xmlFile.readFloat("positionY",&value))
					position.y = value;

				if (xmlFile.readFloat("rotationY",&value))
					rotationY = value;

				if (xmlFile.readFloat("scale",&value))
					scaling = value;

				if ((position.x>=0.0f) && (position.x<Terrain::instance->getWidth()) &&
					(position.y>=0.0f) && (position.y<Terrain::instance->getWidth()))
				{
					positionIndex = addPosition(position,scaling,0.0f,rotationY,0.0f,false);
				}

				xmlFile.endReadListElement();
				i++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	LOG("Adding positions OK", Logger::LOG_INFO);

	//build quadtree for this object
	quadTree.posTop = 0;
	quadTree.posLeft = 0;
	quadTree.posRight = Terrain::instance->getWidth();
	quadTree.posBottom = Terrain::instance->getWidth();
	buildQuadTree(&quadTree);

	//fill all positions in tree
	for (int position=0;position<positionsFullMarker;position++)
	{
		fillQuadTree(&quadTree,position);
	}

	//optimize quadtree (create bounding boxes also)
	optimizeQuadTree(&quadTree);

	LOG("Building quad tree OK", Logger::LOG_INFO);

	return S_OK;
}

/****************************************************************************
** StaticTerrainObject DestroyGeometry
**
** destroy the staticTerrainObject, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT StaticTerrainObject::destroyGeometry()
{
	//call function of super class first
	Object::destroyGeometry();

	//delete quadtree
	deleteQuadTree(&quadTree);

	return S_OK;
}

/****************************************************************************
** StaticTerrainObject Update
**
**
** Author: Dirk Plate
****************************************************************************/
HRESULT StaticTerrainObject::update()
{
	//call function of super class first
	Object::update();

	//update quadtree (checks visibility and lods)
	updateQuadTreeVisible(&quadTree);
	updateQuadTreeLOD(&quadTree);

	return S_OK;
}

/****************************************************************************
** StaticTerrainObject buildQuadTree
**
** build quadtree from this root (recursive function!)
**
** Author: Dirk Plate
****************************************************************************/

void StaticTerrainObject::buildQuadTree(QuadTreeStruct *node)
{
	std::vector<int> *objects = &(node->objects);
	D3DXVECTOR3 *allAABBEdges = NULL;
	
	//create childs
	//calculate the size of the childs
	int childSize = (node->posRight-node->posLeft)/2;
	
	//only create childs, if current one has more than one objects and the size is bigger than minimum
	if (childSize >= MINQUADTREEAREASIZE)
	{
		//this is not a leaf
		node->leaf = false;

		for (int i=0;i<4;i++)
		{
			QuadTreeStruct *child = new QuadTreeStruct();
			
			//save position of the child
			switch(i)
			{
			case QuadTreeStruct::UPPERLEFT:
				child->posLeft = node->posLeft;
				child->posTop = node->posTop;
				child->posRight = node->posLeft+childSize;
				child->posBottom = node->posTop+childSize;
				break;
			case QuadTreeStruct::UPPERRIGHT:
				child->posLeft = node->posLeft+childSize;
				child->posTop = node->posTop;
				child->posRight = node->posRight;
				child->posBottom = node->posTop+childSize;
				break;
			case QuadTreeStruct::LOWERLEFT:
				child->posLeft = node->posLeft;
				child->posTop = node->posTop+childSize;
				child->posRight = node->posLeft+childSize;
				child->posBottom = node->posBottom;
				break;
			case QuadTreeStruct::LOWERRIGHT:
				child->posLeft = node->posLeft+childSize;
				child->posTop = node->posTop+childSize;
				child->posRight = node->posRight;
				child->posBottom = node->posBottom;
				break;
			}
			
			//build subtree of the child
			buildQuadTree(child);
			
			//add to this node
			node->pChilds[i] = child;
		}
	}
	//no childs... this is a leaf
	else node->leaf = true;
}

/****************************************************************************
** StaticTerrainObject fillQuadTree
**
** fill the quadtree with this tree (recursive function!)
**
** Author: Dirk Plate
****************************************************************************/
void StaticTerrainObject::fillQuadTree(QuadTreeStruct *node, int position)
{
	std::vector<int> *objects = &(node->objects);
	int i;

	//add tree to this node
	objects->push_back(position);

	//add also to right child
	if (!node->leaf)
	{
		for (i=0; i<4; i++)
		{
			if ((positions[position].position.x >= node->pChilds[i]->posLeft) && 
				(positions[position].position.x <  node->pChilds[i]->posRight) &&
				(positions[position].position.z >= node->pChilds[i]->posTop) && 
				(positions[position].position.z <  node->pChilds[i]->posBottom))	
			{
				fillQuadTree(node->pChilds[i], position);
			}
		}
	}
}

/****************************************************************************
** StaticTerrainObject optimizeQuadTree
**
** optimize the quadtree (recursive function)
**
** Author: Dirk Plate
****************************************************************************/

void StaticTerrainObject::optimizeQuadTree(QuadTreeStruct *node)
{
	std::vector<int> *objects = &(node->objects);
	int i;
	D3DXVECTOR3 *allAABBEdges = NULL;
	int allAABBEdgesCount;


	//not already child
	if (!node->leaf)
	{
		//delete child, if only one object in this subtree
		if (objects->size() <= 1)
		{
			for (i=0;i<4;i++)
			{
				SAFE_DELETE(node->pChilds[i]);
			}
			node->leaf = true;
		}
	}

	//optimize all subtrees
	if (!node->leaf)
	{
		for (i=0; i<4; i++)
		{
			optimizeQuadTree(node->pChilds[i]);
		}
	}	

	//make bounding box around all objects 
	//if no childs... -> take boundings boxes from positions in 'object'
	if (node->leaf)
	{
		if (objects->size() > 0)
		{
			//create array for all edges
			allAABBEdgesCount = 0;
			allAABBEdges = new D3DXVECTOR3[objects->size()*2];
			for (i=0;i<objects->size();i++)
			{
				allAABBEdges[allAABBEdgesCount] = positions[(*objects)[i]].pBoundingBox->vecMin;
				allAABBEdges[allAABBEdgesCount+1] = positions[(*objects)[i]].pBoundingBox->vecMax;
				allAABBEdgesCount += 2;
			}
			//create bounding box out of this bounding box edges of the objects
			node->pBoundingBox = new AABB(allAABBEdges,allAABBEdgesCount);
			SAFE_DELETE(allAABBEdges);
		}
		else node->pBoundingBox = NULL;
	}
	//if childs... take bounding boxes from these quadtree nodes
	else
	{
		//create array for all edges
		allAABBEdgesCount = 0;
		allAABBEdges = new D3DXVECTOR3[8];
		for (i=0;i<4;i++)
		{
			if (node->pChilds[i]->pBoundingBox != NULL)
			{
				allAABBEdges[allAABBEdgesCount] = node->pChilds[i]->pBoundingBox->vecMin;
				allAABBEdges[allAABBEdgesCount+1] = node->pChilds[i]->pBoundingBox->vecMax;
				allAABBEdgesCount += 2;
			}
		}
		//create bounding box out of this bounding box edges of the childs
		if (allAABBEdgesCount > 0)
			node->pBoundingBox = new AABB(allAABBEdges,allAABBEdgesCount);
		else node->pBoundingBox = NULL;
		SAFE_DELETE(allAABBEdges);
	}	
}

/****************************************************************************
** StaticTerrainObject deleteQuadTree
**
** delete quadtree from this root (recursive function!)
**
** Author: Dirk Plate
****************************************************************************/

void StaticTerrainObject::deleteQuadTree(QuadTreeStruct *node)
{
	//delete child sub trees
	if (!node->leaf)
	{
		for (int i=0;i<4;i++)
		{
			deleteQuadTree(node->pChilds[i]);
			SAFE_DELETE(node->pChilds[i]);
		}
	}
}

/****************************************************************************
** StaticTerrainObject updateQuadTreeVisible
**
** update quadtree visibility from this root node)
**
** Author: Dirk Plate
****************************************************************************/
void StaticTerrainObject::updateQuadTreeVisible(QuadTreeStruct *node)
{
	std::vector<int> *objects = &(node->objects);
	int currentVisible;
	int i;

	//if no objects in this subtree... return
	if (objects->size() == 0) 
		return;
	
	//calc. visibility
	int visibility = Camera::instance->getViewFrustum()->cullAABB(node->pBoundingBox);

	//also visibility for reflection?
	if (Config::instance->isSubMeshesReflection())
	{
		int reflectionVisibility = Camera::instance->getReflectViewFrustum()->cullAABB(node->pBoundingBox);

		//combine both results
		if (visibility != reflectionVisibility) 
			visibility = VF_CLIPPED;
	}
		
	//objects behind distance fog are invisible
	if (visibility != VF_OUTSIDE)
	{
		float minDistance;
		float maxDistance;
		node->pBoundingBox->getMinDistance(Camera::instance->getPosition(),&minDistance);
		node->pBoundingBox->getMaxDistance(Camera::instance->getPosition(),&maxDistance);
		float realFogDistanceEnd = Sky::instance->getDustEnd()+FOG_ADDDISTANCE;
				if (minDistance > realFogDistanceEnd)
			visibility = VF_OUTSIDE;
		else if (maxDistance > realFogDistanceEnd)
			visibility = VF_CLIPPED;
	}

	//we dont know, if all objects are visible or not
	if (visibility == VF_CLIPPED)
	{
		//if not end of tree...
		if (!node->leaf)
		{
			//we must check child nodes
			for (i=0;i<4;i++) 
				updateQuadTreeVisible(node->pChilds[i]);

			//save that we dont know, if all objects are visible or not
			node->visible = -1;
		}
		else
		{
			//a leaf is every time visible
			setQuadTreeVisible(node, 1);
		}

	}
	//we do know, that all objects are visible or not
	else
	{
		if (visibility == VF_OUTSIDE)
			currentVisible = 0;
		else currentVisible = 1;

		//invisible?
		if (currentVisible == 0)
		{
			//not invisible before?
			if (node->visible != 0)
			{
				//make all lods of object invisible
				for (i=0;i<(*objects).size();i++)
				{
					setPositionLODVisible((*objects)[i]);
				}
			}
		}

		//save that all is invisible or not (in all childs too)
		setQuadTreeVisible(node, currentVisible);
	}
}

/****************************************************************************
** StaticTerrainObject setQuadTreeVisible
**
** set all node to specified visibility
**
** Author: Dirk Plate
****************************************************************************/
void StaticTerrainObject::setQuadTreeVisible(QuadTreeStruct *node, int visible)
{
	std::vector<int> *objects = &(node->objects);
	int i;

	//if no objects in this subtree... return
	if (objects->size() == 0) 
		return;

	//if node not already in right visibility
	if (node->visible != visible)
	{
		//set to invisible?
		if (visible == 0)
		{
			//lods are unsure
			node->lod = -1;
		}

		//set it to visibility 
		node->visible = visible;

		//and call childs if not leaf
		if (!node->leaf)
		{
			for (i=0;i<4;i++) 
				setQuadTreeVisible(node->pChilds[i],visible);
		}
	}
}

/****************************************************************************
** StaticTerrainObject updateQuadTreeLOD
**
** update quadtree lod from this root node
**
** Author: Dirk Plate
****************************************************************************/
void StaticTerrainObject::updateQuadTreeLOD(QuadTreeStruct *node)
{
	std::vector<int> *objects = &(node->objects);
	float minDistance, middleDistance, maxDistance;
	int i, lod, secondLOD;
	float difference, alpha;

	//if no objects in this subtree... return
	if (objects->size() == 0) 
		return;

	//if node complete invisible
	if (node->visible == 0)
	{
		//mhh, do nothing...
	}
	//if node complete visible
	else if (node->visible == 1)
	{
		//find min distance to bounding box
		node->pBoundingBox->getMinDistance(Camera::instance->getPosition(),&minDistance);

		//find max distance to bounding box
		node->pBoundingBox->getMaxDistance(Camera::instance->getPosition(),&maxDistance);

		//find a lod, which includes all objects of this area
		for (lod=0;lod<meshCount;lod++)
		{
			if (lod==0)
			{
				if ((meshes[lod].minDistance <= minDistance) &&
					(meshes[lod].maxDistance-STATICTERRAINOBJECTBLENDDISTANCE > maxDistance))
					break;
			}
			else
			{
				if ((meshes[lod].minDistance+STATICTERRAINOBJECTBLENDDISTANCE <= minDistance) &&
					(meshes[lod].maxDistance-STATICTERRAINOBJECTBLENDDISTANCE > maxDistance))
					break;
			}
		}

		//we found a lod which includes all objects
		if (lod < meshCount)
		{
			//set all objects to this lod
			for (i=0;i<(*objects).size();i++)
			{
				//update transformation matrix
				if (meshes[lod].billBoard)
				{
					calcTransformationMatrix((*objects)[i],true,
						positions[(*objects)[i]].lod[lod].pTransformation);
				}
				
				//if not already same lod
				if (node->lod != lod)
				{
					//set all lods alpha to false
					setPositionLODAlpha((*objects)[i]);
					//set all lods and position visibility to right values
					setPositionLODVisible((*objects)[i], lod);
				}
			}
			//safe lod state (in childs too)
			setQuadTreeLOD(node, lod);
		}
		//the objects in this area maybe have different lods
		else
		{
			//if leaf, we must check lod for all objects in this area
			if (node->leaf)
			{
				for (i=0;i<(*objects).size();i++)
				{
					//find middle distance to bounding box
					middleDistance = D3DXVec3Length(
						&(positions[(*objects)[i]].pBoundingBox->vecMiddle-
						Camera::instance->getPosition()));
									
					//find a lod, which includes the middle of the object
					for (lod=0;lod<meshCount;lod++)
					{
						if (((meshes[lod].minDistance <= middleDistance) &&
							 (meshes[lod].maxDistance >  middleDistance)))
						{
							//update transformation matrix
							if (meshes[lod].billBoard)
							{
								calcTransformationMatrix((*objects)[i],true,
									positions[(*objects)[i]].lod[lod].pTransformation);
							}

							//blending required?
							//blend with higher quality lod?
							difference = STATICTERRAINOBJECTBLENDDISTANCE-
								((meshes[lod].minDistance+STATICTERRAINOBJECTBLENDDISTANCE)-
								middleDistance);
							if ((difference <= STATICTERRAINOBJECTBLENDDISTANCE) &&
								(lod != 0))
							{
								secondLOD = lod-1; 
								alpha = 1.0f-difference/STATICTERRAINOBJECTBLENDDISTANCE;
							}
							else
							{
								//blend with lower quality lod?
								difference = STATICTERRAINOBJECTBLENDDISTANCE-
									(middleDistance-(meshes[lod].maxDistance-STATICTERRAINOBJECTBLENDDISTANCE));
								if (difference <= STATICTERRAINOBJECTBLENDDISTANCE)
								{
									secondLOD = lod+1;
									alpha = 1.0f-difference/STATICTERRAINOBJECTBLENDDISTANCE;
								}
								else 
								{
									secondLOD = -1;
									//set all lods alpha to false
									setPositionLODAlpha((*objects)[i]);
								}
							}

							//set additional settings for second lod stage
							if (secondLOD != -1)
							{
								//update transformation matrix
								if (meshes[secondLOD].billBoard)
								{
									calcTransformationMatrix((*objects)[i],true,
										positions[(*objects)[i]].lod[secondLOD].pTransformation);
								}

								//set all lods and position visibility to right values
								setPositionLODVisible((*objects)[i], lod, secondLOD);
								
								//set all lods alpha to right value
								setPositionLODAlpha((*objects)[i], lod, 1.0f, secondLOD, alpha);
							}
							else
							{
								//set all lods and position visibility to right values
								setPositionLODVisible((*objects)[i], lod);
							}

							break;
						}
					}

					//no lod found?
					if (lod >= meshCount)
					{
						//make object invisible
						setPositionLODVisible((*objects)[i]);
					}
				}
			}
			//not leaf and unsure lod?
			else 
			{
				//update childs
				for (i=0;i<4;i++) 
					updateQuadTreeLOD(node->pChilds[i]);
			}
			
			//safe unknown lod state
			node->lod = -1;
		}
	}
	//lod is part. visible or not
	else
	{
		//update childs
		for (i=0;i<4;i++) 
			updateQuadTreeLOD(node->pChilds[i]);

		//safe unknown lod state
		node->lod = -1;
	}
}

/****************************************************************************
** StaticTerrainObject setQuadTreeLOD
**
** set all node to specified lod
**
** Author: Dirk Plate
****************************************************************************/
void StaticTerrainObject::setQuadTreeLOD(QuadTreeStruct *node, int lod)
{
	std::vector<int> *objects = &(node->objects);
	int i;

	//if no objects in this subtree... return
	if (objects->size() == 0) 
		return;

	//if node not already in right visibility
	if (node->lod != lod)
	{
		//set it to visibility 
		node->lod = lod;

		//and call childs if not leaf
		if (!node->leaf)
		{
			for (i=0;i<4;i++) 
				setQuadTreeLOD(node->pChilds[i],lod);
		}
	}
}

/****************************************************************************
** StaticTerrainObject intersectRay
**
** Determine the intersection between a ray and objects.
**
** Author: Dirk Plate
****************************************************************************/

bool StaticTerrainObject::intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject, int ignorePosition)
{
	return intersectQuadTree(&quadTree,rayPos,rayDir,
		maxIntersectionCount,intersections,intersectionCount,
		useAlphaMaps,invAlpha,minInvAlpha,
		onlySegment,ignoreObject,ignorePosition);
}

/****************************************************************************
** StaticTerrainObject intersectQuadTree
**
** Determine the intersection between a ray and a subtree of objects.
**
** Author: Dirk Plate
****************************************************************************/

bool StaticTerrainObject::intersectQuadTree(QuadTreeStruct *node, const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject, int ignorePosition)
{
	int positionIndex;
	std::vector<int> *objects = &(node->objects);

	//max. intersections found?
	if (*intersectionCount >= maxIntersectionCount)
		return false;

	//if minimal visibility reached... stop
	if (*invAlpha < minInvAlpha)
		return false;

	//if no objects in this subtree... return
	if (objects->size() == 0) return false;

	//no intersection with AABB around this subtree?
	if (!node->pBoundingBox->intersectRay(rayPos,rayDir,onlySegment))
		return false;

	bool oneIntersectionFound = false;

	//if leaf... check intersection for each object
	if (node->leaf)
	{
		//intersect object at all positions
		for (int j=0;j<(*objects).size();j++)
		{
			positionIndex = (*objects)[j];

			//max. intersections found?
			if (*intersectionCount >= maxIntersectionCount)
				return oneIntersectionFound;
			
			//if minimal visibility reached... stop
			if (*invAlpha < minInvAlpha)
				return oneIntersectionFound;

			//ignore this position?
			if ((this == ignoreObject) && (positionIndex == ignorePosition))
				continue;
					
			if (intersectObject(positionIndex, rayPos,rayDir,
					maxIntersectionCount, intersections, intersectionCount,
					useAlphaMaps, invAlpha, minInvAlpha,
					onlySegment))
			{
				oneIntersectionFound = true;
			}
		}
	}
	else //intersect childs
	{
		for (int i=0;i<4;i++)
		{
			if (intersectQuadTree(node->pChilds[i], rayPos, rayDir,
					maxIntersectionCount,intersections,intersectionCount,
					useAlphaMaps,invAlpha, minInvAlpha,
					onlySegment,ignoreObject,ignorePosition))
			{
				oneIntersectionFound = true;
			}
		}
	}

	return oneIntersectionFound;
}

/****************************************************************************
** StaticTerrainObject getObjectColor
**
** return the color of the object at this position (ambient or diffuse)
**
** Author: Dirk Plate
****************************************************************************/

D3DCOLOR StaticTerrainObject::getObjectColor(int positionIndex)
{
	//check if object is in shadow -> then select ambient color
	D3DXVECTOR3 shadowPos;

	shadowPos.x = positions[positionIndex].pBoundingBox->vecMiddle.x;
	if (shadowPos.x < SMALL_NUM) 
		shadowPos.x = SMALL_NUM;
	if (shadowPos.x > Terrain::instance->getWidth()-SMALL_NUM) 
		shadowPos.x = Terrain::instance->getWidth()-SMALL_NUM;
	
	shadowPos.z = positions[positionIndex].pBoundingBox->vecMiddle.z;

	if (shadowPos.z < SMALL_NUM) 
		shadowPos.z = SMALL_NUM;
	if (shadowPos.z > Terrain::instance->getWidth()-SMALL_NUM) 
		shadowPos.z = Terrain::instance->getWidth()-SMALL_NUM;

	//check visibility in different heights of object
	const int CHECKINGHEIGHTS = 5;
	shadowPos.y = (Terrain::instance->getHeightInterpolatedSmooth(shadowPos.x,shadowPos.z)+
			positions[positionIndex].pBoundingBox->vecMiddle.y)/2.0f;
	float heightStep = (positions[positionIndex].pBoundingBox->vecMax.y-shadowPos.y)/CHECKINGHEIGHTS;
	float invAlpha = 1.0f;;
	for (int i=0; i<CHECKINGHEIGHTS; i++)
	{
		float oneRayInvAlpha = 1.0f;

		//intersect with terrain
		if (Terrain::instance->intersectSunRay(Sky::instance->getSun()->getPosition(),
				shadowPos,
				NULL,true) == S_OK)
			oneRayInvAlpha = 0.0f;
		else
		{
			float oneObjectsInvAlpha = 1.0f;
			D3DXVECTOR3 rayDir = shadowPos-Sky::instance->getSun()->getPosition();
			D3DXVECTOR3 intersections[10];
			int intersectionCount;

			//if intersection... then add invalphavalue
			if (Objects::instance->intersectRay(&(Sky::instance->getSun()->getPosition()),
					&rayDir,10,
					intersections,&intersectionCount,
					true,&oneObjectsInvAlpha,SMALL_NUM,
					true,this,positionIndex))
			{
				oneRayInvAlpha *= oneObjectsInvAlpha;
			}

			//height based fog?
			float oneInvAlpha = 1.0f;
			if (HeightBasedFog::instance->intersectRay(&(Sky::instance->getSun()->getPosition()),
				&(shadowPos-Sky::instance->getSun()->getPosition()),
				&oneInvAlpha,true))
			{
				oneRayInvAlpha *= oneInvAlpha;
			}
		}
		//add to invAlpha
		invAlpha -= ((1.0f-oneRayInvAlpha)/((float)CHECKINGHEIGHTS));

		//if invAlpha small enough -> break
		if (invAlpha < SMALL_NUM) break;

		//set next height of ray
		shadowPos.y += heightStep;
	}

	return invAlpha*Sky::instance->getDiffuseColor()+(1.0f-invAlpha)*Sky::instance->getAmbientColor();
}

