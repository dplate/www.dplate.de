/****************************************************************************
** StaticTerrainObject
**
** staticTerrainObject rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(STATICTERRAINOBJECT_H)
#define STATICTERRAINOBJECT_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <fstream>

#include "../camera/viewfrustum.h"
#include "object.h"
#include "../common/AABB.h"
#include "../../common/minixml.h"

#define MINQUADTREEAREASIZE 4
#define STATICTERRAINOBJECTBLENDDISTANCE 4.0f

class StaticTerrainObject : public Object
{
public:
	StaticTerrainObject();
	~StaticTerrainObject();

	virtual HRESULT update();

	virtual HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
								   const char* objectPath,	
								   bool forShadowGen=false);
	virtual HRESULT	destroyGeometry();

	virtual bool intersectRay(const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha,float minInvAlpha,
		bool onlySegment, Object *ignoreObject = NULL, int ignorePosition = -1);
protected:
	inline virtual D3DCOLOR getObjectColor(int positionIndex);

private:
	struct QuadTreeStruct
	{
		QuadTreeStruct();
		~QuadTreeStruct();
		int posLeft,posTop,posRight,posBottom;	//the position of this area
		const enum{UPPERLEFT,UPPERRIGHT,LOWERLEFT,LOWERRIGHT};
		QuadTreeStruct* pChilds[4]; //all childs of these area (upperleft,upperright,lowerleft,lowerright)
		std::vector<int> objects;	//index of all objects in this area
		AABB* pBoundingBox;			//the bounding box around this objects
		bool leaf;					//this is a leaf node (no childs)
		int	visible;				//0 = completly invisible, 1 = completly visible, -1 = dont know
		int lod;					//>0 = current lod, -1 = unknown lod
	} quadTree;

	void buildQuadTree(QuadTreeStruct *node);		//build quadtree from this root node (recursive function!)
	void fillQuadTree(QuadTreeStruct *node, int position);	//fill the quadtree with this tree (recursive function!)
	void optimizeQuadTree(QuadTreeStruct *node);	//optimize the quadtree (recursive function)
	void deleteQuadTree(QuadTreeStruct *node);		//delete quadtree from this root node
	
	void updateQuadTreeVisible(QuadTreeStruct *node); //update visibility of quadtree from this root node 
	void setQuadTreeVisible(QuadTreeStruct *node, 
							int visible);			//set all node to specified value
	void updateQuadTreeLOD(QuadTreeStruct *node);	//update lods of quadtree from this root node 
	void setQuadTreeLOD(QuadTreeStruct *node, 
						int lod);					//set all node to specified value

	bool intersectQuadTree(QuadTreeStruct *node, const D3DXVECTOR3 *rayPos, const D3DXVECTOR3 *rayDir, 
		int maxIntersectionCount, D3DXVECTOR3 *intersections, int *intersectionCount,
		bool useAlphaMaps, float *invAlpha, float minInvAlpha,
		bool onlySegment, Object *ignoreObject, int ignorePosition);
};

#endif