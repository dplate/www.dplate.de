#include "particles.h"
#include "../logger/logger.h"

Particles *Particles::instance = NULL;

/****************************************************************************
** Particles Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Particles::Particles()
{
	Module::Module();
	name = "Particles";

	pD3DDevice = NULL;

	instance = this;
}

Particles::~Particles()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Particles createGeometry
**
** initializes the particles
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Particles::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Particles update
**
** Animate and check visibility of particles
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Particles::update()
{
	HRESULT hr;

	//update all particles
	list<ParticleType>::iterator currentParticleType = particleTypeList.begin();
	while(currentParticleType != particleTypeList.end())
	{
		if (FAILED(hr=currentParticleType->update()))
			return hr;

		currentParticleType++;
	}

	return Module::update();
}

/****************************************************************************
** Particles addParticleType
**
** add a new particle type
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Particles::addParticleType(std::string texturePath, std::list<ParticleType>::iterator &newParticleType)
{
	HRESULT hr;

	//add particle to list
	particleTypeList.push_back(ParticleType());
	newParticleType = particleTypeList.end();
	newParticleType--;

	//initialise particle type
	if (FAILED(hr=newParticleType->createGeometry(pD3DDevice,texturePath)))
		return hr;

	return S_OK;
}

/****************************************************************************
** Particles removeParticleType
**
** remove a particle type
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Particles::removeParticleType(list<ParticleType>::iterator currentParticleType)
{
	HRESULT hr;

	//destroy particle type
	if (FAILED(hr=currentParticleType->destroyGeometry()))
		return hr;

	//remove particle from list
	particleTypeList.erase(currentParticleType);

	return S_OK;
}
