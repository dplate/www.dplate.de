/****************************************************************************
** Particles
**
** particles management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(PARTICLES_H)
#define PARTICLES_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include <list>
#include "../common/enginehelpers.h"
#include "particletype.h"
#include "../module.h"

class Particles : public Module
{
public:
	Particles();
	~Particles();

	HRESULT update();
	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	
	HRESULT	addParticleType(std::string texturePath, std::list<ParticleType>::iterator &newParticleType);
	HRESULT removeParticleType(std::list<ParticleType>::iterator currentParticleType);

	static Particles *instance;				//the instance to the only one particles object
private:
	LPDIRECT3DDEVICE9 pD3DDevice;

	//list with all particle types
	std::list<ParticleType> particleTypeList;
};

#endif