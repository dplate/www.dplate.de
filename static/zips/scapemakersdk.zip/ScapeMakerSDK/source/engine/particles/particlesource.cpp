#include "particlesource.h"

#include "../logger/logger.h"
#include "../camera/camera.h"
#include "../common/time.h"
#include "../terrain/terrain.h"
#include "../common/config.h"
#include "../sky/sky.h"

/****************************************************************************
** ParticleSource Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
ParticleSource::ParticleSource()
{
	pD3DDevice = NULL;
	pMesh = NULL;
	pMaterial = NULL;
	pTexture = NULL;
	positionMin = D3DXVECTOR3(0.0f,0.0f,0.0f);
	positionMax = D3DXVECTOR3(0.0f,0.0f,0.0f);
	speedMin = D3DXVECTOR3(0.0f,0.0f,0.0f);
	speedMax = D3DXVECTOR3(0.0f,0.0f,0.0f);
	massMin = 1.0f;
	massMax = 1.0f;
	lifeTimeMin = 10.0f;
	lifeTimeMax = 10.0f;
	emitIntervalMin = 1.0f;
	emitIntervalMax = 1.0f;
	nextParticleTime = 0.0f;
	pBoundingBox = NULL;
	visible = false;
}

ParticleSource::~ParticleSource()
{
}

/****************************************************************************
** Particles CreateGeometry
**
** initializes the particle source
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleSource::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
		LPD3DXMESH pMesh, D3DMATERIAL9 *pMaterial, LPDIRECT3DTEXTURE9 pTexture, 
		D3DXVECTOR3 positionMin, D3DXVECTOR3 positionMax,
		D3DXVECTOR3 speedMin, D3DXVECTOR3 speedMax,
		float lifeTimeMin, float lifeTimeMax,
		float massMin, float massMax,
		float sizeMin, float sizeMax,
		float growthSpeed, float alphaSpeed,
		float emitIntervalMin, float emitIntervalMax)
{
	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	this->pMesh = pMesh;
	this->pMaterial = pMaterial;
	this->pTexture = pTexture;
	this->positionMin = positionMin;
	this->positionMax = positionMax;
	this->speedMin = speedMin;
	this->speedMax = speedMax;
	this->lifeTimeMin = lifeTimeMin;
	this->lifeTimeMax = lifeTimeMax;
	this->massMin = massMin;
	this->massMax = massMax;
	this->sizeMin = sizeMin;
	this->sizeMax = sizeMax;
	this->growthSpeed = growthSpeed;
	this->alphaSpeed = alphaSpeed;
	this->emitIntervalMin = emitIntervalMin;
	this->emitIntervalMax = emitIntervalMax;

	//calculate max particle count
	maxParticleCount = (lifeTimeMax+lifeTimeMin) / (emitIntervalMax+emitIntervalMin);

	//create first bounding box
	pBoundingBox = new AABB(&positionMin,1);
	pBoundingBox->vecMax = positionMax;

	//not visible (will be updated in update())
	visible = false;

	return S_OK;
}

/****************************************************************************
** ParticleSource DestroyGeometry
**
** destroy the particle source
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleSource::destroyGeometry()
{
	//destroy all particles
	std::list<Particle>::iterator currentParticle = particleList.begin();
	while (currentParticle != particleList.end())
	{
		//remove from submeshes list
		SubMeshes::instance->remove(currentParticle->subMeshIndex);

		//delete all created pointers
		SAFE_DELETE(currentParticle->subMesh.pAlphaBlend);
		SAFE_DELETE(currentParticle->subMesh.pAlphaValue);
		SAFE_DELETE(currentParticle->subMesh.pColorValue);
		SAFE_DELETE(currentParticle->subMesh.pTransformation);
		SAFE_DELETE(currentParticle->subMesh.pCenter);
		SAFE_DELETE(currentParticle->subMesh.pAlphaTexture);

		currentParticle++;
	}

	//clear list
	particleList.clear();

	//destroy bounding box
	SAFE_DELETE(pBoundingBox);

	return S_OK;
}

/****************************************************************************
** ParticleSource Update
**
** Animate and check visibility of the particle source
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleSource::update()
{
	std::list<Particle>::iterator currentParticle;

	//update visibility
	int visibility = Camera::instance->getViewFrustum()->cullAABB(pBoundingBox);
	
	//also visibility for reflection?
	if (Config::instance->isSubMeshesReflection())
	{
		int reflectionVisibility = Camera::instance->getReflectViewFrustum()->cullAABB(pBoundingBox);

		//combine both results
		if (visibility != reflectionVisibility) 
			visibility = VF_CLIPPED;
	}

	//particles behind distance fog are invisible
	if (visibility != VF_OUTSIDE)
	{
		float minDistance;
		float maxDistance;
		pBoundingBox->getMinDistance(Camera::instance->getPosition(),&minDistance);
		pBoundingBox->getMaxDistance(Camera::instance->getPosition(),&maxDistance);
		float realFogDistanceEnd = Sky::instance->getDustEnd()+FOG_ADDDISTANCE;
		if (minDistance > realFogDistanceEnd)
			visibility = VF_OUTSIDE;
		else if (maxDistance > realFogDistanceEnd)
			visibility = VF_CLIPPED;
	}


	//completely outside view?
	if ((visibility == VF_OUTSIDE) ||
		(D3DXVec3Length(&(positionMin-Camera::instance->getPosition())) > 100.0f))
	{
		//last frame visible?
		if (visible)
		{
			//make all particle submeshes invisible
			currentParticle = particleList.begin();
			while (currentParticle != particleList.end())
			{	
				SubMeshes::instance->makeInvisible(currentParticle->subMeshIndex);
				currentParticle++;
			}
			visible = false;
		}
		//no further update required
		return S_OK;
	}
	//partial inside view?
	else
	{
		//last frame invisible?
		if (!visible)
		{
			//make all particle submeshes visible
			currentParticle = particleList.begin();
			while (currentParticle != particleList.end())
			{	
				SubMeshes::instance->makeVisible(currentParticle->subMeshIndex);
				currentParticle++;
			}
			visible = true;
		}
	}

	//current t for physics
	float t = Time::instance->getGameFrameTime();

	//decrease time to next particle
	nextParticleTime -= t;

	//update all particles
	currentParticle = particleList.begin();
	while (currentParticle != particleList.end())
	{
		//decrease life time
		currentParticle->lifeTime -= t;

		//max age reached?
		if (currentParticle->lifeTime <= 0)
		{
			//replace with new particle
			emitParticle(currentParticle);
		}
		else
		{
			//calculate new speed
			//earth gravity
			currentParticle->speed.y -= EARTH_GRAVITIY * currentParticle->mass * t;

			//calculate new position
			currentParticle->position += (currentParticle->speed * t);

			//calculate new visibility
			*currentParticle->subMesh.pAlphaValue = 
				currentParticle->lifeTime*currentParticle->expVar*
				(1.0f-powf(alphaSpeed,-currentParticle->lifeTime))/alphaSpeed;
			if (*currentParticle->subMesh.pAlphaValue < 0.0f)
				*currentParticle->subMesh.pAlphaValue = 0.0f;

			//calculate new size
			currentParticle->size += growthSpeed * t;
			if (currentParticle->size < 0.0f)
				currentParticle->size = 0.0f;

			//calculate new transformation matrix
			calculateTransformationMatrix(currentParticle);
		}

		currentParticle++;
	}

	//add new particle, if time is up
	if ((nextParticleTime < 0) && (particleList.size() < maxParticleCount))
		emitParticle(particleList.end());

	return S_OK;
}

/****************************************************************************
** ParticleSource emitParticle
**
** Emit a new particle 
** (can replace a existing one by particleToReplace != list::end())
**
** Author: Dirk Plate
****************************************************************************/
void ParticleSource::emitParticle(std::list<Particle>::iterator particleToReplace)
{
	//add new particle to list?
	if (particleToReplace == particleList.end())
	{
		particleList.push_back(Particle());
		particleToReplace = particleList.end();
		particleToReplace--;

		//create all pointers
		particleToReplace->subMesh.pAlphaBlend = new bool(true);
		particleToReplace->subMesh.pAlphaValue = new float;
		particleToReplace->subMesh.pColorValue = 
			new D3DCOLOR(Terrain::instance->getLightColor(positionMin.x,positionMin.z));
		particleToReplace->subMesh.pTransformation = new D3DXMATRIX;
		particleToReplace->subMesh.pCenter = new D3DXVECTOR3(0.0,0.0,0.0);
		particleToReplace->subMesh.pAlphaTexture = new bool(true);

		//set all constant properties
		particleToReplace->subMesh.setD3DDevice(pD3DDevice);
		particleToReplace->subMesh.pMesh = pMesh;
		particleToReplace->subMesh.pMaterial = pMaterial;
		particleToReplace->subMesh.pTexture = pTexture;
		particleToReplace->subMesh.alpha = true;	
		particleToReplace->subMesh.setSubMeshID(0);

		//add to submesh list
		particleToReplace->subMeshIndex = SubMeshes::instance->add(particleToReplace->subMesh);
	}

	//set sub mesh parameters to start values
	*particleToReplace->subMesh.pAlphaValue = 1.0f;
	//*particleToReplace->subMesh.pColorValue = D3DCOLOR(0xffffffff);

	//set particle parameters to start values
	particleToReplace->position.x = EngineHelpers::getRandomInInterval(positionMin.x,positionMax.x);
	particleToReplace->position.y = EngineHelpers::getRandomInInterval(positionMin.y,positionMax.y);
	particleToReplace->position.z = EngineHelpers::getRandomInInterval(positionMin.z,positionMax.z);
	particleToReplace->lifeTime = EngineHelpers::getRandomInInterval(lifeTimeMin,lifeTimeMax);;
	particleToReplace->mass = EngineHelpers::getRandomInInterval(massMin,massMax);;
	particleToReplace->speed.x = EngineHelpers::getRandomInInterval(speedMin.x,speedMax.x);
	particleToReplace->speed.y = EngineHelpers::getRandomInInterval(speedMin.y,speedMax.y);
	particleToReplace->speed.z = EngineHelpers::getRandomInInterval(speedMin.z,speedMax.z);
	particleToReplace->size = EngineHelpers::getRandomInInterval(sizeMin,sizeMax);
	particleToReplace->expVar = 1.0f/particleToReplace->lifeTime;
	nextParticleTime = 0.0f;

	//calculate first transformation matrix
	calculateTransformationMatrix(particleToReplace);

	//calculate next particle time
	nextParticleTime = EngineHelpers::getRandomInInterval(emitIntervalMin,emitIntervalMax);
}

/****************************************************************************
** ParticleSource calculateTransformationMatrix
**
** Calculates the transformation matrix for one particle
**
** Author: Dirk Plate
****************************************************************************/
void ParticleSource::calculateTransformationMatrix(std::list<Particle>::iterator currentParticle)
{
	D3DXMATRIX	mat1,mat2;
	
	//scale particle piece to right size
	D3DXMatrixScaling(&mat1,
		currentParticle->size,
		currentParticle->size,
		currentParticle->size);

	//rotate piece to camera
	D3DXMatrixMultiply( &mat1, &(Camera::instance->matBillboardTwo), &mat1 );

	//add translation to matrix
	D3DXMatrixTranslation(&mat2,
		currentParticle->position.x,
		currentParticle->position.y,
		currentParticle->position.z);
	D3DXMatrixMultiply(currentParticle->subMesh.pTransformation, &mat1, &mat2);

	//update bounding box
	//check minimum values
	if (currentParticle->position.x-currentParticle->size < pBoundingBox->vecMin.x)
		pBoundingBox->vecMin.x = currentParticle->position.x-currentParticle->size;
	if (currentParticle->position.y-currentParticle->size < pBoundingBox->vecMin.y)
		pBoundingBox->vecMin.y = currentParticle->position.y-currentParticle->size;
	if (currentParticle->position.z-currentParticle->size < pBoundingBox->vecMin.z)
		pBoundingBox->vecMin.z = currentParticle->position.z-currentParticle->size;

	//check maximum values
	if (currentParticle->position.x+currentParticle->size > pBoundingBox->vecMax.x)
		pBoundingBox->vecMax.x = currentParticle->position.x+currentParticle->size;
	if (currentParticle->position.y+currentParticle->size > pBoundingBox->vecMax.y)
		pBoundingBox->vecMax.y = currentParticle->position.y+currentParticle->size;
	if (currentParticle->position.z+currentParticle->size > pBoundingBox->vecMax.z)
		pBoundingBox->vecMax.z = currentParticle->position.z+currentParticle->size;
}