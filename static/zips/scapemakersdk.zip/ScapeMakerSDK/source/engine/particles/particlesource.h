/****************************************************************************
** ParticleSource
**
** particle source management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(PARTICLESOURCE_H)
#define PARTICLESOURCE_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "../common/enginehelpers.h"
#include "../common/submeshes.h"

//data of one particle
struct Particle 
{
	float size;				//the size
	float mass;				//the mass (weight)
	D3DXVECTOR3	speed;		//the speed
	D3DXVECTOR3	position;	//the position
	float lifeTime;			//the time to say goodbye
	float expVar;			//a constant value for exponent function
	SubMesh subMesh;		//settings for the used submesh
	std::list<SubMesh>::iterator subMeshIndex;	//iterator to submesh in submeshlist
};

class ParticleSource
{
public:
	ParticleSource();
	~ParticleSource();

	HRESULT update();
	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
		LPD3DXMESH pMesh, D3DMATERIAL9 *pMaterial, LPDIRECT3DTEXTURE9 pTexture, 
		D3DXVECTOR3 positionMin, D3DXVECTOR3 positionMax,
		D3DXVECTOR3 speedMin, D3DXVECTOR3 speedMax,
		float lifeTimeMin, float lifeTimeMax,
		float massMin, float massMax,
		float sizeMin, float sizeMax,
		float growthSpeed, float alphaSpeed,
		float emitIntervalMin, float emitIntervalMax);
	HRESULT	destroyGeometry();

private:
	void emitParticle(std::list<Particle>::iterator particleToReplace);
	void calculateTransformationMatrix(std::list<Particle>::iterator currentParticle);

	LPDIRECT3DDEVICE9 pD3DDevice;

	//the quad mesh for all particles
	LPD3DXMESH pMesh;

	//the material of the particle
	D3DMATERIAL9 *pMaterial;

	//the texture of the particle
	LPDIRECT3DTEXTURE9 pTexture;

	//list with all particles
	std::list<Particle> particleList;

	//the position of the source (a axis aligned rectangle)
	D3DXVECTOR3 positionMin;
	D3DXVECTOR3 positionMax;

	//starting speed of particles (includes direction)
	D3DXVECTOR3 speedMin;
	D3DXVECTOR3 speedMax;

	//lifetime of particles
	float lifeTimeMin;
	float lifeTimeMax;

	//mass of particles
	float massMin;
	float massMax;

	//size of particles
	float sizeMin;
	float sizeMax;

	//size changing of particles
	float growthSpeed;

	//fade changing of particles
	float alphaSpeed;

	//emit interval
	float emitIntervalMin;
	float emitIntervalMax;

	//time when next particle should emit
	float nextParticleTime;

	//maximum of particles
	int maxParticleCount;

	//the aabb around all particles of this source
	AABB *pBoundingBox;

	//minimum one particle of this source is visible
	bool visible;
};

#endif