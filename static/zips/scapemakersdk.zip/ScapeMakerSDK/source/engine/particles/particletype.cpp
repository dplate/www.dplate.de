#include "particletype.h"

#include "../logger/logger.h"
#include "../common/config.h"

/****************************************************************************
** ParticleType Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
ParticleType::ParticleType()
{
	pD3DDevice = NULL;
	pMesh = NULL;
	pTexture = NULL;
}

ParticleType::~ParticleType()
{
}

/****************************************************************************
** ParticleType CreateGeometry
**
** initializes the particle type
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleType::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, string texturePath)
{
	HRESULT hr;
	LPD3DXMESH rawMesh;

	//store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;
	
	//load quad mesh
    if(FAILED(hr=D3DXLoadMeshFromX("./enginefiles/particle.x", D3DXMESH_SYSTEMMEM,
                             pD3DDevice, NULL,NULL, NULL, NULL, &rawMesh)))
    {
        LOG("Loading particle mesh from x-file failed", Logger::LOG_CRIT);
		return hr;
    }

	//optimize mesh by sorting attributes (materials).
	if(FAILED(hr=rawMesh->Optimize( D3DXMESHOPT_ATTRSORT, NULL, NULL, NULL, NULL, &pMesh)))
	{
		LOG("Optimizing mesh failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(rawMesh);
	LOG("Mesh loaded OK");

    //set material to nice values
    material.Ambient.r = 1.0f;
	material.Ambient.g = 1.0f;
	material.Ambient.b = 1.0f;
	material.Diffuse.r = 1.0f;
	material.Diffuse.g = 1.0f;
	material.Diffuse.b = 1.0f;
	material.Emissive.r = 0.0f;
	material.Emissive.g = 0.0f;
	material.Emissive.b = 0.0f;
	material.Power = 0.0f;
	material.Specular.r = 0.0f;
	material.Specular.g = 0.0f;
	material.Specular.b = 0.0f;

	//load texture
	if (FAILED(hr = EngineHelpers::loadTexture(pD3DDevice, texturePath.c_str(), D3DFMT_UNKNOWN, &pTexture)))
	{
		LOG("Loading particle texture failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Texture loaded OK");

	return S_OK;
}

/****************************************************************************
** ParticleType DestroyGeometry
**
** destroy the particle type ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleType::destroyGeometry()
{
	HRESULT hr;

	//remove all particle sources
	list<ParticleSource>::iterator currentParticleSource = particleSourceList.begin();
	while(currentParticleSource != particleSourceList.end())
	{
		list<ParticleSource>::iterator particleToRemove = currentParticleSource;
		currentParticleSource++;
		if (FAILED(hr=removeParticleSource(particleToRemove)))
			return hr;
	}

	//release mesh
	SAFE_RELEASE(pMesh);

	//release texture
	SAFE_RELEASE(pTexture);

	return S_OK;
}

/****************************************************************************
** ParticleType Update
**
** Animate and check visibility of particle type
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleType::update()
{
	HRESULT hr;

	//update all particle sources
	list<ParticleSource>::iterator currentParticleSource = particleSourceList.begin();
	while(currentParticleSource != particleSourceList.end())
	{
		if (FAILED(hr=currentParticleSource->update()))
			return hr;

		currentParticleSource++;
	}

	return S_OK;
}

/****************************************************************************
** ParticleType addParticleSource
**
** Add a particle source to this particle type
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleType::addParticleSource(
			D3DXVECTOR3 positionMin, D3DXVECTOR3 positionMax,
			D3DXVECTOR3 speedMin, D3DXVECTOR3 speedMax,
			float lifeTimeMin, float lifeTimeMax,
			float massMin, float massMax,
			float sizeMin, float sizeMax,
			float growthSpeed, float alphaSpeed,
			float emitIntervalMin, float emitIntervalMax, 
			std::list<ParticleSource>::iterator &newParticleSource)
{
	HRESULT hr;

	//add particle to list
	particleSourceList.push_back(ParticleSource());
	newParticleSource = particleSourceList.end();
	newParticleSource--;

	//initialise particle
	if (FAILED(hr=newParticleSource->createGeometry(pD3DDevice,pMesh,&material,pTexture,
					positionMin,positionMax,
					speedMin,speedMax,
					lifeTimeMin,lifeTimeMax,
					massMin,massMax,
					sizeMin,sizeMax,
					growthSpeed, alphaSpeed,
					emitIntervalMin,emitIntervalMax)))
		return hr;

	return S_OK;
}

/****************************************************************************
** ParticleType removeParticleSource
**
** remove a particle source from this type
**
** Author: Dirk Plate
****************************************************************************/
HRESULT ParticleType::removeParticleSource(list<ParticleSource>::iterator currentParticleSource)
{
	HRESULT hr;

	//destroy particle source
	if (FAILED(hr=currentParticleSource->destroyGeometry()))
		return hr;

	//remove particle source from list
	particleSourceList.erase(currentParticleSource);

	return S_OK;
}
