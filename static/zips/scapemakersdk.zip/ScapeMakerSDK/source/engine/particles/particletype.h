/****************************************************************************
** ParticleType
**
** particle type management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(PARTICLETYPE_H)
#define PARTICLETYPE_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include <string>
#include <list>
#include "../common/enginehelpers.h"
#include "particlesource.h"

class ParticleType
{
public:
	ParticleType();
	~ParticleType();

	HRESULT update();
	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, std::string texturePath);
	HRESULT	destroyGeometry();

	HRESULT addParticleSource(
		D3DXVECTOR3 positionMin, D3DXVECTOR3 positionMax,
		D3DXVECTOR3 speedMin, D3DXVECTOR3 speedMax,
		float lifeTimeMin, float lifeTimeMax,
		float massMin, float massMax,
		float sizeMin, float sizeMax,
		float growthSpeed, float alphaSpeed,
		float emitIntervalMin, float emitIntervalMax, 
		std::list<ParticleSource>::iterator &newParticleSource);
	HRESULT removeParticleSource(std::list<ParticleSource>::iterator currentParticleSource);

private:
	LPDIRECT3DDEVICE9 pD3DDevice;

	//the quad of a particle type
	LPD3DXMESH pMesh;

	//the material of a particle type
	D3DMATERIAL9 material;

	//the texture of a particle type
	LPDIRECT3DTEXTURE9 pTexture;

	//list with all particle source for this type
	std::list<ParticleSource> particleSourceList;

};

#endif