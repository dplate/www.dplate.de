#include "depth.h"

#include "../logger/logger.h"
#include "../../common/minixml.h"
#include "../common/enginehelpers.h"
#include "../common/config.h"
#include "../terrain/terrain.h"
#include "../camera/camera.h"
#include "../water/water.h"
#include "../objects/objects.h"
#include "../clouds/clouds.h"
#include "../common/shaderconsts.h"

Depth *Depth::instance = NULL;

/****************************************************************************
** Depth Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
Depth::Depth()
{
	Module::Module();
	name = "Depth";

	enabled = false;
	outOfOrder = true;
	pDepthTexture = NULL;
	pRampRedTexture = NULL;
	pRampGreenTexture = NULL;
	pRampBlueTexture = NULL;
	pRenderToSurface = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	pPixelShader = NULL;
	pVertexShader = NULL;
	pVertexDecl = NULL;

	instance = this;
}

Depth::~Depth()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Depth CreateGeometry
**
** create and initializes the depth rendering
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Depth::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//no height based fog... no depth
	if (!Config::instance->isHeightBasedFog())
		return Module::createGeometry(pD3DDevice);
	
	//create depth texture
	LPDIRECT3DSURFACE9 pBackBuffer;
	D3DSURFACE_DESC backBufferDesc;

	if (FAILED(hr=pD3DDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackBuffer)))
	{
		LOG("Retrieving back buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=pBackBuffer->GetDesc(&backBufferDesc)))
	{
		LOG("Retrieving back buffer description failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(pBackBuffer);

	//depth rendering only works with 32bit back buffer!
	if (backBufferDesc.Format != D3DFMT_X8R8G8B8)
	{
		LOG("Depth rendering disabled because of 16bit back buffer", Logger::LOG_INFO);
		return Module::createGeometry(pD3DDevice);
	}

	if (FAILED(hr=D3DXCreateTexture( pD3DDevice, Camera::instance->getScreenWidth(), Camera::instance->getScreenHeight(), 1,
            D3DUSAGE_RENDERTARGET, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &pDepthTexture)))
	{
		LOG("Depth rendering disabled because of creating depth texture failed", Logger::LOG_CRIT);
		return Module::createGeometry(pD3DDevice);
	}

	if (FAILED(hr=D3DXCreateRenderToSurface(pD3DDevice, Camera::instance->getScreenWidth(), Camera::instance->getScreenHeight(),
			D3DFMT_X8R8G8B8, true, D3DFMT_D24S8, &pRenderToSurface)))
	{
		LOG("Depth rendering disabled because of creating 'render to surface' failed", Logger::LOG_CRIT);
		return Module::createGeometry(pD3DDevice);
	}

	//load the ramp textures (without mipmaps!)
	if(FAILED(hr = (D3DXCreateTextureFromFileEx(pD3DDevice,
		"./enginefiles/rampred.dds",D3DX_DEFAULT,D3DX_DEFAULT,D3DX_FROM_FILE,0,D3DFMT_UNKNOWN,
		D3DPOOL_MANAGED,D3DX_FILTER_NONE,D3DX_FILTER_NONE,0,NULL,NULL,&pRampRedTexture))))
	{
		LOG("Loading red ramp texture failed", Logger::LOG_CRIT);
		return hr;
	}
	if(FAILED(hr = (D3DXCreateTextureFromFileEx(pD3DDevice,
		"./enginefiles/rampgreen.dds",D3DX_DEFAULT,D3DX_DEFAULT,D3DX_FROM_FILE,0,D3DFMT_UNKNOWN,
		D3DPOOL_MANAGED,D3DX_FILTER_NONE,D3DX_FILTER_NONE,0,NULL,NULL,&pRampGreenTexture))))
	{
		LOG("Loading green ramp texture failed", Logger::LOG_CRIT);
		return hr;
	}
	if(FAILED(hr = (D3DXCreateTextureFromFileEx(pD3DDevice,
		"./enginefiles/rampblue.dds",D3DX_DEFAULT,D3DX_DEFAULT,D3DX_FROM_FILE,0,D3DFMT_UNKNOWN,
		D3DPOOL_MANAGED,D3DX_FILTER_NONE,D3DX_FILTER_NONE,0,NULL,NULL,&pRampBlueTexture))))
	{
		LOG("Loading blue ramp texture failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Textures created OK");

	//load vertex shader
	D3DVERTEXELEMENT9  decl[] =
	{
		{ 0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
		{ 0, 12, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
		D3DDECL_END()
	};

	if (FAILED(hr=EngineHelpers::createVSFromFile(pD3DDevice, decl,"./enginefiles/shaders/depth.vsh", &pVertexShader, &pVertexDecl)))
	{
		LOG("Loading vertex shader failed", Logger::LOG_CRIT);
		return hr;
	}
	if (FAILED(hr=EngineHelpers::createPSFromFile(pD3DDevice, "./enginefiles/shaders/depth.psh", &pPixelShader)))
	{
		LOG("Loading pixel shader failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Shader loaded OK");

	//set pixel and vertex shader consts
	depthToTexScale = D3DXVECTOR4(1.0f, 256.0f, 65536.0f, 1.0f/MAX_VIEWDISTANCE);
	texToDepthScale = D3DXVECTOR4(1.0f, 1.0f/256.0f, 1.0f/65536.0f, MAX_VIEWDISTANCE);
	pD3DDevice->SetVertexShaderConstantF(CV_DEPTH_TO_TEX_SCALE, depthToTexScale, 1);
	pD3DDevice->SetPixelShaderConstantF(CP_TEX_TO_DEPTH_SCALE, texToDepthScale, 1);
	pD3DDevice->SetPixelShaderConstantF(CP_ADDITIONAL_ALPHA, D3DXCOLOR(0,0,0,1.0f), 1 );

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetTexture(0, NULL);
		pD3DDevice->SetTexture(1, pRampRedTexture);
		pD3DDevice->SetTexture(2, pRampGreenTexture);
		pD3DDevice->SetTexture(3, pRampBlueTexture);

		//enable testing... but not blending
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true);
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0x7F);
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

		pD3DDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 1, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

		pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

		pD3DDevice->SetSamplerState( 3, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 3, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 3, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 3, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 3, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 3, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
		
		pD3DDevice->SetPixelShader(pPixelShader);
		pD3DDevice->SetVertexShader(pVertexShader);
		pD3DDevice->SetVertexDeclaration(pVertexDecl);
		pD3DDevice->SetRenderState(D3DRS_FOGENABLE, false);

		pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}
	LOG("State block created OK");

	//default not enabled!
	enabled = false;

	//full functional
	outOfOrder = false;

	return Module::createGeometry(pD3DDevice);
}


/****************************************************************************
** Depth DestroyGeometry
**
** destroy the depth stuff
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Depth::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//release texture
	SAFE_RELEASE(pRenderToSurface);
	SAFE_RELEASE(pDepthTexture);
	SAFE_RELEASE(pRampRedTexture);
	SAFE_RELEASE(pRampGreenTexture);
	SAFE_RELEASE(pRampBlueTexture);

	//release state blocks
	SAFE_RELEASE(pSavedStateBlock);
	SAFE_RELEASE(pStateBlock);

	//release shader
	SAFE_RELEASE(pPixelShader);
	SAFE_RELEASE(pVertexShader);
	SAFE_RELEASE(pVertexDecl);

	return Module::destroyGeometry();
}

/****************************************************************************
** Depth Update
**
** Create the depth texture
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Depth::update()
{
	HRESULT hr;

	//if disabled or out of order... do nothing
	if ((!enabled) || (outOfOrder))
		return S_OK;

	//record and set the render states
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	//begin rendering depth texture
	LPDIRECT3DSURFACE9 pDepthSurface = NULL;
	if (FAILED(hr=pDepthTexture->GetSurfaceLevel(0,&pDepthSurface)))
	{
		LOG("Retrieving surface level failed", Logger::LOG_CRIT);
		return hr;
	}
	if (FAILED(hr=pRenderToSurface->BeginScene(pDepthSurface,NULL)))
	{
		LOG("Beginning scene failed", Logger::LOG_CRIT);
		return hr;
	}

	//clear device
	pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF, 1.0f, 0.0f);

	//render all things of landscape
	if (Terrain::instance->getState() == INITIALISED)
	{
		if (FAILED(hr=Terrain::instance->render(DEPTH)))
		{
			LOG("Rendering depth of terrain failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	if (Water::instance->getState() == INITIALISED)
	{
		if (FAILED(hr=Water::instance->render(DEPTH)))
		{
			LOG("Rendering depth of water failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	if ((SubMeshes::instance->getState() == INITIALISED) &&
		(Objects::instance->getState() == INITIALISED) &&
		(Particles::instance->getState() == INITIALISED) &&
		(Clouds::instance->getState() == INITIALISED))
	{
		if (FAILED(hr=SubMeshes::instance->render(DEPTH)))
		{
			LOG("Rendering depth of submeshes failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	
	//end rendering texture
	if (FAILED(hr=pRenderToSurface->EndScene(D3DX_FILTER_NONE)))
	{
		LOG("Ending scene failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(pDepthSurface);

	//Restore the states
	pSavedStateBlock->Apply();

	return Module::update();
}

/****************************************************************************
** Depth enable
**
** enable depth rendering
**
** Author: Dirk Plate
****************************************************************************/
void Depth::enable()
{
	enabled = true;
}

/****************************************************************************
** Depth disable
**
** disable depth rendering
**
** Author: Dirk Plate
****************************************************************************/
void Depth::disable()
{
	enabled = false;
}













































