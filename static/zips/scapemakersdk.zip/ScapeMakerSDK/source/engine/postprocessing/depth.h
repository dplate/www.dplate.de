/****************************************************************************
** Depth
**
** depth rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(DEPTH_H)
#define DEPTH_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "../module.h"

class Depth : public Module
{
public:
	Depth();
	~Depth();

	HRESULT update();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();

	LPDIRECT3DTEXTURE9 getDepthTexture() {return pDepthTexture;}
	LPDIRECT3DSTATEBLOCK9 getStateBlock() {return pStateBlock;}
	LPDIRECT3DSTATEBLOCK9 getSavedStateBlock() {return pSavedStateBlock;}
	D3DXVECTOR4 getDepthToTexScale() {return depthToTexScale;}
	D3DXVECTOR4 getTexToDepthScale() {return texToDepthScale;}

	void enable();
	void disable();

	bool isOutOfOrder() {return outOfOrder;}

	//the instance to the only one depth renderer
	static Depth *instance;

private:
	LPDIRECT3DDEVICE9	pD3DDevice;

	//the depth texture
	LPDIRECT3DTEXTURE9	pDepthTexture;

	//the three ramp textures for encoding depth to rgb
	LPDIRECT3DTEXTURE9 pRampRedTexture;
	LPDIRECT3DTEXTURE9 pRampGreenTexture;
	LPDIRECT3DTEXTURE9 pRampBlueTexture;

	//help class for rendering
	LPD3DXRENDERTOSURFACE pRenderToSurface;

	//state block for depth rendering
	LPDIRECT3DSTATEBLOCK9 pStateBlock;
	LPDIRECT3DSTATEBLOCK9 pSavedStateBlock;

	//the depth shaders
	LPDIRECT3DPIXELSHADER9 pPixelShader;
	LPDIRECT3DVERTEXSHADER9 pVertexShader;
	LPDIRECT3DVERTEXDECLARATION9 pVertexDecl;

	//vectors for depth converting
	D3DXVECTOR4 depthToTexScale;
	D3DXVECTOR4 texToDepthScale;

	//depth en- or disabled
	bool enabled;

	//depth rendering impossible?
	bool outOfOrder;
};

#endif

