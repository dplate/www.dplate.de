#include "heightbasedfog.h"

#include "../logger/logger.h"
#include "../../common/minixml.h"
#include "../common/enginehelpers.h"
#include "../common/config.h"
#include "../terrain/terrain.h"
#include "../sky/sky.h"
#include "../camera/camera.h"
#include "../common/shaderconsts.h"
#include "depth.h"

HeightBasedFog *HeightBasedFog::instance = NULL;

/****************************************************************************
** HeightBasedFog Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
HeightBasedFog::HeightBasedFog()
{
	Module::Module();
	name = "HeightBasedFog";

	forShadowGen = false;
	enabled = false;
	pFogLayerTexture = NULL;
	pDepthAndBackFogLayerTexture = NULL;
	pRenderToSurface = NULL;

	pFogLayerVB = NULL;
	pPostProcessingVB = NULL;

	pFogLayerStateBlock = NULL;
	pFogLayerSavedStateBlock = NULL;
	pPostProcessingStateBlock = NULL;
	pPostProcessingSavedStateBlock = NULL;

	pPixelShaderBack = NULL;
	pPixelShaderFinal = NULL;

	lowerHeight = 0.0f;
	higherHeight = 20.0f;
	density = 0.0f;

	instance = this;
}

HeightBasedFog::~HeightBasedFog()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** HeightBasedFog CreateGeometry
**
** same as below with standard parameters
**
** Author: Dirk Plate
****************************************************************************/
HRESULT HeightBasedFog::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	HRESULT hr;

	if (FAILED(hr=createGeometry(pD3DDevice,false)))
		return hr;

	return Module::createGeometry(pD3DDevice);
} 

/****************************************************************************
** HeightBasedFog CreateGeometry
**
** create and initializes the height based fog
**
** Author: Dirk Plate
****************************************************************************/
HRESULT HeightBasedFog::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, bool forShadowGen)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;
	this->forShadowGen = forShadowGen;

	//load fog properties from file
	string fogPropertiesPath = Config::instance->getEnginePath()+"/heightBasedFog.txt";
	MiniXML xmlFile;
	if (xmlFile.openFile(fogPropertiesPath.c_str(),MiniXML::READ))
	{
		int	value;

		//load start of fog
		if (xmlFile.readInteger("lowerLayer",&value))
			lowerHeight = Terrain::instance->transformHeightInMetersToEngineCoor(value,true);
		
		//load end of fog
		if (xmlFile.readInteger("higherLayer",&value))
			higherHeight = Terrain::instance->transformHeightInMetersToEngineCoor(value,true);
		
		//load fog density
		if (xmlFile.readInteger("density",&value))
		{
			//if fog density == 0% -> no fog
			if ((value > 0) && (Config::instance->isHeightBasedFog()) && !forShadowGen)
				enable();
				
			//calculate fog density value
			density = ((float)value)/100.0f;
		}

		xmlFile.closeFile();
	}

	//depth rendering not active? no height based fog possible
	bool depthOutOfOrder = false;
	if ((Depth::instance != NULL) && (Depth::instance->getState() == INITIALISED))
		depthOutOfOrder = Depth::instance->isOutOfOrder();
	if (depthOutOfOrder && enabled)
	{
		LOG("Height based fog disabled because depth rendering out of order", Logger::LOG_INFO);
		enabled = false;
	}
	
	//load only things, if enabled
	if (enabled)
	{
	
		//create deep textures
		LPDIRECT3DSURFACE9 pBackBuffer;
		D3DSURFACE_DESC backBufferDesc;

		if (FAILED(hr=pD3DDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackBuffer)))
		{
			LOG("Retrieving back buffer failed", Logger::LOG_CRIT);
			return hr;
		}

		if (FAILED(hr=pBackBuffer->GetDesc(&backBufferDesc)))
		{
			LOG("Retrieving back buffer description failed", Logger::LOG_CRIT);
			return hr;
		}

		D3DFORMAT renderTargetFormat = backBufferDesc.Format;

		if (FAILED(hr=D3DXCreateTexture( pD3DDevice, backBufferDesc.Width, backBufferDesc.Height, 1,
				D3DUSAGE_RENDERTARGET, renderTargetFormat, D3DPOOL_DEFAULT, &pFogLayerTexture)))
		{
			LOG("Creating lower fog layer texture failed", Logger::LOG_CRIT);
			return hr;
		}

		if (FAILED(hr=D3DXCreateTexture( pD3DDevice, backBufferDesc.Width, backBufferDesc.Height, 1,
				D3DUSAGE_RENDERTARGET, renderTargetFormat, D3DPOOL_DEFAULT, &pDepthAndBackFogLayerTexture)))
		{
			LOG("Creating higher fog layer texture failed", Logger::LOG_CRIT);
			return hr;
		}


		if (FAILED(hr=D3DXCreateRenderToSurface(pD3DDevice, backBufferDesc.Width, backBufferDesc.Height,
			renderTargetFormat, true, D3DFMT_D24S8, &pRenderToSurface)))
		{
			LOG("Creating 'render to surface' failed", Logger::LOG_CRIT);
			return hr;
		}

		SAFE_RELEASE(pBackBuffer);

		LOG("Textures created OK");

		//set shader consts for fog
		D3DXCOLOR color = Sky::instance->getDustColor();
		pD3DDevice->SetPixelShaderConstantF(CP_HEIGHT_FOG_COLOR, D3DXVECTOR4(color.r, color.g, color.b, density), 1);

		if (FAILED(hr=initPostProcessing()))
			return hr;

		LOG("Post processing stuff created OK");

		if (FAILED(hr=initFogLayers()))
			return hr;

		LOG("Fog layers created OK");
	}

	return S_OK;
}

/****************************************************************************
** HeightBasedFog initPostProcessing
**
** create/init postprocessing quad
**
** Author: Dirk Plate
****************************************************************************/
HRESULT HeightBasedFog::initPostProcessing()
{
	HRESULT hr;

	//load pixel shader
	if (FAILED(hr=EngineHelpers::createPSFromFile(pD3DDevice, "./enginefiles/shaders/heightBasedFogFinal.psh", &pPixelShaderFinal)))
	{
		LOG("Loading pixel shader failed", Logger::LOG_CRIT);
		return hr;
	}

	//create post processing vertex buffer
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer(4 * sizeof(POSTPROCESSINGVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_POSTPROCESSINGVERTEX, D3DPOOL_DEFAULT,
										     &pPostProcessingVB, NULL)))
		return hr;

	//fill post processing vertex buffer
	POSTPROCESSINGVERTEX* pVertices = NULL;
	pPostProcessingVB->Lock(0, 4 * sizeof(POSTPROCESSINGVERTEX), (VOID**)&pVertices, D3DLOCK_DISCARD);

	pVertices[0].p.x = 0.0f;
	pVertices[0].p.y = 0.0f;
	pVertices[0].p.z = 1.0f;
	pVertices[0].rhw = 1.0f;
	pVertices[0].t0.x = 0.0f;
	pVertices[0].t0.y = 0.0f;
	pVertices[0].t1.x = 0.0f;
	pVertices[0].t1.y = 0.0f;

	pVertices[1].p.x = 0.0f;
	pVertices[1].p.y = Camera::instance->getScreenHeight();
	pVertices[1].p.z = 1.0f;
	pVertices[1].rhw = 1.0f;
	pVertices[1].t0.x = 0.0f;
	pVertices[1].t0.y = 1.0f;
	pVertices[1].t1.x = 0.0f;
	pVertices[1].t1.y = 1.0f;
	
	pVertices[2].p.x = Camera::instance->getScreenWidth();
	pVertices[2].p.y = 0.0f;
	pVertices[2].p.z = 1.0f;
	pVertices[2].rhw = 1.0f;
	pVertices[2].t0.x = 1.0f;
	pVertices[2].t0.y = 0.0f;
	pVertices[2].t1.x = 1.0f;
	pVertices[2].t1.y = 0.0f;
	
	pVertices[3].p.x = Camera::instance->getScreenWidth();
	pVertices[3].p.y = Camera::instance->getScreenHeight();
	pVertices[3].p.z = 1.0f;
	pVertices[3].rhw = 1.0f;
	pVertices[3].t0.x = 1.0f;
	pVertices[3].t0.y = 1.0f;
	pVertices[3].t1.x = 1.0f;
	pVertices[3].t1.y = 1.0f;

	pPostProcessingVB->Unlock();

	LOG("Post processing mesh created OK");

	//create post processing state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,  true);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, MIN_ALPHA );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetRenderState(D3DRS_CULLMODE,			D3DCULL_CW);
		pD3DDevice->SetRenderState(D3DRS_ZENABLE,			FALSE);
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE,		FALSE);
		pD3DDevice->SetFVF(D3DFVF_POSTPROCESSINGVERTEX);

		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

		pD3DDevice->SetSamplerState( 1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 1, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

		pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MINFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pPostProcessingStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pPostProcessingSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	LOG("Post processing state block created OK");
	return S_OK;
}

/****************************************************************************
** HeightBasedFog initPostProcessing
**
** create/init fog layer quad
**
** Author: Dirk Plate
****************************************************************************/
HRESULT HeightBasedFog::initFogLayers()
{
	HRESULT hr;

	//load pixel shader
	if (FAILED(hr=EngineHelpers::createPSFromFile(pD3DDevice, "./enginefiles/shaders/heightBasedFogBack.psh", &pPixelShaderBack)))
	{
		LOG("Loading pixel shader failed", Logger::LOG_CRIT);
		return hr;
	}

	//create fog layer vertex buffer
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer(4 * sizeof(FOGLAYERVERTEX),
										     D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC,
										     D3DFVF_FOGLAYERVERTEX, D3DPOOL_DEFAULT,
										     &pFogLayerVB, NULL)))
		return hr;

	//fill post processing vertex buffer
	float width = Terrain::instance->getWidth()+1;
	FOGLAYERVERTEX* pVertices2 = NULL;
	pFogLayerVB->Lock(0, 4 * sizeof(FOGLAYERVERTEX), (VOID**)&pVertices2, D3DLOCK_DISCARD);

	pVertices2[0].p.x = -width;
	pVertices2[0].p.y = 0.0f;
	pVertices2[0].p.z = -width;
	
	pVertices2[1].p.x = -width;
	pVertices2[1].p.y = 0.0f;
	pVertices2[1].p.z = 2.0f*width;
	
	pVertices2[2].p.x = 2.0f*width;
	pVertices2[2].p.y = 0.0f;
	pVertices2[2].p.z = -width;
	
	pVertices2[3].p.x = 2.0f*width;
	pVertices2[3].p.y = 0.0f;
	pVertices2[3].p.z = 2.0f*width;

	pFogLayerVB->Unlock();

	LOG("Fog layer mesh created OK");

	//calculate first layer heights
	fixFogLayerHeight();

	//get fog layer state block from depth rendering
	pFogLayerStateBlock = Depth::instance->getStateBlock();
	pFogLayerSavedStateBlock = Depth::instance->getSavedStateBlock();

	return S_OK;
}


/****************************************************************************
** HeightBasedFog DestroyGeometry
**
** destroy the height based fog
**
** Author: Dirk Plate
****************************************************************************/
HRESULT HeightBasedFog::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//release texture
	SAFE_RELEASE(pRenderToSurface);
	SAFE_RELEASE(pFogLayerTexture);
	SAFE_RELEASE(pDepthAndBackFogLayerTexture);

	//release vertex buffer
	SAFE_RELEASE(pPostProcessingVB);
	SAFE_RELEASE(pFogLayerVB);

	//release state blocks
	SAFE_RELEASE(pPostProcessingSavedStateBlock);
	SAFE_RELEASE(pPostProcessingStateBlock);

	//release pixel shader
	SAFE_RELEASE(pPixelShaderBack);
	SAFE_RELEASE(pPixelShaderFinal);

	return Module::destroyGeometry();
}

/****************************************************************************
** HeightBasedFog Render
**
** renders the height based fog
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	HeightBasedFog::render(ModuleRenderType renderType)
{
	HRESULT hr;

	//if disabled... do nothing
	if (!enabled)
		return S_OK;

	//render post processing quad
	//record and set the render states
	pPostProcessingSavedStateBlock->Capture();
	pPostProcessingStateBlock->Apply();

	//set final pixel shader
	pD3DDevice->SetPixelShader(pPixelShaderFinal);
	pD3DDevice->SetTexture(0, pDepthAndBackFogLayerTexture);
	pD3DDevice->SetTexture(1, pFogLayerTexture);

	//set shader const to right density
	D3DXVECTOR4 texToDepthScale = Depth::instance->getTexToDepthScale();
	texToDepthScale.x *= density*256.0f;
	texToDepthScale.y *= density*256.0f;
	texToDepthScale.z *= density*256.0f;
	pD3DDevice->SetPixelShaderConstantF(CP_TEX_TO_DEPTH_SCALE, texToDepthScale, 1);

	//set vertex stream
	pD3DDevice->SetStreamSource(0, pPostProcessingVB, NULL, sizeof(POSTPROCESSINGVERTEX));

	//render quad
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering post processing quad failed", Logger::LOG_CRIT);
		return hr;
	}

	//Restore the states
	pD3DDevice->SetPixelShader(NULL);
	pD3DDevice->SetTexture(0, NULL);
	pD3DDevice->SetTexture(1, NULL);
	pPostProcessingSavedStateBlock->Apply();

	return Module::render(renderType);
}

/****************************************************************************
** HeightBasedFog Update
**
** Prepare the height based fog
**
** Author: Dirk Plate
****************************************************************************/
HRESULT HeightBasedFog::update()
{
	HRESULT hr;

	//if disabled... do nothing
	if (!enabled)
		return S_OK;

	//fix layer height and get camera state
	int cameraState = fixFogLayerHeight();
	
	//record and set the render states
	pFogLayerSavedStateBlock->Capture();
	pFogLayerStateBlock->Apply();

	//begin rendering back fog layers
	LPDIRECT3DSURFACE9 pFogLayerSurface = NULL;
	if (FAILED(hr=pFogLayerTexture->GetSurfaceLevel(0,&pFogLayerSurface)))
	{
		LOG("Retrieving surface level failed", Logger::LOG_CRIT);
		return hr;
	}
	if (FAILED(hr=pRenderToSurface->BeginScene(pFogLayerSurface,NULL)))
	{
		LOG("Beginning scene failed", Logger::LOG_CRIT);
		return hr;
	}

	//clear device
	pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF, 1.0f, 0.0f);

	//set vertex stream
	pD3DDevice->SetStreamSource(0, pFogLayerVB, NULL, sizeof(FOGLAYERVERTEX));

	//draw lower layer, if camera above this layer
	if ((cameraState == 1) || (cameraState == 0))
	{
		//set position
		EngineHelpers::setWorldTransform(pD3DDevice,&lowerFogLayerTransformation,true);
		//render fog layer
		if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			LOG("Rendering lower fog layer failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//draw higher layer, if camera below this layer
	if ((cameraState == 0) || (cameraState == -1))
	{
		//set position
		EngineHelpers::setWorldTransform(pD3DDevice,&higherFogLayerTransformation,true);
		//render fog layer
		if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
		{
			LOG("Rendering higher fog layer failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//end rendering texture
	if (FAILED(hr=pRenderToSurface->EndScene(D3DX_FILTER_NONE)))
	{
		LOG("Ending scene failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(pFogLayerSurface);

	//Restore the states
	pFogLayerSavedStateBlock->Apply();


	
	//record and set the render states
	pPostProcessingSavedStateBlock->Capture();
	pPostProcessingStateBlock->Apply();

	//combine back fog layer with depth texture
	LPDIRECT3DSURFACE9 pDepthAndBackFogLayerSurface = NULL;
	if (FAILED(hr=pDepthAndBackFogLayerTexture->GetSurfaceLevel(0,&pDepthAndBackFogLayerSurface)))
	{
		LOG("Retrieving surface level failed", Logger::LOG_CRIT);
		return hr;
	}
	if (FAILED(hr=pRenderToSurface->BeginScene(pDepthAndBackFogLayerSurface,NULL)))
	{
		LOG("Beginning scene failed", Logger::LOG_CRIT);
		return hr;
	}

	//clear device
	pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF, 1.0f, 0.0f);

	//set back pixel shader
	pD3DDevice->SetPixelShader(pPixelShaderBack);
	pD3DDevice->SetTexture(0, Depth::instance->getDepthTexture());
	pD3DDevice->SetTexture(1, pFogLayerTexture);

	//set pixel shader constant
	pD3DDevice->SetPixelShaderConstantF(CP_ADDITIONAL_ALPHA, D3DXCOLOR(0,0,0,0.5f), 1 );

	//set vertex stream
	pD3DDevice->SetStreamSource(0, pPostProcessingVB, NULL, sizeof(POSTPROCESSINGVERTEX));

	//render quad
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering post processing quad failed", Logger::LOG_CRIT);
		return hr;
	}

	//Restore the states
	pD3DDevice->SetPixelShader(NULL);
	pD3DDevice->SetTexture(0, NULL);
	pD3DDevice->SetTexture(1, NULL);
	pPostProcessingSavedStateBlock->Apply();
	pD3DDevice->SetPixelShaderConstantF(CP_ADDITIONAL_ALPHA, D3DXCOLOR(0,0,0,1.0f), 1 );

	//end rendering texture
	if (FAILED(hr=pRenderToSurface->EndScene(D3DX_FILTER_NONE)))
	{
		LOG("Ending scene failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(pDepthAndBackFogLayerSurface);

	//Restore the states
	pPostProcessingSavedStateBlock->Apply();


	//record and set the render states
	pFogLayerSavedStateBlock->Capture();
	pFogLayerStateBlock->Apply();

	//begin rendering front fog layers
	if (FAILED(hr=pFogLayerTexture->GetSurfaceLevel(0,&pFogLayerSurface)))
	{
		LOG("Retrieving surface level failed", Logger::LOG_CRIT);
		return hr;
	}
	if (FAILED(hr=pRenderToSurface->BeginScene(pFogLayerSurface,NULL)))
	{
		LOG("Beginning scene failed", Logger::LOG_CRIT);
		return hr;
	}

	//only render something, if camera not in fog
	if (cameraState != 0)
	{
		//clear device
		pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF, 1.0f, 0.0f);

		//set vertex stream
		pD3DDevice->SetStreamSource(0, pFogLayerVB, NULL, sizeof(FOGLAYERVERTEX));

		//draw higher layer, if camera above this layer
		if (cameraState == 1)
		{
			//set position
			EngineHelpers::setWorldTransform(pD3DDevice,&higherFogLayerTransformation,true);
			//render fog layer
			if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
			{
				LOG("Rendering higher fog layer failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		//draw lower layer, if camera below this layer
		if (cameraState == -1)
		{
			//set position
			EngineHelpers::setWorldTransform(pD3DDevice,&lowerFogLayerTransformation,true);
			//render fog layer
			if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
			{
				LOG("Rendering lower fog layer failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}
	else
	{
		//clear device
		pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0.0f);
	}

	//end rendering texture
	if (FAILED(hr=pRenderToSurface->EndScene(D3DX_FILTER_NONE)))
	{
		LOG("Ending scene failed", Logger::LOG_CRIT);
		return hr;
	}
	SAFE_RELEASE(pFogLayerSurface);


	//Restore the states
	pFogLayerSavedStateBlock->Apply();

	return Module::update();
}

/****************************************************************************
** HeightBasedFog enable
**
** enable height based fog
**
** Author: Dirk Plate
****************************************************************************/
void HeightBasedFog::enable()
{
	enabled = true;

	//enable depth rendering
	Depth::instance->enable();
}

/****************************************************************************
** HeightBasedFog disable
**
** disable height based fog
**
** Author: Dirk Plate
****************************************************************************/
void HeightBasedFog::disable()
{
	enabled = false;

	//disable depth rendering
	Depth::instance->enable();
}

/****************************************************************************
** HeightBasedFog fixFogLayerHeight
**
** fix the height of the fog layer to solve near clip planes problems
**
** Author: Dirk Plate
****************************************************************************/
int HeightBasedFog::fixFogLayerHeight()
{
	//calculate extremes of near clip plane
	//get important values from camera
	D3DXVECTOR3 direction = Camera::instance->getDirection();
	D3DXVec3Normalize(&direction,&direction);
	D3DXVECTOR3 up = Camera::instance->getUp();
	D3DXVec3Normalize(&up,&up);
	D3DXVECTOR3 right = Camera::instance->getRight();
	D3DXVec3Normalize(&right,&right);
	float aspect = Camera::instance->getAspect();
	float halfFov = Camera::instance->getFieldOfView()/2.0f;
	float distance = Camera::instance->getNearClipPlane();

	//calculate half height of clip plane
	float halfHeight = distance * tanf(halfFov);
	
	//calculate half width of clip plane
	float halfWidth = halfHeight*aspect;

	//calculate position of edges of clip plane
	D3DXVECTOR3 center = Camera::instance->getPosition() + distance * direction;
	D3DXVECTOR3 rightTop = center + halfHeight * up + halfWidth * right;
	D3DXVECTOR3 leftTop = center + halfHeight * up - halfWidth * right;
	D3DXVECTOR3 rightBottom = center - halfHeight * up + halfWidth * right;
	D3DXVECTOR3 leftBottom = center - halfHeight * up - halfWidth * right;

	//get lowest and highest height
	float lowestHeight  = MIN(MIN(rightBottom.y,leftBottom.y),MIN(rightTop.y,leftTop.y));
	float highestHeight = MAX(MAX(rightBottom.y,leftBottom.y),MAX(rightTop.y,leftTop.y));

	//get new heights for fog layers
	float newLowerHeight = lowerHeight;
	float newHigherHeight = higherHeight;
	int cameraState;

	//only higher fog layer through clip plane
	if ((lowestHeight > lowerHeight) && 
		(lowestHeight < higherHeight) && (highestHeight > higherHeight))
	{
		//fix higher plane height
		if ((higherHeight - lowestHeight) < (highestHeight - higherHeight))
		{
			newHigherHeight = lowestHeight;
			cameraState = 1;
		}
		else 
		{
			newHigherHeight = highestHeight;
			cameraState = 0;
		}
	}
	//only lower fog layer through clip plane
	else if ((highestHeight < higherHeight) && 
			 (lowestHeight < lowerHeight) && (highestHeight > lowerHeight))
	{
		//fix lower plane height
		if ((lowerHeight - lowestHeight) < (highestHeight - lowerHeight))
		{
			newLowerHeight = lowestHeight;
			cameraState = 0;
		}
		else
		{
			newLowerHeight = highestHeight;
			cameraState = -1;
		}
	}
	//both layers through clip plane
	else if ((lowestHeight < higherHeight) && (highestHeight > higherHeight) &&
			 (lowestHeight < lowerHeight) && (highestHeight > lowerHeight))
	{
		//fog both plane heights
		newLowerHeight = lowestHeight;
		newHigherHeight = highestHeight;
		cameraState = 0;
	}
	//both layers below clip plane
	else if (higherHeight < lowestHeight)
		cameraState = 1;
	//both layer above clip plane
	else if (lowerHeight > highestHeight)
		cameraState = -1;
	//lower layer below and higher layer above clip plane
	else cameraState = 0;

	//set new transformation matrices
	D3DXMatrixTranslation(&lowerFogLayerTransformation,0.0f,newLowerHeight,0.0f);
	D3DXMatrixTranslation(&higherFogLayerTransformation,0.0f,newHigherHeight,0.0f);

	//return position of camera
	return cameraState;
}

/****************************************************************************
** HeightBasedFog intersectRay
**
** Determine the intersection between a ray and the fog
**
** rayPos					Start of the ray
** rayDir					Direction (and length) of the ray
** invAlpha					The alpha value at intersection
** onlySegment				Find only intersections between rayPos and rayPos+rayDir
**
** Author: Dirk Plate
****************************************************************************/
bool HeightBasedFog::intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir, 
		float *pInvAlpha, bool onlySegment)
{
	if ((!enabled) && (!forShadowGen))
		return false;

	//init alpha to invisible
	*pInvAlpha = 1.0f;

	//calculate intersection points of lower and higher fog layer
	D3DXVECTOR3 lowerIntersection;
	lowerIntersection.y = lowerHeight;
	if (!EngineHelpers::getXZCoordinateOfRay(pRayPos,pRayDir, 
		&(lowerIntersection.x), lowerHeight,&(lowerIntersection.z)))
		return false;

	D3DXVECTOR3 higherIntersection;
	higherIntersection.y = higherHeight;
	if (!EngineHelpers::getXZCoordinateOfRay(pRayPos,pRayDir, 
		&(higherIntersection.x), higherHeight,&(higherIntersection.z)))
		return false;

	//checking segment?
	if (onlySegment)
	{
		D3DXVECTOR3 intersectDir;
		float factor;
		bool lowerBehindPos = false;
		bool lowerBehindEndOfRay = false;

		//check position of lower intersection
		intersectDir = lowerIntersection-(*pRayPos);
		factor = (pRayDir->y)/(intersectDir.y);

		//behind pos?
		if (factor < 0.0f)
		{
			//flag it
			lowerBehindPos = true;

			//use pos
			lowerIntersection = *pRayPos;
		}
		//behind end of ray?
		else if (factor < 1.0f)
		{
			//flag it
			lowerBehindEndOfRay = true;

			//use end of ray
			lowerIntersection = *pRayPos+*pRayDir;
		}

		//check position of higher intersection
		intersectDir = higherIntersection-(*pRayPos);
		factor = (pRayDir->y)/(intersectDir.y);

		//behind pos?
		if (factor < 0.0f)
		{
			//lower behind pos, too?
			if (lowerBehindPos)
				return false;

			//use pos
			higherIntersection = *pRayPos;
		}
		//behind end of ray?
		else if (factor < 1.0f)
		{
			//higher behind end of ray, too?
			if (lowerBehindEndOfRay)
				return false;

			//use end of ray
			higherIntersection = *pRayPos+*pRayDir;
		}
	}

	//error?
	if (higherIntersection.y <= lowerIntersection.y)
		return false;

	//calculate length through fog
	float fogDistance = D3DXVec3Length(&(higherIntersection-lowerIntersection));

	//set to nice alpha value
	*pInvAlpha = fogDistance*density*0.3f;
	if (*pInvAlpha < 0.0f) *pInvAlpha = 0.0f;
	if (*pInvAlpha > 1.0f) *pInvAlpha = 1.0f;
	*pInvAlpha = 1.0f-*pInvAlpha;

	return true;
}











































