/****************************************************************************
** HeightBasedFog
**
** height based fog rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(HEIGHTBASEDFOG_H)
#define HEIGHTBASEDFOG_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "../module.h"

struct POSTPROCESSINGVERTEX
{
	D3DXVECTOR3 p;
	float rhw;
	D3DXVECTOR2 t0;
	D3DXVECTOR2 t1;
};

#define D3DFVF_POSTPROCESSINGVERTEX (D3DFVF_XYZRHW | D3DFVF_TEX2)

struct FOGLAYERVERTEX
{
	D3DXVECTOR3 p;
	D3DXVECTOR2 t0;
};

#define D3DFVF_FOGLAYERVERTEX (D3DFVF_XYZ | D3DFVF_TEX1)

class HeightBasedFog : public Module
{
public:
	HeightBasedFog();
	~HeightBasedFog();

	HRESULT update();
	HRESULT render(ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, bool forShadowGen);
	HRESULT	destroyGeometry();

	void enable();
	void disable();

	bool intersectRay(const D3DXVECTOR3 *pRayPos, const D3DXVECTOR3 *pRayDir,
		float *pInvAlpha, bool onlySegment);

	//the instance to the only one height based fog objects
	static HeightBasedFog *instance;				

private:
	HRESULT initPostProcessing();
	HRESULT initFogLayers();
	int fixFogLayerHeight();

	LPDIRECT3DDEVICE9	pD3DDevice;
	bool				forShadowGen;

	//the fog layer texture
	LPDIRECT3DTEXTURE9	pFogLayerTexture;

	//the combined depth and back fog layer texture
	LPDIRECT3DTEXTURE9	pDepthAndBackFogLayerTexture;

	//help class for rendering
	LPD3DXRENDERTOSURFACE pRenderToSurface;
	
	//the transformation matrix for lower fog layer
	D3DXMATRIX			lowerFogLayerTransformation;

	//the transformation matrix for higher fog layer
	D3DXMATRIX			higherFogLayerTransformation;

	//the mesh of one fog layer
	LPDIRECT3DVERTEXBUFFER9 pFogLayerVB;

	//the mesh of post processing quad
	LPDIRECT3DVERTEXBUFFER9 pPostProcessingVB;

	//state block for fog layer rendering
	LPDIRECT3DSTATEBLOCK9 pFogLayerStateBlock;
	LPDIRECT3DSTATEBLOCK9 pFogLayerSavedStateBlock;

	//state block for post processing quad rendering
	LPDIRECT3DSTATEBLOCK9 pPostProcessingStateBlock;
	LPDIRECT3DSTATEBLOCK9 pPostProcessingSavedStateBlock;

	//the height base fog pixel shader
	LPDIRECT3DPIXELSHADER9 pPixelShaderBack;
	LPDIRECT3DPIXELSHADER9 pPixelShaderFinal;
	
	//height based fog en- or disabled
	bool enabled;

	//density of fog
	float density;
	
	//fog height start in engine coordinates
	float lowerHeight;
	
	//fog height end in engine coordinates
	float higherHeight;

};

#endif

