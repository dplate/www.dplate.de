/****************************************************************************
** Commands
**
** lists of all commands
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_COMMANDS)
#define H_COMMANDS
#pragma warning(disable:4786)

#include <stdio.h>
#include <string>

static const class Command
{
public:
	const char *prefix;
	const char *method;
	const char *parameter;
} commands[] = {{"camera",  "setPosition",		"(x, y, z)"},
				{"camera",	"movePosition",		"(startDirX, startDirY, startDirZ, endPosX, endPosY, endPosZ, endDirX, endDirY, endDirZ, duration)"},
				{"camera",  "setLookAt",		"(x, y, z)"},
				{"camera",	"moveLookAt",		"(startDirX, startDirY, startDirZ, endPosX, endPosY, endPosZ, endDirX, endDirY, endDirZ, duration)"},
				{"camera",  "makeScreenshot",	"()"},
				{"camera",  "makeScreenshotEx",	"(prefix, aspect)"},
				{"camera",  "setFieldOfView",	"(verticalAngle)"},
				{"console", "addMessage",		"(\"text\")"},
				{"console", "open",				"()"},
				{"console", "close",			"()"},
				{"heightBasedFog", "enable",	"()"},
				{"heightBasedFog", "disable",	"()"},
				{"hud",		"show",				"()"},
				{"hud",		"hide",				"()"},
				{"scripts", "loadScript",		"(\"name\")"},
				{"scripts", "showAll",			"()"},
				{"scripts", "stopAll",			"()"},
				{"water",	"enable",			"()"},
				{"water",	"disable",			"()"},
				{"water",	"enableWireframe",	"()"},
				{"water",	"disableWireframe",	"()"},
				{"terrain",	"enableWireframe",	"()"},
				{"terrain",	"disableWireframe",	"()"},
				{"time",	"setGameTimeFactor","(factor)"}};

static const int COMMANDS_COUNT = 24;

enum CommandID
{
	CAMERA_SETPOSITION = 0, 
	CAMERA_MOVEPOSITION = 1,
	CAMERA_SETLOOKAT = 2, 
	CAMERA_MOVELOOKAT = 3,
	CAMERA_MAKESCREENSHOT = 4, 
	CAMERA_MAKESCREENSHOTEX = 5, 
	CAMERA_SETFIELDOFVIEW = 6,
	CONSOLE_ADDMESSAGE = 7,
	CONSOLE_OPEN = 8,
	CONSOLE_CLOSE = 9,
	HEIGHTBASEDFOG_ENABLE = 10,
	HEIGHTBASEDFOG_DISABLE = 11,
	HUD_SHOW = 12,
	HUD_HIDE = 13,
	SCRIPTS_LOADSCRIPT = 14,
	SCRIPTS_SHOWALL = 15,
	SCRIPTS_STOPALL = 16,
	WATER_ENABLE = 17,
	WATER_DISABLE = 18,
	WATER_ENABLEWIREFRAME = 19,
	WATER_DISABLEWIREFRAME = 20,
	TERRAIN_ENABLEWIREFRAME = 21,
	TERRAIN_DISABLEWIREFRAME = 22,
	TIME_SETGAMETIMEFACTOR = 23
};

#endif