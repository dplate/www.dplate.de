#include "scripts.h"
#include "../../common/minixml.h"
#include "../terrain/terrain.h"
#include "../console/console.h"
#include "../camera/camera.h"
#include "../water/water.h"	
#include "../common/time.h"
#include "../hud/hud.h"
#include "../postprocessing/heightbasedfog.h"

/****************************************************************************
** Scripts Constructor
**
** inits variables
**
** Author: Dirk Plate
****************************************************************************/
Scripts::Scripts()
{
}

/****************************************************************************
** Scripts Destructor
**
** deallocates vars
**
** Author: Dirk Plate
****************************************************************************/
Scripts::~Scripts()
{
}

/****************************************************************************
** Scripts init
**
** init everything
**
** Author: Dirk Plate
****************************************************************************/	
void Scripts::init()
{
	//delete all active scripts
	scripts.clear();
}

/****************************************************************************
** Scripts update
**
** update all scripts
**
** Author: Dirk Plate
****************************************************************************/	
void Scripts::update()
{
	//get elapsed engine time in last frame
	float elapsedTime = Time::instance->getEngineFrameTime();

	//traverse all scripts
	std::list<Script>::iterator i = scripts.begin();
	while (i != scripts.end())
	{
		//add elapsed time
		i->currentTime += elapsedTime;

		//time of current method is elapsed?
		if (i->methods[i->nextMethod].time < i->currentTime)
		{
			//call method
			callMethod(i->methods[i->nextMethod]);

			//switch to next method
			i->nextMethod++;

			//all methods called?
			if (i->nextMethod >= i->methods.size())
			{
				//delete script
				std::list<Script>::iterator tmp = i;
				i++;
				scripts.erase(tmp);
				continue;
			}
		}

		i++;
	}
}

/****************************************************************************
** Scripts loadScript
**
** load a script from file and start it
**
** Author: Dirk Plate
****************************************************************************/	
bool Scripts::loadScript(std::string &name)
{
	//the new script
	Script newScript;

	//construct path for file
	std::string filePath = std::string("./enginefiles/scripts/") + name + std::string(".txt");

	//open file with minixml
	MiniXML xmlFile;
	if (xmlFile.openFile(filePath.c_str(),MiniXML::READ))
	{
		//read list with all elements
		if (xmlFile.startReadList("script"))
		{
			int i=0;
			float fValue;
			char sValue[512] = "";
						
			while (xmlFile.startReadListElement(i))
			{	
				//add new method to vector
				newScript.methods.push_back(Method());

				//read time
				if (xmlFile.readFloat("time",&fValue))
					newScript.methods[i].time = fValue;
				else 
				{
					Console::instance->addMessage(std::string("error: missing time tag in script"));						
					return false;
				}

				//read method string
				if (xmlFile.readString("method",sValue,512))
				{
					//parse method string
					if (!parseMethodString(sValue,newScript.methods[i]))
					{
						Console::instance->addMessage(std::string("error: unknown method \"")+sValue+"\" in script found");						
						return false;
					}
				}	
				else 
				{
					Console::instance->addMessage(std::string("error: missing method tag in script"));				
					return false;
				}

				xmlFile.endReadListElement();
				i++;
			}			

			xmlFile.endReadList();
		}
		else 
		{
			Console::instance->addMessage(std::string("error: missing script tag in script"));				
			return false;
		}
		
		xmlFile.closeFile();
	}
	else 
	{
		Console::instance->addMessage(std::string("error: cant open script file \"")+filePath+"\"");						
		return false;
	}

	//begin script
	newScript.currentTime = 0.0f;
	newScript.nextMethod = 0;
	
	//add script to script list
	scripts.push_back(newScript);

	return true;
}


/****************************************************************************
** Scripts callMethod
**
** call a method instantly by string
**
** Author: Dirk Plate
****************************************************************************/
bool Scripts::callMethod(std::string &methodString)
{
	//create a new method
	Method method;

	Console::instance->addMessage(methodString);

	//parse method string
	if (!parseMethodString(methodString, method))
	{
		Console::instance->addMessage(std::string("error: unknown method \"")+methodString+"\"");
		return false;
	}

	//call method
	if (!callMethod(method))
	{
		Console::instance->addMessage(std::string("error: illegal call of \"")+methodString+"\"");
		return false;
	}

	return true;
}

/****************************************************************************
** Scripts callMethod
**
** call a method instantly by method structure
**
** Author: Dirk Plate
****************************************************************************/
bool Scripts::callMethod(Method &method)
{
	//call every method differently
	switch (method.id)
	{
	case CAMERA_SETPOSITION:
		Camera::instance->setPosition(method.floatParameters[0],
									  method.floatParameters[1],
									  method.floatParameters[2]);
		break;

	case CAMERA_MOVEPOSITION:
		Camera::instance->movePosition(method.floatParameters[0], //startDir
									   method.floatParameters[1],
									   method.floatParameters[2],
									   method.floatParameters[3], //endPos
									   method.floatParameters[4],
									   method.floatParameters[5],
									   method.floatParameters[6], //endDir
									   method.floatParameters[7],
									   method.floatParameters[8],
									   method.floatParameters[9]);//duration
		break;
		
	case CAMERA_SETLOOKAT:
		Camera::instance->setLookAt(method.floatParameters[0],
									method.floatParameters[1],
									method.floatParameters[2]);
		break;

	case CAMERA_MOVELOOKAT:
		Camera::instance->moveLookAt(method.floatParameters[0], //startDir
									 method.floatParameters[1],
									 method.floatParameters[2],
									 method.floatParameters[3], //endPos
									 method.floatParameters[4],
									 method.floatParameters[5],
									 method.floatParameters[6], //endDir
									 method.floatParameters[7],
									 method.floatParameters[8],
									 method.floatParameters[9]);//duration
		break;

	case CAMERA_MAKESCREENSHOT:
		Camera::instance->makeScreenshot();
		break;

	case CAMERA_MAKESCREENSHOTEX:
		Camera::instance->makeScreenshotEx(method.stringParameters[0], method.floatParameters[0]);
		break;

	case CAMERA_SETFIELDOFVIEW:
		Camera::instance->setFieldOfView(method.floatParameters[0]);
		break;

	case CONSOLE_ADDMESSAGE:
		Console::instance->addMessage(method.stringParameters[0]);
		break;

	case CONSOLE_OPEN:
		Console::instance->open();
		break;

	case CONSOLE_CLOSE:
		Console::instance->close();
		break;

	case HEIGHTBASEDFOG_ENABLE:
		HeightBasedFog::instance->enable();
		break;

	case HEIGHTBASEDFOG_DISABLE:
		HeightBasedFog::instance->disable();
		break;

	case HUD_SHOW:
		Hud::instance->show();
		break;

	case HUD_HIDE:
		Hud::instance->hide();
		break;

	case SCRIPTS_LOADSCRIPT:
		this->loadScript(method.stringParameters[0]);
		break;

	case SCRIPTS_SHOWALL:
		this->showAll();
		break;

	case SCRIPTS_STOPALL:
		this->stopAll();
		break;

	case WATER_ENABLE:
		Water::instance->enable();
		break;

	case WATER_DISABLE:
		Water::instance->disable();
		break;

	case WATER_ENABLEWIREFRAME:
		Water::instance->enableWireframe();
		break;

	case WATER_DISABLEWIREFRAME:
		Water::instance->disableWireframe();
		break;

	case TERRAIN_ENABLEWIREFRAME:
		Terrain::instance->enableWireframe();
		break;

	case TERRAIN_DISABLEWIREFRAME:
		Terrain::instance->disableWireframe();
		break;

	case TIME_SETGAMETIMEFACTOR:
		Time::instance->setGameTimeFactor(method.floatParameters[0]);
		break;

	default:
		return false;
	}

	return true;
}

/****************************************************************************
** Scripts parseMethodString
**
** parse the string and fill the method structure
**
** Author: Dirk Plate
****************************************************************************/
bool Scripts::parseMethodString(std::string methodString, Method &method)
{
	int pos;

	//acquire identifier of method
	pos = methodString.find_first_of("(");
	std::string identifierString = methodString.substr(0, pos);
	methodString = methodString.substr(pos+1, methodString.size());

	//parse different things... each method have different parameter
	if (identifierString == std::string(commands[CAMERA_SETPOSITION].prefix) + "." +	
										commands[CAMERA_SETPOSITION].method)
	{
		method.id = CAMERA_SETPOSITION;
		
		//get position x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get position y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get position z parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CAMERA_MOVEPOSITION].prefix) + "." +	
										commands[CAMERA_MOVEPOSITION].method)
	{
		method.id = CAMERA_MOVEPOSITION;
		
		//get start dir x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get start dir y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get start dir z parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end pos x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end pos y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end pos z parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end dir x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end dir y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end dir z parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get duration parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CAMERA_SETLOOKAT].prefix) + "." +	
											 commands[CAMERA_SETLOOKAT].method)
	{
		method.id = CAMERA_SETLOOKAT;
		
		//get look at x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get look at y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get look at z parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CAMERA_MOVELOOKAT].prefix) + "." +	
											 commands[CAMERA_MOVELOOKAT].method)
	{
		method.id = CAMERA_MOVELOOKAT;
		
		//get start dir x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get start dir y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get start dir z parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end pos x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end pos y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end pos z parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end dir x parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end dir y parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get end dir z parameter
		if (!parseFloatParameter(&methodString, ",", method)) return false;
		//get duration parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CAMERA_MAKESCREENSHOT].prefix) + "." +	
											 commands[CAMERA_MAKESCREENSHOT].method)
	{
		method.id = CAMERA_MAKESCREENSHOT;
	}
	else if (identifierString == std::string(commands[CAMERA_MAKESCREENSHOTEX].prefix) + "." +	
											 commands[CAMERA_MAKESCREENSHOTEX].method)
	{
		method.id = CAMERA_MAKESCREENSHOTEX;
		
		//get prefix parameter
		if (!parseStringParameter(&methodString, ",", method)) return false;
		//get aspect parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CAMERA_SETFIELDOFVIEW].prefix) + "." +	
											 commands[CAMERA_SETFIELDOFVIEW].method)
	{
		method.id = CAMERA_SETFIELDOFVIEW;
		
		//get vertical angle parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CONSOLE_ADDMESSAGE].prefix) + "." +	
											 commands[CONSOLE_ADDMESSAGE].method)
	{
		method.id = CONSOLE_ADDMESSAGE;
		
		//get string parameter
		if (!parseStringParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[CONSOLE_OPEN].prefix) + "." +	
											 commands[CONSOLE_OPEN].method)
	{
		method.id = CONSOLE_OPEN;
	}
	else if (identifierString == std::string(commands[CONSOLE_CLOSE].prefix) + "." +	
											 commands[CONSOLE_CLOSE].method)
	{
		method.id = CONSOLE_CLOSE;
	}
	else if (identifierString == std::string(commands[HEIGHTBASEDFOG_ENABLE].prefix) + "." +	
											 commands[HEIGHTBASEDFOG_ENABLE].method)
	{
		method.id = HEIGHTBASEDFOG_ENABLE;
	}
	else if (identifierString == std::string(commands[HEIGHTBASEDFOG_DISABLE].prefix) + "." +	
											 commands[HEIGHTBASEDFOG_DISABLE].method)
	{
		method.id = HEIGHTBASEDFOG_DISABLE;
	}
	else if (identifierString == std::string(commands[HUD_SHOW].prefix) + "." +	
											 commands[HUD_SHOW].method)
	{
		method.id = HUD_SHOW;
	}
	else if (identifierString == std::string(commands[HUD_HIDE].prefix) + "." +	
											 commands[HUD_HIDE].method)
	{
		method.id = HUD_HIDE;
	}
	else if (identifierString == std::string(commands[SCRIPTS_LOADSCRIPT].prefix) + "." +	
											 commands[SCRIPTS_LOADSCRIPT].method)
	{
		method.id = SCRIPTS_LOADSCRIPT;
		
		//get string parameter
		if (!parseStringParameter(&methodString, ")", method)) return false;
	}
	else if (identifierString == std::string(commands[SCRIPTS_SHOWALL].prefix) + "." +	
											 commands[SCRIPTS_SHOWALL].method)
	{
		method.id = SCRIPTS_SHOWALL;
	}
	else if (identifierString == std::string(commands[SCRIPTS_STOPALL].prefix) + "." +	
											 commands[SCRIPTS_STOPALL].method)
	{
		method.id = SCRIPTS_STOPALL;
	}
	else if (identifierString == std::string(commands[WATER_ENABLE].prefix) + "." +	
											 commands[WATER_ENABLE].method)
	{
		method.id = WATER_ENABLE;
	}
	else if (identifierString == std::string(commands[WATER_DISABLE].prefix) + "." +	
											 commands[WATER_DISABLE].method)
	{
		method.id = WATER_DISABLE;
	}
	else if (identifierString == std::string(commands[WATER_ENABLEWIREFRAME].prefix) + "." +	
											 commands[WATER_ENABLEWIREFRAME].method)
	{
		method.id = WATER_ENABLEWIREFRAME;
	}
	else if (identifierString == std::string(commands[WATER_DISABLEWIREFRAME].prefix) + "." +	
											 commands[WATER_DISABLEWIREFRAME].method)
	{
		method.id = WATER_DISABLEWIREFRAME;
	}
	else if (identifierString == std::string(commands[TERRAIN_ENABLEWIREFRAME].prefix) + "." +	
											 commands[TERRAIN_ENABLEWIREFRAME].method)
	{
		method.id = TERRAIN_ENABLEWIREFRAME;
	}
	else if (identifierString == std::string(commands[TERRAIN_DISABLEWIREFRAME].prefix) + "." +	
											 commands[TERRAIN_DISABLEWIREFRAME].method)
	{
		method.id = TERRAIN_DISABLEWIREFRAME;
	}
	else if (identifierString == std::string(commands[TIME_SETGAMETIMEFACTOR].prefix) + "." +	
											 commands[TIME_SETGAMETIMEFACTOR].method)
	{
		method.id = TIME_SETGAMETIMEFACTOR;

		//get game time factor parameter
		if (!parseFloatParameter(&methodString, ")", method)) return false;
	}
	else
	{
		//nothing found
		return false;
	}

	return true;
}

/****************************************************************************
** Scripts parseFloatParameter
**
** parse a float parameter from string
**
** Author: Dirk Plate
****************************************************************************/
bool Scripts::parseFloatParameter(std::string *pMethodString, std::string limiter, Method &method)
{
	long pos = pMethodString->find_first_of(limiter);
	if (pos >= pMethodString->size())
		return false;

	std::string parameterString = pMethodString->substr(0,pos);
	float floatParameter;
	//calculate formula
	if (!EngineHelpers::floatCalculator(parameterString,floatParameter))
		return false;
	method.floatParameters.push_back(floatParameter);

	*pMethodString = pMethodString->substr(pos+1, pMethodString->size());
	
	return true;
}

/****************************************************************************
** Scripts parseStringParameter
**
** parse a string parameter from string
**
** Author: Dirk Plate
****************************************************************************/
bool Scripts::parseStringParameter(std::string *pMethodString, std::string limiter, Method &method)
{
	long pos, limiterPos = 0;

	//find first "
	pos = pMethodString->find_first_of("\"");
	if (pos < 0)
		return false;

	//search right limiter (not so easy, because limiters are allowed inside strings)
	while(1)
	{
		//find second "
		pos = pMethodString->find_first_of("\"",pos+1);
		if (pos < 0)
			return false;

		//find limiter behind second "
		limiterPos = pMethodString->find_first_of(limiter, pos+1);
		if (limiterPos < 0)
			return false;

		//find first "
		pos = pMethodString->find_first_of("\"",pos+1);

		//accept limiter, if before next first "
		if ((limiterPos < pos) || (pos < 0))
			break;
	}

	std::string parameterString = pMethodString->substr(0,limiterPos);
	std::string stringParameter;
	//calculate formula
	if (!EngineHelpers::stringCalculator(parameterString,stringParameter))
		return false;
	method.stringParameters.push_back(stringParameter);

	*pMethodString = pMethodString->substr(limiterPos+1, pMethodString->size());

	return true;
}

/****************************************************************************
** Scripts stopAll
**
** stops and delete all scripts
**
** Author: Dirk Plate
****************************************************************************/
bool Scripts::stopAll()
{
	//clear scripts list
	scripts.clear();

	return true;
}

/****************************************************************************
** Scripts showAll
**
** write out all available scripts
**
** Author: Dirk Plate
****************************************************************************/
void Scripts::showAll()
{
	//find all txt files in script path
	std::string dirPath = "./enginefiles/scripts/*.txt";

	WIN32_FIND_DATA findData; 
	HANDLE searchHandle = FindFirstFile(dirPath.c_str(), &findData);
    if (searchHandle != INVALID_HANDLE_VALUE) 
    { 
        do
        { 
			//only files... no directories
            if (!(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) 
            { 
				std::string name = findData.cFileName;
				
				//delete ".txt"
				name = name.substr(0, name.size()-4);
				
				//write out to console
				Console::instance->addMessage(name);
			}
		} 
		while(FindNextFile(searchHandle, &findData)) ;
        FindClose(searchHandle); 
	}
}
