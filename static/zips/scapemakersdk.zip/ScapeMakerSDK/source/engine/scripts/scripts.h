/****************************************************************************
** Scripts
**
** manage all aktive scripts
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(H_SCRIPTS)
#define H_SCRIPTS
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <vector>
#include <list>
#include <string>
#include "commands.h"

class Scripts
{
public:
	Scripts();
	~Scripts();

	//init
	void init();

	//update all scripts
	void update();


	//call a method instantly by a string
	bool callMethod(std::string &methodString);	
	
	//load a script from file and start it
	bool loadScript(std::string &name);

	//stops (and delete) all scripts
	bool stopAll();

private:
	//structure with all elements of a call
	struct Method
	{
		//time offset to start method
		float time;
		//identifier of method (e.g. camera.setPosition)
		CommandID id;
		//all float parameter in right order
		std::vector<float> floatParameters;	
		//all string parameter in right order
		std::vector<std::string> stringParameters;	
	};

	//structure with all elements of one script
	struct Script
	{
		//list with all methods of script
		std::vector<Method> methods;
		//current method to call
		int nextMethod;
		//current time (add some time each frame)
		float currentTime;
	};

	//parse the string an fill the method structure
	bool parseMethodString(std::string methodString, Method &method);
	
	//call a method instantly by a method structure
	bool callMethod(Method &method);	
	
	//parse a float parameter from string
	bool parseFloatParameter(std::string *pMethodString, std::string limiter, Method &method);

	//parse a string parameter from string
	bool parseStringParameter(std::string *pMethodString, std::string limiter, Method &method);

	//write out all available scripts
	void showAll();

	//all active scripts
	std::list<Script> scripts;
};

#endif