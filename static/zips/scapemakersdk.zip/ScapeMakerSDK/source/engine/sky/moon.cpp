#include "moon.h"

#include "../logger/logger.h"
#include "../common/config.h"
#include "../terrain/terrain.h"
#include "stars.h"

/****************************************************************************
** Moon Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Moon::Moon()
{
	pD3DDevice = NULL;
	pVB = NULL;
	pTexture = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	visible = false;
}

Moon::~Moon()
{
}

/****************************************************************************
** Moon createGeometry
**
** create the moon
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Moon::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, float skyRadius, D3DXVECTOR3 position, int time)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//calculate visibility
	if (time > 12) time = 24-time;
	if (time > 5) 
	{
		visible = false;
		return S_OK;
	}
	else visible = true;
	float visibility = 1.0f-float(time)/6.0f;
	visibility = sqrtf(visibility);
	
	//move middle of sphere to middle of landscape
	D3DXVECTOR3 terrainCenter(Terrain::instance->getWidth()/2,0.0f,Terrain::instance->getWidth()/2);
	position.x += terrainCenter.x;
	position.z += terrainCenter.z;

	//load sun texture
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, "./enginefiles/moon.png", D3DFMT_UNKNOWN, &pTexture)))
	{
		LOG("Loading moon texture failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Texture loaded OK");

	//calculate the transformation matrix for moon
	D3DXVECTOR3	direction = terrainCenter-position; //look to the middle of the scene
	if (fabs(direction.x) < SMALL_NUM)
		direction.x = SMALL_NUM;
	if (fabs(direction.z) < SMALL_NUM)
		direction.z = SMALL_NUM;

	float yaw = -atanf(direction.z/direction.x);
	float pitch = 0.0f;
	float roll;
	if (direction.x < 0) roll = -atanf(direction.y/sqrtf(direction.x*direction.x+direction.z*direction.z));
	else roll = atanf(direction.y/sqrtf(direction.x*direction.x+direction.z*direction.z));
	D3DXQUATERNION rotation;
	D3DXQuaternionRotationYawPitchRoll(&rotation,
				yaw,	//Yaw   (y-axis)
				pitch,	//Pitch (x-axis)
				roll);	//Roll  (z-axis)

	//create the new sun transformation matrix
	D3DXMatrixTransformation(&transformation, //destination-matrix
			NULL,				//scaling center
			NULL,				//scaling rotation
			&D3DXVECTOR3(700.0f,700.0f,700.0f),//scaling
			&D3DXVECTOR3(0,0,0),//rotation center
			&rotation,			//rotation
			&position);			//transition


	//create vertexbuffer with real vertices to render
	long vertexSize = 4*sizeof(Stars::STARSVERTEX);
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vertexSize, D3DUSAGE_WRITEONLY,
		D3DFVF_STARSVERTEX, D3DPOOL_MANAGED, &pVB, NULL)))
	{
		LOG("Creating moon vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	VOID* pVertices;
	if (FAILED(hr=pVB->Lock(0,vertexSize,(VOID**)&pVertices,0)))
	{
		LOG("Locking moon vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}
	Stars::STARSVERTEX* currentStarVertex = (Stars::STARSVERTEX*)pVertices;

	//fill vertex buffer
	//calculate color moon
	D3DXCOLOR color;
	color.r = 1.0f;
	color.g = 1.0f;
	color.b = 1.0f;

	//add common visibility
	color.a = visibility;

	D3DXVec3TransformCoord(&(currentStarVertex->position),&D3DXVECTOR3(0.0f,-1.0f,-1.0f),&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(0.0f,0.0f);
	currentStarVertex++;
	D3DXVec3TransformCoord(&(currentStarVertex->position),&D3DXVECTOR3(0.0f,1.0f,-1.0f),&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(1.0f,0.0f);
	currentStarVertex++;
	D3DXVec3TransformCoord(&(currentStarVertex->position),&D3DXVECTOR3(0.0f,-1.0f,1.0f),&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(0.0f,1.0f);
	currentStarVertex++;
	D3DXVec3TransformCoord(&(currentStarVertex->position),&D3DXVECTOR3(0.0f,1.0f,1.0f),&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(1.0f,1.0f);

	//release memory
	pVB->Unlock();

	//no world transformation need (vertices are already transformed)
	D3DXMatrixIdentity(&transformation);

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//needed for color keying
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_MODULATE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

		pD3DDevice->SetRenderState(D3DRS_ZENABLE, false);
		pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);

		pD3DDevice->SetFVF( D3DFVF_STARSVERTEX );

		pD3DDevice->SetTexture(0,pTexture);

		//move to right position
		pD3DDevice->SetTransform(D3DTS_WORLD,&transformation);

		//disable fog
		pD3DDevice->SetRenderState(D3DRS_FOGENABLE, false);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Moon destroyGeometry
**
** releases the vertex buffer
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Moon::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//delete sun mesh
	SAFE_RELEASE(pVB);

	//release sun textures
	SAFE_RELEASE(pTexture);

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);

	return S_OK;
}

/****************************************************************************
** Moon update
**
** nothing - for now
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Moon::update()
{
	return S_OK;
}

/****************************************************************************
** Moon render
**
** renders the Moon
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Moon::render()
{
	if (!visible) return S_OK;

	HRESULT hr;
	D3DXMATRIX matTemp;

	//set state block for moon
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	//draw moon
	pD3DDevice->SetStreamSource(0, pVB, NULL, sizeof(Stars::STARSVERTEX));
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering moon failed", Logger::LOG_CRIT);
		return hr;
	}

	//restore state block
	pSavedStateBlock->Apply();

	return S_OK;
}




