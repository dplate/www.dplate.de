#include "sky.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../terrain/terrain.h"
#include "../common/config.h"

Sky *Sky::instance = NULL;

/****************************************************************************
** Sky Constructor
**
** set pointers to NULL
**
** Author: Matthias Buchetics
****************************************************************************/
Sky::Sky()
{
	Module::Module();
	name = "Sky";

	pD3DDevice = NULL;
	pVB = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	instance = this;
}

Sky::~Sky()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Sky createGeometry
**
** calls the generateSkyDome method
**
** Author: Matthias Buchetics
****************************************************************************/

HRESULT Sky::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;
	this->radius = 10000.0f;

	//load all settings from text file
	MiniXML xmlFile;
	int value;
	int r, g, b;
	int time = 7;
	int sunDirection = 45;
	ambientColor = 0xb2b2b2b2;
	diffuseColor = 0xffffffff;
	dustColor = 0xFFA0A0FF;
	mainColor = 0xFF0000FF;
	dustStart = 200.0f;
	dustEnd = 200.0f;
	
	//load properties from file
	string sunPropertiesPath = Config::instance->getEnginePath()+"/sky.txt";
	if (xmlFile.openFile(sunPropertiesPath.c_str(),MiniXML::READ))
	{
		if (xmlFile.readInteger("rFrom",&value))
			r = value;
		if (xmlFile.readInteger("gFrom",&value))
			g = value;
		if (xmlFile.readInteger("bFrom",&value))
			b = value;
		dustColor = D3DXCOLOR((float)r/255.0f, (float)g/255.0f, (float)b/255.0f, 1.0f);

		if (xmlFile.readInteger("rTo",&value))
			r = value;
		if (xmlFile.readInteger("gTo",&value))
			g = value;
		if (xmlFile.readInteger("bTo",&value))
			b = value;
		mainColor = D3DXCOLOR((float)r/255.0f, (float)g/255.0f,	  (float)b/255.0f,   1.0f);

		if (xmlFile.readInteger("time",&value))
			time = value;
		if (xmlFile.readInteger("sunDirection",&value))
			sunDirection = value;

		if (xmlFile.readInteger("rAmbient",&value))
			r = value;
		if (xmlFile.readInteger("gAmbient",&value))
			g = value;
		if (xmlFile.readInteger("bAmbient",&value))
			b = value;
		ambientColor = D3DXCOLOR(((float)r)/255.0f,((float)g)/255.0f,((float)b)/255.0f,1.0f);

		if (xmlFile.readInteger("rDiffuse",&value))
			r = value;
		if (xmlFile.readInteger("gDiffuse",&value))
			g = value;
		if (xmlFile.readInteger("bDiffuse",&value))
			b = value;
		diffuseColor = D3DXCOLOR(((float)r)/255.0f,((float)g)/255.0f,((float)b)/255.0f,1.0f);
	}

	//load dust properties from file
	string fogPropertiesPath = Config::instance->getEnginePath()+"/dust.txt";
	if (xmlFile.openFile(fogPropertiesPath.c_str(),MiniXML::READ))
	{
		int	value;

		//load start of dust
		if (xmlFile.readInteger("start",&value))
			dustStart = float(value)/100.0f * Terrain::instance->getWidth();
		
		//load end of dust
		if (xmlFile.readInteger("end",&value))
			dustEnd = float(value)/100.0f * Terrain::instance->getWidth();

		xmlFile.closeFile();
	}

	//set dust/fog
    pD3DDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
 
    //set the fog color.
	pD3DDevice->SetRenderState(D3DRS_FOGCOLOR, Sky::instance->getDustColor());
    
    //set fog parameters.
    pD3DDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
    pD3DDevice->SetRenderState(D3DRS_FOGSTART, *(DWORD *)(&dustStart));
    pD3DDevice->SetRenderState(D3DRS_FOGEND,   *(DWORD *)(&dustEnd));

	//calculate position of sun
	float alpha = D3DXToRadian(sunDirection);
	float beta = D3DXToRadian(90-((time-6)*360)/24);
	D3DXVECTOR3 sunPosition(radius*sinf(beta)*cosf(alpha),
						    radius*cosf(beta),
						    radius*sinf(beta)*sinf(alpha));

	//sun is visible between 6 and 18 o'clock
	bool sunVisible = false;
	if ((time >= 6) && (time <= 18))
		sunVisible = true;

	//set intensity of sun
	float sunIntensity = 1.0f;
	if ((time == 6) || (time == 18))
		sunIntensity = 0.0f;
	if ((time == 7) || (time == 17))
		sunIntensity = 0.5f;

	//create sun
	if(FAILED(hr=sun.createGeometry(pD3DDevice, sunPosition, diffuseColor, sunVisible, sunIntensity)))
	{
		LOG("Creating sun failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Sun created OK");

	//calculate position of moon
	beta += D3DX_PI;
	D3DXVECTOR3 moonPosition(radius*sinf(beta)*cosf(alpha),
							 radius*cosf(beta),
							 radius*sinf(beta)*sinf(alpha));

	//create moon
	if(FAILED(hr=moon.createGeometry(pD3DDevice,radius, moonPosition, time)))
	{
		LOG("Creating moon failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Moon created OK");

	//create stars
	if(FAILED(hr=stars.createGeometry(pD3DDevice,radius,time,D3DXToRadian(sunDirection))))
	{
		LOG("Creating stars failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Stars created OK");

	if(FAILED(hr=generateSkyDome(5.0f, 5.0f)))
	{
		LOG("Generating Sky Dome failed", Logger::LOG_CRIT);
		return hr;
	}
	LOG("Sky dome created OK");

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Sky generateSkyDome
**
** generates the skydome with the given parameters
**
** Author: Matthias Buchetics
****************************************************************************/

HRESULT Sky::generateSkyDome(float dtheta, float dphi)
{
	int theta, phi;
	HRESULT hr;

	//get fog properties
	nrVertices = (int)((360/dtheta)*(90/dphi+1)*4);

	// allocate memory for the vertex data
	SKYVERTEX *pVertexData = new SKYVERTEX[nrVertices];
	VOID* pVertices;

	D3DXCOLOR color = mainColor;
	D3DXCOLOR oldColor = color;

	int stepCnt = (90/int(dphi) - 1);

	//calculate height of dust
	int stepDustEnd = atan2(Terrain::instance->getHighestHeight(),dustEnd);
	stepDustEnd++;
	int stepDustBegin = stepDustEnd+stepDustEnd*stepDustEnd+3;
	if (stepDustBegin > stepCnt)
		stepDustBegin = stepCnt;
	if (stepDustEnd >= stepDustBegin)
		stepDustEnd = stepDustBegin-1;
	float dustFactor = stepDustBegin-stepDustEnd;
	float rStep	= float(dustColor.r - mainColor.r)/dustFactor;
	float gStep = float(dustColor.g - mainColor.g)/dustFactor;
	float bStep	= float(dustColor.b - mainColor.b)/dustFactor;

	// Generate the dome
	int n = 0;

	for (phi=0; phi <= 90; phi += (int)dphi)
	{
		for (theta=0; theta <= 360 - dtheta; theta += (int)dtheta)
		{
			// Calculate the vertex at phi, theta
			pVertexData[n].position.x = radius * sinf(D3DXToRadian(phi)) * cosf(D3DXToRadian(theta));
			pVertexData[n].position.z = radius * sinf(D3DXToRadian(phi)) * sinf(D3DXToRadian(theta));
			pVertexData[n].position.y = radius * cosf(D3DXToRadian(phi));
			pVertexData[n].position.z = (-1) * pVertexData[n].position.z;

			pVertexData[n].color = oldColor;
			if (stepCnt+1 > stepDustEnd)
				addCorona(pVertexData+n, &oldColor);

			n++;

			// Calculate the vertex at phi+dphi, theta
			pVertexData[n].position.x = radius * sinf(D3DXToRadian(phi+dphi)) * cosf(D3DXToRadian(theta));
			pVertexData[n].position.z = radius * sinf(D3DXToRadian(phi+dphi)) * sinf(D3DXToRadian(theta));
			pVertexData[n].position.y = radius * cosf(D3DXToRadian(phi+dphi));
			pVertexData[n].position.z = (-1) * pVertexData[n].position.z;

			pVertexData[n].color = color;
			if (stepCnt > stepDustEnd)
				addCorona(pVertexData+n, &color);
	
			//close bottom of cube
			if (phi == 90)
			{
				pVertexData[n].position.x = 0.0f;
				pVertexData[n].position.z = 0.0f;
			}

			n++;

			// Calculate the vertex at phi, theta+dtheta
			pVertexData[n].position.x = radius * sinf(D3DXToRadian(phi)) * cosf(D3DXToRadian(theta+dtheta));
			pVertexData[n].position.z = radius * sinf(D3DXToRadian(phi)) * sinf(D3DXToRadian(theta+dtheta));
			pVertexData[n].position.y = radius * cosf(D3DXToRadian(phi));
			pVertexData[n].position.z = (-1) * pVertexData[n].position.z;

			pVertexData[n].color = oldColor;
			if (stepCnt+1 > stepDustEnd)
				addCorona(pVertexData+n, &oldColor);
	
			n++;

			// Calculate the vertex at phi+dphi, theta+dtheta
			pVertexData[n].position.x = radius * sinf(D3DXToRadian(phi+dphi)) * cosf(D3DXToRadian(theta+dtheta));
			pVertexData[n].position.z = radius * sinf(D3DXToRadian(phi+dphi)) * sinf(D3DXToRadian(theta+dtheta));
			pVertexData[n].position.y = radius * cosf(D3DXToRadian(phi+dphi));
			pVertexData[n].position.z = (-1) * pVertexData[n].position.z;

			pVertexData[n].color = color;
			if (stepCnt > stepDustEnd)
				addCorona(pVertexData+n, &color);

			//close bottom of cube
			if (phi == 90)
			{
				pVertexData[n].position.x = 0.0f;
				pVertexData[n].position.z = 0.0f;
			}
			n++;
		}

		oldColor = color;

		if(stepCnt <= stepDustBegin && stepCnt > stepDustEnd)
		{
			color.r += rStep;
			color.g += gStep;
			color.b += bStep;
		}

		stepCnt--;
	}

	// create the vertex buffer with the vertex data
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer( nrVertices*sizeof(SKYVERTEX),
                                                  D3DUSAGE_WRITEONLY, D3DFVF_SKYVERTEX,
                                                  D3DPOOL_MANAGED, &pVB, NULL)))
	{
		LOG("Creating vertex buffer failed", Logger::LOG_CRIT);
        return hr;
	}

    if(FAILED(hr=pVB->Lock( 0, sizeof(*pVertexData) * nrVertices, (VOID**)&pVertices, 0)))
    {
		LOG("Locking vertex buffer failed", Logger::LOG_CRIT);
        return hr;
	}

    memcpy( pVertices, pVertexData, sizeof(*pVertexData) * nrVertices );
	pVB->Unlock();

	// delete the array, we don't need them anymore
	delete []pVertexData;


	//move sky dome to right position
	D3DXMATRIX translateMatrix, scaleMatrix, matTemp;
	float terrainWidth = Terrain::instance->getWidth();
	D3DXMatrixTranslation(&translateMatrix, terrainWidth/2.0f, 0.0f , terrainWidth/2.0f);
	D3DXMatrixScaling(&scaleMatrix, 1.0f, 1.0f, 1.0f);
	D3DXMatrixMultiply(&skyDomeTransformation, &scaleMatrix, &translateMatrix);

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}
		
		pD3DDevice->SetFVF(D3DFVF_SKYVERTEX);

		//set texture properties
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE );
				
		// wire frame mode activated
		//pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );

	    pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW );
		pD3DDevice->SetTransform(D3DTS_WORLD, &skyDomeTransformation);

		//disable fog
		pD3DDevice->SetRenderState(D3DRS_FOGENABLE, false);

		
		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Sky addCorona
**
** add corona light to a sky vertex
**
** Author: Dirk Plate
****************************************************************************/
void Sky::addCorona(SKYVERTEX *pVertexData, D3DXCOLOR *pOldColor)
{
	D3DXVECTOR3 sunPosition = sun.getPosition();
	if (sunPosition.y < 0) return;

	//calculate distance to sun
	float sundist = D3DXVec3Length(&(pVertexData->position-sunPosition))/radius;

	//calculate corona size (fewer corona at horizon)
	float coronaSize = sunPosition.y/radius;
	coronaSize = coronaSize * 0.5f+SMALL_NUM;

	float corona = expf( (-sundist) / coronaSize);
	if(corona<0.0f) corona=0.0f;
	if(corona>1.0f) corona=1.0f;
	D3DXCOLOR def_color;
	def_color.r = (1.0f-corona) * pOldColor->r + corona * diffuseColor.r;
	def_color.g = (1.0f-corona) * pOldColor->g + corona * diffuseColor.g;
	def_color.b = (1.0f-corona) * pOldColor->b + corona * diffuseColor.b;

	pVertexData->color=def_color;
}

/****************************************************************************
** Sky destoryGeometry
**
** releases the vertex buffer
**
** Author: Matthias Buchetics
****************************************************************************/

HRESULT Sky::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	HRESULT hr;

	//destroy sun
	if (FAILED(hr=sun.destroyGeometry()))
		return hr;

	//destroy moon
	if (FAILED(hr=moon.destroyGeometry()))
		return hr;

	//destroy stars
	if (FAILED(hr=stars.destroyGeometry()))
		return hr;

	if(pVB)
	{
		pVB->Release();
		pVB = NULL;
	}

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);

	return Module::destroyGeometry();
}

/****************************************************************************
** Sky update
**
** update all sky elements
**
** Author: Matthias Buchetics
****************************************************************************/

HRESULT Sky::update()
{
	HRESULT hr;

	if (FAILED(hr=sun.update()))
		return hr;

	if (FAILED(hr=moon.update()))
		return hr;

	if (FAILED(hr=stars.update()))
		return hr;

	return Module::update();
}

/****************************************************************************
** Sky render
**
** renders the skydome with the vertex colors
**
** Author: Matthias Buchetics
****************************************************************************/

HRESULT Sky::render(ModuleRenderType renderType)
{
	HRESULT hr;

	//no sky while depth rendering
	if (renderType != DEPTH)
	{	
		if (FAILED(hr=renderScene(NULL,NULL)))
			return hr;
	}

	return Module::render(renderType);
}

/****************************************************************************
** Sky renderToEnviromentMap
**
** render the sky to a cube map
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Sky::renderToEnviromentMap(ID3DXRenderToEnvMap* pRenderToEnvMap)
{
	HRESULT hr;

	float terrainWidth = Terrain::instance->getWidth();

	//set the projection matrix for a field of view of 90 degrees
    D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI * 0.5f, 1.0f, 0.5f, 100000.0f );

    for( UINT i = 0; i < 6; i++ )
    {
        pRenderToEnvMap->Face((D3DCUBEMAP_FACES)i, NULL);

		// Set the view transform for this cubemap surface
        D3DXMATRIX matView;
        matView = EngineHelpers::getCubeMapViewMatrix((D3DCUBEMAP_FACES)i,
			D3DXVECTOR3(terrainWidth/2,0.0f,terrainWidth/2));

        //render the sky
		if (FAILED(hr=renderScene(&matView,&matProj)))
			return hr;
	}

    return S_OK;
}

/****************************************************************************
** Sky renderScene
**
** render the sky
**
** Author: Matthias Buchetics / Dirk Plate
****************************************************************************/

HRESULT Sky::renderScene(const D3DXMATRIX *pView, const D3DXMATRIX *pProject)
{
	HRESULT hr;
	D3DXMATRIX oldMatProj,oldMatView, matTemp, matView, matProj, matWorld;

	//save old matrixes
	if (pView != NULL)
	{
		pD3DDevice->GetTransform(D3DTS_VIEW,&oldMatView);
		pD3DDevice->SetTransform( D3DTS_VIEW, pView );
	}
	if (pProject != NULL)
	{
		pD3DDevice->GetTransform(D3DTS_PROJECTION,&oldMatProj);
		pD3DDevice->SetTransform( D3DTS_PROJECTION, pProject );
	}

	//set state block for sky dome
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	// how many triangles do we have to render
	int nrTriangles = nrVertices-2;

	// render the skydome
	pD3DDevice->SetStreamSource( 0, pVB, NULL, sizeof(SKYVERTEX) );
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, nrTriangles)))
	{
		LOG("Rendering sky dome failed", Logger::LOG_CRIT);
		return hr;
	}

	//restore state block
	pSavedStateBlock->Apply();

	//render stars
	if (FAILED(hr=stars.render()))
		return hr;

	//render sun
	if (FAILED(hr=sun.render()))
		return hr;

	//render moon
	if (FAILED(hr=moon.render()))
		return hr;

	if (pView != NULL)
		pD3DDevice->SetTransform( D3DTS_VIEW, &oldMatView);
	if (pProject != NULL)
		pD3DDevice->SetTransform( D3DTS_PROJECTION, &oldMatProj);

	return S_OK;
}

/****************************************************************************
** Sky getColorFrom
**
** return the dust (horizon) color of sky
**
** Author: Dirk Plate
****************************************************************************/

D3DXCOLOR Sky::getDustColor()
{
	return dustColor;
}

/****************************************************************************
** Sky getColorTo
**
** return the main color of sky
**
** Author: Dirk Plate
****************************************************************************/

D3DXCOLOR Sky::getMainColor()
{
	return mainColor;
}

/****************************************************************************
** Sky getAmbientColor
**
** return the ambient color of scene
**
** Author: Dirk Plate
****************************************************************************/

D3DXCOLOR Sky::getAmbientColor()
{
	return ambientColor;
}

/****************************************************************************
** Sky getDiffuseColor
**
** return the diffuse color of scene
**
** Author: Dirk Plate
****************************************************************************/

D3DXCOLOR Sky::getDiffuseColor()
{
	return diffuseColor;
}

/****************************************************************************
** Sky getRadius
**
** return the radius of sky dome
**
** Author: Dirk Plate
****************************************************************************/

float Sky::getRadius()
{
	return radius;
}
