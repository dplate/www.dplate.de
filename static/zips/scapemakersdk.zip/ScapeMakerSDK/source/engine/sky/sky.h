/****************************************************************************
** Sky
**
** skydome rendering and management class
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(SKY_H)
#define SKY_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "../common/dxutil.h"
#include <Dxerr9.h>
#include "../common/enginehelpers.h"
#include "../../common/minixml.h"
#include "sun.h"
#include "stars.h"
#include "moon.h"
#include "../module.h"

struct SKYVERTEX
{
     D3DXVECTOR3 position;
	 D3DCOLOR	 color;
};

#define D3DFVF_SKYVERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE)

class Sky : public Module
{
public:
	Sky();
	~Sky();

	HRESULT update();
	HRESULT render(ModuleRenderType renderType);
	HRESULT renderToEnviromentMap(ID3DXRenderToEnvMap* pRenderToEnvMap);
	HRESULT renderScene(const D3DXMATRIX *pView, const D3DXMATRIX *pProject);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT generateSkyDome(float dtheta, float dphi);
	HRESULT	destroyGeometry();

	Sun *getSun() {return &sun;}

	D3DXCOLOR getDustColor();
	D3DXCOLOR getMainColor();
	D3DXCOLOR getAmbientColor();
	D3DXCOLOR getDiffuseColor();
	float	  getDustStart() {return dustStart;}
	float	  getDustEnd() {return dustEnd;}

	float	getRadius();

	static Sky *instance;				//the instance to the only one sky object
	int		polyRendered;
	int		nrVertices;

private:	
	void addCorona(SKYVERTEX *pVertexData, D3DXCOLOR *pOldColor);

	LPDIRECT3DVERTEXBUFFER9 pVB;			//vertex buffer
	LPDIRECT3DDEVICE9		pD3DDevice;
	float					radius;			//the radius of sky

	D3DXCOLOR				dustColor;		//the first color of sky
	D3DXCOLOR				mainColor;		//the second color of sky
	D3DXMATRIX				skyDomeTransformation; //transformation of dome

	D3DXCOLOR				ambientColor;	//the ambient color of the landscape
	D3DXCOLOR				diffuseColor;	//the diffuse color of the landscape
	
	float					dustStart;		//start distance of fog
	float					dustEnd;		//end distance of fog

	LPDIRECT3DSTATEBLOCK9	pStateBlock;		//used state block for rendering sky dome
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;	//saved old state block for rendering sky dome

	//the sun
	Sun						sun;

	//the stars
	Stars					stars;

	//the moon
	Moon					moon;
};

#endif