#include "stars.h"

#include "../logger/logger.h"
#include "../common/config.h"
#include "../terrain/terrain.h"
#include "../common/submeshes.h"
#include "../common/time.h"

/****************************************************************************
** Stars Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Stars::Stars()
{
	pD3DDevice = NULL;

	pTexture = NULL;
	pHLTexture = NULL;
	visible = false;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;
}

Stars::~Stars()
{
}

/****************************************************************************
** Stars createGeometry
**
** create the stars
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Stars::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, float skyRadius, int time, float direction)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;

	//calculate visibility
	if (time > 12) time = 24-time;
	if (time > 6) 
	{
		visible = false;
		return S_OK;
	}
	else visible = true;
	float visibility = 1.0f-float(time)/7.0f;
	visibility = sqrtf(visibility);

	//load star texture
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, "./enginefiles/star.png", D3DFMT_UNKNOWN, &pTexture)))
	{
		LOG("Loading star texture failed", Logger::LOG_CRIT);
		return hr;
	}

	//load highlight star texture
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, "./enginefiles/star_highlight.png", D3DFMT_UNKNOWN, &pHLTexture)))
	{
		LOG("Loading star texture failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Textures loaded OK");


	//load properties from file
	std::list<float> ra;		//rotation angle
	std::list<float> dec;		//declination
	std::list<float> mag;		//magnification
	MiniXML xmlFile;
	long index = 1;
	verticesCountAll = 0;
	indicesCountAll = 0;
	if (xmlFile.openFile("./enginefiles/stars.txt",MiniXML::READ))
	{
		if (xmlFile.startReadList("stars"))
		{
			while(xmlFile.startReadListElement(index))
			{
				float ra2, dec2, mag2;
				if (xmlFile.readFloat("ra",&ra2) && 
					xmlFile.readFloat("dec",&dec2) &&
					xmlFile.readFloat("mag",&mag2))
				{
					//show different stars at different direction
					ra2 += direction;

					//do not use stars below horizon
					if (dec2 > 0.0f)
					{
						ra.push_back(ra2);
						dec.push_back(dec2);
						mag.push_back(mag2);

						//count vertices and indices
						verticesCountAll += 4;
						indicesCountAll += 6;
					}
				}
				xmlFile.endReadListElement();
				index++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	//calculate count of buffers
	int bufferCount = (indicesCountAll/STARS_MAXPERINDEXBUFFER) + 1;

	std::list<float>::iterator currentRa = ra.begin();
	std::list<float>::iterator currentDec = dec.begin();
	std::list<float>::iterator currentMag = mag.begin();

	for (int i=0; i<bufferCount; i++)
	{
		//add vertices data to lists
		std::list<long>::iterator currentVCount = verticesCountList.insert(verticesCountList.end());
		if (i<bufferCount-1)
			*currentVCount = (STARS_MAXPERINDEXBUFFER/6*4);
		else *currentVCount = (indicesCountAll%STARS_MAXPERINDEXBUFFER)/6*4;
		std::list<LPDIRECT3DVERTEXBUFFER9>::iterator currentVB = vBList.insert(vBList.end());
		*currentVB = NULL;
		
		//create vertex buffers
		long vBSize = (*currentVCount)*sizeof(STARSVERTEX);
		if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vBSize, D3DUSAGE_WRITEONLY,
			D3DFVF_STARSVERTEX, D3DPOOL_MANAGED, &(*currentVB), NULL)))
		{
			LOG("Creating stars vertex buffer failed", Logger::LOG_CRIT);
			return hr;
		}

		//lock vertex buffer
		VOID* pVertices;
		if (FAILED(hr=(*currentVB)->Lock(0,vBSize,(VOID**)&pVertices,0)))
		{
			LOG("Locking stars vertex buffer failed", Logger::LOG_CRIT);
			return hr;
		}
		STARSVERTEX* currentStarVertex = (STARSVERTEX*)pVertices;

		//fill vertex buffer
		for (long currentStarForVertices = 0; currentStarForVertices < (*currentVCount)/4; currentStarForVertices++)
		{
			STARSVERTEX edgeVertex;
		
			//calculate color star
			D3DXCOLOR color;
			color.r = 1.0f;
			color.g = 1.0f;
			color.b = 0.7f;

			//more transparency near at horizon
			color.a = (*currentDec)/(D3DX_PI/6.0f);
			if (color.a > 1.0f) color.a = 1.0f;

			//smaller stars are more transparent
			float addAlpha = ((*currentMag)*(*currentMag))/49.0f;
			if (addAlpha > 1.0f) addAlpha = 1.0f;
			color.a *= addAlpha;

			//add common visibility
			color.a *= visibility;

			//edge1
			float edgeDec = (*currentDec)-STARS_HALFANGLEFORMAGONE*(*currentMag);
			float edgeRa = (*currentRa)-(STARS_HALFANGLEFORMAGONE*(*currentMag))/cosf(*currentDec);
			edgeVertex.position.x = -cosf(edgeDec)*sinf(edgeRa)*skyRadius;
			edgeVertex.position.y = sinf(edgeDec)*skyRadius;
			edgeVertex.position.z = cosf(edgeDec)*cosf(edgeRa)*skyRadius;
			edgeVertex.diffuse = color;
			edgeVertex.texture1.x = 0.0f;
			edgeVertex.texture1.y = 0.0f;
			*currentStarVertex = edgeVertex;
			currentStarVertex++;
		
			//edge2
			edgeDec = (*currentDec)+STARS_HALFANGLEFORMAGONE*(*currentMag);
			edgeRa = (*currentRa)-(STARS_HALFANGLEFORMAGONE*(*currentMag))/cosf(*currentDec);
			edgeVertex.position.x = -cosf(edgeDec)*sinf(edgeRa)*skyRadius;
			edgeVertex.position.y = sinf(edgeDec)*skyRadius;
			edgeVertex.position.z = cosf(edgeDec)*cosf(edgeRa)*skyRadius;
			edgeVertex.diffuse = color;
			edgeVertex.texture1.x = 0.0f;
			edgeVertex.texture1.y = 1.0f;
			*currentStarVertex = edgeVertex;
			currentStarVertex++;

			//edge3
			edgeDec = (*currentDec)-STARS_HALFANGLEFORMAGONE*(*currentMag);
			edgeRa = (*currentRa)+(STARS_HALFANGLEFORMAGONE*(*currentMag))/cosf(*currentDec);
			edgeVertex.position.x = -cosf(edgeDec)*sinf(edgeRa)*skyRadius;
			edgeVertex.position.y = sinf(edgeDec)*skyRadius;
			edgeVertex.position.z = cosf(edgeDec)*cosf(edgeRa)*skyRadius;
			edgeVertex.diffuse = color;
			edgeVertex.texture1.x = 1.0f;
			edgeVertex.texture1.y = 0.0f;
			*currentStarVertex = edgeVertex;
			currentStarVertex++;

			//edge4
			edgeDec = (*currentDec)+STARS_HALFANGLEFORMAGONE*(*currentMag);
			edgeRa = (*currentRa)+(STARS_HALFANGLEFORMAGONE*(*currentMag))/cosf(*currentDec);
			edgeVertex.position.x = -cosf(edgeDec)*sinf(edgeRa)*skyRadius;
			edgeVertex.position.y = sinf(edgeDec)*skyRadius;
			edgeVertex.position.z = cosf(edgeDec)*cosf(edgeRa)*skyRadius;
			edgeVertex.diffuse = color;
			edgeVertex.texture1.x = 1.0f;
			edgeVertex.texture1.y = 1.0f;
			*currentStarVertex = edgeVertex;
			currentStarVertex++;

			//go to next star
			currentRa++; currentDec++; currentMag++;
		}

		//release memory
		(*currentVB)->Unlock();


		//add indices data to lists
		std::list<long>::iterator currentICount = indicesCountList.insert(indicesCountList.end());
		if (i<bufferCount-1)
			*currentICount = STARS_MAXPERINDEXBUFFER;
		else *currentICount = (indicesCountAll%STARS_MAXPERINDEXBUFFER);
		std::list<LPDIRECT3DINDEXBUFFER9>::iterator currentIB = iBList.insert(iBList.end());
		*currentIB = NULL;

		// create the index buffers
		long iBSize = *currentICount*sizeof(WORD);
		if (FAILED(hr=pD3DDevice->CreateIndexBuffer(iBSize,D3DUSAGE_WRITEONLY, 
													D3DFMT_INDEX16,D3DPOOL_MANAGED, 
			&(*currentIB), NULL)))
		{
			LOG("Creating index buffer failed", Logger::LOG_CRIT);
			return hr;
		}
		
		//lock index buffer
		VOID* pIndices;
		if (FAILED(hr=(*currentIB)->Lock( 0, iBSize, (VOID**)&pIndices, 0)))
		{
			LOG("Locking index buffer failed", Logger::LOG_CRIT);
			return hr;
		}
		
		//fill index buffer
		WORD* currentWORDIndex = (WORD*)pIndices;
		long maxStars = (*currentICount)/6;
		for (long currentStarForIndices = 0; 
			 currentStarForIndices < maxStars; 
			 currentStarForIndices++)
		{	
			(*currentWORDIndex) = currentStarForIndices*4+0;
			currentWORDIndex++;
			(*currentWORDIndex) = currentStarForIndices*4+1;
			currentWORDIndex++;
			(*currentWORDIndex) = currentStarForIndices*4+2;
			currentWORDIndex++;
			(*currentWORDIndex) = currentStarForIndices*4+2;
			currentWORDIndex++;
			(*currentWORDIndex) = currentStarForIndices*4+1;
			currentWORDIndex++;
			(*currentWORDIndex) = currentStarForIndices*4+3;
			currentWORDIndex++;
		}

		//release memory
		(*currentIB)->Unlock();
	}

	LOG("Vertex- and index buffers created OK");
	
 	//transform is moving, so middle of sphere is middle of landscape
	D3DXVECTOR3 terrainCenter(Terrain::instance->getWidth()/2.0f, 0.0f, Terrain::instance->getWidth()/2.0f);
	D3DXMatrixTranslation(&transformation,terrainCenter.x,terrainCenter.y,terrainCenter.z);

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//needed for color keying
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);

		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TFACTOR);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_TEXTURE);
		
		pD3DDevice->SetTextureStageState( 1, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );

		pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAOP, D3DTOP_MODULATE );
		pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG1,D3DTA_CURRENT );
		pD3DDevice->SetTextureStageState( 1, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

		pD3DDevice->SetRenderState(D3DRS_ZENABLE, false);
		pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);

		pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR,D3DCOLOR_COLORVALUE(0.0f,0.0f,0.0f,1.0f));
		pD3DDevice->SetFVF( D3DFVF_STARSVERTEX );

		pD3DDevice->SetTexture(0,pTexture);

		//move to right position
		pD3DDevice->SetTransform(D3DTS_WORLD,&transformation);

		//disable fog
		pD3DDevice->SetRenderState(D3DRS_FOGENABLE, false);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Stars destroyGeometry
**
** releases the vertex buffer
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Stars::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//release star texture
	SAFE_RELEASE(pTexture);
	SAFE_RELEASE(pHLTexture);

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);
	
	//go through list with all buffers
	std::list<LPDIRECT3DVERTEXBUFFER9>::iterator currentVB = vBList.begin();
	std::list<LPDIRECT3DINDEXBUFFER9>::iterator currentIB = iBList.begin();
	while (currentIB != iBList.end())
	{
		//release vertex buffer
		SAFE_RELEASE(*currentVB);

		//release index buffer
		SAFE_RELEASE(*currentIB);

		currentVB++;
		currentIB++;
	}
	vBList.clear();
	iBList.clear();
	verticesCountList.clear();
	indicesCountList.clear();

	//delete list with highlighted star
	highLightedList.clear();
	
	return S_OK;
}

/****************************************************************************
** Stars update
**
** check visibilities of segments
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Stars::update()
{
	if (!visible) return S_OK;

	//get game time difference since last frame
	float time = Time::instance->getGameFrameTime();

	//go through list with all highlighted star
	std::list<HighLightedStar>::iterator currentStar = highLightedList.begin();
	while (currentStar != highLightedList.end())
	{
		//change state of star
		currentStar->state += currentStar->speed*time;

		//if state reached end... delete star from list
		if (currentStar->state > D3DX_PI)
		{
			std::list<HighLightedStar>::iterator trashStar = currentStar;	
			currentStar++;
			highLightedList.erase(trashStar);
		}
		else currentStar++;
	}

	//add highlighted stars
	if (highLightedList.size() < STARS_HIGHLIGHTEDCOUNT)
	{
		HighLightedStar newStar;

		//choose a random star
		newStar.index = (rand()%(indicesCountAll/6))*6;
		//set to start value
		newStar.state = -D3DX_PI;
		//set a random changing speed
		newStar.speed = 3.0f+float(rand())/RAND_MAX*1.0f;

		//get the right index- and vertex-buffer for this index
		int indexBufferNr = newStar.index/STARS_MAXPERINDEXBUFFER;
		std::list<LPDIRECT3DVERTEXBUFFER9>::iterator currentVB = vBList.begin();
		std::list<LPDIRECT3DINDEXBUFFER9>::iterator currentIB = iBList.begin();
		std::list<long>::iterator currentVCount = verticesCountList.begin();
		for (int i=0;i<indexBufferNr;i++)
		{
			currentVB++;
			currentIB++;
			currentVCount++;
		}
		newStar.pVB = *currentVB;
		newStar.pIB = *currentIB;
		newStar.vBCount = *currentVCount;

		//correct index
		newStar.index -= STARS_MAXPERINDEXBUFFER*indexBufferNr;

		//add to end of list
		highLightedList.push_back(newStar);
	}

	return S_OK;
}

/****************************************************************************
** Stars render
**
** renders the stars
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Stars::render()
{
	if (!visible) return S_OK;

	HRESULT hr;
	D3DXMATRIX matTemp;

	//set state block for stars
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	//Draw all stars
	//go through list with all buffers
	std::list<LPDIRECT3DVERTEXBUFFER9>::iterator currentVB = vBList.begin();
	std::list<LPDIRECT3DINDEXBUFFER9>::iterator currentIB = iBList.begin();
	std::list<long>::iterator currentVCount = verticesCountList.begin();
	std::list<long>::iterator currentICount = indicesCountList.begin();
	while (currentIB != iBList.end())
	{
		pD3DDevice->SetStreamSource(0, *currentVB, NULL, sizeof(STARSVERTEX));
		pD3DDevice->SetIndices(*currentIB);

		if (FAILED(hr=pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 
			(*currentVCount), 0, (*currentICount)/3)))
		{
			LOG("Rendering stars failed", Logger::LOG_CRIT);
			return hr;
		}

		currentVB++;
		currentIB++;
		currentVCount++;
		currentICount++;
	}

	//render highlighted star
	pD3DDevice->SetTexture(0,pHLTexture);
	std::list<HighLightedStar>::iterator currentStar = highLightedList.begin();
	while (currentStar != highLightedList.end())
	{
		float currentHighlight = (cosf(currentStar->state)+1.0f)/2.0f;
		pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR,D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,currentHighlight));

		pD3DDevice->SetStreamSource(0, currentStar->pVB, NULL, sizeof(STARSVERTEX));
		pD3DDevice->SetIndices(currentStar->pIB);

		if (FAILED(hr=pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 
			currentStar->vBCount, currentStar->index, 2)))
		{
			LOG("Rendering highlighted star failed", Logger::LOG_CRIT);
			return hr;
		}
		
		currentStar++;
	}
	
	//restore state block
	pSavedStateBlock->Apply();

	return S_OK;
}


