/****************************************************************************
** Sun
**
** sun rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(STARS_H)
#define STARS_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "../common/dxutil.h"
#include <Dxerr9.h>
#include "../common/enginehelpers.h"
#include "../../common/minixml.h"
#include "../common/aabb.h"
#include <list>

#define D3DFVF_STARSVERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1)
#define STARS_HALFANGLEFORMAGONE 0.0005f	//size of stars
#define STARS_HIGHLIGHTEDCOUNT 40			//count of highlighted stars
#define STARS_MAXPERINDEXBUFFER 16002		//max indices in one index buffer (must be dividable to 6!)

struct HighLightedStar
{
	LPDIRECT3DVERTEXBUFFER9 pVB;//vertex buffer of star
	LPDIRECT3DINDEXBUFFER9 pIB;	//index buffer of star
	int vBCount;	//count of vertex buffer for star
	long index;		//indexbufferindex for star
	float state;	//state of highlightning (-pi - +pi)
	float speed;	//changing speed
};

class Stars
{
public:
	Stars();
	~Stars();

	HRESULT update();
	HRESULT render();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, float skyRadius, int time, float direction);
	HRESULT	destroyGeometry();

	struct STARSVERTEX
	{
		D3DXVECTOR3 position;
		D3DCOLOR	diffuse;
		D3DXVECTOR2 texture1;
	};

private:
	LPDIRECT3DDEVICE9		pD3DDevice;
	bool					visible;
	LPDIRECT3DTEXTURE9		pTexture;		//the texture of one star

	LPDIRECT3DSTATEBLOCK9	pStateBlock;	 //used state block for rendering stars
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;//saved old state block for rendering stars

	std::list<LPDIRECT3DVERTEXBUFFER9> vBList;	//the vertex buffers with all stars 
	std::list<LPDIRECT3DINDEXBUFFER9> iBList;	//the index buffers for the vertex buffer
	long verticesCountAll;						//number of all vertices
	long indicesCountAll;						//number of all indices 
	std::list<long> verticesCountList;			//number of vertices of one vertex buffer
	std::list<long> indicesCountList;			//number of indices of one index buffer

	D3DXMATRIX				transformation; //the transformation of all stars

	//list with all highlighted stars
	std::list<HighLightedStar> highLightedList;

	LPDIRECT3DTEXTURE9		pHLTexture;		//the texture of a highlighted star
};

#endif