#include "sun.h"

#include "../logger/logger.h"
#include "../common/config.h"
#include "../terrain/terrain.h"
#include "stars.h"

/****************************************************************************
** Sun Constructor
**
** set pointers to NULL
**
** Author: Dirk Plate
****************************************************************************/
Sun::Sun()
{
	pD3DDevice = NULL;
	pVertices = NULL;
	pVB = NULL;
	pTexture = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	position = D3DXVECTOR3(0.0f,-10000.0f,0.0f);
	visible = false;
}

Sun::~Sun()
{
}

/****************************************************************************
** Sun createGeometry
**
** create the sun
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Sun::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, D3DXVECTOR3 position, D3DXCOLOR color, bool visible, float intensity)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;

	this->pD3DDevice = pD3DDevice;
	this->visible = visible;
	this->intensity = intensity;

	//load sun texture
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, "./enginefiles/sun.png", D3DFMT_UNKNOWN, &pTexture)))
	{
		LOG("Loading sun texture failed", Logger::LOG_CRIT);
		return hr;
	}

	LOG("Texture loaded OK");

	//move middle of sphere to middle of landscape
	D3DXVECTOR3 terrainCenter(Terrain::instance->getWidth()/2,0.0f,Terrain::instance->getWidth()/2);
	position.x += terrainCenter.x;
	position.z += terrainCenter.z;
	this->position = position;

	//load the vertices mesh
	LPD3DXMESH verticesMesh;
	unsigned long verticesMaterialCount;
	LPD3DXBUFFER pTempMtrlBuffer;
	if(FAILED(hr = D3DXLoadMeshFromX("./enginefiles/sunvertices.x", D3DXMESH_SYSTEMMEM,
                                pD3DDevice, NULL,
                                &pTempMtrlBuffer, NULL, &verticesMaterialCount,
                                &verticesMesh)))
    {
        LOG("Loading vertices mesh from x-file failed", Logger::LOG_CRIT);
		return hr;
    }

	//calculate the transformation matrix for sun
	//calculate the look-direction of the sun
	D3DXVECTOR3	direction = terrainCenter-position; //look to the middle of the scene
	if (fabs(direction.x) < SMALL_NUM)
		direction.x = SMALL_NUM;
	if (fabs(direction.z) < SMALL_NUM)
		direction.z = SMALL_NUM;

	float yaw = -atanf(direction.z/direction.x);
	float pitch = 0.0f;
	float roll;
	if (direction.x < 0) roll = -atanf(direction.y/sqrtf(direction.x*direction.x+direction.z*direction.z));
	else roll = atanf(direction.y/sqrtf(direction.x*direction.x+direction.z*direction.z));
	D3DXQUATERNION rotation;
	D3DXQuaternionRotationYawPitchRoll(&rotation,
				yaw,	//Yaw   (y-axis)
				pitch,	//Pitch (x-axis)
				roll);	//Roll  (z-axis)

	//create the new sun transformation matrix
	D3DXMatrixTransformation(&transformation, //destination-matrix
			NULL,				//scaling center
			NULL,				//scaling rotation
			&D3DXVECTOR3(80.0f,80.0f,80.0f),//scaling
			&D3DXVECTOR3(0,0,0),//rotation center
			&rotation,			//rotation
			&position);			//transition

	//calculate vertices of sun mesh to right position
	MeshTool *mesh = NULL;
	mesh = new MeshTool(verticesMesh);
	
	//create array for all vertices
	verticesCount = mesh->dwNumVertices;
	pVertices = new D3DXVECTOR3[verticesCount];
	D3DXVECTOR3 minVertex(0.0f,0.0f,0.0f);
	D3DXVECTOR3 maxVertex(0.0f,0.0f,0.0f);
	for(int j=0; j<verticesCount; j++)
	{
		//get min and max vertex for sun quad
		if (mesh->pVertices[j].p.y < minVertex.y)
			minVertex.y = mesh->pVertices[j].p.y;
		if (mesh->pVertices[j].p.z < minVertex.z)
			minVertex.z = mesh->pVertices[j].p.z;
		if (mesh->pVertices[j].p.y > maxVertex.y)
			maxVertex.y = mesh->pVertices[j].p.y;
		if (mesh->pVertices[j].p.z > maxVertex.z)
			maxVertex.z = mesh->pVertices[j].p.z;
		
		//transform vertex and add to array
		D3DXVec3TransformCoord(&pVertices[j],&mesh->pVertices[j].p,&transformation);
	}
	SAFE_DELETE(mesh);

	//we don't need the sunvertices mesh anymore
	SAFE_RELEASE(verticesMesh);

	//the real sun mesh is a factor bigger than the vertices
	minVertex *= 1.5f;
	maxVertex *= 1.5f;

	//create vertexbuffer with real vertices to render
	long vertexSize = 4*sizeof(Stars::STARSVERTEX);
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vertexSize, D3DUSAGE_WRITEONLY,
		D3DFVF_STARSVERTEX, D3DPOOL_MANAGED, &pVB, NULL)))
	{
		LOG("Creating sun vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	VOID* pVertices;
	if (FAILED(hr=pVB->Lock(0,vertexSize,(VOID**)&pVertices,0)))
	{
		LOG("Locking sun vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}
	Stars::STARSVERTEX* currentStarVertex = (Stars::STARSVERTEX*)pVertices;

	//fill vertex buffer
	D3DXVec3TransformCoord(&(currentStarVertex->position),&minVertex,&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(0.0f,0.0f);
	currentStarVertex++;
	D3DXVec3TransformCoord(&(currentStarVertex->position),&D3DXVECTOR3(0.0f,maxVertex.y,minVertex.z),&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(1.0f,0.0f);
	currentStarVertex++;
	D3DXVec3TransformCoord(&(currentStarVertex->position),&D3DXVECTOR3(0.0f,minVertex.y,maxVertex.z),&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(0.0f,1.0f);
	currentStarVertex++;
	D3DXVec3TransformCoord(&(currentStarVertex->position),&maxVertex,&transformation);
	currentStarVertex->diffuse = color;
	currentStarVertex->texture1 = D3DXVECTOR2(1.0f,1.0f);
	
	//release memory
	pVB->Unlock();

	//no world transformation need (vertices are already transformed)
	D3DXMatrixIdentity(&transformation);

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//needed for color keying
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		
		pD3DDevice->SetRenderState(D3DRS_ZENABLE, false);
		pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);

		pD3DDevice->SetFVF( D3DFVF_STARSVERTEX );
		pD3DDevice->SetTexture(0,pTexture);

		//move to right position
		pD3DDevice->SetTransform(D3DTS_WORLD,&transformation);

		//disable fog
		pD3DDevice->SetRenderState(D3DRS_FOGENABLE, false);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Sun destroyGeometry
**
** releases the vertex buffer and the sun vertices
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Sun::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	//delete sun vertices array
	SAFE_DELETE_ARRAY(pVertices);

	//delete sun mesh
	SAFE_RELEASE(pVB);

	//release sun textures
	SAFE_RELEASE(pTexture);

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);

	return S_OK;
}

/****************************************************************************
** Sun update
**
** nothing - for now
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Sun::update()
{
	return S_OK;
}

/****************************************************************************
** Sun render
**
** renders the sun
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Sun::render()
{
	if (!visible) return S_OK;

	HRESULT hr;
	D3DXMATRIX matTemp;

	//set state block for sun
	pSavedStateBlock->Capture();
	pStateBlock->Apply();

	//draw sun
	pD3DDevice->SetStreamSource(0, pVB, NULL, sizeof(Stars::STARSVERTEX));
	if (FAILED(hr=pD3DDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2)))
	{
		LOG("Rendering sun failed", Logger::LOG_CRIT);
		return hr;
	}

	//restore state block
	pSavedStateBlock->Apply();

	return S_OK;
}

/****************************************************************************
** Sun getPosition
**
** return the position of the center of the sun
**
** Author: Dirk Plate
****************************************************************************/

D3DXVECTOR3 Sun::getPosition()
{
	return position;
}

/****************************************************************************
** Sun getVertices
**
** return a pointer to all vertices of the sun (and the number)
**
** Author: Dirk Plate
****************************************************************************/

const D3DXVECTOR3* Sun::getVertices(int *count)
{
	*count = verticesCount;
	return pVertices;
}


