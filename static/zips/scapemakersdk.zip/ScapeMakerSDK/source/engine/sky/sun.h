/****************************************************************************
** Sun
**
** sun rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(SUN_H)
#define SUN_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "../common/dxutil.h"
#include <Dxerr9.h>
#include "../common/enginehelpers.h"
#include "../../common/minixml.h"

class Sun
{
public:
	Sun();
	~Sun();

	HRESULT update();
	HRESULT render();

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, D3DXVECTOR3 position, D3DXCOLOR color, bool visible, float intensity);
	HRESULT	destroyGeometry();

	D3DXVECTOR3 getPosition();
	const D3DXVECTOR3 *getVertices(int *count);
	float getIntensity() { return intensity;}

private:
	LPDIRECT3DDEVICE9		pD3DDevice;
	bool					visible;

	//sun variables
	LPDIRECT3DVERTEXBUFFER9 pVB;			//the vertex buffer with sun vertices
	LPDIRECT3DTEXTURE9		pTexture;		//the texture
	D3DXVECTOR3				position;		//the position of the sun
	D3DXMATRIX				transformation;
	D3DXVECTOR3*			pVertices;		//all vertices of the sun (at the right position)
	int						verticesCount;	//number of sun vertices

	LPDIRECT3DSTATEBLOCK9	pStateBlock;		//used state block for rendering sun
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;//saved old state block for rendering sun

	float					intensity;		//the intensity of the sun (lesser at horizon)
};

#endif