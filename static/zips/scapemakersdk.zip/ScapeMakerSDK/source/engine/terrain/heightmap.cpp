#include "heightmap.h"
#include <math.h>
#include <stdio.h>
#include <fstream>
#include "../../common/minixml.h"
#include "ximage.h"

/****************************************************************************
** Heightmap Constructor
**
** just store the scale factor
** 
** Author: Matthias Buchetics
****************************************************************************/
Heightmap::Heightmap(const char *enginePath, const char *fileName)
{
	// store the engine path
	strcpy(this->enginePath, enginePath);

	// get the settings filename
	char filenameSettings[512];
	sprintf(filenameSettings, "%sheightmap.txt", enginePath);

	// get the heightmap filename
	char filenameHeightMap[512];
	sprintf(filenameHeightMap, "%s%s", enginePath,fileName);

	//load all settings from text file 
	MiniXML xmlFile;
	tileable = false;
	if (xmlFile.openFile(filenameSettings,MiniXML::READ))
	{
		int value;
		bool bValue;

		if (xmlFile.readInteger("lowestHeight",&value))
			minHeight = value;

		if (xmlFile.readInteger("highestHeight",&value))
			maxHeight = value;

		if (xmlFile.readBoolean("tileable",&bValue))
			tileable = bValue;

		xmlFile.closeFile();
	}

	// set the height scale factor (scaleY)
	engineScaleY = ((float)(maxHeight-minHeight)/(float)(PIXELWIDTH))/255.0f;
	meterScaleY =  ((float)(maxHeight-minHeight))/255.0f;

	loadHeightmap(filenameHeightMap);

	// calculate normal for every pixel
	for(int y = 0; y < size; y++)
		for(int x = 0; x < size; x++)
	{
		calculateNormal(x, y, pNormalArray+y*size+x);
	}
}

/****************************************************************************
** Heightmap Destructor
**
** delete the allocated array
** 
** Author: Matthias Buchetics
****************************************************************************/
Heightmap::~Heightmap()
{
	delete []pHeightmapArray;
	delete []pNormalArray;
}

/****************************************************************************
** Heightmap LoadHeightmap
**
** load the heightmap from the bmp file and store the values in the integer
** array
** 
** Author: Matthias Buchetics
****************************************************************************/
void Heightmap::loadHeightmap(char *filenameHeightmap)
{
	int x, y;

	CxImage hMapBitmap;
	
	hMapBitmap.Load(filenameHeightmap, CXIMAGE_FORMAT_PNG);

	// width and height must be the same (only quadratic heightmaps allowed)
	if(hMapBitmap.GetWidth() != hMapBitmap.GetHeight())
		return;
	else
		size = hMapBitmap.GetWidth();
	
	// allocate the arrays
	pHeightmapArray = new int[size*size];
	pNormalArray = new D3DXVECTOR3[size*size];

	// for every pixel
	for(y = 0; y < size; y++)
		for(x = 0; x < size; x++)
		{
			// store it in the array
			pHeightmapArray[y*size+x] = hMapBitmap.GetPixelGray(x,y);
		}
}

/****************************************************************************
** Heightmap calculateNormal
**
** calculate the normal of heightmap at one position
** 
** Author: Dirk Plate
****************************************************************************/
void Heightmap::calculateNormal(int x, int y, D3DXVECTOR3 *pNormal)
{
	//get own vector
	D3DXVECTOR3 middle((float)x, getHeightInEngineCoor(x,y), (float)y);

	//get the 4 vectors from neighbours
	D3DXVECTOR3 left((float)x-1, getHeightInEngineCoor(x-1,y), (float)y);
	D3DXVECTOR3 right((float)x+1, getHeightInEngineCoor(x+1,y), (float)y);
	D3DXVECTOR3 top((float)x, getHeightInEngineCoor(x,y+1), (float)y+1);
	D3DXVECTOR3 bottom((float)x, getHeightInEngineCoor(x,y-1), (float)y-1);

	//get the 4 vectors from middle to neighbours
	D3DXVECTOR3 toLeft = left-middle;
	D3DXVECTOR3 toRight = right-middle;
	D3DXVECTOR3 toTop = top-middle;
	D3DXVECTOR3 toBottom = bottom-middle;

	//get the 4 normals for the 'edges'
	D3DXVECTOR3 normalLeftTop;
	D3DXVec3Cross(&normalLeftTop,&left,&top);
	D3DXVECTOR3 normalTopRight;
	D3DXVec3Cross(&normalTopRight,&top,&right);
	D3DXVECTOR3 normalRightBottom;
	D3DXVec3Cross(&normalRightBottom,&right,&bottom);
	D3DXVECTOR3 normalBottomLeft;
	D3DXVec3Cross(&normalBottomLeft,&bottom,&left);

	//calculate middle normal by adding all
	D3DXVECTOR3 normalMiddle = normalLeftTop+normalTopRight+normalRightBottom+normalBottomLeft;

	//return normalized normal
	D3DXVec3Normalize(pNormal,&normalMiddle);
}

/****************************************************************************
** Heightmap getHeight
**
** get the heightmap height at a given point (must be in integer coordinates)
** 
** Author: Matthias Buchetics
****************************************************************************/

int Heightmap::getHeight(int x, int y)
{
	//need coordinates inside terrain
	x = transformOutsideCoordinatesInt(x);
	y = transformOutsideCoordinatesInt(y);

	return pHeightmapArray[y*size+x];
}

/****************************************************************************
** Heightmap getHeightInEngineCoor
**
** get the scaled height at a given point (must be in integer coordinates)
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getHeightInEngineCoor(int x, int y)
{
	return ((float)getHeight(x, y)) * engineScaleY;
}

/****************************************************************************
** Heightmap GetInterpolatedHeight
**
** get the interpolated height values for float coordinates (e.g. x=1,5 ...)
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getInterpolatedHeight(float fx, float fy)
{
	int lu_x = (int)fx;
	int lu_y = (int)fy;
	int rd_x = lu_x+1;
	int rd_y = lu_y+1;

	// use the extended funtion, were we can select the points between
	// which the interpolation should happen
	return getInterpolatedHeightEx(lu_x, lu_y, rd_x, rd_y, fx, fy);
}

/****************************************************************************
** Heightmap GetHeightInMeters
**
** get the "real" height at the given point (in meters)
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getHeightInMeters(int x, int y)
{
	return minHeight+((float)getHeight(x, y)) * meterScaleY;
}

/****************************************************************************
** Heightmap GetInterpolatedHeightInEngineCoor
**
** get the height at the given point in engine coordinates
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getInterpolatedHeightInEngineCoor(float fx, float fy)
{
	return getInterpolatedHeight(fx, fy) * engineScaleY;
}

/****************************************************************************
** Heightmap GetInterpolatedHeightInMeters
**
** get the "real" height at the given point (in meters)
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getInterpolatedHeightInMeters(float fx, float fy)
{
	return minHeight+getInterpolatedHeight(fx, fy) * meterScaleY;
}

/****************************************************************************
** Heightmap GetInterpolatedHeightEx
**
** the points between the interpolation should be made, can be specified
** this is needed for the calcError function!
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getInterpolatedHeightInEngineCoorEx(int lu_x, int lu_y, int rd_x, int rd_y, float point_x, float point_y) 
{
	return getInterpolatedHeightEx(lu_x, lu_y, rd_x, rd_y, point_x, point_y) * engineScaleY;
}

/****************************************************************************
** Heightmap GetInterpolatedHeightEx
**
** the points between the interpolation should be made, can be specified
** this is needed for the calcError function!
** 
** Author: Matthias Buchetics
****************************************************************************/
float Heightmap::getInterpolatedHeightEx(int lu_x, int lu_y, int rd_x, int rd_y, float point_x, float point_y) 
{
/*
	P3(x1,y2,z3) ----- P4 (x2,y2,z4)
			     |  /|
			     | / |
			     |/  |
    P1(x1,y1,z1) ----- P2 (x2,y1,z2)
*/

	float a = (float)(point_x-lu_x)/(float)(rd_x - lu_x);
	float b = (float)(point_y-lu_y)/(float)(rd_y - lu_y);

	// look at the drawing above
	int x1 = lu_x;	
	int y1 = rd_y;
	int x2 = rd_x;			
	int y2 = lu_y;
	
	if ((a+b) < 1.0f) //point in the left upper triangle?
	{
		//get the heights of the triangle edges
		float z1 = (float)getHeight(x1,y2);
		float z2 = (float)getHeight(x2,y2);
		float z3 = (float)getHeight(x1,y1);

		return (z1-(z1-z2)*a-(z1-z3)*b); //calc. the height
	}
	else //then point in the right lower triangle
	{
		//get the heights of the triangle edges
		float z2 = (float)getHeight(x2,y1);
		float z3 = (float)getHeight(x1,y1);
		float z4 = (float)getHeight(x2,y2);

		return (z2-(z2-z3)*(1.0f-a)-(z2-z4)*(1.0f-b)); //calc. the height		
	}
}

/****************************************************************************
** Heightmap getInterpolatedHeightSmooth
**
** get the height of a point for texturing (smooth)
** 
** Author: Dirk Plate
****************************************************************************/
float Heightmap::getInterpolatedHeightSmooth(float fx, float fy)
{
	float strengthLeftTop;
	float strengthRightTop;
	float strengthLeftBottom;
	float strengthRightBottom;

	//need coordinate inside heightmap
	fx = transformOutsideCoordinatesFloat(fx);
	fy = transformOutsideCoordinatesFloat(fy);	

	int xInt = int(fx);
	int yInt = int(fy);

	//get strength from all edges around this point
	EngineHelpers::getInterpolationStrengths(fx, fy,&strengthLeftTop, &strengthRightTop, &strengthLeftBottom, &strengthRightBottom);

	//get normal from edges
	int heightLeftTop = getHeight(xInt, yInt);
	int heightRightTop = getHeight(xInt+1, yInt);
	int heightLeftBottom = getHeight(xInt, yInt+1);
	int heightRightBottom = getHeight(xInt+1, yInt+1);
	
	//calculate mean value
	float height = (strengthLeftTop*heightLeftTop+
					strengthRightTop*heightRightTop+
					strengthLeftBottom*heightLeftBottom+
					strengthRightBottom*heightRightBottom);	
	return height;
}

/****************************************************************************
** Heightmap getInterpolatedHeigthInEngineCoorSmooth
**
** get the height of a point for texturing (smooth)
** 
** Author: Dirk Plate
****************************************************************************/
float Heightmap::getInterpolatedHeigthInEngineCoorSmooth(float fx, float fy)
{
	return getInterpolatedHeightSmooth(fx,fy) * engineScaleY;
}

/****************************************************************************
** Heightmap getInterpolatedHeightInMetersSmooth
**
** get the height of a point for texturing (smooth)
** 
** Author: Dirk Plate
****************************************************************************/
float Heightmap::getInterpolatedHeightInMetersSmooth(float fx, float fy)
{
	return minHeight+getInterpolatedHeightSmooth(fx, fy) * meterScaleY;
}

/****************************************************************************
** Heightmap GetSlope
**
** get the slope for texturing
** 
** Author: Dirk Plate
****************************************************************************/
float Heightmap::getSlope(int x, int y)
{
	//need coordinate inside heightmap
	x = transformOutsideCoordinatesInt(x);
	y = transformOutsideCoordinatesInt(y);

	//get normal at this point
	D3DXVECTOR3 *pNormal = pNormalArray+y*size+x;
	
	//return right angle
	return acosf(pNormal->y);
}

/****************************************************************************
** Heightmap GetInterpolatedSlopeSmooth
**
** get the interpolated slope for texturing
** (and smoothness (ignore polygons!!))
** 
** Author: Dirk Plate
****************************************************************************/
float Heightmap::getInterpolatedSlopeSmooth(float fx, float fy)
{
	//get normal at this point
	D3DXVECTOR3 normal = getInterpolatedNormalSmooth(fx,fy);
	
	//return right angle
	return acosf(normal.y);
}

/****************************************************************************
** Heightmap getNormal
**
** get normal on a specified integer coordinate
** 
** Author: Dirk Plate
****************************************************************************/
D3DXVECTOR3 Heightmap::getNormal(int x, int y)
{
	//need coordinate inside heightmap
	x = transformOutsideCoordinatesInt(x);
	y = transformOutsideCoordinatesInt(y);

	return pNormalArray[y*size+x];
}

/****************************************************************************
** Heightmap getNormalSmooth
**
** get normal on a specified float coordinate with interpolation 
** (and smoothness (ignore polygons!!))
** 
** Author: Dirk Plate
****************************************************************************/
D3DXVECTOR3 Heightmap::getInterpolatedNormalSmooth(float fx, float fy)
{
	float strengthLeftTop;
	float strengthRightTop;
	float strengthLeftBottom;
	float strengthRightBottom;

	//need coordinate inside heightmap
	fx = transformOutsideCoordinatesFloat(fx);
	fy = transformOutsideCoordinatesFloat(fy);	

	int xInt = int(fx);
	int yInt = int(fy);

	//get strength from all edges around this point
	EngineHelpers::getInterpolationStrengths(fx, fy,&strengthLeftTop, &strengthRightTop, &strengthLeftBottom, &strengthRightBottom);

	//get normal from edges
	D3DXVECTOR3 normalLeftTop = getNormal(xInt, yInt);
	D3DXVECTOR3 normalRightTop = getNormal(xInt+1, yInt);
	D3DXVECTOR3 normalLeftBottom = getNormal(xInt, yInt+1);
	D3DXVECTOR3 normalRightBottom = getNormal(xInt+1, yInt+1);
	
	//calculate mean value
	D3DXVECTOR3 normal = (strengthLeftTop*normalLeftTop+
						 strengthRightTop*normalRightTop+
						 strengthLeftBottom*normalLeftBottom+
						 strengthRightBottom*normalRightBottom);	

	//return normalized normal
	D3DXVec3Normalize(&normal,&normal);
	return normal;
}

/****************************************************************************
** Heightmap setHeight
**
** set the heightmap height at a given point (must be in integer coordinates)
** 
** Author: Dirk Plate
****************************************************************************/
void Heightmap::setHeight(int x, int y, int height)
{
	//need coordinate inside heightmap
	x = transformOutsideCoordinatesInt(x);
	y = transformOutsideCoordinatesInt(y);

	pHeightmapArray[y*size+x] = height;
}

/****************************************************************************
** Heightmap setHeightInEngineCoor
**
** set the heightmap height in engine coordinates at a given point 
** (must be in integer coordinates)
** 
** Author: Dirk Plate
****************************************************************************/
void Heightmap::setHeightInEngineCoor(int x, int y, float height)
{
	if (engineScaleY > SMALL_NUM)
		setHeight(x, y, height/engineScaleY);
}

/****************************************************************************
** Heightmap setHeightInMeters
**
** set the heightmap height in meters at a given point 
** (must be in integer coordinates)
** 
** Author: Dirk Plate
****************************************************************************/
void Heightmap::setHeightInMeters(int x, int y, float height)
{
	if (meterScaleY > SMALL_NUM)
		setHeight(x, y,(height-minHeight)/meterScaleY);
}

/****************************************************************************
** Heightmap save
**
** save the file as png
** 
** Author: Dirk Plate
****************************************************************************/
void Heightmap::save(const char *filePath)
{
	CxImage hMapBitmap;
	hMapBitmap.Create(size,size,24);
	
	// for every pixel
	for(int y = 0; y < size; y++)
		for(int x = 0; x < size; x++)
	{
		// store it as gray value
		RGBQUAD color;
		color.rgbRed = pHeightmapArray[y*size+x];
		color.rgbGreen = color.rgbRed;
		color.rgbBlue = color.rgbRed;
		hMapBitmap.SetPixelColor(x,y,color); 
	}

	hMapBitmap.Save(filePath, CXIMAGE_FORMAT_PNG);
}

/****************************************************************************
** Heightmap transformOutsideCoordinatesInt
**
** transform a coordinate, so that it lies inside the heightmap
** (considering (not) tileable terrains)
** 
** Author: Dirk Plate
****************************************************************************/
int	Heightmap::transformOutsideCoordinatesInt(int coordinate)
{
	//if tileable... make modulo
	if (tileable)
	{
		//correct negative values
		while (coordinate < 0)
			coordinate += size;

		//make modulo
		if (coordinate >= size)
			coordinate %= size;
	}
	//if not tileable... considering mirroring
	else
	{
		//correct negative values
		while (coordinate < 0)
			coordinate += 2*size;

		//in a not mirrored terrain?
		if ((coordinate/size)%2 == 0)
			coordinate %= size;
		//in a mirrored terrain
		else coordinate = size - coordinate%size - 1;
	}

	return coordinate;
}


/****************************************************************************
** Heightmap transformOutsideCoordinatesFloat
**
** transform a coordinate, so that it lies inside the heightmap
** (considering (not) tileable terrains)
** 
** Author: Dirk Plate
****************************************************************************/
float Heightmap::transformOutsideCoordinatesFloat(float coordinate)
{
	//if tileable... make modulo
	if (tileable)
	{
		//correct negative values
		while (coordinate < 0.0f)
			coordinate += size;

		//make modulo
		if (coordinate >= size)
		{
			int coordinateInt = int(coordinate);
			coordinate = coordinate-coordinateInt+coordinateInt%size;
		}
	}
	//if not tileable... considering mirroring
	else
	{
		//correct negative values
		while (coordinate < 0.0f)
			coordinate += 2.0f*size;

		//in a not mirrored terrain?
		int coordinateInt = int(coordinate);
		if ((coordinateInt/size)%2 == 0)
			coordinate = coordinate-coordinateInt+coordinateInt%size;
		//in a mirrored terrain
		else coordinate = float(size) - (coordinate-coordinateInt+coordinateInt%size) - 1.0f;
	}

	//needed!
	if (coordinate < 0.0f)
		coordinate = 0.0f;
	
	return coordinate;
}
