/****************************************************************************
** Heightmap
**
** loads the heightmap and gives access to it through varios functions
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(HEIGHTMAP_H)
#define HEIGHTMAP_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "../common/enginehelpers.h"

const int PIXELWIDTH = 50;	//how many meters is the width of one pixel of the heightmap

class Heightmap
{
public:
	Heightmap(const char *enginePath, const char *fileName);
	~Heightmap();

	int		getHeight(int x, int y);
	float	getHeightInEngineCoor(int x, int y);
	float	getHeightInMeters(int x, int y);

	float	getInterpolatedHeight(float fx, float fy);
	float	getInterpolatedHeightInEngineCoor(float fx, float fy);
	float	getInterpolatedHeightInMeters(float fx, float fy);

	float	getInterpolatedHeightInEngineCoorEx(int lu_x, int lu_y, int rd_x, int rd_y, float point_x, float point_y);
	float	getInterpolatedHeightEx(int lu_x, int lu_y, int rd_x, int rd_y, float point_x, float point_y);

	float	getInterpolatedHeightSmooth(float fx, float fy);
	float	getInterpolatedHeigthInEngineCoorSmooth(float fx, float fy);
	float	getInterpolatedHeightInMetersSmooth(float fx, float fy);

	float	getSlope(int x, int y);
	float	getInterpolatedSlopeSmooth(float fx, float fy);

	D3DXVECTOR3 getNormal(int x, int y);
	D3DXVECTOR3 getInterpolatedNormalSmooth(float fx, float fy);

	int		getSize() { return size; }
	float	getEngineScaleY() { return engineScaleY; }
	float	getMeterScaleY() { return meterScaleY; }
	int		getMinHeightInMeters() {return minHeight;}

	void	setHeight(int x, int y, int height);
	void	setHeightInEngineCoor(int x, int y, float height);
	void	setHeightInMeters(int x, int y, float height);
	void	save(const char *filePath);

	bool	isTileable() {return tileable;}

private:
	// helper function for interpolating between two values
	float interpolate(float a, float b, float x)
	{
		return (a*(1.0f-x)+b*x);
	}

	void	loadHeightmap(char *filenameHeightmap);
	void	calculateNormal(int x, int y, D3DXVECTOR3 *pNormal);
	int		transformOutsideCoordinatesInt(int coordinate);
	float   transformOutsideCoordinatesFloat(float coordinate);


	int		*pHeightmapArray;	// the heightmap is stored in an integer array
	float	engineScaleY;		// the height scale factor to get height in engine coordinates
	float	meterScaleY;		// the height scale factor to get height in meters
	int		size;				// size of the heightmap
	int		minHeight;			// minimum height of the landscape (eg. 1000 m)
	int		maxHeight;			// maximum height of the landscape (eg. 2500 m)
	char	enginePath[512];	// path to the engine directory of the current landscape
	D3DXVECTOR3 *pNormalArray;	// the normals of each point of heightmap
	bool	tileable;			// the heightmap is tileable
};

#endif




















