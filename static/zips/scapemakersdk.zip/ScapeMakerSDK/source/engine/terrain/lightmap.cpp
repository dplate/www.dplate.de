#include "lightmap.h"

/****************************************************************************
** Lightmap Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
Lightmap::Lightmap(const char *enginePath)
{
	// store the engine path
	strcpy(this->enginePath, enginePath);

	// get the lightmap filename
	char filenameLightMap[512];
	sprintf(filenameLightMap, "%slightmap.jpg", enginePath);

	loadLightmap(filenameLightMap);
}

/****************************************************************************
** Lightmap Destructor
**
** delete the allocated array
**
** Author: Dirk Plate
****************************************************************************/
Lightmap::~Lightmap()
{
	for (int x=0;x<size;x++)
		SAFE_DELETE_ARRAY(lightmap[x]);
	SAFE_DELETE_ARRAY(lightmap);
}

/****************************************************************************
** Lightmap LoadLightmap
**
** load the lightmap from the bmp file and store the values in the array
**
** Author: Dirk Plate
****************************************************************************/
void Lightmap::loadLightmap(char *filenameLightmap)
{
	int x, y;

	CxImage lMapBitmap;

	lMapBitmap.Load(filenameLightmap, CXIMAGE_FORMAT_JPG);

	//save size of lightmap
	size = lMapBitmap.GetWidth();

	//allocate the array
	lightmap = new D3DXCOLOR*[size];
	for (x=0;x<size;x++)
		lightmap[x] = new D3DXCOLOR[size];

	//for every pixel
	for(x = 0; x < size; x++)
		for(y = 0; y < size; y++)
		{
			//store it in the array
			RGBQUAD color = lMapBitmap.GetPixelColor(x,y);
			lightmap[x][y].r = ((float)color.rgbRed)/255.0f;
			lightmap[x][y].g = ((float)color.rgbGreen)/255.0f;
			lightmap[x][y].b = ((float)color.rgbBlue)/255.0f;
			lightmap[x][y].a = 1.0f;
		}
}

/****************************************************************************
** Lightmap getLightColor
**
** get the lightmap color at a given point (must be in integer coordinates)
**
** Author: Dirk Plate
****************************************************************************/
D3DXCOLOR Lightmap::getLightColor(int x, int y)
{
	if ((x<0) || (x>=size) || (y<0) || (y>=size))
		return 0xffffffff;
	return lightmap[x][y];
}





















