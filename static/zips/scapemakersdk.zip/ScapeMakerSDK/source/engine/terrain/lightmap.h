/****************************************************************************
** Lightmap
**
** loads the lightmap and gives access to it through varios functions
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(LIGHTMAP_H)
#define LIGHTMAP_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "../common/dxutil.h"
#include "ximage.h"

class Lightmap
{
public:
	Lightmap(const char *enginePath);
	~Lightmap();

	D3DXCOLOR getLightColor(int x, int y);
private:
	void loadLightmap(char *filenameLightmap);
	D3DXCOLOR **lightmap;		//the lightmap is stored in a dynamic 2D array
	int		size;				//the size of the lightmap
	char	enginePath[512];	//path to the engine directory of the current landscape
};

#endif




















