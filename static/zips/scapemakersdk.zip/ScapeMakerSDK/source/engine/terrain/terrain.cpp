#include "terrain.h"

#include "../../common/minixml.h"
#include "../logger/logger.h"
#include "terraintile.h"
#include "../camera/camera.h"	
#include "../camera/viewfrustum.h"
#include "lightmap.h"
#include "../common/enginehelpers.h"
#include "../common/config.h"
#include "../hud/hud.h"
#include <vector>

Terrain *Terrain::instance = NULL;

/****************************************************************************
** Terrain Constructor
**
** set pointers to NULL
**
** Author: Matthias Buchetics
****************************************************************************/
Terrain::Terrain()
{
	Module::Module();
	name = "Terrain";

	pD3DDevice = NULL;
	pHeightmap = NULL;
	pLightmap = NULL;
	pHighIB = NULL;
	pMediumIB = NULL;
	pLowIB = NULL;
	pVeryLowIB = NULL;
	pTerrainTiles = NULL;
	pDetailTexture = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;
		
	wireframeEnabled = false;

	instance = this;
}

Terrain::~Terrain()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Terrain CreateGeometry
**
** initializes the terrain (calls all the loading functions)
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	HRESULT hr;

	LOGFUNC("createGeometry()");

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;

	//call sub create geometry function
	if (FAILED(hr = createGeometryForShadowGen(Config::instance->getEnginePath().c_str())))
		return hr;

	// load the lightmap
	pLightmap = new Lightmap(Config::instance->getEnginePath().c_str());
	
	// init all tiles
	if(FAILED(hr = initTiles()))
		return hr;

	// and create all index buffers
	if(FAILED(hr = initIndexBuffers()))
		return hr;


	//try to load the user specific detail texture (DXT1 format)
	if(FAILED(hr = D3DXCreateTextureFromFileEx(pD3DDevice, (Config::instance->getEnginePath()+"/detailmap.jpg").c_str(), D3DX_DEFAULT,
		D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_DXT1, D3DPOOL_MANAGED, D3DX_DEFAULT,
		D3DX_DEFAULT, 0, NULL, NULL, &pDetailTexture)))
	{
		//try to load default detail map
		if(FAILED(hr = D3DXCreateTextureFromFileEx(pD3DDevice, "./detailmaps/default.jpg", D3DX_DEFAULT,
			D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_DXT1, D3DPOOL_MANAGED, D3DX_DEFAULT,
			D3DX_DEFAULT, 0, NULL, NULL, &pDetailTexture)))
		{
			LOG("Loading detail texture failed", Logger::LOG_CRIT);
			return hr;
		}
    }
	LOG("Detail texture loaded OK");

	if (FAILED(hr = initStateBlock()))
		return hr;

	LOG("State block created OK");

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Terrain DestroyGeometry
**
** destroy the terrain, free memory, release index buffers ...
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	int x, y;

	// destroy all terrain tiles
	for(y = 0; y < nrTiles; y++)
		for(x = 0; x < nrTiles; x++)
			pTerrainTiles[y*nrTiles+x].destroyGeometry();

	// free allocated memory
	destroyGeometryForShadowGen();
	delete []pTerrainTiles;

	// and release all index buffers
	if(pHighIB)
	{
		pHighIB->Release();
		pHighIB=NULL;
	}

	if(pMediumIB)
	{
		pMediumIB->Release();
		pMediumIB=NULL;
	}

	if(pLowIB)
	{
		pLowIB->Release();
		pLowIB=NULL;
	}

	if(pVeryLowIB)
	{
		pVeryLowIB->Release();
		pVeryLowIB=NULL;
	}

	if(pDetailTexture)
	{
		pDetailTexture->Release();
		pDetailTexture = NULL;
	}

	// also release all transition index buffers
	for(int i=0; i<4; i++)
		for(int j=0; j<4; j++)
		{
			pLeftTransition[i][j]->Release();
			pLeftTransition[i][j] = NULL;
			pUpperTransition[i][j]->Release();
			pUpperTransition[i][j] = NULL;
		}

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);
	
	return Module::destroyGeometry();
}

/****************************************************************************
** Terrain createGeometryForShadowGen
**
** initializes the terrain (only these parts needed for shadow generation)
**
** Author: Dirk Plate
****************************************************************************/

HRESULT Terrain::createGeometryForShadowGen(const char *enginePath)
{
	// load the heightmap
	pHeightmap = new Heightmap(enginePath,"heightmap.png");
	heightmapSize = pHeightmap->getSize();

	// if the heightmapSize is -1, then the loading failed
	if(heightmapSize == -1)
		return E_FAIL; 

	return S_OK;
}

/****************************************************************************
** Terrain destroyGeometryForShadowGen
**
** destroy the terrain (only these parts needed for shadow generation)
**
** Author: Dirk Plate
****************************************************************************/

HRESULT	Terrain::destroyGeometryForShadowGen()
{
	// free allocated memory
	delete pHeightmap;

	delete pLightmap;

	return S_OK;
}

/****************************************************************************
** Terrain InitTiles
**
** initializes the terrain tiles (calls the init function for each tile)
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::initTiles()
{
	int x, y;
	HRESULT hr;

	// how many tiles do we have?
	nrTiles = heightmapSize/TILE_SIZE;

	// allocate the terrain tile array
	pTerrainTiles = new TerrainTile[nrTiles*nrTiles];

	//allocate temporary tile array
	Tile** pTmpTiles = new Tile*[nrTiles*nrTiles];

	//check if terrain is tileable
	bool mirroredTiles = !pHeightmap->isTileable();

	// for every tile ...
	for(y = 0; y < nrTiles; y++)
		for(x = 0; x < nrTiles; x++)
		{
			// init the tile (create vertex buffer ...)
			if(FAILED(hr=pTerrainTiles[y*nrTiles+x].initTile(x, y, heightmapSize, mirroredTiles, pHeightmap, pD3DDevice)))
				return hr;
			
			char filenameTexture[512];
			sprintf(filenameTexture, "%s\\textures\\terrain_%d_%d.jpg", 
				Config::instance->getEnginePath().c_str(), x, y);

			// load the tile texture
			if(FAILED(hr=pTerrainTiles[y*nrTiles+x].loadTexture(filenameTexture)))
				return hr;

			// set the pointers to the neighbour tiles (for lod transition)
			pTerrainTiles[y*nrTiles+x].setNeighbours(pTerrainTiles, nrTiles);

			//save pointer to tile in array
			pTmpTiles[y*nrTiles+x] = &pTerrainTiles[y*nrTiles+x];
		}

	//add to tile checker
	tileCheck.setTiles(pTmpTiles, nrTiles, heightmapSize, 
		true, mirroredTiles);

	//delete temporay array
	SAFE_DELETE_ARRAY(pTmpTiles);

	LOG("Terrain Tiles created OK");

	return S_OK;
}

/****************************************************************************
** Terrain InitIndexBuffers
**
** calls the index buffer init functions to create all the index buffers we
** need (one for each lod and two for each transition)
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::initIndexBuffers()
{
	HRESULT hr;

	// init the lod index buffers
	if(FAILED(hr=initIndexBuffer(HIGH_DETAIL, &pHighIB)))
		return hr;
	if(FAILED(hr=initIndexBuffer(MEDIUM_DETAIL, &pMediumIB)))
		return hr;
	if(FAILED(hr=initIndexBuffer(LOW_DETAIL, &pLowIB)))
		return hr;
	if(FAILED(hr=initIndexBuffer(VERYLOW_DETAIL, &pVeryLowIB)))
		return hr;

	// init the lod transition index buffers, one for the upper tile and one for the left one
	// HIGH_DETAIL = 0, MEDIUM_DETAIL = 1 ... so we can use 2 for loops to generate all
	// transitions (also HIGH->HIGH !)
	for(int i=0; i<4; i++)
		for(int j=0; j<4; j++)
		{
			if(FAILED(hr=initIndexBufferLODTransitionUpper(i, j, &pUpperTransition[i][j])))
				return hr;
			if(FAILED(hr=initIndexBufferLODTransitionLeft(i, j, &pLeftTransition[i][j])))
				return hr;
		}

	LOG("Index buffers created OK");

	return S_OK;
}

/****************************************************************************
** Terrain InitIndexBuffer
**
** create the index buffer for one lod level
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::initIndexBuffer(int lod, LPDIRECT3DINDEXBUFFER9 *pIB)
{
	HRESULT hr;

	// jump can be 1, 2, 4, 8 (according to the lod level, "how many pixels are not considered")
	int jump = getJumpFromLod(lod);
	int x, y;
	int index = 0;

	// nrVertices is alway constant
	int nrVertices = (TILE_SIZE+1)*(TILE_SIZE+1);

	// max nrIndices (*2 because we need 2 triangles for one quad, *3 because one triangle has 3 indices)
	int nrIndices = TILE_SIZE * TILE_SIZE * 2 * 3;
	VOID* pIndices;

	// lower lod levels need less Indices (quadratic)
	nrIndices/=(jump*jump);

	// allocate the indexdate array
	WORD* pIndexData = new WORD[nrIndices];

	// 0----4     0 = 3
	// | \  |
	// |  \ |
	// |   \|
	// 2----1     1 = 5

	// main tile (the middle), always rendered, never changes
	for (y = 0; y < TILE_SIZE-jump; y+=jump)
		for (x = jump; x < TILE_SIZE; x+=jump)
		{
			pIndexData[index]	= (y+jump)	* (TILE_SIZE+1) +	(x);
			pIndexData[index+1]	= (y)		* (TILE_SIZE+1) +	(x+jump);
			pIndexData[index+2]	= (y)		* (TILE_SIZE+1) +	(x);
			pIndexData[index+3]	= pIndexData[index];
			pIndexData[index+4]	= (y+jump)	* (TILE_SIZE+1) +	(x+jump);
			pIndexData[index+5]	= pIndexData[index+1];
			index+=6;
		}

	// store upper and left border at the end of the index buffer, so we can switch it off
	// easily (so we can only render the middle tile)

	// upper border
	for (y = TILE_SIZE-jump, x= 0; x < TILE_SIZE; x+=jump)
	{
		pIndexData[index]	= (y+jump)	* (TILE_SIZE+1) +	(x);
		pIndexData[index+1]	= (y)		* (TILE_SIZE+1) +	(x+jump);
		pIndexData[index+2]	= (y)		* (TILE_SIZE+1) +	(x);
		pIndexData[index+3]	= pIndexData[index];
		pIndexData[index+4]	= (y+jump)	* (TILE_SIZE+1) +	(x+jump);
		pIndexData[index+5]	= pIndexData[index+1];
		index+=6;
	}

	// left border
	for (x = 0, y = 0; y < TILE_SIZE-jump; y+=jump)
	{
		pIndexData[index]	= (y+jump)	* (TILE_SIZE+1) +	(x);
		pIndexData[index+1]	= (y)		* (TILE_SIZE+1) +	(x+jump);
		pIndexData[index+2]	= (y)		* (TILE_SIZE+1) +	(x);
		pIndexData[index+3]	= pIndexData[index];
		pIndexData[index+4]	= (y+jump)	* (TILE_SIZE+1) +	(x+jump);
		pIndexData[index+5]	= pIndexData[index+1];
		index+=6;
	}

	// create the index buffer
	if (FAILED(hr = pD3DDevice->CreateIndexBuffer(nrIndices * sizeof(WORD),
											D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                            D3DPOOL_MANAGED, pIB, NULL)))
    {
		LOG("Creating index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	if (FAILED(hr = (*pIB)->Lock( 0, sizeof(*pIndexData) * nrIndices, (VOID**)&pIndices, 0)))
	{
       	LOG("Locking index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	memcpy(pIndices, pIndexData, sizeof(*pIndexData) * nrIndices);
	(*pIB)->Unlock();

	delete []pIndexData;

	return S_OK;
}

/****************************************************************************
** Terrain InitIndexBufferLODTransitionUpper
**
** create the index buffer for the upper border transition
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::initIndexBufferLODTransitionUpper(int lodFrom, int lodTo, LPDIRECT3DINDEXBUFFER9 *pIB)
{
	HRESULT hr;

	// lodFrom = the lod level of "our" tile
	int jumpFrom = getJumpFromLod(lodFrom);

	// lodTo = the lod level of the neighbour tile
	int jumpTo = getJumpFromLod(lodTo);

	int index = 0;
	int xBottom, xUp;

	// y is constant (we create the upper border)
	int y = TILE_SIZE-jumpFrom;

	// -1 because we dont render the first triangle
	int nrIndices = ((TILE_SIZE/jumpFrom) + (TILE_SIZE/jumpTo) - 1) * 3;

	WORD* pIndexData = new WORD[nrIndices];
	VOID* pIndices;

	// from = high detail level, to = lower, bottom = high, up = low
	if(lodFrom <= lodTo)
	{
		// for every low detail point
		for(xUp=0; xUp < TILE_SIZE; xUp+=jumpTo)
		{
			// first triangle (not beginning)
			if(xUp!=0)
			{
				pIndexData[index]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xUp);
				pIndexData[index+1]	= (y)			* (TILE_SIZE+1) +	(xUp+jumpFrom);
				pIndexData[index+2]	= (y)			* (TILE_SIZE+1) +	(xUp);
				index+=3;
			}

			// the "transition triangles" (looks like a triangle fan)
			// for every high detail point
			for(xBottom=xUp+jumpFrom; xBottom < (xUp+jumpTo); xBottom+=jumpFrom)
			{
				pIndexData[index]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xUp);
				pIndexData[index+1] = (y)			* (TILE_SIZE+1) +	(xBottom+jumpFrom);
				pIndexData[index+2] = (y)			* (TILE_SIZE+1) +	(xBottom);
				index+=3;
			}

			// the triangle at the end
			pIndexData[index]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xUp);
			pIndexData[index+1]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xUp+jumpTo);
			pIndexData[index+2]	= (y)			* (TILE_SIZE+1) +	(xUp+jumpTo);
			index+=3;
		}
	}

	// from = low detail level, to = higher, bottom = low, up = high
	if(lodFrom > lodTo)
	{
		// for every low detail point
		for(xBottom=0; xBottom < TILE_SIZE; xBottom+=jumpFrom)
		{
			// first triangle (not at beginning)
			if(xBottom!=0)
			{
				pIndexData[index]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xBottom);
				pIndexData[index+1]	= (y)			* (TILE_SIZE+1) +	(xBottom+jumpFrom);
				pIndexData[index+2]	= (y)			* (TILE_SIZE+1) +	(xBottom);
				index+=3;
			}

			// transition triangles
			// for every high detail point
			for(xUp=xBottom; xUp < (xBottom+jumpFrom); xUp+=jumpTo)
			{
				pIndexData[index]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xUp);
				pIndexData[index+1] = (y+jumpFrom)	* (TILE_SIZE+1) +	(xUp+jumpTo);
				pIndexData[index+2] = (y)			* (TILE_SIZE+1) +	(xBottom+jumpFrom);
				index+=3;
			}

			// we dont need to extra code the last triangle, it is generated above
		/*	pIndexData[index]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xBottom+jumpFrom-jumpTo);
			pIndexData[index+1]	= (y+jumpFrom)	* (TILE_SIZE+1) +	(xBottom+jumpFrom);
			pIndexData[index+2]	= (y)			* (TILE_SIZE+1) +	(xBottom+jumpFrom);
			index+=3;*/
		}
	}

	// create the index buffer
	if (FAILED(hr = pD3DDevice->CreateIndexBuffer(nrIndices * sizeof(WORD),
											D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                            D3DPOOL_MANAGED, pIB, NULL)))
    {
		LOG("Creating index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	if (FAILED(hr = (*pIB)->Lock( 0, sizeof(*pIndexData) * nrIndices, (VOID**)&pIndices, 0)))
	{
       	LOG("Locking index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	memcpy(pIndices, pIndexData, sizeof(*pIndexData) * nrIndices);
	(*pIB)->Unlock();

	delete []pIndexData;

	return S_OK;
}

/****************************************************************************
** Terrain InitIndexBufferLODTransitionLeft
**
** create the index buffer for the left transition
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT Terrain::initIndexBufferLODTransitionLeft(int lodFrom, int lodTo, LPDIRECT3DINDEXBUFFER9 *pIB)
{
	HRESULT hr;

	// lodFrom = the lod level of "our" tile
	int jumpFrom = getJumpFromLod(lodFrom);

	// lodTo = the lod level of the neighbour tile
	int jumpTo = getJumpFromLod(lodTo);

	int index = 0;
	int yLeft, yRight;

	// x is constant (the left border)
	int x = 0;

	// nr of needed indices, -1 because the first triangle is not rendered at the beginning
	int nrIndices = ((TILE_SIZE/jumpFrom) + (TILE_SIZE/jumpTo) - 1) * 3;
	WORD* pIndexData = new WORD[nrIndices];;
	VOID* pIndices;

	// important note: if y = 0 it is at the bottom, not on the top!
	// so if we add something to y, it means that we are going upwards!

	// from = high detail, to = low detail, left = low, right = high
	if(lodFrom <= lodTo)
	{
		// for every low detail point
		for(yLeft=0; yLeft < TILE_SIZE; yLeft+=jumpTo)
		{
			// alway rendered (see wireframe mode or drawings)
			pIndexData[index]	= (yLeft+jumpTo)* (TILE_SIZE+1) +	(x);
			pIndexData[index+1]	= (yLeft)		* (TILE_SIZE+1) +	(x+jumpFrom);
			pIndexData[index+2]	= (yLeft)		* (TILE_SIZE+1) +	(x);
			index+=3;

			// for every high detail point, like a triangle fan
			for(yRight=yLeft+jumpFrom; yRight < (yLeft+jumpTo); yRight+=jumpFrom)
			{
				pIndexData[index]	= (yLeft+jumpTo)	* (TILE_SIZE+1) +	(x);
				pIndexData[index+1] = (yRight)			* (TILE_SIZE+1) +	(x+jumpFrom);
				pIndexData[index+2] = (yRight-jumpFrom)	* (TILE_SIZE+1) +	(x+jumpFrom);
				index+=3;
			}

			// the "last" triangle (rendered at the top, for the viewer it is the "first")
			if(yLeft!=TILE_SIZE-jumpTo)
			{
				pIndexData[index]	= (yLeft+jumpTo)  * (TILE_SIZE+1) +	(x);
				pIndexData[index+1]	= (yLeft+jumpTo)  * (TILE_SIZE+1) +	(x+jumpFrom);
				pIndexData[index+2]	= (yLeft+jumpTo-jumpFrom)* (TILE_SIZE+1) +	(x+jumpFrom);
				index+=3;
			}
		}
	}

	// from = low detail level, to = higher, left = low, right = high
	if(lodFrom > lodTo)
	{
		// for every low detail point
		for(yRight=0; yRight < TILE_SIZE; yRight+=jumpFrom)
		{
			// the first triangle can also be rendered in the loop, no extra code needed
			// for every high detail point, like a triangle fan
			for(yLeft=yRight+jumpTo; yLeft <= (yRight+jumpFrom); yLeft+=jumpTo)
			{
				pIndexData[index]	= (yLeft)			* (TILE_SIZE+1) +	(x);
				pIndexData[index+1] = (yRight)			* (TILE_SIZE+1) +	(x+jumpFrom);
				pIndexData[index+2] = (yLeft-jumpTo)	* (TILE_SIZE+1) +	(x);
				index+=3;
			}

			// the "last" triangle at the top, not rendered at the "beginning" (so we can
			// use left and upper border without disturbing each other)
			if(yRight!=TILE_SIZE-jumpFrom)
			{
				pIndexData[index]	= (yRight+jumpFrom)  * (TILE_SIZE+1) +	(x);
				pIndexData[index+1]	= (yRight+jumpFrom)  * (TILE_SIZE+1) +	(x+jumpFrom);
				pIndexData[index+2]	= (yRight)			 * (TILE_SIZE+1) +	(x+jumpFrom);
				index+=3;
			}
		}
	}

	// create the index buffer
	if (FAILED(hr = pD3DDevice->CreateIndexBuffer(nrIndices * sizeof(WORD),
											D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
                                            D3DPOOL_MANAGED, pIB, NULL)))
    {
		LOG("Creating index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	if (FAILED(hr = (*pIB)->Lock( 0, sizeof(*pIndexData) * nrIndices, (VOID**)&pIndices, 0)))
	{
       	LOG("Locking index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	memcpy(pIndices, pIndexData, sizeof(*pIndexData) * nrIndices);
	(*pIB)->Unlock();

	delete []pIndexData;

	return S_OK;
}

/****************************************************************************
** Terrain initStateBlock
**
** set the render states for default rendering
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Terrain::initStateBlock()
{
	HRESULT hr;

	//create state blocks to change the render states
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr = pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}
		
		// textur stages for base and detail texture
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
		//pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		
		// set mirror
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSW, D3DTADDRESS_MIRROR );

		//set wireframe
		pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );
		
		pD3DDevice->SetFVF(D3DFVF_TERRAINVERTEX);
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,	D3DCULL_CCW);
					
		if (block == 0)
		{
			if (FAILED(hr = pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr = pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Terrain Render
**
** renders the whole terrain, checks the visibility before rendering
** chooses the right lod level and also draws the transitions between
** different lod levels
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT	Terrain::render(ModuleRenderType renderType)
{
	int x, y;
	int lod;
	TerrainTile *pActTile;
	bool detail;

	//set state block
	switch (renderType)
	{
	case DEPTH:
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,	D3DCULL_CCW);
		break;

	default:
		pSavedStateBlock->Capture();
		pStateBlock->Apply();
	}

	//set wire frame
	if (!wireframeEnabled)
		pD3DDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
	polyRendered = 0;
	tilesRendered = 0;

	// for every tile
	for(y = 0; y < nrTiles; y++)
		for(x = 0; x < nrTiles; x++)
	{
		// pointer, so we dont have to write the same thing so often
		pActTile = &pTerrainTiles[y*nrTiles+x];

		//if tile not visible... continue with next one
		if (!tileCheck.isVisible(pActTile))
			continue;

		//render in all parts
		for (int part=0;part<9;part++)
		{
			//if the tile in this part not visible ... continue with next part
			if(!tileCheck.isVisible(pActTile,part))
				continue;

			//set right culling
			if (renderType == REFLECTION)
				pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
			else 
				pD3DDevice->SetRenderState(D3DRS_CULLMODE, tileCheck.getCullingMode(part));

			// which lod does the tile have?
			lod = pActTile->chooseLOD(part);
			
			// set the correct lod index buffer
			switch(lod)
			{
			case HIGH_DETAIL:
				pD3DDevice->SetIndices(pHighIB);
				polyRendered += TILE_SIZE * TILE_SIZE * 2;
				break;
			case MEDIUM_DETAIL:
				pD3DDevice->SetIndices(pMediumIB);
				polyRendered += TILE_SIZE * TILE_SIZE * 2 / 4;
				break;
			case LOW_DETAIL:
				pD3DDevice->SetIndices(pLowIB);
				polyRendered += TILE_SIZE * TILE_SIZE * 2 / 16;
				break;
			case VERYLOW_DETAIL:
				pD3DDevice->SetIndices(pVeryLowIB);
				polyRendered += TILE_SIZE * TILE_SIZE * 2 / 64;
				break;
			}

			//no detail map while rendering for reflection or deep or not center part
			if ((renderType != DEFAULT) || (part != PART_CENTER) || !Config::instance->isDetailTexture())
				detail = false;
			else
				detail = pActTile->checkDetail();

			if (detail)
			{
				pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
				pD3DDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_ADDSIGNED);
				pD3DDevice->SetTexture( 1, pDetailTexture );
			}

			//set world to this part
			EngineHelpers::setWorldTransform(pD3DDevice,tileCheck.getTransformation(part),
											 renderType == DEPTH);

			// and render the tile, jipee!
			pActTile->render(renderType, lod, detail, part);

			// do we also have to render transitions?
			if (pActTile->isDifferentNeighbour(lod, part))
			{
				//get the upper transition
				int upperLOD = pActTile->getUpperLOD(part);
				if (upperLOD == -1) 
					upperLOD = VERYLOW_DETAIL;
				pD3DDevice->SetIndices(pUpperTransition[lod][upperLOD]);
								
				// render the upper transition
				pActTile->renderTransition(lod, upperLOD, detail);
				
				//get left transitions
				int leftLOD = pActTile->getLeftLOD(part);
				if (leftLOD == -1)
					leftLOD	= VERYLOW_DETAIL;
				pD3DDevice->SetIndices(pLeftTransition[lod][leftLOD]);

				// render the left transition
				pActTile->renderTransition(lod, leftLOD, detail);
			}

			// reset the detail texture settings
			if (detail == true)
			{
				pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
				pD3DDevice->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_DISABLE);
				pD3DDevice->SetTexture( 1, NULL );
			}

			tilesRendered++;
		}
	}

	//reset state block
	switch (renderType)
	{
	case DEPTH:
		pD3DDevice->SetRenderState(D3DRS_CULLMODE,	D3DCULL_NONE);
		break;

	default:
		pSavedStateBlock->Apply();
	}

	return Module::render(renderType);
}

/****************************************************************************
** Terrain Update
**
** updates the visibility of terrain tiles
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Terrain::update()
{
	//updates visibility of all terrain tiles
	tileCheck.update();

	// update the distances
	// this is needed because we need the actual distances to calculate
	// the correct transitions (without delay)
	for(int y = 0; y < nrTiles; y++)
		for(int x = 0; x < nrTiles; x++)
	{
		pTerrainTiles[y*nrTiles+x].updateDistance(Camera::instance->getPosition());
	}

	return Module::update();
}

/****************************************************************************
** Terrain getHeightInterpolated
**
** Get the height of the terrain at a 2D coordinate
**
** Author: Dirk Plate
****************************************************************************/
float Terrain::getHeightInterpolated(float x, float y)
{
	return pHeightmap->getInterpolatedHeightInEngineCoor(x,y);
}

/****************************************************************************
** Terrain getHeightInterpolatedSmooth
**
** Get the height of the terrain at a 2D coordinate
**
** Author: Dirk Plate
****************************************************************************/
float Terrain::getHeightInterpolatedSmooth(float x, float y)
{
	return pHeightmap->getInterpolatedHeigthInEngineCoorSmooth(x,y);
}

/****************************************************************************
** Terrain getHeight
**
** Get the height of the terrain at a 2D coordinate
**
** Author: Dirk Plate
****************************************************************************/
float Terrain::getHeight(int x, int y)
{
	return pHeightmap->getHeightInEngineCoor(x,y);
}

/****************************************************************************
** Terrain getNormal
**
** Get the normal of the terrain at a 2D coordinate
**
** Author: Dirk Plate
****************************************************************************/
D3DXVECTOR3 Terrain::getNormal(int x, int y)
{
	return pHeightmap->getNormal(x,y);
}

/****************************************************************************
** Terrain getInterpolatedNormal
**
** Get the normal of the terrain at a 2D coordinate
**
** Author: Dirk Plate
****************************************************************************/
D3DXVECTOR3 Terrain::getNormalInterpolatedSmooth(float fx, float fy)
{
	return pHeightmap->getInterpolatedNormalSmooth(fx,fy);
}

/****************************************************************************
** Terrain getLightColor
**
** Get the light color of the terrain at a 2D coordinate
**
** Author: Dirk Plate
****************************************************************************/
D3DXCOLOR Terrain::getLightColor(int x, int y)
{
	return pLightmap->getLightColor(x,y);
}

/****************************************************************************
** Terrain intersectSunTileRay
**
** Check the intersection of a line-segment with the terrain and return
** the intersection point, if a intersection occur. Otherwise S_FALSE.
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Terrain::intersectSunRay(D3DXVECTOR3 rayStart, D3DXVECTOR3 rayEnd, POINT *pIntersectionTile, bool exact)
{
	int		i;
	float	x1,y1,x2,y2;	//the position of the beginning and the ending
	float	x,y;
	float	dX, dY;
	float	sX, sY;
	POINT	hitTile;		//which tile?
	int		steps;
	bool	moreDX;			//more x-Difference or y-Difference?
	float	scaleY = pHeightmap->getEngineScaleY();
	int		terrainSize = pHeightmap->getSize();
	D3DXVECTOR3 rayDir = rayEnd-rayStart;
	float	stepJumpFactor;
	bool	goOn,nextAbove;
	float	heightOfTile,heightOfRay;
	bool	rayNowhereAbove;	//flag for correct shadows at borders

	//is the origin higher than the highest mountain?
	if (rayStart.y > 256.0f*scaleY)
	{
		//then find the point on the ray, which is exact as high as the highest mountain
		EngineHelpers::getXZCoordinateOfRay(&rayStart,&rayDir,&x2,256.0f*scaleY,&y2);
	}
	//else is the origin lower than lowest valley?
	else if (rayStart.y < 0.0f)
	{
		//then find the point on the ray, which is exact as low as the lowest valley
		EngineHelpers::getXZCoordinateOfRay(&rayStart,&rayDir,&x2,0.0f,&y2);
	}
	else	//take the origin as the beginning
	{
		x2 = rayStart.x;
		y2 = rayStart.z;
	}

	x1 = rayEnd.x;
	y1 = rayEnd.z;

	steps=0;
	hitTile.x = -1;
	hitTile.y = -1;

	dX = x2-x1;
	dY = y2-y1;
	x = x2;
	y = y2;

	//find the nr. of steps and stepwidth
	if (fabs(dX)>fabs(dY))
	{
		if (dX>0)  sX = -1; else sX = 1;
		if (dX==0)  sY = 0; else sY = (float)dY/((float)(dX*sX));
		steps = fabs(dX);
		moreDX = true;
	}
	else
	{
		if (dY>0)  sY = -1; else sY = 1;
		if (dY==0)  sX = 0; else sX = (float)dX/((float)(dY*sY));
		steps = fabs(dY);
		moreDX = false;
	}

	//jump to border of (wide) terrain
	stepJumpFactor = 0;
	if (x < -terrainSize) stepJumpFactor = MAX((-x-terrainSize)/sX,stepJumpFactor);
	else if (x >= 2*terrainSize) stepJumpFactor = MAX((x-2*terrainSize)/(-sX),stepJumpFactor);
	if (y < -terrainSize) stepJumpFactor = MAX((-y-terrainSize)/sY,stepJumpFactor);
	else if (y >= 2*terrainSize) stepJumpFactor = MAX((y-2*terrainSize)/(-sY),stepJumpFactor);

	x += sX*stepJumpFactor;
	y += sY*stepJumpFactor;
	steps -= stepJumpFactor;

	nextAbove = false;
	if ((stepJumpFactor != 0) && (steps > 0)) rayNowhereAbove = true;
	else rayNowhereAbove = false;

	for (i=0; i<steps; i++)
	{
		heightOfTile = pHeightmap->getInterpolatedHeigthInEngineCoorSmooth(x,y);
		heightOfRay = EngineHelpers::getHeightOfRay(&rayStart,&rayDir,x,y);

		if ((rayNowhereAbove) && (heightOfRay > heightOfTile))	
			rayNowhereAbove = false;

		//find the first tile, which is higher or lower than the ray
		if (((!nextAbove) && (heightOfTile > heightOfRay)) ||
			(( nextAbove) && (heightOfTile < heightOfRay)))
		{
			hitTile.x = (int)(x);
			hitTile.y = (int)(y);

			//should we find the exact point?
			if (exact)
			{
				//find the exact point
				int j,k;
				float	tmpX = x,tmpY = y;		//the latest exact coordinates
				int		tileX,tileY;			//the coordinates of the neighb. tiles
				int		tileX2,tileY2;

				goOn = false;

				k=2;
				while (!getIntersectionDetail(&rayStart, &rayDir,hitTile.x, hitTile.y))
				{
					//check the other tiles around at this step (fuzzy)
					if (moreDX)
					{
						tileX  = hitTile.x;
						tileY  = hitTile.y+1;
						tileX2 = hitTile.x;
						tileY2 = hitTile.y-1;
					}
					else
					{
						tileX  = hitTile.x+1;
						tileY  = hitTile.y;
						tileX2 = hitTile.x-1;
						tileY2 = hitTile.y;
					}
					if (getIntersectionDetail(&rayStart, &rayDir,tileX, tileY)) break;
					if (getIntersectionDetail(&rayStart, &rayDir,tileX2, tileY2)) break;

					//check the other tiles on the line
					if (k%2 == 0) j = (k-k%2)/2;
					else j = -(k-k%2)/2;
					tmpX = x+j*sX;
					tmpY = y+j*sY;
					hitTile.x = int(tmpX);
					hitTile.y = int(tmpY);
					k++;
					if (k == 8)
					{
						//if the last one was higher... than find now the lower one or otherwise
						nextAbove = !nextAbove;

						goOn = true;
						break;
					}
				}
				if (!goOn) break;
			}
			else break;


		}
		x += sX;
		y += sY;
	}

	//if no tile found
	if ((hitTile.x == -1) &&  (!rayNowhereAbove)) return S_FALSE;

	if (pIntersectionTile != NULL)
		*pIntersectionTile = hitTile;

	return S_OK;
}

/****************************************************************************
** Terrain getIntersectionDetail
**
** get the intersection coordinates if you know the 2D integer coordinate of the
** intersection position
**
** Author: Dirk Plate
****************************************************************************/

bool Terrain::getIntersectionDetail(D3DXVECTOR3 *rayPos, D3DXVECTOR3 *rayDir, int intX, int intY)
{
	D3DXVECTOR3 t0,t1,t2,tmp;
	int			terrainSize = pHeightmap->getSize();

	//check terrain bounds
	if ((intX < 0) || (intX >= terrainSize) ||
		(intY < 0) || (intY >= terrainSize))
		return false;

	//get the coordinates of the first triangle
	t0.x = (float)intX-SMALL_NUM;
	t0.y = pHeightmap->getHeightInEngineCoor(intX,intY);
	t0.z = (float)intY-SMALL_NUM;
	t1.x = (float)(intX+1)+SMALL_NUM;
	t1.y = pHeightmap->getHeightInEngineCoor(intX+1,intY);
	t1.z = (float)intY-SMALL_NUM;
	t2.x = (float)intX-SMALL_NUM;
	t2.y = pHeightmap->getHeightInEngineCoor(intX,intY+1);
	t2.z = (float)(intY+1)+SMALL_NUM;

	if (EngineHelpers::intersectRayTriangle(rayPos, rayDir,&t0,&t1,&t2,false,&tmp)) return true;

	//if (D3DXIntersectTri(&t0,&t1,&t2,rayPos,rayDir,&u,&v,&dist)) return true;

	//test the second triangle
	t0.x = (float)(intX+1)+SMALL_NUM;
	t0.y = pHeightmap->getHeightInEngineCoor(intX+1,intY+1);
	t0.z = (float)(intY+1)+SMALL_NUM;

	if (EngineHelpers::intersectRayTriangle(rayPos, rayDir,&t0,&t1,&t2,false,&tmp)) return true;

	return false;
}

/****************************************************************************
** Terrain getHighestHeight
**
** get the highest possible height of the terrain
**
** Author: Dirk Plate
****************************************************************************/

float Terrain::getHighestHeight()
{
	return pHeightmap->getEngineScaleY()*255.0f;
}

/****************************************************************************
** Terrain transformHeightInMetersToEngineCoor
**
** calculate a height value in meters to a height value in engine coordinates
**
** Author: Dirk Plate
****************************************************************************/

float Terrain::transformHeightInMetersToEngineCoor(float heightInMeters, bool absolute)
{
	if (absolute)
	{
		if (pHeightmap->getMeterScaleY() < SMALL_NUM)
			return 0.0f;
		else return ((heightInMeters-pHeightmap->getMinHeightInMeters())/pHeightmap->getMeterScaleY())*
					pHeightmap->getEngineScaleY();
	}
	else
	{
		if (pHeightmap->getMeterScaleY() < SMALL_NUM)
			return 0.0f;
		else return (heightInMeters/pHeightmap->getMeterScaleY())*
					pHeightmap->getEngineScaleY();
	}
}

/****************************************************************************
** Terrain getStatusMessage
**
** implementation of status source (called by status line)
**
** Author: Dirk Plate
****************************************************************************/
std::string Terrain::getStatusMessage()
{
	char buffer[256];

	sprintf(buffer, "Terrain Tiles rendered: %03d, Polygons: %06d", 
		Terrain::instance->tilesRendered, Terrain::instance->polyRendered);
	
	std::string statusMessage(buffer);

	return statusMessage;
}

/****************************************************************************
** Terrain areMirroredTiles
**
** return if terrain tiles are mirrored around center terrain
**
** Author: Dirk Plate
****************************************************************************/
bool Terrain::areMirroredTiles()
{
	return tileCheck.areMirroredTiles();
}