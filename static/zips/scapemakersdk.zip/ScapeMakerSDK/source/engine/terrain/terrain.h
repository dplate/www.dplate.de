/****************************************************************************
** Terrain
**
** terrain rendering and management class
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(TERRAIN_H)
#define TERRAIN_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include "heightmap.h"
#include "lightmap.h"
#include "terraintile.h"
#include "../camera/viewfrustum.h"
#include "../module.h"
#include "../hud/statusline.h"
#include "../common/tilecheck.h"

class Terrain : public Module, public StatusSource
{
public:
	Terrain();
	~Terrain();

	HRESULT update();
	HRESULT render(ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();

	HRESULT createGeometryForShadowGen(const char *enginePath);
	HRESULT	destroyGeometryForShadowGen();

	HRESULT intersectSunRay(D3DXVECTOR3 rayStart, D3DXVECTOR3 rayEnd, 
		POINT *pIntersectionTile, bool exact);

	void enableWireframe() {wireframeEnabled = true; }
	void disableWireframe() {wireframeEnabled = false; }

	float	getHeightInterpolated(float x, float y);
	float	getHeightInterpolatedSmooth(float x, float y);
	float	getHeight(int x, int y);
	D3DXVECTOR3 getNormal(int x, int y);
	D3DXVECTOR3 getNormalInterpolatedSmooth(float fx, float fy);
	D3DXCOLOR getLightColor(int x, int y);
	int		getWidth() { return heightmapSize+1; }
	float	getHighestHeight();
	float	transformHeightInMetersToEngineCoor(float heightInMeters, bool absolute);
	bool	areMirroredTiles();

	//implementation of status source
	virtual std::string getStatusMessage();

	static Terrain *instance;	//the instance to the only one terrain objects
	int		polyRendered;
	int		tilesRendered;

private:
	HRESULT initTiles();
	HRESULT initIndexBuffers();
	HRESULT initIndexBuffer(int lod, LPDIRECT3DINDEXBUFFER9 *pIB);
	HRESULT initIndexBufferLODTransitionUpper(int lodFrom, int lodTo, LPDIRECT3DINDEXBUFFER9 *pIB);
	HRESULT initIndexBufferLODTransitionLeft(int lodFrom, int lodTo, LPDIRECT3DINDEXBUFFER9 *pIB);
	HRESULT initStateBlock();

	bool	getIntersectionDetail(D3DXVECTOR3 *rayPos, D3DXVECTOR3 *rayDir,int intX, int intY);

	bool wireframeEnabled;	//is wireframe mode enabled?

	int		nrTiles;

	int			heightmapSize;
	Heightmap	*pHeightmap;
	Lightmap	*pLightmap;

	TerrainTile	*pTerrainTiles;

	//visible checker for terrain tiles
	TileCheck	tileCheck;

	LPDIRECT3DDEVICE9 pD3DDevice;

	LPDIRECT3DINDEXBUFFER9	pHighIB;
	LPDIRECT3DINDEXBUFFER9	pMediumIB;
	LPDIRECT3DINDEXBUFFER9	pLowIB;
	LPDIRECT3DINDEXBUFFER9	pVeryLowIB;

	LPDIRECT3DINDEXBUFFER9	pUpperTransition[4][4];
	LPDIRECT3DINDEXBUFFER9  pLeftTransition[4][4];

	LPDIRECT3DTEXTURE9		pDetailTexture;

	LPDIRECT3DSTATEBLOCK9	pStateBlock;		//used state block for default rendering
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;	//saved old state block for default rendering
};

#endif