#include "terraintile.h"

#include "../logger/logger.h"
#include "../common/aabb.h"
#include "../camera/viewfrustum.h"
#include "heightmap.h"
#include "../../common/minixml.h"
#include "../common/config.h"

/****************************************************************************
** GetJumpFromLOD
**
** jump values are 1, 2, 4, 8 ...
** 2 means that we just choose every second heightmap point (e.g. for lod
** level "medium")
**
** Author: Matthias Buchetics
****************************************************************************/
int getJumpFromLod(int lod)
{
	switch(lod)
	{
	case HIGH_DETAIL:
		return 1;
	case MEDIUM_DETAIL:
		return 2;
	case LOW_DETAIL:
		return 4;
	case VERYLOW_DETAIL:
		return 8;
	}

	return 0;
}

/****************************************************************************
** TerrainTile Constructor
**
** set pointers to NULL
**
** Author: Matthias Buchetics
****************************************************************************/
TerrainTile::TerrainTile()
{
	Tile::Tile();

	pVB = NULL;
	pBaseTexture = NULL;
	pD3DDevice = NULL;
	pHeightmap = NULL;
	
	configLod = Config::instance->getTerrainLOD();

	if(configLod == CONFIG_HIGH || configLod == CONFIG_FULL)
	{
		distanceDetail = 50.0f;
		errorFactor = 120.0f;
	}
		
	if(configLod == CONFIG_MEDIUM)
	{
		distanceDetail = 40.0f;
		errorFactor = 60.0f;
	}
		
	if(configLod == CONFIG_LOW)
	{
		distanceDetail = 30.0f;
		errorFactor = 30.0f;
	}		
}

TerrainTile::~TerrainTile()
{
}

/****************************************************************************
** TerrainTile Render
**
** render the tile with the given detail level (called from the terrain class)
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT	TerrainTile::render(ModuleRenderType renderType, int lod, bool detail, int part)
{
	// nr of vertices in the vertex buffer
	int nrVertices = (TILE_SIZE+1)*(TILE_SIZE+1);

	// get the jump value for the lod level
	int jump = getJumpFromLod(lod);

	// how many triangles do we have to render
	int nrTriangles = (TILE_SIZE * TILE_SIZE * 2)/(jump*jump);

	// set the vertex buffer
	pD3DDevice->SetStreamSource( 0, pVB, NULL, sizeof(TERRAINVERTEX) );

	//no texture in deep rendering
	if (renderType != DEPTH)
		pD3DDevice->SetTexture(0, pBaseTexture);

	// if the neighbour tiles are different, we just render the main middle tile
	// (less triangles)
	if(isDifferentNeighbour(lod, part))
		nrTriangles -= (TILE_SIZE/jump*2 + (TILE_SIZE/jump-1)*2);

	// render the tile (the index buffer is set at the terrain render function, not here)
	pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, nrVertices, 0, nrTriangles);

	return S_OK;
}

/****************************************************************************
** TerrainTile RenderTransition
**
** render the transition tile for the given lod levels
** note: index buffers are set at the terrain class render function, not here!
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT TerrainTile::renderTransition(int lodFrom, int lodTo, bool detail)
{
	int jumpFrom = getJumpFromLod(lodFrom);
	int jumpTo = getJumpFromLod(lodTo);
	int nrVertices = (TILE_SIZE+1)*(TILE_SIZE+1);

	// number of triangles in the transition (see the transition tile generation)
	int nrIndices = ((TILE_SIZE/jumpFrom) + (TILE_SIZE/jumpTo) - 1) * 3;
	int nrTriangles = nrIndices/3;

	// render the transition
	pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, nrVertices, 0, nrTriangles);
	
	return S_OK;
}

/****************************************************************************
** TerrainTile InitTile
**
** store variables, create the vertex buffer and calc the error values of
** each tile
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT TerrainTile::initTile(int tilex, int tiley, int heightmapSize, bool mirroredTiles, Heightmap *pHeightmap, LPDIRECT3DDEVICE9 pD3DDevice)
{
	this->pHeightmap = pHeightmap;
	this->pD3DDevice = pD3DDevice;
	this->heightmapSize = heightmapSize;
	this->mirroredTiles = mirroredTiles;
	this->tilex = tilex;
	this->tiley = tiley;

	initVertexBuffer();		// create the index buffer of the tile
	calcErrors();			// calc the error values

	return S_OK;
}

/****************************************************************************
** TerrainTile InitVertexBuffer
**
** create the index buffer of the tile (every point considered, so the vertex
** buffer is always at the highest possible detail level)
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT TerrainTile::initVertexBuffer()
{
	int x, y;
	int nrVertices = (TILE_SIZE+1)*(TILE_SIZE+1);
	int index = 0;
	HRESULT hr;

	// allocate memory for the vertex data
	TERRAINVERTEX *pVertexData = new TERRAINVERTEX[nrVertices];
	VOID* pVertices;

	// the vertex list is used to create the AABB
	D3DXVECTOR3	*pVertexList = new D3DXVECTOR3[nrVertices];

	// for every point
	for(y=0; y < TILE_SIZE+1; y++)
		for(x=0; x < TILE_SIZE+1; x++, index++)
		{
			// get the height value of this point
			int hlpx = tilex*TILE_SIZE + x;
			int hlpy = tiley*TILE_SIZE + y;
			float height = pHeightmap->getHeightInEngineCoor(hlpx, hlpy);

			// scale the X and Z values (height is automaticaly scaled by the
			// getheight function
			// store the terrain vertex in array
			pVertexData[index].position.x = hlpx;
			pVertexData[index].position.y = height;
			pVertexData[index].position.z = hlpy;

			// store the same stuff in the vertex list
			pVertexList[index].x = pVertexData[index].position.x;
			pVertexList[index].y = pVertexData[index].position.y;
			pVertexList[index].z = pVertexData[index].position.z;

			// texture coordinates (for the base texture)
			pVertexData[index].tu = (float)x/TILE_SIZE;
			pVertexData[index].tv = 1.0f-(float)y/TILE_SIZE;

			// texture coordinates (for the detail texture)
			pVertexData[index].detail_tu = (float)x;
			pVertexData[index].detail_tv = TILE_SIZE - (float)y;
		}

	// create the bounding box with the vertex list
	pBoundingBox = new AABB(pVertexList, nrVertices);

	// last but not least create the vertex buffer with the vertex data
	if(FAILED(hr=pD3DDevice->CreateVertexBuffer( nrVertices*sizeof(TERRAINVERTEX),
                                                  D3DUSAGE_WRITEONLY, D3DFVF_TERRAINVERTEX,
                                                  D3DPOOL_MANAGED, &pVB, NULL)))
	{
		LOG("Creating vertex buffer failed", Logger::LOG_CRIT);
        return hr;
	}

    if(FAILED(hr=pVB->Lock( 0, sizeof(*pVertexData) * nrVertices, (VOID**)&pVertices, 0)))
    {
		LOG("vertex buffer lock failed", Logger::LOG_CRIT);
        return hr;
	}

    memcpy( pVertices, pVertexData, sizeof(*pVertexData) * nrVertices );
	pVB->Unlock();

	// delete the array, we dont need them anymore
	delete []pVertexData;
	delete []pVertexList;

	return S_OK;
}

/****************************************************************************
** TerrainTile LoadTexture
**
** load the base texture for each tile
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT TerrainTile::loadTexture(char *filenameTexture)
{
	HRESULT hr;

	// we use compressed textures (DXT1 format)
	if(FAILED(hr=D3DXCreateTextureFromFileEx(pD3DDevice, filenameTexture, D3DX_DEFAULT,
		D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_DXT1, D3DPOOL_MANAGED, D3DX_FILTER_BOX | D3DX_FILTER_MIRROR,
		D3DX_FILTER_BOX | D3DX_FILTER_MIRROR, 0, NULL, NULL, &pBaseTexture)))
	{
		LOG("Loading terrain texture failed", Logger::LOG_CRIT);
		return hr;
    }

	return S_OK;
}

/****************************************************************************
** TerrainTile CalcErrors
**
** calculate the error values for each tile and each lod level
**
** Author: Matthias Buchetics
****************************************************************************/
void TerrainTile::calcErrors()
{
	int x,y;
	int lu_x, lu_y, rd_x, rd_y;
	float errorAct;

	// HIGH ERROR
	// the high detail error is alway 0, because we render everything at
	// high detail
	errorHigh = 0.0f;

	// MEDIUM ERROR
	errorAct = 0.0f;

	// for every tile
	for(y=0; y<TILE_SIZE+1; y++)
		for(x=0; x<TILE_SIZE+1; x++)
		{
			// coordinates for interpolating (see getInterpolatedHeightEx())
			int hlpx = tilex*TILE_SIZE + x;
			int hlpy = tiley*TILE_SIZE + y;

			lu_x = floor((float)hlpx/2)*2;

			if(x == TILE_SIZE)
				rd_x = lu_x;
			else
				rd_x = lu_x + 2;

			lu_y = floor((float)hlpy/2)*2;

			if(y == TILE_SIZE)
				rd_y = lu_y;
			else
				rd_y = lu_y + 2;

			// calc the error
			float realHeight = pHeightmap->getHeightInEngineCoor(hlpx, hlpy);
			float interpolatedHeight = pHeightmap->getInterpolatedHeightInEngineCoorEx(lu_x, lu_y, rd_x, rd_y, hlpx, hlpy);
			float error = fabs(realHeight-interpolatedHeight);

			// store the maximal error
			if(error>errorAct)
				errorAct=error;
		}
	errorMedium = errorAct;

	// the other errors are calculated the exact same way

	// LOW ERROR
	errorAct = 0.0f;
	for(y=0; y<TILE_SIZE+1; y++)
		for(x=0; x<TILE_SIZE+1; x++)
		{
			int hlpx = tilex*TILE_SIZE + x;
			int hlpy = tiley*TILE_SIZE + y;

			lu_x = floor((float)hlpx/4)*4;

			if(x == TILE_SIZE)
				rd_x = lu_x;
			else
				rd_x = lu_x + 4;

			lu_y = floor((float)hlpy/4)*4;

			if(y == TILE_SIZE)
				rd_y = lu_y;
			else
				rd_y = lu_y + 4;

			float realHeight = pHeightmap->getHeightInEngineCoor(hlpx, hlpy);
			float interpolatedHeight = pHeightmap->getInterpolatedHeightInEngineCoorEx(lu_x, lu_y, rd_x, rd_y, hlpx, hlpy);
			float error = fabs(realHeight-interpolatedHeight);

			if(error>errorAct)
				errorAct=error;
		}
	errorLow = errorAct;

	// VERY LOW ERROR
	errorAct = 0.0f;
	for(y=0; y<TILE_SIZE+1; y++)
		for(x=0; x<TILE_SIZE+1; x++)
		{
			int hlpx = tilex*TILE_SIZE + x;
			int hlpy = tiley*TILE_SIZE + y;

			lu_x = floor((float)hlpx/8)*8;

			if(x == TILE_SIZE)
				rd_x = lu_x;
			else
				rd_x = lu_x + 8;

			lu_y = floor((float)hlpy/8)*8;

			if(y == TILE_SIZE)
				rd_y = lu_y;
			else
				rd_y = lu_y + 8;

			float realHeight = pHeightmap->getHeightInEngineCoor(hlpx, hlpy);
			float interpolatedHeight = pHeightmap->getInterpolatedHeightInEngineCoorEx(lu_x, lu_y, rd_x, rd_y, hlpx, hlpy);
			float error = fabs(realHeight-interpolatedHeight);

			if(error>errorAct)
				errorAct=error;
		}
	errorVeryLow = errorAct;

}

/****************************************************************************
** TerrainTile chooseLOD
**
** chooses the lod level according to the distance and the error value
** of the tile
**
** Author: Matthias Buchetics
****************************************************************************/
int TerrainTile::chooseLOD(int part)
{
	if (mirroredTiles)
	{
		//nearly any other parts than center has very low detail
		if ((part == PART_CENTER) || 
			((part == PART_RIGHT) && (tilex==nrTiles-1)) ||
			((part == PART_TOP) && (tiley==0)) || 
			((part == PART_TOPRIGHT) && (tiley==0) && (tilex==nrTiles-1)))
		{
			if(configLod == CONFIG_FULL)
				return HIGH_DETAIL;
			
			float hlp = minDistance/errorFactor;

			if(errorVeryLow < hlp)
				return VERYLOW_DETAIL;
			else if(errorLow < hlp)
				return LOW_DETAIL;
			else if(errorMedium < hlp)
				return MEDIUM_DETAIL;
			else return HIGH_DETAIL;
		}
		else return VERYLOW_DETAIL;
	}
	else
	{
		//any other parts than center has very low detail
		if (part == PART_CENTER)
		{
			if(configLod == CONFIG_FULL)
				return HIGH_DETAIL;
			
			float hlp = minDistance/errorFactor;

			if(errorVeryLow < hlp)
				return VERYLOW_DETAIL;
			else if(errorLow < hlp)
				return LOW_DETAIL;
			else if(errorMedium < hlp)
				return MEDIUM_DETAIL;
			else return HIGH_DETAIL;
		}
		else return VERYLOW_DETAIL;
	}
}

/****************************************************************************
** TerrainTile checkDetail
**
** check if the detail texture should be rendered or not
**
** Author: Matthias Buchetics
****************************************************************************/
bool TerrainTile::checkDetail()
{
	if(minDistance < distanceDetail)
		return true;
	else
		return false;
}

/****************************************************************************
** TerrainTile GetUpperLOD
**
** get the detail level of the upper neighbour
**
** Author: Matthias Buchetics
****************************************************************************/
int TerrainTile::getUpperLOD(int part)
{
	if(pUpperTile)
		return pUpperTile->chooseLOD(part);
	else if ((part == PART_TOP) && (!mirroredTiles))
		return pTerrainTiles[0*nrTiles+tilex].chooseLOD(PART_CENTER);

	// return -1 if there is no upper neighbour (tile is at the top border)
	return -1;
}

/****************************************************************************
** TerrainTile GetLeftLOD
**
** get the detail level of the left neighbour
**
** Author: Matthias Buchetics
****************************************************************************/
int TerrainTile::getLeftLOD(int part)
{
	if(pLeftTile)
		return pLeftTile->chooseLOD(part);
	else if ((part == PART_RIGHT) && (!mirroredTiles))
		return pTerrainTiles[tiley*nrTiles+(nrTiles-1)].chooseLOD(PART_CENTER);
	// return -1 if there is no left neighbour (tile is at the left border)
	return -1;
}

/****************************************************************************
** TerrainTile UpdateDistance
**
** calculate the camera distance from the nearest point of the tile to
** the camera position (the viewer)
**
** Author: Matthias Buchetics
****************************************************************************/
void TerrainTile::updateDistance(D3DXVECTOR3 cameraPos)
{
	pBoundingBox->getMinDistance(cameraPos,&minDistance);
}

/****************************************************************************
** TerrainTile IsDifferentNeighbour
**
** check if one of the neighbours (left or upper) has a different lod level
** then this tile
**
** Author: Matthias Buchetics
****************************************************************************/
int TerrainTile::isDifferentNeighbour(int detail, int part)
{
	if (mirroredTiles)
	{
		if (((pUpperTile == NULL) && (VERYLOW_DETAIL != detail)) ||
			((pLeftTile == NULL)  && (VERYLOW_DETAIL != detail)))
			return true;
		else if ((pUpperTile != NULL && pUpperTile->chooseLOD(part) != detail) ||
				 (pLeftTile != NULL && pLeftTile->chooseLOD(part) != detail))
			return true;
	}
	else
	{
		if (pUpperTile == NULL)
		{
			if (part == PART_CENTER)
			{
				if (VERYLOW_DETAIL != detail)
					return true;
			}
			else if (part == PART_TOP)
			{
				if (pTerrainTiles[0*nrTiles+tilex].chooseLOD(PART_CENTER) != detail)
					return true;
			}
		}
		else
		{
			if (pUpperTile->chooseLOD(part) != detail)
				return true;
		}
		
		if (pLeftTile == NULL)
		{
			if (part == PART_CENTER)
			{
				if (VERYLOW_DETAIL != detail)
					return true;
			}
			else if (part == PART_RIGHT)
			{
				if (pTerrainTiles[tiley*nrTiles+(nrTiles-1)].chooseLOD(PART_CENTER) != detail)
					return true;
			}
		}
		else
		{
			if (pLeftTile->chooseLOD(part) != detail)
				return true;
		}
	}
	return false;
}

/****************************************************************************
** TerrainTile DestroyGeometry
**
** release the vertex buffer and the texture
**
** Author: Matthias Buchetics
****************************************************************************/
HRESULT TerrainTile::destroyGeometry()
{
	if(pVB)
	{
		pVB->Release();
		pVB = NULL;
	}
	if(pBaseTexture)
	{
		pBaseTexture->Release();
		pBaseTexture = NULL;
	}

	delete pBoundingBox;

	return S_OK;
}

/****************************************************************************
** TerrainTile SetNeighbours
**
** set the pointers to the neighbour tiles (so we dont have to calc it every
** time)
**
** Author: Matthias Buchetics
****************************************************************************/
void TerrainTile::setNeighbours(TerrainTile *pTerrainTiles, int nrTiles)
{
	this->nrTiles = nrTiles;
	this->pTerrainTiles = pTerrainTiles;

	if(tiley < (nrTiles-1))
		pUpperTile = &pTerrainTiles[(tiley+1)*nrTiles+tilex];
	else
		pUpperTile = NULL;

	if(tilex > 0)
		pLeftTile = &pTerrainTiles[tiley*nrTiles+(tilex-1)];
	else
		pLeftTile = NULL;
}





















