/****************************************************************************
** TerrainTile
**
** terrain is split up in tiles (33x33 big), this class handles the
** single tiles
** 
** Author: Matthias Buchetics
****************************************************************************/

#if !defined(TERRAINTILE_H)
#define TERRAINTILE_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <stdio.h>
#include <qimage.h>
#include "../camera/viewfrustum.h"
#include "../common/tilecheck.h"
#include "../module.h"
#include "heightmap.h"

struct TERRAINVERTEX
{
     D3DXVECTOR3 position;
	 float		 tu, tv;
	 float		 detail_tu, detail_tv;
};

#define D3DFVF_TERRAINVERTEX (D3DFVF_XYZ | D3DFVF_TEX2)

const int TILE_SIZE = 32;		// 32x32 quads (33x33 vertices)
const int HIGH_DETAIL = 0;
const int MEDIUM_DETAIL = 1;
const int LOW_DETAIL = 2;
const int VERYLOW_DETAIL = 3;
const int FULL_DETAIL = 4;

const int CONFIG_FULL = 3;
const int CONFIG_HIGH = 2;
const int CONFIG_MEDIUM = 1;
const int CONFIG_LOW = 0;

// retrieve the jump values (1,2,4,8) for the lod levels
int getJumpFromLod(int lod);

class TerrainTile : public Tile
{
public:
	TerrainTile();
	~TerrainTile();

	HRESULT render(ModuleRenderType renderType, int lod, bool detail, int part);
	HRESULT renderTransition(int lodFrom, int lodTo, bool detail);

	HRESULT initTile(int tilex, int tiley, int heightMapSize, bool mirroredTiles, Heightmap *pHeightMap, LPDIRECT3DDEVICE9 pD3DDevice);

	HRESULT loadTexture(char *filenameTexture);
	void	setNeighbours(TerrainTile *pTerrainTiles, int nrTiles);	

	int		chooseLOD(int part);
	bool	checkDetail();
	void	updateDistance(D3DXVECTOR3 cameraPos);
	int		isDifferentNeighbour(int detail, int part);
	
	int		getUpperLOD(int part);
	int		getLeftLOD(int part);

	HRESULT destroyGeometry();


private:
	HRESULT initVertexBuffer();
	void	calcErrors();

	int			heightmapSize;	// how big is the heightmap (256x256, 512x512 ...)
	Heightmap	*pHeightmap;	// pointer to the heightmap object
	
	// coordinates of this tile
	int		tilex;	
	int		tiley;

	//all other terrain tiles
	TerrainTile *pTerrainTiles;

	//number of tiles
	int		nrTiles;

	//tiles other of center part are mirrored
	bool	mirroredTiles;

	// minimum distance to the camera
	float	minDistance;

	// the error values of this tile
	float	errorHigh;
	float	errorMedium;
	float	errorLow;
	float	errorVeryLow;

	// the config lod value
	int		configLod;

	// the detail texture distance
	float	distanceDetail;

	// "error factor" to choose lod level
	float	errorFactor;

	// pointer to the neighbour tiles
	TerrainTile *pUpperTile;
	TerrainTile *pLeftTile;

	LPDIRECT3DVERTEXBUFFER9 pVB;			// vertex buffer
	LPDIRECT3DDEVICE9		pD3DDevice;
	LPDIRECT3DTEXTURE9		pBaseTexture;	// base texture of the tile
};

#endif




















