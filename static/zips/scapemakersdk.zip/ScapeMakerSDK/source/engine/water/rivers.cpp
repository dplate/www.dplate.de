#include "rivers.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../common/enginehelpers.h"
#include "../camera/camera.h"
#include "../terrain/terrain.h"
#include "../sky/sky.h"
#include "../../common/minixml.h"
#include "../common/config.h"


/****************************************************************************
** Rivers Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
Rivers::Rivers()
{
	enabled = true;
	used = true;
	wireframeEnabled = false;

	pRiversMap = NULL;

	lightMapTexture = NULL;
	streamTexture = NULL;
	normalTexture = NULL;
	cubeTexture = NULL;

	pEnvironmentStateBlock = NULL;
	pEnvironmentSavedStateBlock = NULL;
	pTextureStateBlock = NULL;
	pTextureSavedStateBlock = NULL;
	pLightMapStateBlock = NULL;
	pLightMapSavedStateBlock = NULL;
	
	environmentVertexShader = NULL;
	environmentVertexDecl = NULL;
	environmentPixelShader = NULL;

	D3DXMatrixIdentity(&textureMatrix);

	normalRotation = 0.0f;

	pRiversTiles = NULL;
	riversTilesCount = 0;
}

Rivers::~Rivers()
{
}

/****************************************************************************
** Rivers CreateGeometry
**
** create and initializes the sea
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, 
							   float seaHeight, float reflection, float transparency, D3DXCOLOR color,
							   LPDIRECT3DTEXTURE9 lightMapTexture, LPDIRECT3DTEXTURE9 waterTexture)
{
	LOGFUNC("createGeometry()");

	int x,y;
	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;
	this->reflection = reflection;
	this->transparency = transparency;
	this->color = color;
	this->lightMapTexture = lightMapTexture;
	this->waterTexture = waterTexture;

	//the width of terrain
	terrainWidth = Terrain::instance->getWidth();

	//create array with informations about all river elements
	pRiversMap = new RiversMap(terrainWidth);

	//fill array with saved river elements
	int no = 0;
	used = false;
	MiniXML xmlFile;
	if (xmlFile.openFile((Config::instance->getEnginePath()+"/rivers.txt").c_str(),MiniXML::READ))
	{
		if (xmlFile.startReadList("rivers"))
		{
			//try to load information about each element
			while (xmlFile.startReadListElement(no))
			{
				int value;
				float fValue;
				bool bValue;
				int x = 0, y = 0;

				if (xmlFile.readInteger("x", &value))
					x = value;
				if (xmlFile.readInteger("y", &value))
					y = value;

				//get element
				RiversMap::OneWaterElement *pElement = NULL;
				if (pRiversMap->getElement(x,y,&pElement))
				{
					pElement->used = true;
					used = true;

					if (xmlFile.readFloat("amount", &fValue))
						pElement->amount = Terrain::instance->transformHeightInMetersToEngineCoor(fValue,false);
					
					if (xmlFile.readFloat("streamStrength", &fValue))
						pElement->streamStrength = fValue;

					if (xmlFile.readFloat("tu", &fValue))
						pElement->tu = fValue;

					if (xmlFile.readFloat("tv", &fValue))
						pElement->tv = fValue;

					if (xmlFile.readBoolean("border", &bValue))
						pElement->border = bValue;
				}

				xmlFile.endReadListElement();
				no++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	//no rivers... cancel
	if (!used)
		return S_OK;

	//create steam particle
	if (FAILED(hr=Particles::instance->addParticleType("./enginefiles/watersteam.png",steamParticle)))
		return hr;

	//set right height for border water elements
	for (y=0;y<terrainWidth;y++)
		for (x=0;x<terrainWidth;x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;
			
			//only border elements
			if (!pElement->border)
				continue;

			//retrieve right height
			float meanAbsHeight = 0;
			int meanCount = 0;
			for (int checkY = y-1; checkY <= y+1; checkY++)
				for (int checkX = x-1; checkX <= x+1; checkX++)
			{
				//get element
				RiversMap::OneWaterElement *pCheckElement = NULL;
				if (pRiversMap->getElement(checkX,checkY,&pCheckElement))
				{				
					//only elements, with water and not border
					if ((pCheckElement->used) &&
						(!pCheckElement->border))
					{
						//get height
						float currentAbsHeight = Terrain::instance->getHeight(checkX,checkY)+
												 pCheckElement->amount;
						meanAbsHeight += currentAbsHeight;
						meanCount++;
					}
				}
			}
			if (meanCount == 0)
				pElement->amount = -0.2f;
			else
			{
				meanAbsHeight /= meanCount;

				//set to mean height 
				if (meanAbsHeight > Terrain::instance->getHeight(x,y) - 0.2f)
					pElement->amount = -0.2f;
				else
					pElement->amount = meanAbsHeight-Terrain::instance->getHeight(x,y);
			}
		}
	}

	//calculate world position, normals and alpha for all elements
	for (y=0;y<terrainWidth;y++)
		for (x=0;x<terrainWidth;x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//calculate world position
			float height = Terrain::instance->getHeight(x,y)+pElement->amount;
			pElement->worldPosition = D3DXVECTOR3(x,height,y);

			//calculate normal
			calculateNormal(x, y, &pElement->normal);

			//calculate alpha
			float alpha = 0.0f;

			//if water... take it
			if (pElement->amount > 0.0f)
			{
				alpha = pElement->amount;
			}
			alpha += 0.5f;
			
			//make some conversion to alpha
			alpha = atanf(transparency * alpha) * 2.0f / D3DX_PI;
			if (alpha > 1.0f) alpha = 1.0f;
			if (alpha < 0.0f) alpha = 0.0f;
			pElement->alpha = alpha;

			//set water steam
			if (FAILED(hr=setWaterSteam(x,y)))
				return hr;
		}
	}

	//remove elements under sea
	for (y=0;y<terrainWidth;y++)
		for (x=0;x<terrainWidth;x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//element under sea?
			if (pElement->worldPosition.y < seaHeight)
			{
				//if all neighbours under sea, too ... remove
				bool allUnderSea = true;
				for (int checkY = y-1; checkY <= y+1; checkY++)
					for (int checkX = x-1; checkX <= x+1; checkX++)
				{
					//get element
					RiversMap::OneWaterElement *pCheckElement = NULL;
					if (pRiversMap->getElement(checkX,checkY,&pCheckElement))
					{				
						//element with water and under sea
						if ((pCheckElement->used) &&
							(pCheckElement->worldPosition.y > seaHeight))
							allUnderSea = false;
					}
				}
				//mark it
				if (allUnderSea)
					pElement->underSeaType = RiversMap::OneWaterElement::UNDERSEA;
				else pElement->underSeaType = RiversMap::OneWaterElement::UNDERSEABORDER;
			}
		}
	}
	for (y=0;y<terrainWidth;y++)
		for (x=0;x<terrainWidth;x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//element and all neighbours under sea?
			if (pElement->underSeaType == RiversMap::OneWaterElement::UNDERSEA)
			{
				//if all neighbours completly under sea, too ... remove
				bool allCompleteUnderSea = true;
				for (int checkY = y-1; checkY <= y+1; checkY++)
					for (int checkX = x-1; checkX <= x+1; checkX++)
				{
					//get element
					RiversMap::OneWaterElement *pCheckElement = NULL;
					if (pRiversMap->getElement(checkX,checkY,&pCheckElement))
					{				
						//element with water and under sea
						if ((pCheckElement->used) &&
							(pCheckElement->underSeaType != RiversMap::OneWaterElement::UNDERSEA))
							allCompleteUnderSea = false;
					}
				}
				//remove it
				if (allCompleteUnderSea)
					pElement->used = false;
				//make invisible (blend out)
				else pElement->alpha = 0.0f;
			}
		}
	}

	//create renderstate blocks and load textures for all layer (common for all river tiles)
	if (Config::instance->isWaterReflection())
	{
		if (FAILED(hr=createEnvironmentLayer()))
			return hr;
	}
	else
	{
		if (FAILED(hr=createNonReflectionLayer()))
			return hr;
	}

	if (FAILED(hr=createTextureLayer()))
		return hr;

	if (FAILED(hr=createLightMapLayer()))
		return hr;

	//create array with all river tiles
	//determine count of river tiles
	int riversTilesCountPerSide = (terrainWidth-1)/RIVERS_TILE_SIZE;
	riversTilesCount = riversTilesCountPerSide * riversTilesCountPerSide;

	// allocate the terrain tile array
	pRiversTiles = new RiversTile[riversTilesCount];
	Tile** pTempTiles = new Tile*[riversTilesCount];

	//create all rivers tiles
	for (int terrainY = 0; terrainY < riversTilesCountPerSide; terrainY++)
		for (int terrainX = 0; terrainX < riversTilesCountPerSide; terrainX++)
	{
		//calculate x and y offset for tile
		int offsetX = terrainX*RIVERS_TILE_SIZE;
		int offsetY = terrainY*RIVERS_TILE_SIZE;
		int width = RIVERS_TILE_SIZE+1;

		//create tile
		int index = terrainY*riversTilesCountPerSide+terrainX;
		if (FAILED(hr=pRiversTiles[index].createGeometry(
						pD3DDevice,offsetX,offsetY,width,terrainWidth,pRiversMap)))
			return hr;

		//add pointer to temporary array
		pTempTiles[index] = &(pRiversTiles[index]);
	}

	//add to visibility checker
	tileCheck.setTiles(pTempTiles, riversTilesCountPerSide, terrainWidth-1, 
		false, Terrain::instance->areMirroredTiles());

	return S_OK;
}

/****************************************************************************
** Rivers createNonReflectionLayer
**
** create vertex buffer and render state block for environment backup layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::createNonReflectionLayer()
{
	HRESULT hr;

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, MIN_ALPHA );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );

		//set textures
		pD3DDevice->SetTexture(0,waterTexture);
	
		pD3DDevice->SetFVF(D3DFVF_RIVERS_ENVIRONMENT_VERTEX);
		
		pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
		pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );

		//only last layer will write to z buffer to avoid z fighting
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, false);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pEnvironmentStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pEnvironmentSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Rivers createEnvironmentLayer
**
** create vertex buffer and render state block for environment layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::createEnvironmentLayer()
{
	HRESULT hr;

	//try to load user specified water texture
	string wavesTexturePath = Config::instance->getEnginePath()+"/waves.dds";
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, wavesTexturePath.c_str(), D3DFMT_UNKNOWN, &normalTexture)))
	{
		//then load default water normal texture
		if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, "./wavetextures/default.dds", D3DFMT_UNKNOWN, &normalTexture)))
		{
			LOG("Loading waves texture failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//create cube enviroment texture
	LPD3DXRenderToEnvMap pRenderToEnvMap = NULL;
	LPDIRECT3DSURFACE9 pBackBuffer;
	D3DSURFACE_DESC backBufferDesc;

	if (FAILED(hr=pD3DDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackBuffer)))
	{
		LOG("Retrieving back buffer for environment map failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=pBackBuffer->GetDesc(&backBufferDesc)))
	{
		LOG("Retrieving description of back buffer for environment map failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=D3DXCreateCubeTexture( pD3DDevice, RIVERS_ENVIROMENTTEXTURESIZE, 1,
            D3DUSAGE_RENDERTARGET, backBufferDesc.Format, D3DPOOL_DEFAULT, &cubeTexture)))
	{
		LOG("Creating cube texture failed", Logger::LOG_CRIT);
		return hr;
	}

	//render enviroment to cube map
	if (FAILED(hr=D3DXCreateRenderToEnvMap(pD3DDevice, RIVERS_ENVIROMENTTEXTURESIZE, 1, 
        backBufferDesc.Format, FALSE, D3DFMT_DXT1, &pRenderToEnvMap)))
	{
		LOG("Creating render to environment map failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=pRenderToEnvMap->BeginCube(cubeTexture)))
	{
		LOG("Beginning cube rendering failed", Logger::LOG_CRIT);
		return hr;
	}
	
	if (FAILED(hr=Sky::instance->renderToEnviromentMap(pRenderToEnvMap)))
	{
		LOG("Rendering to cube failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=pRenderToEnvMap->End(D3DX_FILTER_BOX)))
	{
		LOG("Ending cube rendering failed", Logger::LOG_CRIT);
		return hr;
	}

	SAFE_RELEASE(pBackBuffer);
	SAFE_RELEASE(pRenderToEnvMap);

	//load pixel shader
	if (FAILED(hr=EngineHelpers::createPSFromFile(pD3DDevice, "./enginefiles/shaders/water.psh", &environmentPixelShader)))
	{
		LOG("Loading environment pixel shader failed", Logger::LOG_CRIT);
		return hr;
	}

	// Create the shader declaration.
	D3DVERTEXELEMENT9  decl[] =
	{
		{ 0, 0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
		{ 0, 12, D3DDECLTYPE_D3DCOLOR, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR, 0 },
		{ 0, 16, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
		{ 0, 24, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 1 },
		{ 0, 36, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 2 },
		{ 0, 48, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 3 },
		D3DDECL_END()
	};

	// load the vertex shader.
	if (FAILED(hr=EngineHelpers::createVSFromFile(pD3DDevice, decl,"./enginefiles/shaders/water.vsh", &environmentVertexShader, &environmentVertexDecl)))
	{
		LOG("Loading environment vertex shader failed", Logger::LOG_CRIT);
		return hr;
	}

	//set fixed vertex shader constants
	//set reflection amount as constant
	//convert reflection value
	D3DXCOLOR reflectionColor;
	reflectionColor.r = reflectionColor.g = reflectionColor.b = reflection;
	reflectionColor.a = 1.0f;
	pD3DDevice->SetPixelShaderConstantF(CP_WATER_REFLECTION, reflectionColor, 1);

	//set fixed pixel shader constants
	//set water color as constant
	pD3DDevice->SetPixelShaderConstantF(CP_WATER_COLOR, color, 1);

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, MIN_ALPHA );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_DISABLE );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );

		//set textures
		pD3DDevice->SetTexture(0,normalTexture);
		pD3DDevice->SetTexture(3,cubeTexture);

		//render environmented river
		pD3DDevice->SetVertexShader(environmentVertexShader);
		pD3DDevice->SetVertexDeclaration(environmentVertexDecl);
		pD3DDevice->SetPixelShader(environmentPixelShader);

		pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
		pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );

		//only last layer will write to z buffer to avoid z fighting
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, false);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pEnvironmentStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pEnvironmentSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Rivers createTextureLayer
**
** create vertex buffer and render state block for texture layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::createTextureLayer()
{
	HRESULT hr;

	//load rivers texture
	string texturePath = "./enginefiles/riverstream.jpg";
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, texturePath.c_str(), D3DFMT_UNKNOWN, &streamTexture)))
	{
		LOG("Loading rivers stream texture failed", Logger::LOG_CRIT);
		return hr;
	}
 
	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );

		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );

		//set textures
		pD3DDevice->SetTexture(0,streamTexture);
				
		pD3DDevice->SetFVF(D3DFVF_RIVERS_TEXTURE_VERTEX);
		
		pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
		pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );

		//only last layer will write to z buffer to avoid z fighting
		pD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, false);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pTextureStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pTextureSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Rivers createLightMapLayer
**
** create vertex buffer and render state block for light map layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::createLightMapLayer()
{
	HRESULT hr;

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_DESTCOLOR);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_ZERO);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_CURRENT );
		pD3DDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);

		//set textures
		pD3DDevice->SetTexture(0,lightMapTexture);
				
		pD3DDevice->SetFVF(D3DFVF_RIVERS_LIGHTMAP_VERTEX);
		
		pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pLightMapStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pLightMapSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Rivers DestroyGeometry
**
** destroy the rivers, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");
	
	//no rivers... cancel
	if (!used)
		return S_OK;

	int i;
	HRESULT hr;

	//delete array with all elements
	SAFE_DELETE(pRiversMap);

	//release texture
	SAFE_RELEASE(streamTexture);
	SAFE_RELEASE(normalTexture);
	SAFE_RELEASE(cubeTexture);
	
	//release shaders
	SAFE_RELEASE(environmentVertexShader);
	SAFE_RELEASE(environmentVertexDecl);
	SAFE_RELEASE(environmentPixelShader);

	//delete state blocks
	SAFE_RELEASE(pEnvironmentStateBlock);
	SAFE_RELEASE(pEnvironmentSavedStateBlock);
	SAFE_RELEASE(pTextureStateBlock);
	SAFE_RELEASE(pTextureSavedStateBlock);
	SAFE_RELEASE(pLightMapStateBlock);
	SAFE_RELEASE(pLightMapSavedStateBlock);

	//delete terrain tiles
	for (i=0;i<riversTilesCount;i++)
	{
		if (FAILED(hr=pRiversTiles[i].destroyGeometry()))
			return hr;
	}
	SAFE_DELETE_ARRAY(pRiversTiles);
	riversTilesCount = 0;

	//remove steam particle
	if (FAILED(hr=Particles::instance->removeParticleType(steamParticle)))
		return hr;

	return S_OK;
}

/****************************************************************************
** Rivers Render
**
** renders all sea
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Rivers::render(ModuleRenderType renderType)
{
	HRESULT hr;
	int i;

	//no rivers... cancel
	if ((!enabled) || (!used))
		return S_OK;

	//set world 
	D3DXMATRIX transformation;
	D3DXMatrixIdentity(&transformation);
	EngineHelpers::setWorldTransform(pD3DDevice,&transformation,
		((renderType == DEFAULT) && Config::instance->isWaterReflection()) || 
		(renderType == DEPTH) ||
		(renderType == REFLECTION));
	
	//render only lightmap layer, when rendering depth
	if (renderType != DEPTH)
	{
		//render environment layer

		//record and set the render states
		pEnvironmentSavedStateBlock->Capture();
		pEnvironmentStateBlock->Apply();

		//set wire frame
		if (!wireframeEnabled)
			pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

		//use transformed clip plane (if there is one)
		DWORD currentClipPlane;
		bool clipPlaneChanged = false;
		if (Config::instance->isWaterReflection())
		{
			pD3DDevice->GetRenderState(D3DRS_CLIPPLANEENABLE, &currentClipPlane);
			if (currentClipPlane == D3DCLIPPLANE0)
			{
				clipPlaneChanged = true;
				pD3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, D3DCLIPPLANE1);
			}
		}

		//set move vector as constant
		D3DXVECTOR2 movedDistance(0.0f,0.0f);
		pD3DDevice->SetVertexShaderConstantF(CV_WATER_MOVE, movedDistance, 1);

		//set rotation of normal map as constant
		D3DXVECTOR3 rotation(sinf(normalRotation),cosf(normalRotation),0.0f);
		pD3DDevice->SetVertexShaderConstantF(CV_WATER_ROTATION, rotation, 1);

		//render environmented river
		for (i=0;i<riversTilesCount;i++)
		{
			if (FAILED(hr=pRiversTiles[i].renderEnvironmentLayer(&tileCheck)))
				return hr;
		}

		//reset clip plane
		if (clipPlaneChanged)
			pD3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, D3DCLIPPLANE0);

		//restore state block
		pEnvironmentSavedStateBlock->Apply();

		//render texture layer

		//record and set the render states
		pTextureSavedStateBlock->Capture();
		pTextureStateBlock->Apply();

		//set wire frame
		if (!wireframeEnabled)
			pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

		//set texture transformation
		pD3DDevice->SetTransform( D3DTS_TEXTURE0, &textureMatrix );

		//render rivers
		for (i=0;i<riversTilesCount;i++)
		{
			if (FAILED(hr=pRiversTiles[i].renderTextureLayer(&tileCheck)))
				return hr;
		}

		//reset texture transformation
		D3DXMATRIX identityMatrix;
		D3DXMatrixIdentity(&identityMatrix);
		pD3DDevice->SetTransform( D3DTS_TEXTURE0, &identityMatrix );

		//restore state block
		pTextureSavedStateBlock->Apply();
	}

	//render light map layer

	//record and set the render states
	if (renderType != DEPTH)
	{
		pLightMapSavedStateBlock->Capture();
		pLightMapStateBlock->Apply();

		//set wire frame
		if (!wireframeEnabled)
			pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
	}
	else pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

	//render rivers
	for (i=0;i<riversTilesCount;i++)
	{
		if (FAILED(hr=pRiversTiles[i].renderLightMapLayer(&tileCheck)))
			return hr;
	}

	//restore state block
	if (renderType != DEPTH) pLightMapSavedStateBlock->Apply();
	else pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	return S_OK;
}

/****************************************************************************
** Rivers Update
**
** Animate rivers
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::update(float elapsedTime)
{
	//no rivers... cancel
	if ((!enabled) || (!used))
		return S_OK;

	//calculate texture transformation matrix
	textureMatrix._32 += elapsedTime*0.5f;

	//make rotation of normals of normal map
	normalRotation += elapsedTime;

	//update visibility of all river tiles
	tileCheck.update();

	return S_OK;
}

/****************************************************************************
** Rivers calculateNormal
**
** calculate the normal of a river element
** 
** Author: Dirk Plate
****************************************************************************/
void Rivers::calculateNormal(int x, int y, D3DXVECTOR3 *pNormal)
{
	int nX, nY;
	float height;
	RiversMap::OneWaterElement *pElement = NULL;


	//get element
	if (!pRiversMap->getElement(x,y,&pElement))
		return;

	//get own vector
	height = Terrain::instance->getHeight(x,y)+pElement->amount;
	D3DXVECTOR3 middle((float)x, height, (float)y);

	//get the 4 vectors from neighbours
	nX = x-1;
	nY = y;
	if (pRiversMap->getElement(nX,nY,&pElement))
	{
		if (pElement->used)
			height = Terrain::instance->getHeight(nX,nY)+pElement->amount;
	}
	D3DXVECTOR3 left(nX, height, nY);

	nX = x+1;
	nY = y;
	if (pRiversMap->getElement(nX,nY,&pElement))
	{
		if (pElement->used)
			height = Terrain::instance->getHeight(nX,nY)+pElement->amount;
	}
	D3DXVECTOR3 right(nX, height, nY);

	nX = x;
	nY = y+1;
	if (pRiversMap->getElement(nX,nY,&pElement))
	{
		if (pElement->used)
			height = Terrain::instance->getHeight(nX,nY)+pElement->amount;
	}
	D3DXVECTOR3 top(nX, height, nY);

	nX = x;
	nY = y-1;
	if (pRiversMap->getElement(nX,nY,&pElement))
	{
		if (pElement->used)
			height = Terrain::instance->getHeight(nX,nY)+pElement->amount;
	}
	D3DXVECTOR3 bottom(nX, height, nY);
	

	//get the 4 vectors from middle to neighbours
	D3DXVECTOR3 toLeft = left-middle;
	D3DXVECTOR3 toRight = right-middle;
	D3DXVECTOR3 toTop = top-middle;
	D3DXVECTOR3 toBottom = bottom-middle;

	//get the 4 normals for the 'edges'
	D3DXVECTOR3 normalLeftTop;
	D3DXVec3Cross(&normalLeftTop,&left,&top);
	D3DXVECTOR3 normalTopRight;
	D3DXVec3Cross(&normalTopRight,&top,&right);
	D3DXVECTOR3 normalRightBottom;
	D3DXVec3Cross(&normalRightBottom,&right,&bottom);
	D3DXVECTOR3 normalBottomLeft;
	D3DXVec3Cross(&normalBottomLeft,&bottom,&left);

	//calculate middle normal by adding all
	D3DXVECTOR3 normalMiddle = normalLeftTop+normalTopRight+normalRightBottom+normalBottomLeft;

	//return normalized normal
	D3DXVec3Normalize(pNormal,&normalMiddle);
}

/****************************************************************************
** Rivers getHeight
**
** return the height of water at a position
**
** Author: Dirk Plate
****************************************************************************/
float Rivers::getHeight(float x, float y)
{
	float amount = pRiversMap->getInterpolatedAmount(x,y);

	if (amount+SMALL_NUM <= 0.0f)
		return 0.0f;
	else
		return Terrain::instance->getHeightInterpolated(x,y)+amount;
}

/****************************************************************************
** Rivers setWaterSteam
**
** set water steam particles
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Rivers::setWaterSteam(int x, int y)
{
	HRESULT hr;
	std::list<ParticleSource>::iterator newParticleSource;

	//get current element
	RiversMap::OneWaterElement *pElement = NULL;
	if (!pRiversMap->getElement(x,y,&pElement))
		return S_OK;

	//not at border elements
	if (pElement->border)
		return S_OK;

	//get own height
	float refHeight = Terrain::instance->getHeight(x,y)+pElement->amount;
	
	//find highest height difference to neighbours
	float maxHeightDifference=0.0f;
	int elementsWithLowDifference=0;
	for (int nY=y-1;nY<=y+1;nY++)
		for (int nX=x-1;nX<=x+1;nX++)
	{
		if (pRiversMap->getElement(nX,nY,&pElement))
		{
			if ((pElement->used) && (!pElement->border))
			{
				float currentHeight = Terrain::instance->getHeight(nX,nY)+pElement->amount;
				//new record?
				if (currentHeight-refHeight > maxHeightDifference)
					maxHeightDifference = currentHeight-refHeight;
				if (fabs(currentHeight-refHeight) <= RIVERS_MAXNODIFFERENCEFORSTEAM)
					elementsWithLowDifference++;
			}
		}		
	}

	//difference to small?
	if ((maxHeightDifference < RIVERS_MINDIFFERENCEFORSTEAM) ||
		(elementsWithLowDifference < 4))
		return S_OK;

	//add steam to this position
	if (FAILED(hr=steamParticle->addParticleSource(
			D3DXVECTOR3(x-0.5f,refHeight-0.5f,y-0.5f),
			D3DXVECTOR3(x+0.5f,refHeight-0.5f,y+0.5f),//position
			D3DXVECTOR3(-0.1f,0.5f,-0.1f),D3DXVECTOR3(0.1f,1.0f,0.1f),	//speed
			2.0f+maxHeightDifference,2.0f+maxHeightDifference*2,	//lifetime
			0.005f,0.01f,									//mass
			0.5f,0.7f,										//size
			0.1f,1.5f,										//growth and alpha speed
			0.1f,0.2f,										//emit interval
			newParticleSource)))
		return hr;

	return S_OK;
}



































