/****************************************************************************
** Rivers
**
** rivers rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(RIVERS_H)
#define RIVERS_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include <list>
#include "riverstile.h"
#include "riversmap.h"
#include "../particles/particles.h"

#define RIVERS_ENVIROMENTTEXTURESIZE 512
#define RIVERS_MINDIFFERENCEFORSTEAM 0.5f
#define RIVERS_MAXNODIFFERENCEFORSTEAM 0.2f

class Rivers
{
public:
	Rivers();
	~Rivers();

	HRESULT update(float elapsedTime);
	HRESULT render(ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
						   float seaHeight, 
						   float reflection, float transparency, D3DXCOLOR color,
						   LPDIRECT3DTEXTURE9 lightMapTexture, LPDIRECT3DTEXTURE9 waterTexture);
	HRESULT	destroyGeometry();

	float getHeight(float x, float y);

	void enable() {enabled = true;}
	void disable() {enabled = false;}

	void enableWireframe() {wireframeEnabled = true; }
	void disableWireframe() {wireframeEnabled = false; }

private:
	HRESULT createEnvironmentLayer();
	HRESULT createNonReflectionLayer();
	HRESULT createTextureLayer();
	HRESULT createLightMapLayer();
	void calculateNormal(int x, int y, D3DXVECTOR3 *pNormal);
	HRESULT setWaterSteam(int x, int y);
	

	LPDIRECT3DDEVICE9	pD3DDevice;
	int					terrainWidth; //the width of terrain
	
	bool enabled;					  //are the rivers enabled?
	bool used;						  //rivers used?
	bool wireframeEnabled;			  //is wireframe enabled?
	
	//visibility checking class
	TileCheck tileCheck;

	//informations about all water elements
	RiversMap *pRiversMap;

	LPDIRECT3DTEXTURE9		lightMapTexture;	//the light map
	LPDIRECT3DTEXTURE9		waterTexture;		//the water texture (backup for old graphic cards)
	LPDIRECT3DTEXTURE9		streamTexture;		//the rivers stream texture
	LPDIRECT3DTEXTURE9		normalTexture;		//the water normals texture
	LPDIRECT3DCUBETEXTURE9	cubeTexture;		//the cube texture (enviroment mapping)
	LPDIRECT3DSTATEBLOCK9	pEnvironmentStateBlock;			//used state block for environment layer
	LPDIRECT3DSTATEBLOCK9	pEnvironmentSavedStateBlock;	//saved old state block for environment layer 
	LPDIRECT3DSTATEBLOCK9	pTextureStateBlock;				//used state block for environment layer
	LPDIRECT3DSTATEBLOCK9	pTextureSavedStateBlock;		//saved old state block for environment layer 
	LPDIRECT3DSTATEBLOCK9	pLightMapStateBlock;			//used state block for light map layer
	LPDIRECT3DSTATEBLOCK9	pLightMapSavedStateBlock;		//saved old state block for light map layer 

	//Shaders for environment mapping
	LPDIRECT3DVERTEXSHADER9		 environmentVertexShader;
	LPDIRECT3DVERTEXDECLARATION9 environmentVertexDecl;
	LPDIRECT3DPIXELSHADER9       environmentPixelShader;

	//texture transformation matrix
	D3DXMATRIX textureMatrix;

	//the current rotation of wave normals in degree
	float normalRotation;

	//the transparency factor of water
	float transparency;

	//the reflection strength of environment mapping
	float reflection;

	//the color of water
	D3DXCOLOR color;

	//all river tiles
	RiversTile	*pRiversTiles;

	//count of river tiles
	int riversTilesCount;

	//steam particle type
	std::list<ParticleType>::iterator steamParticle;
};

#endif