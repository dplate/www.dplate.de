#include "riversmap.h"

#include "../logger/logger.h"
#include "../common/enginehelpers.h"


/****************************************************************************
** RiversMap Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
RiversMap::RiversMap(int terrainWidth)
{
	int x,y;

	this->terrainWidth = terrainWidth;

	//create array
	pAllElements = new RiversMap::OneWaterElement*[terrainWidth];
	for (x=0;x<terrainWidth;x++)
	{
		pAllElements[x] = new RiversMap::OneWaterElement[terrainWidth];
		for (y=0;y<terrainWidth;y++)
		{
			pAllElements[x][y].used = false;
			pAllElements[x][y].border = false;
			pAllElements[x][y].underSeaType = RiversMap::OneWaterElement::OVERSEA;
			pAllElements[x][y].amount = 0.0f;
			pAllElements[x][y].streamStrength = 0.0f;
			pAllElements[x][y].tu = 0.0f;
			pAllElements[x][y].tv = 0.0f;
			pAllElements[x][y].worldPosition = D3DXVECTOR3(0.0f,0.0f,0.0f);
			pAllElements[x][y].normal = D3DXVECTOR3(0.0f,1.0f,0.0f);
			pAllElements[x][y].alpha = 1.0f;
		}
	}
}

RiversMap::~RiversMap()
{
	int x;

	//delete array with all elements
	for (x=0;x<terrainWidth;x++)
		SAFE_DELETE_ARRAY(pAllElements[x]);
	SAFE_DELETE_ARRAY(pAllElements);

}

/****************************************************************************
** RiversMap getElement
**
** returns one element of map
**
** Author: Dirk Plate
****************************************************************************/
bool RiversMap::getElement(int x, int y, OneWaterElement **pElement)
{
	if ((x<0) || (x>=terrainWidth) || (y<0) || (y>=terrainWidth))
	{
		*pElement = NULL;
		return false;
	}
	else
	{
		*pElement = &(pAllElements[x][y]);
		return true;
	}
}

/****************************************************************************
** RiversMap getAmount
**
** returns the amount of water at one position
**
** Author: Dirk Plate
****************************************************************************/
float RiversMap::getAmount(int x, int y)
{
	if (x<0) x=0;
	if (y<0) y=0;
	if (x>=terrainWidth) x=terrainWidth-1;
	if (y>=terrainWidth) y=terrainWidth-1;

	if (!pAllElements[x][y].used)
		return 0.0f;
	else return pAllElements[x][y].amount;
}

/****************************************************************************
** RiversMap isUsed
**
** returns if element is used
**
** Author: Dirk Plate
****************************************************************************/
bool RiversMap::isUsed(int x, int y)
{
	if (x<0) x=0;
	if (y<0) y=0;
	if (x>=terrainWidth) x=terrainWidth-1;
	if (y>=terrainWidth) y=terrainWidth-1;

	return pAllElements[x][y].used;
}

/****************************************************************************
** RiversMap isBorder
**
** returns if element is border
**
** Author: Dirk Plate
****************************************************************************/
bool RiversMap::isBorder(int x, int y)
{
	if (x<0) x=0;
	if (y<0) y=0;
	if (x>=terrainWidth) x=terrainWidth-1;
	if (y>=terrainWidth) y=terrainWidth-1;

	return pAllElements[x][y].border;
}


/****************************************************************************
** RiversMap getInterpolatedAmount
**
** returns the interpolated amount of water at one position
**
** Author: Dirk Plate
****************************************************************************/
float RiversMap::getInterpolatedAmount(float x, float y)
{
	int lu_x = (int)x;
	int lu_y = (int)y;
	int rd_x = lu_x+1;
	int rd_y = lu_y+1;

/*
	P3(x1,y2,z3) ----- P4 (x2,y2,z4)
			     |  /|
			     | / |
			     |/  |
    P1(x1,y1,z1) ----- P2 (x2,y1,z2)
*/

	float a = (float)(x-lu_x)/(float)(rd_x - lu_x);
	float b = (float)(y-lu_y)/(float)(rd_y - lu_y);

	// look at the drawing above
	int x1 = lu_x;	
	int y1 = rd_y;
	int x2 = rd_x;			
	int y2 = lu_y;
	
	if ((a+b) < 1.0f) //point in the left upper triangle?
	{
		//get the amounts of the triangle edges
		float z1 = getAmount(x1,y2);
		if (isBorder(x1,y2)) z1 = -0.2f;
		float z2 = getAmount(x2,y2);
		if (isBorder(x2,y2)) z2 = -0.2f;
		float z3 = getAmount(x1,y1);
		if (isBorder(x1,y1)) z3 = -0.2f;

		return (z1-(z1-z2)*a-(z1-z3)*b); //calc. the amount
	}
	else //then point in the right lower triangle
	{
		//get the amounts of the triangle edges
		float z2 = getAmount(x2,y1);
		if (isBorder(x2,y1)) z2 = -0.2f;
		float z3 = getAmount(x1,y1);
		if (isBorder(x1,y1)) z3 = -0.2f;
		float z4 = getAmount(x2,y2);
		if (isBorder(x2,y2)) z4 = -0.2f;

		return (z2-(z2-z3)*(1.0f-a)-(z2-z4)*(1.0f-b)); //calc. the amount		
	}
}

/****************************************************************************
** RiversMap getInterpolatedAmountSmooth
**
** returns the smooth interpolated amount of water at one position
**
** Author: Dirk Plate
****************************************************************************/
float RiversMap::getInterpolatedAmountSmooth(float x, float y)
{
	//!!Somethings wrong with this function!!//

	float strengthLeftTop;
	float strengthRightTop;
	float strengthLeftBottom;
	float strengthRightBottom;
	int xInt = int(x);
	int yInt = int(y);

	//get strength from all edges around this point
	EngineHelpers::getInterpolationStrengths(x, y,&strengthLeftTop, &strengthRightTop, &strengthLeftBottom, &strengthRightBottom);

	//get normal from edges
	int heightLeftTop = getAmount(xInt, yInt);
	int heightRightTop = getAmount(xInt+1, yInt);
	int heightLeftBottom = getAmount(xInt, yInt+1);
	int heightRightBottom = getAmount(xInt+1, yInt+1);
	
	//calculate mean value
	float amount = (strengthLeftTop*heightLeftTop+
					strengthRightTop*heightRightTop+
					strengthLeftBottom*heightLeftBottom+
					strengthRightBottom*heightRightBottom);	
	return amount;
}




































