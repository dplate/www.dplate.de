/****************************************************************************
** RiversMap
**
** rivers map management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(RIVERSMAP_H)
#define RIVERSMAP_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>

class RiversMap
{
public:
	struct OneWaterElement
	{
		//element is used
		bool used;

		//this element is a border element
		bool border;

		//the under sea type
		enum{OVERSEA,UNDERSEA,UNDERSEABORDER} underSeaType;

		//amount of water on this element
		float amount;

		//stream at this element
		float streamStrength;

		//texture coordinates for stream
		float tu,tv;

		//the world position of this element
		D3DXVECTOR3 worldPosition;

		//the normal at this position
		D3DXVECTOR3 normal;

		//transparency of element
		float alpha;

		//index of vertex
		WORD vertexIndex;
	};

	RiversMap(int terrainWidth);
	~RiversMap();

	bool getElement(int x, int y, OneWaterElement **pElement);

	float getAmount(int x, int y);
	bool isUsed(int x, int y);
	bool isBorder(int x, int y);
	float getInterpolatedAmount(float x, float y);
	float getInterpolatedAmountSmooth(float x, float y);
private:
	//informations about all water elements
	OneWaterElement **pAllElements;

	//size of map (and terrain
	int terrainWidth;
};

#endif