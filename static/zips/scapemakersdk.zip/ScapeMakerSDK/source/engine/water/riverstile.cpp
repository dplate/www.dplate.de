#include "riverstile.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../common/enginehelpers.h"
#include "../camera/camera.h"
#include "../../common/minixml.h"
#include "../common/config.h"	


/****************************************************************************
** RiversTile Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
RiversTile::RiversTile()
{
	Tile::Tile();

	pRiversMap = NULL;

	riversTileEnabled = false;

	meshEnvironmentVB = NULL;
	meshTextureVB = NULL;
	meshLightMapVB = NULL;
	meshIB = NULL;
}

RiversTile::~RiversTile()
{
}

/****************************************************************************
** RiversTile CreateGeometry
**
** create and initializes one tile of rivers
**
** Author: Dirk Plate
****************************************************************************/
HRESULT RiversTile::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, int offsetX, int offsetY, int width,
						int terrainWidth, RiversMap* pRiversMap)
{
	int x,y;
	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;
	this->offsetX = offsetX;
	this->offsetY = offsetY;
	this->width = width;
	this->terrainWidth = terrainWidth;
	this->pRiversMap = pRiversMap;


	//determine the count of vertices and indices
	verticesCount = 0;
	indicesCount = 0;
	for (y=offsetY;y<offsetY+width;y++)
		for (x=offsetX;x<offsetX+width;x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//count all used elements
			verticesCount++;

			//indices ignored at right und top border
			if ((x >= offsetX+width-1) || (y <= offsetY))
				continue;

			//count all triangled from this vertices in right/bottom direction
			RiversMap::OneWaterElement *pCheckElement = NULL;
			pRiversMap->getElement(x+1,y-1,&pCheckElement);
			if (pCheckElement->used)
			{
				pRiversMap->getElement(x,y-1,&pCheckElement);
				if (pCheckElement->used)
					indicesCount += 3;

				pRiversMap->getElement(x+1,y,&pCheckElement);
				if (pCheckElement->used)
					indicesCount += 3;
			}
		}
	}

	//no triangles... no river in this segment
	riversTileEnabled = true;
	if (indicesCount <=0)
	{
		riversTileEnabled = false;
		pBoundingBox = new AABB(&D3DXVECTOR3(offsetX+width/2.0f,0.0f,offsetY+width/2.0f),1);
		return S_OK;
	}

	//create bounding box
	//create array with all points to construct bounding box
	D3DXVECTOR3 *pAllVectors = new D3DXVECTOR3[verticesCount];

	//fill list
	int index = 0;
	for (y=offsetY; y<offsetY+width; y++)
		for (x=offsetX; x<offsetX+width; x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//save world position for this vertex
			pAllVectors[index] = pElement->worldPosition;

			//save vertex index of element
			pElement->vertexIndex = index;

			index++;
		}
	}

	//construct bounding box		
	pBoundingBox = new AABB(pAllVectors,verticesCount);

	//delete temporay array
	SAFE_DELETE_ARRAY(pAllVectors);

	//check size of vertices count
	if (verticesCount >= 65536)
	{
		LOG("Too many river elements... please wait for further versions of ScapeMaker", Logger::LOG_CRIT);
		return E_FAIL;
	}

	if (FAILED(hr=createEnvironmentLayer()))
		return hr;

	if (FAILED(hr=createTextureLayer()))
		return hr;

	if (FAILED(hr=createLightMapLayer()))
		return hr;

	if (FAILED(hr=createIndexBuffer()))
		return hr;

	return S_OK;
}

/****************************************************************************
** RiversTile createEnvironmentLayer
**
** create vertex buffer and render state block for environment layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT RiversTile::createEnvironmentLayer()
{
	HRESULT hr;

	// allocate memory for vertex and index data
	RIVERSENVIRONMENTVERTEX *vertices = new RIVERSENVIRONMENTVERTEX[verticesCount];

	// set all vertices
	int index = 0;
	for (int y=offsetY; y<offsetY+width; y++)
		for (int x=offsetX; x<offsetX+width; x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//set world position for this vertex
			vertices[index].position = pElement->worldPosition;

			//set transparency in diffuse
			vertices[index].diffuse = D3DXCOLOR(0.0f,0.0f,0.0f,pElement->alpha);

			//set texture position for environment map
			vertices[index].texture1 = D3DXVECTOR2(float(x)/10.0f,float(y)/10.0f);

			//calculate normal transformation for environment mapping
			D3DXVECTOR3 normal = pElement->normal;
			float yaw = 0.0f;
			float pitch = 0.0f;
			if (fabs(normal.y) > SMALL_NUM)
				pitch = -tanf(normal.z/normal.y);
			float roll = 0.0f;
			if (fabs(normal.y) > SMALL_NUM)
				roll = -tanf(normal.x/normal.y);

			D3DXMATRIX tangentMatrix;
			D3DXMatrixRotationYawPitchRoll(&tangentMatrix, yaw, pitch, roll);
			D3DXMatrixTranspose(&tangentMatrix,&tangentMatrix);
			vertices[index].texture2 = D3DXVECTOR3(tangentMatrix._11,tangentMatrix._12,tangentMatrix._13);
			vertices[index].texture3 = D3DXVECTOR3(tangentMatrix._21,tangentMatrix._22,tangentMatrix._23);
			vertices[index].texture4 = D3DXVECTOR3(tangentMatrix._31,tangentMatrix._32,tangentMatrix._33);

			index++;
		}
	}

	//create vertex buffer
	int vertexSize = verticesCount*sizeof(RIVERSENVIRONMENTVERTEX);
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vertexSize, D3DUSAGE_WRITEONLY,
		D3DFVF_RIVERS_ENVIRONMENT_VERTEX, D3DPOOL_MANAGED, &meshEnvironmentVB, NULL)))
	{
		LOG("Creating environment vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	VOID* pVertices;
	if (FAILED(hr=meshEnvironmentVB->Lock(0,vertexSize,(VOID**)&pVertices,0)))
	{
		LOG("Locking environment vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//copy vertices
	memcpy(pVertices, vertices, vertexSize);

	//release memory
	meshEnvironmentVB->Unlock();
	SAFE_DELETE_ARRAY(vertices);

	return S_OK;
}

/****************************************************************************
** RiversTile createEnvironmentLayer
**
** create vertex buffer and render state block for texture layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT RiversTile::createTextureLayer()
{
	HRESULT hr;

	// allocate memory for vertex and index data
	RIVERSTEXTUREVERTEX *vertices = new RIVERSTEXTUREVERTEX[verticesCount];

	// set all vertices
	int index = 0;
	for (int y=offsetY; y<offsetY+width; y++)
		for (int x=offsetX; x<offsetX+width; x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//set world position for this vertex
			vertices[index].position = pElement->worldPosition;

			//normalized length
			float normalizedLength = pElement->streamStrength / 5.0f;

			//use stream strength as alpha component of diffuse color
			vertices[index].diffuse = D3DXCOLOR(0.0f,0.0f,0.0f,
				normalizedLength*pElement->alpha);

			//set texture position for stream
			vertices[index].texture1 = D3DXVECTOR2(pElement->tu,pElement->tv);

			index++;
		}
	}

	//create vertex buffer
	int vertexSize = verticesCount*sizeof(RIVERSTEXTUREVERTEX);
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vertexSize, D3DUSAGE_WRITEONLY,
		D3DFVF_RIVERS_TEXTURE_VERTEX, D3DPOOL_MANAGED, &meshTextureVB, NULL)))
	{
		LOG("Creating texture vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	VOID* pVertices;
	if (FAILED(hr=meshTextureVB->Lock(0,vertexSize,(VOID**)&pVertices,0)))
	{
		LOG("Locking texture vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//copy vertices
	memcpy(pVertices, vertices, vertexSize);

	//release memory
	meshTextureVB->Unlock();
	SAFE_DELETE_ARRAY(vertices);

	return S_OK;
}

/****************************************************************************
** RiversTile createLightMapLayer
**
** create vertex buffer and render state block for light map layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT RiversTile::createLightMapLayer()
{
	HRESULT hr;

	// allocate memory for vertex and index data
	RIVERSLIGHTMAPVERTEX *vertices = new RIVERSLIGHTMAPVERTEX[verticesCount];

	// set all vertices
	int index = 0;
	for (int y=offsetY; y<offsetY+width; y++)
		for (int x=offsetX; x<offsetX+width; x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//set world position for this vertex
	  		vertices[index].position = pElement->worldPosition;

			//set texture for lightmap
			vertices[index].texture1 = D3DXVECTOR2(float(x)/float(terrainWidth), 1.0f-float(y)/float(terrainWidth));

			index++;
		}
	}

	//create vertex buffer
	int vertexSize = verticesCount*sizeof(RIVERSLIGHTMAPVERTEX);
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vertexSize, D3DUSAGE_WRITEONLY,
		D3DFVF_RIVERS_LIGHTMAP_VERTEX, D3DPOOL_MANAGED, &meshLightMapVB, NULL)))
	{
		LOG("Creating lightmap vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	VOID* pVertices;
	if (FAILED(hr=meshLightMapVB->Lock(0,vertexSize,(VOID**)&pVertices,0)))
	{
		LOG("Locking lightmap vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//copy vertices
	memcpy(pVertices, vertices, vertexSize);

	//release memory
	meshLightMapVB->Unlock();
	SAFE_DELETE_ARRAY(vertices);

	return S_OK;
}

/****************************************************************************
** RiversTile createIndexBuffer
**
** create index buffer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT RiversTile::createIndexBuffer()
{
	HRESULT hr;

	//create temporary array for indices
	WORD *indices = new WORD[indicesCount];

	// set all indices
	int index = 0;
	for (int y=offsetY; y<offsetY+width; y++)
		for (int x=offsetX; x<offsetX+width; x++)
	{
		//get element
		RiversMap::OneWaterElement *pElement = NULL;
		if (pRiversMap->getElement(x,y,&pElement))
		{
			//only make something at used elements
			if (!pElement->used)
				continue;

			//indices ignored at right und bottom border
			if ((x >= offsetX+width-1) || (y <= offsetY))
				continue;

			//add all triangles from this vertices in right/bottom direction
			RiversMap::OneWaterElement *pTopRightElement = NULL;
			RiversMap::OneWaterElement *pTopElement = NULL;
			RiversMap::OneWaterElement *pRightElement = NULL;
			pRiversMap->getElement(x+1,y-1,&pTopRightElement);
			pRiversMap->getElement(x,y-1,&pTopElement);
			pRiversMap->getElement(x+1,y,&pRightElement);
			if (pTopRightElement->used)
			{
				if (pTopElement->used)
				{
					indices[index]	= pElement->vertexIndex;
					index++;
					indices[index]	= pTopRightElement->vertexIndex;
					index++;
					indices[index]	= pTopElement->vertexIndex;
					index++;
				}

				if (pRightElement->used)
				{
					indices[index]	= pElement->vertexIndex;
					index++;
					indices[index]	= pRightElement->vertexIndex;
					index++;
					indices[index]	= pTopRightElement->vertexIndex;
					index++;
				}
			}
		}
	}

	// create the index buffer
	int indexSize = indicesCount*sizeof(WORD);
	if (FAILED(hr=pD3DDevice->CreateIndexBuffer(indexSize,D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,D3DPOOL_MANAGED, &meshIB, NULL)))
    {
		LOG("Creating index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	//lock index buffer
	VOID* pIndices;
	if (FAILED(hr=meshIB->Lock( 0, indexSize, (VOID**)&pIndices, 0)))
	{
       	LOG("Locking index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	//copy indices
	memcpy(pIndices, indices, indexSize);

	//release memory
	meshIB->Unlock();
	SAFE_DELETE_ARRAY(indices);

	return S_OK;
}


/****************************************************************************
** RiversTile DestroyGeometry
**
** destroy the rivers, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT RiversTile::destroyGeometry()
{
	//delete bounding box
	SAFE_DELETE(pBoundingBox);
	
	//no river in this tile
	if (!riversTileEnabled)
		return S_OK;

	//release mesh
	SAFE_RELEASE(meshEnvironmentVB);
	SAFE_RELEASE(meshTextureVB);
	SAFE_RELEASE(meshLightMapVB);
	SAFE_RELEASE(meshIB);

	return S_OK;
}

/****************************************************************************
** RiversTile RenderEnvironmentLayer
**
** renders environment layer of one rivers tile
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	RiversTile::renderEnvironmentLayer(TileCheck *pTileCheck)
{
	HRESULT hr;

	//no river in this tile
	if (!riversTileEnabled)
		return S_OK;

	//tile in no part visible
	if (!pTileCheck->isVisible(this))
		return S_OK;

	//render environmented river
	pD3DDevice->SetIndices(meshIB);
	pD3DDevice->SetStreamSource(0, meshEnvironmentVB, NULL, sizeof(RIVERSENVIRONMENTVERTEX));
	if (FAILED(hr=pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, verticesCount, 0, indicesCount/3)))
	{
		LOG("Rendering rivers failed (environment layer)", Logger::LOG_CRIT);
		return hr;
	}
	return S_OK;
}

/****************************************************************************
** RiversTile RenderTextureLayer
**
** renders texture layer of one rivers tile
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	RiversTile::renderTextureLayer(TileCheck *pTileCheck)
{
	HRESULT hr;

	//no river in this tile
	if (!riversTileEnabled)
		return S_OK;

	//tile in no part visible
	if (!pTileCheck->isVisible(this))
		return S_OK;

	//render texture layer
	pD3DDevice->SetIndices(meshIB);
	pD3DDevice->SetStreamSource(0, meshTextureVB, NULL, sizeof(RIVERSTEXTUREVERTEX));
	if (FAILED(hr=pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, verticesCount, 0, indicesCount/3)))
	{
		LOG("Rendering rivers failed (texture layer)", Logger::LOG_CRIT);
		return hr;
	}
	return S_OK;
}

/****************************************************************************
** RiversTile RenderLightMapLayer
**
** renders light map layer of one rivers tile
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	RiversTile::renderLightMapLayer(TileCheck *pTileCheck)
{
	HRESULT hr;

	//no river in this tile
	if (!riversTileEnabled)
		return S_OK;

	//tile in no part visible
	if (!pTileCheck->isVisible(this))
		return S_OK;

	//render light map layer
	pD3DDevice->SetIndices(meshIB);
	pD3DDevice->SetStreamSource(0, meshLightMapVB, NULL, sizeof(RIVERSLIGHTMAPVERTEX));
	if (FAILED(hr=pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, verticesCount, 0, indicesCount/3)))
	{
		LOG("Rendering rivers failed (light map layer)", Logger::LOG_CRIT);
		return hr;
	}
	return S_OK;
}








































