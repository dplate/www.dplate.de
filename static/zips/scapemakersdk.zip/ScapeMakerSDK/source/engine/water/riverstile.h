/****************************************************************************
** RiversTile
**
** rivers tile rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(RIVERSTILE_H)
#define RIVERSTILE_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "riversmap.h"
#include "../common/aabb.h"
#include "../common/tilecheck.h"

const int RIVERS_TILE_SIZE = 32;		// 32x32 quads (33x33 vertices)

#define D3DFVF_RIVERS_ENVIRONMENT_VERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX4 | D3DFVF_TEXCOORDSIZE2(0) | D3DFVF_TEXCOORDSIZE3(1) | D3DFVF_TEXCOORDSIZE3(2) | D3DFVF_TEXCOORDSIZE3(3))
#define D3DFVF_RIVERS_TEXTURE_VERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1)
#define D3DFVF_RIVERS_LIGHTMAP_VERTEX (D3DFVF_XYZ | D3DFVF_TEX1)

class RiversTile : public Tile
{
public:
	RiversTile();
	~RiversTile();

	HRESULT renderEnvironmentLayer(TileCheck *pTileCheck);
	HRESULT renderTextureLayer(TileCheck *pTileCheck);
	HRESULT renderLightMapLayer(TileCheck *pTileCheck);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, int offsetX, int offsetY, int width,
						   int terrainWidth, RiversMap *pRiversMap);
	HRESULT	destroyGeometry();

private:
	HRESULT createEnvironmentLayer();
	HRESULT createTextureLayer();
	HRESULT createLightMapLayer();
	HRESULT createIndexBuffer();

	struct RIVERSENVIRONMENTVERTEX
	{
		D3DXVECTOR3 position;
		D3DCOLOR	diffuse;	//transparency of reflection
		D3DXVECTOR2 texture1;
		D3DXVECTOR3 texture2;	//used for tangent space transformation
		D3DXVECTOR3 texture3;	//used for tangent space transformation
		D3DXVECTOR3 texture4;	//used for tangent space transformation
	};

	struct RIVERSTEXTUREVERTEX
	{
		D3DXVECTOR3 position;
		D3DCOLOR	diffuse;
		D3DXVECTOR2 texture1;
	};

	struct RIVERSLIGHTMAPVERTEX
	{
		D3DXVECTOR3 position;
		D3DXVECTOR2 texture1;
	};

	LPDIRECT3DDEVICE9	pD3DDevice;
	int					terrainWidth; //the width of terrain

	//is this rivers tile enabled
	bool riversTileEnabled;

	//informations about all water elements
	RiversMap *pRiversMap;

	//offset of current tile in pAllElements
	int offsetX,offsetY;

	//width of tile (quad)
	int width;

	//number of vertices and indices
	long verticesCount;
	long indicesCount;

	LPDIRECT3DVERTEXBUFFER9 meshEnvironmentVB;	//the mesh of the rivers (environment mapping)
	LPDIRECT3DVERTEXBUFFER9 meshTextureVB;		//the mesh of the rivers (stream)
	LPDIRECT3DVERTEXBUFFER9 meshLightMapVB;		//the mesh of the rivers (lightmap and fog)
	LPDIRECT3DINDEXBUFFER9	meshIB;				//the index buffer for the mesh
};

#endif