#include "sea.h"

#include "../logger/logger.h"
#include "../common/enginehelpers.h"
#include "../common/submeshes.h"
#include "../camera/camera.h"
#include "../terrain/terrain.h"
#include "../sky/sky.h"
#include "../clouds/clouds.h"
#include "rivers.h"
#include "../common/shaderconsts.h"
#include "../../common/minixml.h"
#include "../common/config.h"

inline DWORD F2DW( FLOAT f ) { return *((DWORD*)&f); }

/****************************************************************************
** Sea Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
Sea::Sea()
{
	enabled = true;
	used = true;
	wireframeEnabled = false;

	pAllElements = NULL;

	lightMapTexture = NULL;
	waterTexture = NULL;
	mirrorTexture = NULL;
	pRenderToSurface = NULL;
	normalTexture = NULL;

	pStateBlock = NULL;
	pSavedStateBlock = NULL;

	D3DXMatrixIdentity(&envTexMatrix);
	D3DXMatrixIdentity(&normTexMatrix);

	pSeaTiles = NULL;
	seaTilesCount = 0;

	movedDistance.x = 0.0f;
	movedDistance.y = 0.0f;
}

Sea::~Sea()
{
}

/****************************************************************************
** Sea CreateGeometry
**
** create and initializes the sea
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Sea::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
						   Rivers *pRivers,
						   float reflectionSet, float transparencySet, D3DXCOLOR colorSet,
						   LPDIRECT3DTEXTURE9 lightMapTextureSet, LPDIRECT3DTEXTURE9 waterTexture)
{
	LOGFUNC("createGeometry()");

	HRESULT hr;
	int x,y;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;
	this->pRivers = pRivers;
	this->color = colorSet;
	this->reflection = reflectionSet;
	this->transparency = transparencySet;
	this->lightMapTexture = lightMapTextureSet;
	this->waterTexture = waterTexture;

	height = 0.0f;

	//the width of terrain
	terrainWidth = Terrain::instance->getWidth();

	//load the properties of sea from file
	int heightInMeters = 0;
	speed = 20;
	string seaPropertiesPath = Config::instance->getEnginePath()+"/sea.txt";
	MiniXML xmlFile;
	if (xmlFile.openFile(seaPropertiesPath.c_str(),MiniXML::READ))
	{
		int value;
		if (xmlFile.readInteger("height",&value))
			heightInMeters = value;
		if (xmlFile.readInteger("speed",&value))
			speed = value;
		xmlFile.closeFile();
	}

	//if height <= 0... no sea -> disable sea
	if (heightInMeters <= 0)
	{
		used = false;
		return S_OK;
	}

	//convert from meters to engine coordinate
	height = Terrain::instance->transformHeightInMetersToEngineCoor(heightInMeters,true);
	//convert reflection value
	reflection.r = reflection.g = reflection.b = reflectionSet;
	reflection.a = 1.0f;

	LOG("Properties loaded OK");

	//create array with informations about all sea elements
	pAllElements = new SeaTile::OneSeaElement*[terrainWidth];
	for (x=0;x<terrainWidth;x++)
	{
		pAllElements[x] = new SeaTile::OneSeaElement[terrainWidth];
		for (y=0;y<terrainWidth;y++)
		{
			pAllElements[x][y].used = false;
			pAllElements[x][y].worldPosition = D3DXVECTOR3(x,height,y);
			pAllElements[x][y].alpha = 1.0f;
		}
	}

	//fill array
	int no = 0;
	used = false;
	for (y=0;y<terrainWidth;y++)
		for (x=0;x<terrainWidth;x++)
	{
		//vertex is used, if self or one of neighbours are above ground
		for (int checkY = y-1; checkY <= y+1; checkY++)
			for (int checkX = x-1; checkX <= x+1; checkX++)
		{
			//don't get values in top/left and bottom/right
			if (((checkY == y-1) && (checkX == x-1)) ||
				((checkY == y+1) && (checkX == x+1)))
				continue;

			//check border of terrain
			if ((checkX < 0) || (checkX >= terrainWidth) ||
				(checkY < 0) || (checkY >= terrainWidth))
				continue;

			//vertex above ground?
			if (pAllElements[checkX][checkY].worldPosition.y > Terrain::instance->getHeight(checkX,checkY))
			{
				used = true;
				pAllElements[x][y].used = true;
			}
		}

		//calculate alpha
		float alpha = 0.0f;

		//if water... take it
		if (pAllElements[x][y].worldPosition.y > Terrain::instance->getHeight(x,y))
		{
			alpha = pAllElements[x][y].worldPosition.y-Terrain::instance->getHeight(x,y);
		}
		alpha += 0.5f;

		//make some conversion to alpha
		alpha = atanf(transparency * alpha) * 2.0f / D3DX_PI;
		if (alpha > 1.0f) alpha = 1.0f;
		if (alpha < 0.0f) alpha = 0.0f;
		pAllElements[x][y].alpha = alpha;
	}

	//no sea... cancel
	if (!used)
		return S_OK;

	//create renderstate blocks 
	if (Config::instance->isWaterReflection())
	{
		if (FAILED(hr=createEnvironmentLayer()))
			return hr;
	}
	else
	{
		if (FAILED(hr=createNonReflectionLayer()))
			return hr;
	}

	//create array with all sea tiles
	//determine count of sea tiles
	int seaTilesCountPerSide = (terrainWidth-1)/SEA_TILE_SIZE;
	seaTilesCount = seaTilesCountPerSide * seaTilesCountPerSide;

	// allocate the terrain tile array
	pSeaTiles = new SeaTile[seaTilesCount];
	Tile** pTempArray = new Tile*[seaTilesCount];

	//create all sea tiles
	for (int terrainY = 0; terrainY < seaTilesCountPerSide; terrainY++)
		for (int terrainX = 0; terrainX < seaTilesCountPerSide; terrainX++)
	{
		//calculate x and y offset for tile
		int offsetX = terrainX*SEA_TILE_SIZE;
		int offsetY = terrainY*SEA_TILE_SIZE;
		int width = SEA_TILE_SIZE+1;

		//create tile
		int index = terrainY*seaTilesCountPerSide+terrainX;
		if (FAILED(hr=pSeaTiles[index].createGeometry(
						pD3DDevice,offsetX,offsetY,width,terrainWidth,color,pAllElements)))
			return hr;

		//save pointer to this object
		pTempArray[index] = &(pSeaTiles[index]);
	}

	//add tiles to tile check system
	tileCheck.setTiles(pTempArray, seaTilesCountPerSide, terrainWidth-1, 
		true, Terrain::instance->areMirroredTiles());
	
	SAFE_DELETE_ARRAY(pTempArray);

	return S_OK;
}

/****************************************************************************
** Sea createNonReflectionLayer
**
** create vertex buffer and render state block for environment backup layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Sea::createNonReflectionLayer()
{
	HRESULT hr;

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
		pD3DDevice->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );

		//lightmap
		pD3DDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE);
		pD3DDevice->SetTextureStageState(1, D3DTSS_COLORARG2, D3DTA_CURRENT);
		pD3DDevice->SetTextureStageState(1, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);

		//set textures
		pD3DDevice->SetTexture(0,waterTexture);
		pD3DDevice->SetTexture(1,lightMapTexture);
	
		pD3DDevice->SetFVF(D3DFVF_SEA_VERTEX);
	    pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW );
		pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Sea createEnvironmentLayer
**
** create vertex buffer and render state block for environment layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Sea::createEnvironmentLayer()
{
	HRESULT hr;

	//create clip plane
	D3DXPlaneFromPoints(&clipPlane, &pAllElements[1][0].worldPosition,
									&pAllElements[0][0].worldPosition,
									&pAllElements[0][1].worldPosition);

	//try to load user specified water texture
	string wavesTexturePath = Config::instance->getEnginePath()+"/waves.dds";
	if(FAILED(hr=(D3DXCreateTextureFromFileEx(pD3DDevice,
		wavesTexturePath.c_str(),
		D3DX_DEFAULT,D3DX_DEFAULT,
		0,0,
		D3DFMT_V8U8,
		D3DPOOL_MANAGED,D3DX_DEFAULT,D3DX_DEFAULT,
		0,NULL,NULL,
		&normalTexture))))
	{
		//then load default water normal texture
		if(FAILED(hr=(D3DXCreateTextureFromFileEx(pD3DDevice,
			"./wavetextures/default.dds",
			D3DX_DEFAULT,D3DX_DEFAULT,
			0,0,
			D3DFMT_V8U8,
			D3DPOOL_MANAGED,D3DX_DEFAULT,D3DX_DEFAULT,
			0,NULL,NULL,
			&normalTexture))))
		{
			LOG("Loading waves texture failed", Logger::LOG_CRIT);
			return hr;
		}
	}

	//create mirror textures
	LPDIRECT3DSURFACE9 pBackBuffer;
	D3DSURFACE_DESC backBufferDesc;

	if (FAILED(hr=pD3DDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackBuffer)))
	{
		LOG("Retrieving back buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=pBackBuffer->GetDesc(&backBufferDesc)))
	{
		LOG("Retrieving back buffer description failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=D3DXCreateTexture( pD3DDevice, SEAENVIROMENTTEXTURESIZE, SEAENVIROMENTTEXTURESIZE, 1,
            D3DUSAGE_RENDERTARGET, backBufferDesc.Format, D3DPOOL_DEFAULT, &mirrorTexture)))
	{
		LOG("Creating mirror texture failed", Logger::LOG_CRIT);
		return hr;
	}

	if (FAILED(hr=D3DXCreateRenderToSurface(pD3DDevice, SEAENVIROMENTTEXTURESIZE, SEAENVIROMENTTEXTURESIZE,
        backBufferDesc.Format, true, D3DFMT_D16, &pRenderToSurface)))
	{
		LOG("Creating 'render to surface' failed", Logger::LOG_CRIT);
		return hr;
	}

	SAFE_RELEASE(pBackBuffer);

	//create state block
	for (long block = 0; block < 2; block++)
	{
		if (FAILED(hr=pD3DDevice->BeginStateBlock()))
		{
			LOG("Beginning state block failed", Logger::LOG_CRIT);
			return hr;
		}

		//set texture properties
		pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
		pD3DDevice->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
		pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, true );
		pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0.0f );
		pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		pD3DDevice->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
		//pD3DDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
		pD3DDevice->SetTextureStageState(0, D3DTSS_BUMPENVMAT00, F2DW(1.0f));
		//pD3DDevice->SetTextureStageState(0, D3DTSS_BUMPENVMAT01, F2DW(0.0f));
		//pD3DDevice->SetTextureStageState(0, D3DTSS_BUMPENVMAT10, F2DW(0.0f));
		pD3DDevice->SetTextureStageState(0, D3DTSS_BUMPENVMAT11, F2DW(1.0f));
		pD3DDevice->SetTextureStageState(0, D3DTSS_COLOROP,	D3DTOP_BUMPENVMAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
		pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );

		pD3DDevice->SetTextureStageState(1, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT3|D3DTTFF_PROJECTED );
		pD3DDevice->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEPOSITION | 1 );
		pD3DDevice->SetTextureStageState(1, D3DTSS_COLOROP,   D3DTOP_LERP );
		//pD3DDevice->SetTextureStageState(1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		pD3DDevice->SetTextureStageState(1, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
		pD3DDevice->SetTextureStageState(1, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
		pD3DDevice->SetTextureStageState(1, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
		pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR, reflection );
		pD3DDevice->SetTextureStageState(1, D3DTSS_COLORARG0, D3DTA_TFACTOR );
 		pD3DDevice->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR );
		pD3DDevice->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR );
		pD3DDevice->SetSamplerState(1, D3DSAMP_ADDRESSW, D3DTADDRESS_MIRROR );

		//lightmap
		pD3DDevice->SetTextureStageState(2, D3DTSS_TEXCOORDINDEX, 1 );
		pD3DDevice->SetTextureStageState(2, D3DTSS_COLOROP, D3DTOP_MODULATE);
		pD3DDevice->SetTextureStageState(2, D3DTSS_COLORARG2, D3DTA_CURRENT);
		pD3DDevice->SetTextureStageState(2, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		pD3DDevice->SetTextureStageState(2, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MAGFILTER, D3DTEXF_ANISOTROPIC);
		pD3DDevice->SetSamplerState( 2, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
		//set textures
		pD3DDevice->SetTexture(0,normalTexture);
		pD3DDevice->SetTexture(1,mirrorTexture);
		pD3DDevice->SetTexture(2,lightMapTexture);

		pD3DDevice->SetFVF(D3DFVF_SEA_VERTEX);
	    pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW );
		pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);

		//state block created
		if (block == 0)
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pStateBlock)))
			{
				LOG("Ending state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
		else
		{
			if (FAILED(hr=pD3DDevice->EndStateBlock(&pSavedStateBlock)))
			{
				LOG("Ending saved state block failed", Logger::LOG_CRIT);
				return hr;
			}
		}
	}

	return S_OK;
}

/****************************************************************************
** Sea DestroyGeometry
**
** destroy the sea, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Sea::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	int x,i;
	HRESULT hr;

	//delete array with all elements
	if (pAllElements != NULL)
	{
		for (x=0;x<terrainWidth;x++)
			SAFE_DELETE_ARRAY(pAllElements[x]);
		SAFE_DELETE_ARRAY(pAllElements);
	}

	//release texture
	SAFE_RELEASE(pRenderToSurface);
	SAFE_RELEASE(mirrorTexture);
	SAFE_RELEASE(normalTexture);

	//delete state blocks
	SAFE_RELEASE(pStateBlock);
	SAFE_RELEASE(pSavedStateBlock);

	//delete terrain tiles
	for (i=0;i<seaTilesCount;i++)
	{
		if (FAILED(hr=pSeaTiles[i].destroyGeometry()))
			return hr;
	}
	SAFE_DELETE_ARRAY(pSeaTiles);
	seaTilesCount = 0;

	return S_OK;
}

/****************************************************************************
** Sea Render
**
** renders all sea
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Sea::render(ModuleRenderType renderType)
{
	HRESULT hr;
	int i;

	//no sea... cancel
	if ((!enabled) || (!used))
		return S_OK;

	//render environment layer
	if (renderType != DEPTH)
	{
		//record and set the render states
		pSavedStateBlock->Capture();
		pStateBlock->Apply();

		//set wire frame
		if (!wireframeEnabled)
			pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
	}

	//set normal texture transformation
	pD3DDevice->SetTransform( D3DTS_TEXTURE0, &normTexMatrix );

	//set environment texture transformation
	pD3DDevice->SetTransform( D3DTS_TEXTURE1, &envTexMatrix );

	//render environmented river
	for (i=0;i<seaTilesCount;i++)
	{
		if (FAILED(hr=pSeaTiles[i].render(&tileCheck, renderType)))
			return hr;
	}

	//restore state block
	if (renderType != DEPTH)
		pSavedStateBlock->Apply();

	return S_OK;
}

/****************************************************************************
** Sea Update
**
** Animate sea
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Sea::update(float elapsedTime)
{
	HRESULT hr;

	if ((!enabled) || (!used))
		return S_OK;

	//update visibility of tiles
	tileCheck.update();

	//move sea
	movedDistance.x -= elapsedTime*speed*0.001f;
	movedDistance.y -= elapsedTime*speed*0.001f;

	//calculate normal transformation matrix
	D3DXMatrixIdentity(&normTexMatrix);
	normTexMatrix._31 = movedDistance.x;
	normTexMatrix._32 = movedDistance.y;

	if (Config::instance->isWaterReflection())
	{
		//calculate mirror transformation matrix
		float fy = 1.0f/tanf(Camera::instance->getFieldOfView()/2.0f);
		float fx = fy/Camera::instance->getAspect();
		envTexMatrix._11 =-fx*0.5f;	envTexMatrix._12 = 0.0f;	envTexMatrix._13 = 0.0f;	envTexMatrix._14 = 0.0f;
		envTexMatrix._21 = 0.0f;	envTexMatrix._22 =-fy*0.5f;	envTexMatrix._23 = 0.0f;	envTexMatrix._24 = 0.0f;
		envTexMatrix._31 = 0.5f;	envTexMatrix._32 =-0.5f;	envTexMatrix._33 = 1.0f;	envTexMatrix._34 = 0.0f;
		envTexMatrix._41 = 0.0f;	envTexMatrix._42 = 0.0f;	envTexMatrix._43 = 0.0f;	envTexMatrix._44 = 1.0f;

		//begin rendering mirror texture
		LPDIRECT3DSURFACE9 pMirrorSurface = NULL;
		if (FAILED(hr=mirrorTexture->GetSurfaceLevel(0,&pMirrorSurface)))
		{
			LOG("Retrieving surface level failed", Logger::LOG_CRIT);
			return hr;
		}
		if (FAILED(hr=pRenderToSurface->BeginScene(pMirrorSurface,NULL)))
		{
			LOG("Beginning scene failed", Logger::LOG_CRIT);
			return hr;
		}

		//clear device
		pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, color, 1.0f, 0.0f);

		//set reflect camera position
		pD3DDevice->SetTransform(D3DTS_VIEW, Camera::instance->getReflectViewMatrix());

		//set vertex and pixel shader constants for fog calculating
		D3DXMATRIX matView, matProj, matWorld, matTemp;
		D3DXMatrixIdentity(&matWorld);
		pD3DDevice->SetTransform(D3DTS_WORLD, &matWorld);
 		pD3DDevice->GetTransform(D3DTS_VIEW, &matView);
		pD3DDevice->GetTransform(D3DTS_PROJECTION, &matProj);

		//set camera position as constant
		pD3DDevice->SetVertexShaderConstantF(CV_CAMERA_POS, Camera::instance->getReflectPosition(), 1);

		//set clip plane (don't render things below sea)
		pD3DDevice->SetClipPlane(0, clipPlane);

		//if things rendered with shaders transform clip plane to clip space
		D3DXMatrixTranspose(&matTemp, &(matView * matProj));
		D3DXMatrixInverse(&matTemp, NULL, &matTemp);
		D3DXPLANE transformedClipPlane;
		D3DXPlaneTransform(&transformedClipPlane, &clipPlane, &matTemp);
		pD3DDevice->SetClipPlane(1, transformedClipPlane);
		
		//use untransformed clipplane by default
		pD3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, D3DCLIPPLANE0);

		//render all thing which should reflect
		if (Config::instance->isSkyReflection())
		{
			if (FAILED(hr=Sky::instance->render(REFLECTION)))
			{
				LOG("Rendering sky in mirror failed", Logger::LOG_CRIT);
				return hr;
			}
		}

		if (Config::instance->isSubMeshesReflection())
		{
			if (FAILED(hr=Clouds::instance->render(REFLECTION)))
			{
				LOG("Rendering clouds in mirror failed", Logger::LOG_CRIT);
				return hr;
			}
		}

		if (Config::instance->isTerrainReflection())
		{
			if (FAILED(hr=Terrain::instance->render(REFLECTION)))
			{
				LOG("Rendering terrain in mirror failed", Logger::LOG_CRIT);
				return hr;
			}
		}

		if (Config::instance->isTerrainReflection())
		{
			if (FAILED(hr=pRivers->render(REFLECTION)))
			{
				LOG("Rendering rivers in mirror failed", Logger::LOG_CRIT);
				return hr;
			}
		}

		if (Config::instance->isSubMeshesReflection())
		{
			if (FAILED(hr=SubMeshes::instance->render(REFLECTION)))
			{
				LOG("Rendering sub meshes in mirror failed", Logger::LOG_CRIT);
				return hr;
			}
		}

		//reset camera position
		pD3DDevice->SetTransform(D3DTS_VIEW, Camera::instance->getViewMatrix());

		//set camera position as constant
		pD3DDevice->SetVertexShaderConstantF(CV_CAMERA_POS, Camera::instance->getPosition(), 1);

		//reset clip plane
		pD3DDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, 0);

		//end rendering texture
		if (FAILED(hr=pRenderToSurface->EndScene(D3DX_FILTER_BOX)))
		{
			LOG("Ending scene failed", Logger::LOG_CRIT);
			return hr;
		}
		SAFE_RELEASE(pMirrorSurface);
	}

	return S_OK;
}





































