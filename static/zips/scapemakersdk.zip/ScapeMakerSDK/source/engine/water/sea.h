/****************************************************************************
** Sea
**
** sea rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(SEA_H)
#define SEA_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "seatile.h"

#include "rivers.h"

#define SEAENVIROMENTTEXTURESIZE 256

class Sea
{
public:
	Sea();
	~Sea();

	HRESULT update(float elapsedTime);
	HRESULT render(ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice,
						   Rivers *pRivers,
						   float reflection, float transparency, D3DXCOLOR color,
						   LPDIRECT3DTEXTURE9 lightMapTexture, LPDIRECT3DTEXTURE9 waterTexture);



	HRESULT	destroyGeometry();

	float getHeight() { return height;}

	void enable() {enabled = true;}
	void disable() {enabled = false;}

	void enableWireframe() {wireframeEnabled = true; }
	void disableWireframe() {wireframeEnabled = false; }

private:
	HRESULT createNonReflectionLayer();
	HRESULT createEnvironmentLayer();

	LPDIRECT3DDEVICE9	pD3DDevice;
	Rivers				*pRivers;

	TileCheck			tileCheck;		//tile visibility check system

	int					terrainWidth;	//the width of terrain

	bool enabled;						//is the sea enabled?
	bool used;							//sea used
	bool wireframeEnabled;				//is wireframe enabled?

	//informations about all water elements
	SeaTile::OneSeaElement **pAllElements;

	LPDIRECT3DTEXTURE9		lightMapTexture;	//the light map
	LPDIRECT3DTEXTURE9		waterTexture;		//water backup textur for old graphic card without reflection support
	LPDIRECT3DTEXTURE9		normalTexture;		//the water normals texture
	LPDIRECT3DTEXTURE9		mirrorTexture;		//the mirror texture
	LPD3DXRENDERTOSURFACE	pRenderToSurface;	//help class for mirror rendering

	LPDIRECT3DSTATEBLOCK9	pStateBlock;		//used state block for environment layer
	LPDIRECT3DSTATEBLOCK9	pSavedStateBlock;	//saved old state block for environment layer

	D3DXVECTOR2				movedDistance;		//the distance to water moved already
	D3DXPLANE				clipPlane;			//the clip plane for mirror rendering
	D3DXMATRIX				envTexMatrix;		//environment texture transformation matrix
	D3DXMATRIX				normTexMatrix;		//normal texture transformation matrix

	//texture transformation matrix
	D3DXMATRIX textureMatrix;

	//the current rotation of wave normals in degree
	float normalRotation;

	//the transparency factor of water
	float transparency;

	//the reflection strength of environment mapping
	D3DXCOLOR reflection;

	//the color of water
	D3DXCOLOR color;

	//the height of the sea
	float height;

	//the speed of the waves
	int	speed;

	//all sea tiles
	SeaTile	*pSeaTiles;

	//count of sea tiles
	int seaTilesCount;
};

#endif