#include "seatile.h"

#include "../logger/logger.h"
#include "../common/shaderconsts.h"
#include "../common/enginehelpers.h"
#include "../camera/camera.h"
#include "../common/config.h"


/****************************************************************************
** SeaTile Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
SeaTile::SeaTile()
{
	Tile::Tile();

	pAllElements = NULL;

	seaTileEnabled = false;

	meshVB = NULL;
	meshIB = NULL;
}

SeaTile::~SeaTile()
{
}

/****************************************************************************
** SeaTile CreateGeometry
**
** create and initializes one tile of sea
**
** Author: Dirk Plate
****************************************************************************/
HRESULT SeaTile::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, int offsetX, int offsetY, int width,
						int terrainWidth, D3DXCOLOR color, OneSeaElement** pAllElements)
{
	int x,y;
	HRESULT hr;

	// store the direct3d device pointer
	this->pD3DDevice = pD3DDevice;
	this->offsetX = offsetX;
	this->offsetY = offsetY;
	this->width = width;
	this->color = color;
	this->terrainWidth = terrainWidth;
	this->pAllElements = pAllElements;


	//determine the count of vertices and indices
	verticesCount = 0;
	indicesCount = 0;
	for (y=offsetY;y<offsetY+width;y++)
		for (x=offsetX;x<offsetX+width;x++)
	{
		//only make something at used elements
		if (!pAllElements[x][y].used)
			continue;

		//count all used elements
		verticesCount++;

		//indices ignored at left and bottom border
		if ((x <= offsetX) || (y >= offsetY+width-1))
			continue;

		//count all triangled from this vertices in left/bottom direction
		if ((pAllElements[x-1][y+1].used))
		{
			if (pAllElements[x-1][y].used) 
				indicesCount += 3;
			if (pAllElements[x][y+1].used)
				indicesCount += 3;
		}
	}

	//no triangles... no sea in this segment
	seaTileEnabled = true;
	if (indicesCount <=0)
	{
		seaTileEnabled = false;
		pBoundingBox = new AABB(&D3DXVECTOR3(offsetX+width/2.0f,0.0f,offsetY+width/2.0f),1);
		return S_OK;
	}

	//create bounding box
	//create array with all points to construct bounding box
	D3DXVECTOR3 *pAllVectors = new D3DXVECTOR3[verticesCount];

	//fill list
	int index = 0;
	for (y=offsetY; y<offsetY+width; y++)
		for (x=offsetX; x<offsetX+width; x++)
	{
		//only make something at used elements
		if (!pAllElements[x][y].used)
			continue;

		//save world position for this vertex
		pAllVectors[index] = pAllElements[x][y].worldPosition;

		//save vertex index of element
		pAllElements[x][y].vertexIndex = index;

		index++;
	}

	//construct bounding box
	pBoundingBox = new AABB(pAllVectors,verticesCount);

	//delete temporay array
	SAFE_DELETE_ARRAY(pAllVectors);

	//check size of vertices count
	if (verticesCount >= 65536)
	{
		LOG("Too many sea elements... please wait for further versions of ScapeMaker", Logger::LOG_CRIT);
		return E_FAIL;
	}

	if (FAILED(hr=createLayer()))
		return hr;

	if (FAILED(hr=createIndexBuffer()))
		return hr;

	return S_OK;
}

/****************************************************************************
** SeaTile createLayer
**
** create vertex buffer and render state block for environment layer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT SeaTile::createLayer()
{
	HRESULT hr;

	// allocate memory for vertex and index data
	SEAVERTEX *vertices = new SEAVERTEX[verticesCount];

	// set all vertices
	int index = 0;
	for (int y=offsetY; y<offsetY+width; y++)
		for (int x=offsetX; x<offsetX+width; x++)
	{
		//only make something at used elements
		if (!pAllElements[x][y].used)
			continue;

		//set world position for this vertex
		vertices[index].position = pAllElements[x][y].worldPosition;

		//set transparency in diffuse
		color.a = pAllElements[x][y].alpha;
		vertices[index].diffuse = color;

		//set texture position for environment map
		vertices[index].texture1 = D3DXVECTOR2(float(x)/10.0f,float(y)/10.0f);

		//set texture for lightmap
		vertices[index].texture2 = D3DXVECTOR2(float(x)/float(terrainWidth), 1.0f-float(y)/float(terrainWidth));

		//save vertex index of element
		pAllElements[x][y].vertexIndex = index;

		index++;
	}

	//create vertex buffer
	int vertexSize = verticesCount*sizeof(SEAVERTEX);
	if (FAILED(hr=pD3DDevice->CreateVertexBuffer(vertexSize, D3DUSAGE_WRITEONLY,
		D3DFVF_SEA_VERTEX, D3DPOOL_MANAGED, &meshVB, NULL)))
	{
		LOG("Creating environment vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//lock vertex buffer
	VOID* pVertices;
	if (FAILED(hr=meshVB->Lock(0,vertexSize,(VOID**)&pVertices,0)))
	{
		LOG("Locking environment vertex buffer failed", Logger::LOG_CRIT);
		return hr;
	}

	//copy vertices
	memcpy(pVertices, vertices, vertexSize);

	//release memory
	meshVB->Unlock();
	SAFE_DELETE_ARRAY(vertices);

	return S_OK;
}

/****************************************************************************
** SeaTile createIndexBuffer
**
** create index buffer
**
** Author: Dirk Plate
****************************************************************************/
HRESULT SeaTile::createIndexBuffer()
{
	HRESULT hr;

	//create temporary array for indices
	WORD *indices = new WORD[indicesCount];

	// set all indices
	int index = 0;
	for (int y=offsetY; y<offsetY+width; y++)
		for (int x=offsetX; x<offsetX+width; x++)
	{
		//only make something at used elements
		if (!pAllElements[x][y].used)
			continue;

		//indices ignored at left und bottom border
		if ((x <= offsetX) || (y >= offsetY+width-1))
			continue;

		//add all triangles from this vertices in left/bottom direction
		if ((pAllElements[x-1][y+1].used))
		{
			if (pAllElements[x][y+1].used) 
			{
				indices[index] = pAllElements[x][y].vertexIndex;
				index++;
				indices[index] = pAllElements[x-1][y+1].vertexIndex;
				index++;
				indices[index] = pAllElements[x][y+1].vertexIndex;
				index++;
			}
			if (pAllElements[x-1][y].used)
			{
				indices[index] = pAllElements[x][y].vertexIndex;
				index++;
				indices[index] = pAllElements[x-1][y].vertexIndex;
				index++;
				indices[index] = pAllElements[x-1][y+1].vertexIndex;
				index++;
			}
		}
	}

	// create the index buffer
	int indexSize = indicesCount*sizeof(WORD);
	if (FAILED(hr=pD3DDevice->CreateIndexBuffer(indexSize,D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,D3DPOOL_MANAGED, &meshIB, NULL)))
    {
		LOG("Creating index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	//lock index buffer
	VOID* pIndices;
	if (FAILED(hr=meshIB->Lock( 0, indexSize, (VOID**)&pIndices, 0)))
	{
       	LOG("Locking index buffer failed", Logger::LOG_CRIT);
        return hr;
    }

	//copy indices
	memcpy(pIndices, indices, indexSize);

	//release memory
	meshIB->Unlock();
	SAFE_DELETE_ARRAY(indices);

	return S_OK;
}


/****************************************************************************
** SeaTile DestroyGeometry
**
** destroy the sea, free memory, release index buffers ...
**
** Author: Dirk Plate
****************************************************************************/
HRESULT SeaTile::destroyGeometry()
{
	//delete bounding box
	SAFE_DELETE(pBoundingBox);
	
	//no sea in this tile
	if (!seaTileEnabled)
		return S_OK;

	//release mesh
	SAFE_RELEASE(meshVB);
	SAFE_RELEASE(meshIB);

	return S_OK;
}

/****************************************************************************
** SeaTile render
**
** renders environment layer of one sea tile
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	SeaTile::render(TileCheck *pTileCheck, ModuleRenderType renderType)
{
	HRESULT hr;

	//no sea in this tile
	if (!seaTileEnabled)
		return S_OK;

	//tile in no part visible
	if (!pTileCheck->isVisible(this))
		return S_OK;

	//set index and vertex buffer
	pD3DDevice->SetIndices(meshIB);
	pD3DDevice->SetStreamSource(0, meshVB, NULL, sizeof(SEAVERTEX));

	//render in all parts
	for (int part=0;part<9;part++)
	{
		//not visible in this part
		if (!pTileCheck->isVisible(this,part))
			continue;

		//set right culling
		pD3DDevice->SetRenderState(D3DRS_CULLMODE, pTileCheck->getCullingMode(part));

		//set world 
		EngineHelpers::setWorldTransform(pD3DDevice,pTileCheck->getTransformation(part),renderType == DEPTH);

		//render environmented sea
		if (FAILED(hr=pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, verticesCount, 0, indicesCount/3)))
		{
			LOG("Rendering sea tile failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	return S_OK;
}











































