/****************************************************************************
** SeaTile
**
** sea tile rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(SEATILE_H)
#define SEATILE_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "../common/aabb.h"
#include "../common/tilecheck.h"
#include "../module.h"

const int SEA_TILE_SIZE = 32;		// 32x32 quads (33x33 vertices)

#define D3DFVF_SEA_VERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX2)

class SeaTile : public Tile
{
public:
	struct OneSeaElement
	{
		//element is used
		bool used;

		//the world position of this element
		D3DXVECTOR3 worldPosition;

		//transparency of element
		float alpha;

		//index of vertex
		WORD vertexIndex;
	};


	SeaTile();
	~SeaTile();

	HRESULT render(TileCheck *pTileCheck, ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice, int offsetX, int offsetY, int width,
						   int terrainWidth, D3DXCOLOR color, OneSeaElement** pAllElements);
	HRESULT	destroyGeometry();

private:
	HRESULT createLayer();
	HRESULT createIndexBuffer();

	struct SEAVERTEX
	{
		D3DXVECTOR3 position;
		DWORD		diffuse;
		D3DXVECTOR2 texture1; //normal map
		D3DXVECTOR2 texture2; //lightmap
	};


	LPDIRECT3DDEVICE9	pD3DDevice;
	int					terrainWidth; //the width of terrain

	//is this sea tile enabled
	bool seaTileEnabled;

	//informations about all sea elements
	OneSeaElement **pAllElements;

	//offset of current tile in pAllElements
	int offsetX,offsetY;

	//the color of water
	D3DXCOLOR color;

	//width of tile (quad)
	int width;

	//number of vertices and indices
	long verticesCount;
	long indicesCount;

	LPDIRECT3DVERTEXBUFFER9 meshVB;	//the mesh of the sea 
	LPDIRECT3DINDEXBUFFER9	meshIB;	//the index buffer for the mesh
};

#endif