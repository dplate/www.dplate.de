#include "water.h"

#include "../logger/logger.h"
#include "../../common/minixml.h"
#include "../common/enginehelpers.h"
#include "../common/time.h"
#include "../common/config.h"	

#include <tchar.h>
inline DWORD F2DW( FLOAT f ) { return *((DWORD*)&f); }

Water *Water::instance = NULL;

/****************************************************************************
** Water Constructor
**
** init vars
**
** Author: Dirk Plate
****************************************************************************/
Water::Water()
{
	Module::Module();
	name = "Water";

	lightMapTexture = NULL;
	waterTexture = NULL;

	instance = this;
}

Water::~Water()
{
	instance = NULL;

	Module::~Module();
}

/****************************************************************************
** Water CreateGeometry
**
** create and initializes the water elements
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Water::createGeometry(LPDIRECT3DDEVICE9 pD3DDevice)
{
	LOGFUNC("createGeometry()");

	this->pD3DDevice = pD3DDevice;

	HRESULT hr;

	//load common settings
	D3DXCOLOR color = 0x202020FF;
	float reflection = 0.5f;
	float transparency = 0.5f;

	//load properties of water
	string waterPropertiesPath = Config::instance->getEnginePath()+"/water.txt";
	MiniXML xmlFile;
	if (xmlFile.openFile(waterPropertiesPath.c_str(),MiniXML::READ))
	{
		int value;
		if (xmlFile.readInteger("reflection",&value))
			reflection = (float)value/100.0f;
		if (xmlFile.readInteger("transparency",&value))
			transparency = float((100-value)*5)/100.0f;
		if (xmlFile.readInteger("rColor",&value))
			color.r = (float)value/255.0f;
		if (xmlFile.readInteger("gColor",&value))
			color.g = (float)value/255.0f;
		if (xmlFile.readInteger("bColor",&value))
			color.b = (float)value/255.0f;
		xmlFile.closeFile();
	}

	//if no water reflection, we need to load the water texture
	if (!Config::instance->isWaterReflection())
	{
		if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, "./enginefiles/water.jpg", D3DFMT_UNKNOWN, &waterTexture)))
		{
			LOG("Loading water texture failed", Logger::LOG_CRIT);
			return hr;
		}
	}
	else waterTexture = NULL;

	//load common light map texture
	string seaLightmapPath = Config::instance->getEnginePath()+"/waterlightmap.jpg";
	if (FAILED(hr=EngineHelpers::loadTexture( pD3DDevice, seaLightmapPath.c_str(), D3DFMT_UNKNOWN, &lightMapTexture)))
	{
		lightMapTexture = NULL;
	}

	//create sea
	if (FAILED(hr=sea.createGeometry(pD3DDevice,&rivers,
									 reflection,transparency,color,lightMapTexture,
									 waterTexture)))
	{
		LOG("Creating sea failed", Logger::LOG_CRIT);
		return hr;
	}

	//create rivers
	if (FAILED(hr=rivers.createGeometry(pD3DDevice,sea.getHeight(),
										reflection,transparency,color,lightMapTexture,
										waterTexture)))
	{
		LOG("Creating rivers failed", Logger::LOG_CRIT);
		return hr;
	}

	//update camera position
	Camera::instance->translateToCamera(0.0f, 0.0f, 0.0f);

	return Module::createGeometry(pD3DDevice);
}

/****************************************************************************
** Water DestroyGeometry
**
** destroy the water elements
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Water::destroyGeometry()
{
	LOGFUNC("destroyGeometry()");

	HRESULT hr;

	//release common textures
	SAFE_RELEASE(lightMapTexture);
	SAFE_RELEASE(waterTexture);

	if (FAILED(hr=sea.destroyGeometry()))
		return hr;

	if (FAILED(hr=rivers.destroyGeometry()))
		return hr;

	return Module::destroyGeometry();
}

/****************************************************************************
** Water Render
**
** renders all water elements
**
** Author: Dirk Plate
****************************************************************************/
HRESULT	Water::render(ModuleRenderType renderType)
{
	HRESULT hr;

	if (FAILED(hr=rivers.render(renderType)))
		return hr;

	if (FAILED(hr=sea.render(renderType)))
		return hr;

	return Module::render(renderType);
}

/****************************************************************************
** Water Update
**
** Animate sea and rivers
**
** Author: Dirk Plate
****************************************************************************/
HRESULT Water::update()
{
	HRESULT hr;

	//water uses frame time of game (controllable by user)
	float elapsedTime = Time::instance->getGameFrameTime();

	if (FAILED(hr=rivers.update(elapsedTime)))
		return hr;

	if (FAILED(hr=sea.update(elapsedTime)))
		return hr;

	return Module::update();
}

/****************************************************************************
** Water getHeight
**
** return the max height of water at a position
**
** Author: Dirk Plate
****************************************************************************/
float Water::getHeight(float x, float y)
{
	return MAX(sea.getHeight(),rivers.getHeight(x,y));
}

/****************************************************************************
** Water enable
**
** enable all water elements
**
** Author: Dirk Plate
****************************************************************************/
void Water::enable()
{
	sea.enable();
	rivers.enable();
}

/****************************************************************************
** Water disable
**
** disable all water elements
**
** Author: Dirk Plate
****************************************************************************/
void Water::disable()
{
	sea.disable();
	rivers.disable();
}


/****************************************************************************
** Water enableWireframe
**
** show all water elements in wireframe mode
**
** Author: Dirk Plate
****************************************************************************/
void Water::enableWireframe()
{
	sea.enableWireframe();
	rivers.enableWireframe();
}

/****************************************************************************
** Water disableWireframe
**
** show all water elements in normal mode
**
** Author: Dirk Plate
****************************************************************************/
void Water::disableWireframe()
{
	sea.disableWireframe();
	rivers.disableWireframe();
}











































