/****************************************************************************
** Water
**
** water rendering and management class
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(WATER_H)
#define WATER_H
#pragma warning(disable:4786)

#include <d3d9.h>
#include <d3dx9.h>
#include <Dxerr9.h>
#include "sea.h"
#include "rivers.h"
#include "../module.h"


class Water : public Module
{
public:
	Water();
	~Water();

	HRESULT update();
	HRESULT render(ModuleRenderType renderType);

	HRESULT createGeometry(LPDIRECT3DDEVICE9 pD3DDevice);
	HRESULT	destroyGeometry();

	void enable();
	void disable();
	void enableWireframe();
	void disableWireframe();

	float getHeight(float x, float y);
	Sea *getSea() {return &sea;}

	static Water *instance;				//the instance to the only one water objects

private:
	LPDIRECT3DDEVICE9	pD3DDevice;

	//the common light map texture
	LPDIRECT3DTEXTURE9 lightMapTexture;

	//the common water texture (backup for old graphic cards)
	LPDIRECT3DTEXTURE9 waterTexture;

	//the sea
	Sea sea;

	//the rivers
	Rivers rivers;
};

#endif