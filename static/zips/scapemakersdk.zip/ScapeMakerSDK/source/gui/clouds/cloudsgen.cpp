/****************************************************************************
** CloudsGen
**
** The cloud layer generator class
**
** Author: Dirk Plate
****************************************************************************/

#include <qimage.h>
#include "cloudsgen.h"
#include "math.h"
#include "../../engine/common/enginehelpers.h"

#define SMALLEST_NOISE_SIZE 32

/****************************************************************************
** CloudsGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

CloudsGen::CloudsGen()
{
	preview = false;
	noiseMap.setAutoDelete(true);
}

CloudsGen::~CloudsGen()
{

}

/****************************************************************************
** CloudsGen generatePreview
**
** starts the generation of clouds preview
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::generatePreview(CxImage *pPreviewBitmapSet,
								int coverageSet, int sizeSet, int smoothnessSet)
{
	//stop a old thread
	cancel();

	//save all settings intern
	pPreviewBitmap = pPreviewBitmapSet;
	coverage = coverageSet;
	size = sizeSet;
	smoothness = smoothnessSet;

	//this is only the preview
	preview = true;

	//start the generate thread
	start();
}

/****************************************************************************
** CloudsGen generate
**
** starts the generation of the cloud layers
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::generate(int *pProgressSet, CxImage *pPreviewBitmapSet, QString enginePathSet,
						 int resolutionSet, int coverageSet, int sizeSet, int smoothnessSet, int framesSet)
{
	//save all settings intern
	pProgress = pProgressSet;
	pPreviewBitmap = pPreviewBitmapSet;
	enginePath = enginePathSet;
	resolution = resolutionSet;
	coverage = coverageSet;
	size = sizeSet;
	smoothness = smoothnessSet;
	frames = framesSet;
	
	//we are making the real shadow texture
	preview = false;

	//start the generate thread
	start();
}

/****************************************************************************
** CloudsGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::cancel()
{
	//set flag true, so the thread will stop
	if (running()) cancelFlag = true;
}

/****************************************************************************
** CloudsGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::run()
{
	//init cancel-flag
	cancelFlag = false;

	if (preview) doPreview();
	else doGeneration();
}

/****************************************************************************
** CloudsGen doPreview
**
** this is the real generation of the cloud layer preview
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::doPreview()
{	
	//init random generator
	srand((unsigned)time(NULL));

	//create preview bitmap
	pPreviewBitmap->Create(256,256,24);
	pPreviewBitmap->Clear(0x00);

	//calculate smallest noise size
	int smallestNoiseSize = 256 >> (size-1);

	//create image with right size
	QImage currentNoise(smallestNoiseSize,smallestNoiseSize,8,256);
		
	//insert noise
	createNoise(&currentNoise,255);

	//resample it to right size
	QImage sampledNoise = interpolate(currentNoise, 256);

	//threshold cloud layer
	threshold(sampledNoise);

	//copy to preview
	for (int y=0; y<256; y++)
		for (int x=0; x<256; x++)
	{
		int grayValue = sampledNoise.pixelIndex(x,y);
		//set gray value in preview
		RGBQUAD color;
		color.rgbRed = grayValue;
		color.rgbGreen = grayValue;
		color.rgbBlue = grayValue;
		pPreviewBitmap->SetPixelColor(x,y,color);
	}

}

/****************************************************************************
** CloudsGen doGeneration
**
** this is the real generation of the cloud layer
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::doGeneration()
{
	*pProgress = 0;
	exactProgress = 0.0f;

	//calculate progress progress per frame
	float progressAdd = 100.0f/frames;

	//init random generator
	srand((unsigned)time(NULL));

	//create preview bitmap
	pPreviewBitmap->Create(resolution,resolution,24);

	//calculate number of octaves
	int n = 0;
	int i = resolution;
	while (i > 2)
	{
		i /=2;
		n++;
	}
	int octaveCount = ((size-1)*n)/7;

	//create noise maps for animation
	//one noise map vector for each octave
	noiseMap.resize(octaveCount);

	//calculate smallest noise size
	int smallestNoiseSize = resolution >> octaveCount;

	//calculate gray value factor
	grayValueFactor = (256*smallestNoiseSize*resolution)/(2*resolution-smallestNoiseSize);

	//create noise maps for each octave
	int currentSize = smallestNoiseSize;
	for (int currentOctave=0; currentOctave<octaveCount; currentOctave++)
	{
		//create noise maps for this octave
		createNoiseMaps(currentOctave, currentSize);
		
		//next noise map have double size
		currentSize *= 2;
	}

	//create output png
	CxImage cloudLayerPNG(resolution,resolution,24);
	cloudLayerPNG.AlphaCreate();

	//create clouds layers for all frames
	for (int currentFrame=0; currentFrame < frames; currentFrame++)
	{
		//if cancel... return
		if (cancelFlag) return;

		QImage currentCloudLayer = createCloudLayer(currentFrame);

		//put current frame to preview and disk
		for (int y=0; y<resolution; y++)
			for (int x=0; x<resolution; x++)
		{
			int grayValue = currentCloudLayer.pixelIndex(x,y);
			
			//set gray value in preview
			RGBQUAD color;
			color.rgbRed = grayValue;
			color.rgbGreen = grayValue;
			color.rgbBlue = MAX(200,grayValue);
			pPreviewBitmap->SetPixelColor(x,y,color);
			
			//set alpha in png
			cloudLayerPNG.SetPixelColor(x,y,0xffffffff);
			cloudLayerPNG.AlphaSet(x,y,grayValue);
		}
		
		//finish png
		cloudLayerPNG.AlphaSetMax(255);
		QString cloudLayerPath = enginePath+QString("/cloudlayer/frame_%1.png").arg(currentFrame);
		cloudLayerPNG.Save(cloudLayerPath,CXIMAGE_FORMAT_PNG);

		//make progress
		exactProgress += progressAdd;
		*pProgress = exactProgress;
	}

	//clear noise map vectors
	for (currentOctave=0; currentOctave<octaveCount; currentOctave++)
		noiseMap.at(currentOctave)->clear();
	noiseMap.clear();
	
	*pProgress = 100;
}

/****************************************************************************
** CloudsGen createCloudLayer
**
** create a cloud layer for the specified frame
**
** Author: Dirk Plate
****************************************************************************/
QImage CloudsGen::createCloudLayer(int frame)
{
	int x,y;

	//create new cloud layer texture
	QImage cloudLayer(resolution,resolution,8,256);
	cloudLayer.fill(0);

	//create frame time (between 0 and 1)
	float frameTime = float(frame)/float(frames);

	//combine all octaves
	for (uint currentOctave=0; currentOctave<noiseMap.size(); currentOctave++)
	{
		//calculate frame time multiplier
		int frameTimeFactor = pow(2, currentOctave+1);

		//calculate shift for frame time
		float frameTimeShift = 1.0f/(float(frameTimeFactor)*2.0f);
		
		//shift frame time
		float octaveFrameTime = frameTime-frameTimeShift;
		if (octaveFrameTime < 0.0f) octaveFrameTime += 1.0f;

		//calculate absolute frame time for this octave
		octaveFrameTime = frameTime*frameTimeFactor;

		//get right first noise map
		int firstMap = 0;
		while (int(octaveFrameTime) > 0)
		{
			octaveFrameTime -= 1.0f;
			firstMap++;
		}

		//second map is the map behind the first one
		int secondMap = (firstMap+1)%frameTimeFactor;

		//create image with interpolation between first and second map
		int currentSize = (*noiseMap[currentOctave])[0]->width();
		QImage currentNoise(currentSize,currentSize,8,256);

		//blend both noise maps
		for (y=0; y<currentSize; y++)
			for (x=0; x<currentSize; x++)
		{
			int firstGrayValue = (*noiseMap[currentOctave])[firstMap]->pixelIndex(x,y);
			int secondGrayValue = (*noiseMap[currentOctave])[secondMap]->pixelIndex(x,y);
			int resultGrayValue = (1.0f-octaveFrameTime)*firstGrayValue +
								  octaveFrameTime*secondGrayValue;
			currentNoise.setPixel(x,y,resultGrayValue);
		}

		//calculate max gray value for these noise maps
		int maxGrayValue = (grayValueFactor/currentSize)-1;

		//equalize histogram of new noise map
		//equalize(currentNoise, maxGrayValue);

		//resample it to right size
		QImage sampledNoise = interpolate(currentNoise, resolution);

		//add to result
		for (y=0; y<resolution; y++)
			for (x=0; x<resolution; x++)
		{
			//get old gray values
			int grayValue1 = cloudLayer.pixelIndex(x,y);
			int grayValue2 = sampledNoise.pixelIndex(x,y);

			//add gray value
			int grayValueResult = grayValue1+grayValue2;
			
			//set new gray value
			cloudLayer.setPixel(x,y,grayValueResult);
		}
	}

	//threshold cloud layer
	threshold(cloudLayer);

	return cloudLayer;
}

/****************************************************************************
** CloudsGen createNoiseMaps
**
** create all animation noise maps for one octave
**
** Author: Dirk Plate
****************************************************************************/
void CloudsGen::createNoiseMaps(int octave, int size)
{
	//calculate count of noise maps for this octave
	// 1->3, 2->5, 3->9, 4->17 => 2^n+1
	int mapCount = pow(2,octave+1);

	//create vector in right size
	noiseMap.insert(octave,new ImageVector());
	noiseMap.at(octave)->resize(mapCount);

	//calculate max gray value for these noise maps
	int maxGrayValue = (grayValueFactor/size)-1;

	//create all noise maps 
	for (int currentMap=0; currentMap<mapCount; currentMap++)
	{
		//create image in right size
		QImage *pImage = new QImage(size, size, 8, 256);
		
		//fill with noise
		createNoise(pImage, maxGrayValue);

		//add in vector
		noiseMap.at(octave)->insert(currentMap, pImage);
	}
}

/****************************************************************************
** CloudsGen createNoise
**
** fill the image with a noise
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGen::createNoise(QImage *pImage, int maxGrayValue)
{
	for (int y=0; y<pImage->height(); y++)
		for (int x=0; x<pImage->width(); x++)
	{
		int grayValue = ((float)(rand()*(maxGrayValue)))/((float)RAND_MAX);
		pImage->setPixel(x, y, grayValue);
	}
}

/****************************************************************************
** CloudsGen interpolate
**
** interpolate image to new size (smoothing)
**
** Author: Dirk Plate
****************************************************************************/
QImage CloudsGen::interpolate(QImage image, int newSize)
{
	//if image has right size or is bigger, use smooth scale from qimage
	if (image.width() > newSize)
	{
		return image.smoothScale(newSize, newSize);
	}
	else if(image.width() == newSize)
	{
		return image.copy();
	}

	//create new image with new size
	QImage newImage(newSize, newSize, 8,256);

	//go through all pixels of new image
	for (int newY=0; newY<newSize; newY++)
		for (int newX=0; newX<newSize; newX++)
	{
		//calculate float position in old image
		float x = float(newX*image.width())/float(newSize);
		float y = float(newY*image.height())/float(newSize);
		int xInt = int(x);
		int yInt = int(y);
		
	
		//get strength from all edges around this point
		float strengthLeftTop,strengthRightTop,strengthLeftBottom,strengthRightBottom;
		EngineHelpers::getInterpolationStrengths(x, y,&strengthLeftTop, &strengthRightTop, &strengthLeftBottom, &strengthRightBottom);

		//get values from edges
		float valueLeftTop = image.pixelIndex(xInt, yInt);
		float valueRightTop = image.pixelIndex((xInt+1)%image.width(), yInt);;
		float valueLeftBottom = image.pixelIndex(xInt, (yInt+1)%image.height());;
		float valueRightBottom = image.pixelIndex((xInt+1)%image.width(), (yInt+1)%image.height());
		
		//calculate mean value
		float valueMiddle = (strengthLeftTop*valueLeftTop+
							 strengthRightTop*valueRightTop+
							 strengthLeftBottom*valueLeftBottom+
							 strengthRightBottom*valueRightBottom);

		//set pixel to new value
		newImage.setPixel(newX, newY, valueMiddle);
	}
	return newImage;
}

/****************************************************************************
** CloudsGen threshold
**
** changes the image into black and white areas (not real thresholding)	
**
** Author: Dirk Plate
****************************************************************************/
void CloudsGen::threshold(QImage image)
{
	//calculate right coverage value
	int coverageValue = ((100-(coverage))*250)/100;
	
	//calculate right smoothness value
	float smoothnessValue = 0.5f+float(smoothness)*0.49f/100.0f;

	for (int y=0; y<image.height(); y++)
		for (int x=0; x<image.width(); x++)
	{
		//get gray value of image
		int grayValue = image.pixelIndex(x,y);

		//calculate exponent
		int exp = grayValue - coverageValue;
		if (exp < 0) exp=0;
 
		//calculate new gray value;
		int newGrayValue = 255 - (powf(smoothnessValue, exp) * 255.0f); 

		//set new gray value in image
		image.setPixel(x, y, newGrayValue);
	}
}

/****************************************************************************
** CloudsGen equalize
**
** equalize the histogram of an image
**
** Author: Dirk Plate
****************************************************************************/
void CloudsGen::equalize(QImage image, int maxGrayValue)
{
	int i;
	int x,y;

	//create histogram of image
	long histo[256];
	for (i=0; i<maxGrayValue; i++)
		histo[i]=0;
	for (y=0; y<image.height(); y++)
		for (x=0; x<image.width(); x++)
	{
		histo[image.pixelIndex(x,y)]++;
	}

	//create sum histogram
	for (i=1; i<maxGrayValue; i++)
		histo[i] += histo[i-1];

	//calculate factor k
	float k=float(maxGrayValue)/histo[maxGrayValue-1];

	//calculate new transformed values in histogram
	for (i=0; i<maxGrayValue; i++)
		histo[i] *= k;

	//transform all pixels in image
	for (y=0; y<image.height(); y++)
		for (x=0; x<image.width(); x++)
	{
		image.setPixel(x,y,histo[image.pixelIndex(x,y)]);
	}
}