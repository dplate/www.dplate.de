/****************************************************************************
** CloudsGen
**
** The cloud layer generator class
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include <qthread.h>
#include <qvector.h>
#include <stdlib.h>
#include <time.h>
#include "ximage.h"


class CloudsGen : public QThread
{
public:
	CloudsGen();
	~CloudsGen();

	void generatePreview(CxImage *pPreviewBitmapSet, 
		int coverageSet, int sizeSet, int smoothnessSet);
	void generate(int *pProgressSet, CxImage *pPreviewBitmapSet, QString enginePathSet,
		int resolutionSet, int coverageSet, int sizeSet, int smoothnessSet, int framesSet);
	void cancel();

protected:
	virtual void run();

private:
	void doPreview();			//the real generation of the cloud layer-preview
	void doGeneration();		//the real generation of the cloud layer

	//perlin noise generation functions
	QImage createCloudLayer(int frame);			//create a cloud layer for the specified frame
	void createNoiseMaps(int octave, int size); //create all animation noise maps for one octave
	void createNoise(QImage *pImage, int maxGrayValue);			//fill the image with a noise
	QImage interpolate(QImage image, int newSize);		//interpolate image to new size (smoothing)
	void threshold(QImage image);				//changes the image into black and white areas (not real thresholding)			
	void equalize(QImage image, int maxGrayValue);		//equalize the histo of an image

	int *pProgress;
	float exactProgress;
	bool cancelFlag;			//is true, if the generate-thread should stop

	CxImage *pPreviewBitmap;	//the generated shadow-preview
	bool preview;				//making the shadow preview or the real shadow on texture?
	QString enginePath;			//the path to the engine directory

	//parameter
	int resolution;				//resolution of cloud layer texture
	int coverage;				//density of cloud layer
	int size;					//size of the clouds in cloud layer
	int smoothness;				//smoothness of the edges of the clouds in cloud layer
	int frames;					//how many frames to render?

	//vector with all generated noise maps
	typedef QVector<QImage> ImageVector;
	QVector<ImageVector> noiseMap;

	//gray value factor (to calculate max gray value)
	int grayValueFactor;
};
