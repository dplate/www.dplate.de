/****************************************************************************
** CloudsGUI
**
** the clouds-tab window
**
** Author: Dirk Plate
****************************************************************************/

#include "cloudsgui.h"

/****************************************************************************
** CloudsGUI Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

CloudsGUI::CloudsGUI( QWidget* parent, const char* name, WFlags f )
	: CloudsGUIBase(parent, name, f)
{
	generatingProgress = 0;

	generatingPreviewTimer = false;
	generatingPreviewTimerID = -1;
	generatingTimerID = -1;

	dontRecalculate = false;

	cancelButton->hide();	//hide the cancel button
}

/****************************************************************************
** CloudsGUI showEvent
**
** Is called, when the CloudsGUI will be shown.
** Load everything for this panel!
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::showEvent(QShowEvent *showEvent)
{
	//ignore spontaneous show events (come from iconified)
	if (showEvent->spontaneous())
		return;

	int currentCirrusResolution = 256;

	//get a pointer to the widget with the tab bar (we need this for disabling other tabs while generating)
	topParent =	(ScapeMakerDialog*)(parentWidget()->parentWidget()->parentWidget()->parentWidget());

	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//hide tool in bitmapnav
	bitmapNavContainer->setPenButtonVisible(false);
	bitmapNavContainer->setRubberButtonVisible(false);

	//prepare sliders
	cumulusDensitySlider->setProperties(CoolSlider::LINEAR,tr("Density"),0,100,"%",1);
	cumulusSpeedSlider->setProperties(CoolSlider::LINEAR,tr("Speed"),1,100,"m/s",1);
	cumulusHeightSlider->setProperties(CoolSlider::LINEAR,tr("Height"),1,20,"",1);
	cumulusLengthSlider->setProperties(CoolSlider::LINEAR,tr("Length"),10,50,"",1);
	cumulusWidthSlider->setProperties(CoolSlider::LINEAR,tr("Width"),5,20,"",1);
	cirrusCoverageSlider->setProperties(CoolSlider::LINEAR,tr("Coverage"),0,100,"%",1);
	cirrusSizeSlider->setProperties(CoolSlider::LINEAR,tr("Size"),1,8,"",1);
	cirrusSmoothnessSlider->setProperties(CoolSlider::LINEAR,tr("Smoothness"),0,100,"%",1);
	cirrusFramesSlider->setProperties(CoolSlider::LINEAR,tr("Frames"),1,50,"",1);
	cirrusMutationSpeedSlider->setProperties(CoolSlider::LINEAR,tr("Mutation speed"),0,100,"",1);
	cirrusMovingSpeedSlider->setProperties(CoolSlider::LINEAR,tr("Moving speed"),0,100,"m/s",1);
	cirrusRepetitionSlider->setProperties(CoolSlider::LINEAR,tr("Repetitions"),1,10,"",1);
	cirrusHeightSlider->setProperties(CoolSlider::LINEAR,tr("Height"),0,5000,"m",1);

	//don't recalculate during initialising
	dontRecalculate = true;

	//set default values for sliders first
	cumulusDensitySlider->setValue(0,0);
	cumulusSpeedSlider->setValue(0,50);
	cumulusHeightSlider->setValue(0,8);
	cumulusLengthSlider->setValue(0,30);
	cumulusWidthSlider->setValue(0,10);
	cirrusCoverageSlider->setValue(0,50);
	cirrusSizeSlider->setValue(0,6);
	cirrusSmoothnessSlider->setValue(0,90);
	cirrusFramesSlider->setValue(0,20);
	cirrusMutationSpeedSlider->setValue(0,10);
	cirrusMovingSpeedSlider->setValue(0,10);
	cirrusRepetitionSlider->setValue(0,8);
	cirrusHeightSlider->setValue(0,3000);

	//load all settings from text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/clouds.txt",MiniXML::READ))
	{
		int value;

		if (xmlFile.readInteger("cumulusDensity",&value))
			cumulusDensitySlider->setValue(0,value);

		if (xmlFile.readInteger("cumulusSpeed",&value))
			cumulusSpeedSlider->setValue(0,value);

		if (xmlFile.readInteger("cumulusHeight",&value))
			cumulusHeightSlider->setValue(0,value);

		if (xmlFile.readInteger("cumulusLength",&value))
			cumulusLengthSlider->setValue(0,value);

		if (xmlFile.readInteger("cumulusWidth",&value))
			cumulusWidthSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusResolution",&value))
			currentCirrusResolution = value;

		if (xmlFile.readInteger("cirrusCoverage", &value))
			cirrusCoverageSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusSize", &value))
			cirrusSizeSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusSmoothness", &value))
			cirrusSmoothnessSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusFrames", &value))
			cirrusFramesSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusMutationSpeed", &value))
			cirrusMutationSpeedSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusMovingSpeed", &value))
			cirrusMovingSpeedSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusRepetition", &value))
			cirrusRepetitionSlider->setValue(0,value);

		if (xmlFile.readInteger("cirrusHeight", &value))
			cirrusHeightSlider->setValue(0,value);

		xmlFile.closeFile();
	}
	else
	{
		//try to load from enviroment text file (compatibility to <1.2)
		if (xmlFile.openFile(projectPath+"/enviroment.txt",MiniXML::READ))
		{
			int value;

			if (xmlFile.readInteger("cloudsDensity",&value))
				cumulusDensitySlider->setValue(0,value);

			if (xmlFile.readInteger("cloudsSpeed",&value))
				cumulusSpeedSlider->setValue(0,value);

			xmlFile.closeFile();
		}
	}

	//set right resolution
	if (currentCirrusResolution == 256)
		cirrusResolution->setCurrentItem(0);
	else if (currentCirrusResolution == 512)
		cirrusResolution->setCurrentItem(1);
	else if (currentCirrusResolution == 1024)
		cirrusResolution->setCurrentItem(2);
	else cirrusResolution->setCurrentItem(0);

	//create preview bitmap
	previewBitmap.Create(256,256,24);

	//show the heightmap in bitmapNav
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(previewBitmap));

	//now recalculate again
	dontRecalculate = false;

	//update progress bar
	generatingProgress = 0;
	progressBar->setProgress(generatingProgress);

	//set expert mode
	filterExpertFunctions();

	//create first clouds preview
	createPreview();
}

/****************************************************************************
** CloudsGUI hideEvent
**
** Is called, when the CloudsGUI will be hide.
** Save everything for this panel!
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::hideEvent(QHideEvent *hideEvent)
{
	int currentCirrusResolution = 256;

	//retrieve current resolution
	if (cirrusResolution->currentItem() == 0)
		currentCirrusResolution = 256;
	else if (cirrusResolution->currentItem() == 1)
		currentCirrusResolution = 512;
	else if (cirrusResolution->currentItem() == 2)
		currentCirrusResolution = 1024;


	//save the settings to the text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/clouds.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("cumulusDensity",cumulusDensitySlider->getValue(0));
		xmlFile.writeInteger("cumulusSpeed",cumulusSpeedSlider->getValue(0));
		xmlFile.writeInteger("cumulusHeight",cumulusHeightSlider->getValue(0));
		xmlFile.writeInteger("cumulusLength",cumulusLengthSlider->getValue(0));
		xmlFile.writeInteger("cumulusWidth",cumulusWidthSlider->getValue(0));
		xmlFile.writeInteger("cirrusResolution",currentCirrusResolution);
		xmlFile.writeInteger("cirrusCoverage",cirrusCoverageSlider->getValue(0));
		xmlFile.writeInteger("cirrusSize",cirrusSizeSlider->getValue(0));
		xmlFile.writeInteger("cirrusSmoothness",cirrusSmoothnessSlider->getValue(0));
		xmlFile.writeInteger("cirrusFrames",cirrusFramesSlider->getValue(0));
		xmlFile.writeInteger("cirrusMutationSpeed",cirrusMutationSpeedSlider->getValue(0));
		xmlFile.writeInteger("cirrusMovingSpeed",cirrusMovingSpeedSlider->getValue(0));
		xmlFile.writeInteger("cirrusRepetition",cirrusRepetitionSlider->getValue(0));
		xmlFile.writeInteger("cirrusHeight",cirrusHeightSlider->getValue(0));

		xmlFile.closeFile();
	}

	//save the properties of the clouds in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/clouds.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("cumulusDensity",cumulusDensitySlider->getValue(0));
		xmlFile.writeInteger("cumulusSpeed",cumulusSpeedSlider->getValue(0));
		xmlFile.writeInteger("cumulusHeight",cumulusHeightSlider->getValue(0));
		xmlFile.writeInteger("cumulusLength",cumulusLengthSlider->getValue(0));
		xmlFile.writeInteger("cumulusWidth",cumulusWidthSlider->getValue(0));
		xmlFile.writeInteger("cirrusFrames",cirrusFramesSlider->getValue(0));
		xmlFile.writeInteger("cirrusMutationSpeed",cirrusMutationSpeedSlider->getValue(0));
		xmlFile.writeInteger("cirrusMovingSpeed",cirrusMovingSpeedSlider->getValue(0));
		xmlFile.writeInteger("cirrusRepetition",cirrusRepetitionSlider->getValue(0));
		xmlFile.writeInteger("cirrusHeight",cirrusHeightSlider->getValue(0));

		xmlFile.closeFile();
	}
}


/****************************************************************************
** CloudsGUI setProjectPath
**
** set the current project
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}


/****************************************************************************
** CloudsGUI valuesChanged
**
** Is called, when a value of the cloud layer group changed
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::valuesChanged()
{
	//generate the distribution
	if (!dontRecalculate)
		createPreview();
}

/****************************************************************************
** CloudsGUI generateClicked
**
** Is called, when the generate button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::generateClicked()
{
	//retrieve the current resolution
	int currentCirrusResolution;
	if (cirrusResolution->currentItem() == 0)
		currentCirrusResolution = 256;
	else if (cirrusResolution->currentItem() == 1)
		currentCirrusResolution = 512;
	else if (cirrusResolution->currentItem() == 2)
		currentCirrusResolution = 1024;
	
	//reset the generatingProgress
	generatingProgress = 0;
	progressBar->reset();

	//start the generation thread
	generator.generate(
		&generatingProgress,
		&currentBitmap,
		projectPath+"/engine/",
		currentCirrusResolution,
		cirrusCoverageSlider->getValue(0),
		cirrusSizeSlider->getValue(0),
		cirrusSmoothnessSlider->getValue(0),
		cirrusFramesSlider->getValue(0));

	//hide the generatebutton and show the cancelbutton
	generateButton->hide();
	cancelButton->show();

	//disable all tabs except the own
	enableTabs(false);

	cumulusGroup->setEnabled(false);
	cirrusResolutionLabel->setEnabled(false);
	cirrusResolution->setEnabled(false);
	cirrusCoverageSlider->setEnabled(false);
	cirrusSizeSlider->setEnabled(false);
	cirrusSmoothnessSlider->setEnabled(false);
	cirrusFramesSlider->setEnabled(false);
	cirrusMutationSpeedSlider->setEnabled(false);
	cirrusMovingSpeedSlider->setEnabled(false);
	cirrusRepetitionSlider->setEnabled(false);
	cirrusHeightSlider->setEnabled(false);

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//start timer for updating the image and progressbar
	generatingTimerID = startTimer(1000);
}

/****************************************************************************
** CloudsGUI cancelClicked
**
** Is called, when the cancel-Button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::cancelClicked()
{
	//stop the generating-thread
	generator.cancel();

	//delete timer
	killTimer(generatingTimerID);
	generatingTimerID = -1;

	//update the image
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));

	//update the progress bar
	progressBar->setProgress(generatingProgress);

	//hide the cancel button and show the generate button
	cancelButton->hide();
	generateButton->show();

	//enable all tabs except the own
	enableTabs(true);

	cumulusGroup->setEnabled(true);
	cirrusResolutionLabel->setEnabled(true);
	cirrusResolution->setEnabled(true);
	cirrusCoverageSlider->setEnabled(true);
	cirrusSizeSlider->setEnabled(true);
	cirrusSmoothnessSlider->setEnabled(true);
	cirrusFramesSlider->setEnabled(true);
	cirrusMutationSpeedSlider->setEnabled(true);
	cirrusMovingSpeedSlider->setEnabled(true);
	cirrusRepetitionSlider->setEnabled(true);
	cirrusHeightSlider->setEnabled(true);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();
}

/****************************************************************************
** CloudsGUI createPreview
**
** create clouds preview
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::createPreview()
{
	//delete old timer
	if (generatingPreviewTimer)
		killTimer(generatingPreviewTimerID);

	//disable tabs
	enableTabs(false);

	generator.generatePreview(&currentBitmap,
		cirrusCoverageSlider->getValue(0),
		cirrusSizeSlider->getValue(0),
		cirrusSmoothnessSlider->getValue(0));

	generatingPreviewTimerID = startTimer(100);
	generatingPreviewTimer = true;
}

/****************************************************************************
** CloudsGUI timerEvent
**
** Is called, at timer event
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::timerEvent(QTimerEvent *timerEvent)
{
	//only its our clouds preview timer
	if (timerEvent->timerId() == generatingPreviewTimerID)
	{
		//generating done?
		if (!generator.running())
		{
			//delete timer
			killTimer(generatingPreviewTimerID);
			generatingPreviewTimerID = -1;
			generatingPreviewTimer = false;

			//update the image
			bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));

			//enable tabs
			enableTabs(true);
		}
	}
	//its the real clouds generation
	else if (timerEvent->timerId() == generatingTimerID)
	{
		//update the image
		bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));

		//update the progressbar
		progressBar->setProgress(generatingProgress);

		//generating done?
		if (!generator.running())
		{
			//use cancelClicked for doing the work
			cancelClicked();
		}
	}
}

/****************************************************************************
** CloudsGUI enableTabs
**
** en or disable the tabs
**
** Author: Dirk Plate
****************************************************************************/

void CloudsGUI::enableTabs(bool enable)
{
	topParent->tabContainer->setTabEnabled(topParent->topografie, enable);
	topParent->tabContainer->setTabEnabled(topParent->texture, enable);
	topParent->tabContainer->setTabEnabled(topParent->objects, enable);
	topParent->tabContainer->setTabEnabled(topParent->water, enable);
	topParent->tabContainer->setTabEnabled(topParent->enviroment, enable);
	topParent->tabContainer->setTabEnabled(topParent->preview, enable);
	topParent->menuBar->setEnabled(enable);
}

/****************************************************************************
** CloudsGUI filterExpertFunctions
**
** Hides or show all sliders for expert or beginner mode
**  
** Author: Dirk Plate
****************************************************************************/
void CloudsGUI::filterExpertFunctions()
{
	//load settings from file
	MiniXML xmlFile;
	bool loadedExpert = false;
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		bool bValue;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}	

	//set visibility for all functions
	if (!loadedExpert)
	{
		cumulusGroup->hide();
		cirrusResolutionLabel->hide();
		cirrusResolution->hide();
		cirrusFramesSlider->hide();
		cirrusRepetitionSlider->hide();
		cirrusMutationSpeedSlider->hide();
	}
	else
	{
		cumulusGroup->show();
		cirrusResolutionLabel->show();
		cirrusResolution->show();
		cirrusFramesSlider->show();
		cirrusRepetitionSlider->show();
		cirrusMutationSpeedSlider->show();
	}
}