/****************************************************************************
** CloudsGUI
**
** the clouds-tab window
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "cloudsguibase.h"
#include "../common/coolslider.h"
#include "../scapemakerdialog.h"
#include "../../common/minixml.h"
#include "../common/bitmapnav.h"
#include "cloudsgen.h"
#include "qprogressbar.h"
#include "qtabwidget.h"
#include "qpushbutton.h"
#include "qgroupbox.h"
#include "../common/guihelpers.h"
#include "ximage.h"

class CloudsGUI : public CloudsGUIBase
{
	Q_OBJECT

public:
	CloudsGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setProjectPath(QString projectPathSet);

public slots:
	virtual void valuesChanged();
	virtual void generateClicked();
	virtual void cancelClicked();

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);

private:
	void filterExpertFunctions();
	void createPreview();
	void enableTabs(bool enable);	//en or disable the tabs

	QString projectPath;			//the path to the project-directory
	ScapeMakerDialog *topParent;	//direct pointer to main window

	CxImage previewBitmap;			//the preview of the current settings
	CxImage currentBitmap;			//this bitmap will be shown in bitmapNav

	bool dontRecalculate;			//is this flag set, the clouds preview wont recalculate
	CloudsGen generator;			//the clouds-generator

	bool generatingPreviewTimer;	//clouds preview timer on or not
	int generatingPreviewTimerID;	//the id of the timer while generating the clouds preview
	int generatingTimerID;			//the id of the timer while generating the clouds
	int generatingProgress;			//the progress of generating
};
