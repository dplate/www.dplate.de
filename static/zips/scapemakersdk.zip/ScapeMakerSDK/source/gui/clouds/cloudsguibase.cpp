/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\clouds\cloudsguibase.ui'
**
** Created: Sun Feb 13 15:03:33 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "cloudsguibase.h"

#include <qcombobox.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qprogressbar.h>
#include <qpushbutton.h>
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a CloudsGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
CloudsGUIBase::CloudsGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "CloudsGUIBase" );
    resize( 585, 523 ); 
    setCaption( tr( "CloudsGUI" ) );
    QWhatsThis::add(  this, tr( "Here, different types of clouds can be defined." ) );

    cirrusGroup = new QGroupBox( this, "cirrusGroup" );
    cirrusGroup->setGeometry( QRect( 0, 266, 501, 190 ) ); 
    cirrusGroup->setTitle( tr( "Cirrus clouds" ) );

    cancelButton = new QPushButton( cirrusGroup, "cancelButton" );
    cancelButton->setGeometry( QRect( 10, 155, 93, 23 ) ); 
    cancelButton->setCaption( tr( "" ) );
    cancelButton->setText( tr( "Cancel" ) );
    cancelButton->setFlat( FALSE );
    QToolTip::add(  cancelButton, tr( "Cancel generating clouds" ) );

    progressBar = new QProgressBar( cirrusGroup, "progressBar" );
    progressBar->setGeometry( QRect( 110, 155, 380, 21 ) ); 
    progressBar->setFrameShape( QProgressBar::Box );
    progressBar->setFrameShadow( QProgressBar::Sunken );
    progressBar->setCenterIndicator( TRUE );

    cirrusResolutionLabel = new QLabel( cirrusGroup, "cirrusResolutionLabel" );
    cirrusResolutionLabel->setGeometry( QRect( 10, 20, 60, 20 ) ); 
    cirrusResolutionLabel->setText( tr( "Resolution:" ) );

    cirrusResolution = new QComboBox( FALSE, cirrusGroup, "cirrusResolution" );
    cirrusResolution->insertItem( tr( "256x256" ) );
    cirrusResolution->insertItem( tr( "512x512" ) );
    cirrusResolution->insertItem( tr( "1024x1024" ) );
    cirrusResolution->setGeometry( QRect( 80, 20, 85, 21 ) ); 
    QWhatsThis::add(  cirrusResolution, tr( "Sets the resolution for the cirrus clouds. A high resolution cirrus cloud contains more details but causes a longer generation time and needs more system resources in the 3D-mode." ) );

    cirrusHeightSlider = new CoolSlider( cirrusGroup, "cirrusHeightSlider" );
    cirrusHeightSlider->setGeometry( QRect( 10, 50, 155, 45 ) ); 
    QWhatsThis::add(  cirrusHeightSlider, tr( "Defines the height of the zirrus clouds. Too low a value can lead to errors, if the zirrus clouds touch the cumulus clouds." ) );

    cirrusSizeSlider = new CoolSlider( cirrusGroup, "cirrusSizeSlider" );
    cirrusSizeSlider->setGeometry( QRect( 10, 100, 155, 45 ) ); 
    QWhatsThis::add(  cirrusSizeSlider, tr( "Sets the size of the individual cirrus clouds. A big value creates few, big clouds, while a small value creates many small clouds." ) );

    cirrusCoverageSlider = new CoolSlider( cirrusGroup, "cirrusCoverageSlider" );
    cirrusCoverageSlider->setGeometry( QRect( 175, 15, 90, 60 ) ); 
    QWhatsThis::add(  cirrusCoverageSlider, tr( "Sets how many percent of the sky are covered by cirrus clouds. 100% means a completely covered sky, 0% makes for a clear sky." ) );

    cirrusFramesSlider = new CoolSlider( cirrusGroup, "cirrusFramesSlider" );
    cirrusFramesSlider->setGeometry( QRect( 175, 85, 90, 60 ) ); 
    QWhatsThis::add(  cirrusFramesSlider, tr( "Defines the frame count for the animation of the cirrus clouds. Big values result in smoother changing but also need more system resources. If you do not want animated clouds, set this value to 1." ) );

    cirrusSmoothnessSlider = new CoolSlider( cirrusGroup, "cirrusSmoothnessSlider" );
    cirrusSmoothnessSlider->setGeometry( QRect( 275, 15, 90, 60 ) ); 
    QWhatsThis::add(  cirrusSmoothnessSlider, tr( "Sets the smoothness of the cirrus clouds. Smaller values give sharp edged clouds, big values make clouds slowly fade into the sky." ) );

    cirrusRepetitionSlider = new CoolSlider( cirrusGroup, "cirrusRepetitionSlider" );
    cirrusRepetitionSlider->setGeometry( QRect( 275, 85, 90, 60 ) ); 
    QWhatsThis::add(  cirrusRepetitionSlider, tr( "Defines how often the clouds texture is repeated. High values increase the detail of the clouds, but might lead to visible repititions." ) );

    cirrusMutationSpeedSlider = new CoolSlider( cirrusGroup, "cirrusMutationSpeedSlider" );
    cirrusMutationSpeedSlider->setGeometry( QRect( 375, 15, 115, 60 ) ); 
    QWhatsThis::add(  cirrusMutationSpeedSlider, tr( "Defines how quickly cirrus clouds change shape." ) );

    cirrusMovingSpeedSlider = new CoolSlider( cirrusGroup, "cirrusMovingSpeedSlider" );
    cirrusMovingSpeedSlider->setGeometry( QRect( 375, 85, 115, 60 ) ); 
    QWhatsThis::add(  cirrusMovingSpeedSlider, tr( "Sets the movement speed for the cirrus clouds." ) );

    generateButton = new QPushButton( cirrusGroup, "generateButton" );
    generateButton->setGeometry( QRect( 10, 155, 93, 23 ) ); 
    generateButton->setText( tr( "Generate" ) );
    generateButton->setFlat( FALSE );
    QToolTip::add(  generateButton, tr( "Start generating clouds" ) );
    QWhatsThis::add(  generateButton, tr( "Generates the cirrus clouds." ) );

    cumulusGroup = new QGroupBox( this, "cumulusGroup" );
    cumulusGroup->setGeometry( QRect( 0, 0, 201, 260 ) ); 
    cumulusGroup->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, cumulusGroup->sizePolicy().hasHeightForWidth() ) );
    cumulusGroup->setTitle( tr( "Cumulus clouds" ) );

    cumulusDensitySlider = new CoolSlider( cumulusGroup, "cumulusDensitySlider" );
    cumulusDensitySlider->setGeometry( QRect( 10, 20, 180, 70 ) ); 
    QWhatsThis::add(  cumulusDensitySlider, tr( "Sets the density of the cumulus clouds. If its 0, there are no cumulus clouds at all." ) );

    cumulusLengthSlider = new CoolSlider( cumulusGroup, "cumulusLengthSlider" );
    cumulusLengthSlider->setGeometry( QRect( 10, 100, 85, 70 ) ); 
    QWhatsThis::add(  cumulusLengthSlider, tr( "Defines the length of a cumulus cloud in the direction of its movement." ) );

    cumulusSpeedSlider = new CoolSlider( cumulusGroup, "cumulusSpeedSlider" );
    cumulusSpeedSlider->setGeometry( QRect( 105, 100, 85, 70 ) ); 
    QWhatsThis::add(  cumulusSpeedSlider, tr( "Sets the speed for movement and changing of chape for the cumulus clouds." ) );

    cumulusHeightSlider = new CoolSlider( cumulusGroup, "cumulusHeightSlider" );
    cumulusHeightSlider->setGeometry( QRect( 10, 180, 85, 70 ) ); 
    QWhatsThis::add(  cumulusHeightSlider, tr( "Defines the height of the cumulus clouds." ) );

    cumulusWidthSlider = new CoolSlider( cumulusGroup, "cumulusWidthSlider" );
    cumulusWidthSlider->setGeometry( QRect( 105, 180, 85, 70 ) ); 
    QWhatsThis::add(  cumulusWidthSlider, tr( "Sets the width of the cumulus clouds." ) );

    bitmapNavContainer = new BitmapNav( this, "bitmapNavContainer" );
    bitmapNavContainer->setGeometry( QRect( 210, 0, 290, 260 ) ); 
    QWhatsThis::add(  bitmapNavContainer, tr( "Shows a preview of the distribution of the cirrus-clouds." ) );

    // signals and slots connections
    connect( generateButton, SIGNAL( clicked() ), this, SLOT( generateClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( cirrusSizeSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( cirrusCoverageSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( cirrusSmoothnessSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( cirrusResolution, SIGNAL( activated(int) ), this, SLOT( valuesChanged() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
CloudsGUIBase::~CloudsGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

void CloudsGUIBase::cancelClicked()
{
    qWarning( "CloudsGUIBase::cancelClicked(): Not implemented yet!" );
}

void CloudsGUIBase::generateClicked()
{
    qWarning( "CloudsGUIBase::generateClicked(): Not implemented yet!" );
}

void CloudsGUIBase::valuesChanged()
{
    qWarning( "CloudsGUIBase::valuesChanged(): Not implemented yet!" );
}

