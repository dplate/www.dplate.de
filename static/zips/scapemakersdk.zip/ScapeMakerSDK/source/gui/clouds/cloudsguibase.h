/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\clouds\cloudsguibase.ui'
**
** Created: Sun Feb 13 15:03:33 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef CLOUDSGUIBASE_H
#define CLOUDSGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class BitmapNav;
class CoolSlider;
class QComboBox;
class QGroupBox;
class QLabel;
class QProgressBar;
class QPushButton;

class CloudsGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    CloudsGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~CloudsGUIBase();

    QGroupBox* cirrusGroup;
    QPushButton* cancelButton;
    QProgressBar* progressBar;
    QLabel* cirrusResolutionLabel;
    QComboBox* cirrusResolution;
    CoolSlider* cirrusHeightSlider;
    CoolSlider* cirrusSizeSlider;
    CoolSlider* cirrusCoverageSlider;
    CoolSlider* cirrusFramesSlider;
    CoolSlider* cirrusSmoothnessSlider;
    CoolSlider* cirrusRepetitionSlider;
    CoolSlider* cirrusMutationSpeedSlider;
    CoolSlider* cirrusMovingSpeedSlider;
    QPushButton* generateButton;
    QGroupBox* cumulusGroup;
    CoolSlider* cumulusDensitySlider;
    CoolSlider* cumulusLengthSlider;
    CoolSlider* cumulusSpeedSlider;
    CoolSlider* cumulusHeightSlider;
    CoolSlider* cumulusWidthSlider;
    BitmapNav* bitmapNavContainer;

public slots:
    virtual void cancelClicked();
    virtual void generateClicked();
    virtual void valuesChanged();

};

#endif // CLOUDSGUIBASE_H
