/****************************************************************************
** BitmapNav
**
** the bitmap navigation widget
** 
** Author: Dirk Plate
****************************************************************************/

#include "bitmapnav.h"

/****************************************************************************
** BitmapNav Constructor
**
** initialise vars
**  
** Author: Dirk Plate
****************************************************************************/

BitmapNav::BitmapNav( QWidget* parent, const char* name, WFlags f )
	: BitmapNavBase(parent, name, f)
{
	displayUpToDate = true;
	currentTool = NOTHING;
	partPos.setX(0);
	partPos.setY(0);
	oldMouseCoor.setX(0);
	oldMouseCoor.setY(0);
	miniMapScale = 0.1f;
	zoomFaktor = 1;
	scaleValue = 1.0f;
	zoomButton->setDisabled(false);
	unZoomButton->setDisabled(true);
	handButton->setDisabled(true);
	penButton->setDisabled(false);
	rubberButton->setDisabled(false);

	//some special settings
	display->setBackgroundMode(NoBackground);
	miniMap->setBackgroundMode(NoBackground);

	//install an eventfilter for display and minimap (so we gets the events for them)
	display->installEventFilter(this);
	miniMap->installEventFilter(this);
}

/****************************************************************************
** BitmapNav paintEvent
**
** is called, just before the widget is redrawn
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::paintEvent(QPaintEvent *paintEvent)
{
	//reload the pixmap, if its not uptodate
	if (!displayUpToDate)
	{
		QPixmap pixmap;
		QImage disBitmap;
		QImage disMiniMap;
		QRect positionFrame;
		int x,y;
		unsigned int color = qRgb(0,255,255);
		
		//copy the right rectange from the zoomed orginal to the displayed
		disBitmap = zoomedBitmap.copy(partPos.x(),partPos.y(),display->width(),display->height());
		
		pixmap.convertFromImage(disBitmap);
		display->setPixmap(pixmap);
		
		//calc. the position-frame for minimap
		positionFrame.setX(miniMapScale*partPos.x()/(scaleValue*zoomFaktor));
		positionFrame.setY(miniMapScale*partPos.y()/(scaleValue*zoomFaktor));
		
		positionFrame.setWidth(miniMapScale*display->width()/(scaleValue*zoomFaktor));
		positionFrame.setHeight(miniMapScale*display->height()/(scaleValue*zoomFaktor));

		//draw the position-frame on minimap
		disMiniMap = orgMiniMap.copy();
		//draw the top line
		y=positionFrame.top();
		for (x=positionFrame.left();x<=positionFrame.right();x++)
			disMiniMap.setPixel(x,y,color);
		//draw the bottom line
		y=positionFrame.bottom();
		for (x=positionFrame.left();x<=positionFrame.right();x++)
			disMiniMap.setPixel(x,y,color);
		//draw the left line
		x=positionFrame.left();
		for (y=positionFrame.top();y<=positionFrame.bottom();y++)
			disMiniMap.setPixel(x,y,color);
		//draw the right line
		x=positionFrame.right();
		for (y=positionFrame.top();y<=positionFrame.bottom();y++)
			disMiniMap.setPixel(x,y,color);
		
		//copy the minimap to widget
		pixmap.convertFromImage(disMiniMap);
		miniMap->setPixmap(pixmap);
		
		//nothing more to update
		displayUpToDate = true;
	}
}

/****************************************************************************
** BitmapNav eventFilter
**
** is called, when an the display receive an event
**  
** Author: Dirk Plate
****************************************************************************/

bool BitmapNav::eventFilter ( QObject *targetObject, QEvent *currentEvent)
{
	//its an event for display!
	if (targetObject == display)
	{
		//a mouse button was clicked
		if (currentEvent->type() == QEvent::MouseButtonPress)
		{
			QMouseEvent *mouseEvent = (QMouseEvent*)currentEvent;
			
			//only if tool is hand
			if (currentTool == HAND)
			{
				//only at left mouse button
				if (mouseEvent->button() == LeftButton)
				{
					//now the scroll-drag started
					//init the oldMouseCoor
					oldMouseCoor = mouseEvent->pos();
					return true;
				}
			}
			//only if tool is zoom
			else if ((currentTool == ZOOM) || (currentTool == UNZOOM))
			{
				//calc. the real coor. of the mouseposition
				QPoint middle=transformDisplayToBitmapCoordinates(mouseEvent->pos());

				if (currentTool == ZOOM) zoom(true,middle);
				else zoom(false,middle);

				displayUpToDate = false;
				repaint();
				return true;
			}
			//only if tool is pen
			else if (currentTool == PEN)
			{
				//calc. the real coor. of the mouseposition
				QPoint position=transformDisplayToBitmapCoordinates(mouseEvent->pos());

				//call signal
				emit positionWithPenClicked(position);
				return true;
			}
			//only if tool is rubber
			else if (currentTool == RUBBER)
			{
				//calc. the real coor. of the mouseposition
				QPoint position=transformDisplayToBitmapCoordinates(mouseEvent->pos());

				//call signal
				emit positionWithRubberClicked(position);
				return true;
			}

		}
		//the mouse was moved
		else if (currentEvent->type() == QEvent::MouseMove)
		{
			QMouseEvent *mouseEvent = (QMouseEvent*)currentEvent;
			
			//only if tool is hand
			if (currentTool == HAND)
			{
				//only if left mouse button down
				if (mouseEvent->state() ==	LeftButton)
				{
					QPoint moveDiff;	//the difference of the mouse moving
					
					//calc the new partRect
					moveDiff = mouseEvent->pos()-oldMouseCoor;
					oldMouseCoor = mouseEvent->pos();
					partPos.setX(partPos.x()-moveDiff.x());
					partPos.setY(partPos.y()-moveDiff.y());
					
					checkPartBounds();

					displayUpToDate = false;
					repaint();
					return true;
				}
			}
		}
		//the mouse wheel was moved
		else if (currentEvent->type() == QEvent::Wheel)
		{
			QWheelEvent *wheelEvent = (QWheelEvent*)currentEvent;
			
			//calc. the real coor. of the mouseposition
			QPoint mousePosition = wheelEvent->pos();
			mousePosition -= display->mapToGlobal(QPoint(0,0));
			QPoint middle=transformDisplayToBitmapCoordinates(mousePosition);

			//zoom out or in
			if (wheelEvent->delta() > 0) 
			{
				if (zoomButton->isEnabled()) zoom(true,middle);
			}
			else if (unZoomButton->isEnabled()) zoom(false,middle);

			displayUpToDate = false;
			repaint();
			return true;
		}
	}
	//its an event for minimap!
	else if (targetObject == miniMap)
	{
		//a mouse button was clicked or moved
		if ((currentEvent->type() == QEvent::MouseButtonPress) ||
			(currentEvent->type() == QEvent::MouseMove))
		{
			QMouseEvent *mouseEvent = (QMouseEvent*)currentEvent;
			
			//only at left mouse button
			if (mouseEvent->state() == LeftButton)
			{
				//set partpos to new coor.
				QPoint newPos;
				//transform the coor. from minimap to orgBitmap
				newPos.setX(int(float(mouseEvent->x())/miniMapScale));
				newPos.setY(int(float(mouseEvent->y())/miniMapScale));
				//transform the coor. from orgBitmap to zoomedBitmap
				newPos *= scaleValue*zoomFaktor;
				//we need the upper left edge
				partPos = QPoint(newPos.x()-display->width()/2,
					newPos.y()-display->height()/2);

				checkPartBounds();
				
				displayUpToDate = false;
				repaint();
				return true;
			}
		}
	}
	return false;
}

/****************************************************************************
** BitmapNav toggleHandButton
**
** is called, when hand button is pressed
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::toggleHandButton(bool pressed)
{
	if (pressed) 
	{
		//unpress all other buttons
		zoomButton->setOn(false);
		unZoomButton->setOn(false);
		penButton->setOn(false);
		rubberButton->setOn(false);

		currentTool = HAND;
		//set the cursor for display
		QBitmap handCursor("./guifiles/handcursor.bmp");
		QBitmap handCursorMask("./guifiles/handcursor_mask.bmp");
		display->setCursor(QCursor(handCursor,handCursorMask,8,8));
	}
	else 
	{
		currentTool = NOTHING;
		display->setCursor(QCursor());
	}
}

/****************************************************************************
** BitmapNav togglePenButton
**
** is called, when pen button is pressed
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::togglePenButton(bool pressed)
{
	if (pressed) 
	{
		//unpress all other buttons
		zoomButton->setOn(false);
		unZoomButton->setOn(false);
		handButton->setOn(false);
		rubberButton->setOn(false);

		currentTool = PEN;
		//set the cursor for display
		QBitmap penCursor("./guifiles/pencursor.bmp");
		QBitmap penCursorMask("./guifiles/pencursor_mask.bmp");
		display->setCursor(QCursor(penCursor,penCursorMask,1,14));
	}
	else 
	{
		currentTool = NOTHING;
		display->setCursor(QCursor());
	}
}

/****************************************************************************
** BitmapNav toggleRubberButton
**
** is called, when rubber button is pressed
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::toggleRubberButton(bool pressed)
{
	if (pressed) 
	{
		//unpress all other buttons
		zoomButton->setOn(false);
		unZoomButton->setOn(false);
		handButton->setOn(false);
		penButton->setOn(false);

		currentTool = RUBBER;
		//set the cursor for display
		QBitmap rubberCursor("./guifiles/rubbercursor.bmp");
		QBitmap rubberCursorMask("./guifiles/rubbercursor_mask.bmp");
		display->setCursor(QCursor(rubberCursor,rubberCursorMask,3,13));
	}
	else 
	{
		currentTool = NOTHING;
		display->setCursor(QCursor());
	}
}

/****************************************************************************
** BitmapNav toggleZoomButton
**
** is called, when zoom button is pressed
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::toggleZoomButton(bool pressed)
{
	if (pressed) 
	{
		//unpress all other buttons
		handButton->setOn(false);
		unZoomButton->setOn(false);
		penButton->setOn(false);
		rubberButton->setOn(false);

		currentTool = ZOOM;
		//set the cursor for display
		QBitmap zoomCursor("./guifiles/zoomcursor.bmp");
		QBitmap zoomCursorMask("./guifiles/zoomcursor_mask.bmp");
		display->setCursor(QCursor(zoomCursor,zoomCursorMask,6,6));
	}
	else 
	{
		currentTool = NOTHING;
		display->setCursor(QCursor());
	}
}

/****************************************************************************
** BitmapNav toggleUnZoomButton
**
** is called, when unzoom button is pressed
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::toggleUnZoomButton(bool pressed)
{
	if (pressed) 
	{
		//unpress all other buttons
		zoomButton->setOn(false);
		handButton->setOn(false);
		penButton->setOn(false);
		rubberButton->setOn(false);

		currentTool = UNZOOM;
		//set the cursor for display
		QBitmap unZoomCursor("./guifiles/unzoomcursor.bmp");
		QBitmap unZoomCursorMask("./guifiles/unzoomcursor_mask.bmp");
		display->setCursor(QCursor(unZoomCursor,unZoomCursorMask,6,6));
	}
	else 
	{
		currentTool = NOTHING;
		display->setCursor(QCursor());
	}
}

/****************************************************************************
** BitmapNav setBitmap
**
** sets a new bitmap in the display and repaint the widget
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setBitmap(QImage newBitmap)
{
	//save new bitmap
	orgBitmap = newBitmap;
	scaleValue = float(display->width())/float(orgBitmap.width());

	//calculate new zoomed Bitmap
	zoomedBitmap = orgBitmap.smoothScale(
		scaleValue*orgBitmap.width()*zoomFaktor,
		scaleValue*orgBitmap.height()*zoomFaktor);

	//make the new minimap
	//find the longer side for right scaling
	if (orgBitmap.width() > orgBitmap.height())
		miniMapScale = (float)miniMap->width()/orgBitmap.width();
	else miniMapScale = (float)miniMap->height()/orgBitmap.height();

	//scale the minimap
	orgMiniMap = orgBitmap.smoothScale(miniMapScale*orgBitmap.width(),miniMapScale*orgBitmap.height());
	
	//recalculate and repaint all
	displayUpToDate = false;
	repaint();
}

/****************************************************************************
** BitmapNav setHandButtonVisible
**
** make a button visible or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setHandButtonVisible(bool visible)
{
	if ( visible ) handButton->show();
	else 
		handButton->hide();
	
}

/****************************************************************************
** BitmapNav setZoomButtonVisible
**
** make a button visible or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setZoomButtonVisible(bool visible)
{
	if ( visible ) zoomButton->show();
	else zoomButton->hide();
}

/****************************************************************************
** BitmapNav setUnZoomButtonVisible
**
** make a button visible or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setUnZoomButtonVisible(bool visible)
{
	if ( visible ) unZoomButton->show();
	else unZoomButton->hide();
}

/****************************************************************************
** BitmapNav setPenButtonVisible
**
** make a button visible or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setPenButtonVisible(bool visible)
{
	if ( visible ) penButton->show();
	else penButton->hide();
}

/****************************************************************************
** BitmapNav setRubberButtonVisible
**
** make a button visible or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setRubberButtonVisible(bool visible)
{
	if ( visible ) rubberButton->show();
	else rubberButton->hide();
}

/****************************************************************************
** BitmapNav setHandButtonEnable
**
** make a button Enable or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setHandButtonEnable(bool enable)
{
	handButton->setEnabled(enable);

	if (!enable) handButton->setOn(false);
}

/****************************************************************************
** BitmapNav setZoomButtonEnable
**
** make a button Enable or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setZoomButtonEnable(bool enable)
{
	zoomButton->setEnabled(enable);

	if (!enable) zoomButton->setOn(false);
}

/****************************************************************************
** BitmapNav setUnZoomButtonEnable
**
** make a button Enable or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setUnZoomButtonEnable(bool enable)
{
	unZoomButton->setEnabled(enable);

	if (!enable) unZoomButton->setOn(false);
}

/****************************************************************************
** BitmapNav setPenButtonEnable
**
** make a button Enable or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setPenButtonEnable(bool enable)
{
	penButton->setEnabled(enable);

	if (!enable) penButton->setOn(false);
}

/****************************************************************************
** BitmapNav setRubberButtonEnable
**
** make a button Enable or not
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::setRubberButtonEnable(bool enable)
{
	rubberButton->setEnabled(enable);

	if (!enable) rubberButton->setOn(false);
}


/****************************************************************************
** BitmapNav zoom
**
** zooms in or out
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::zoom(bool in, QPoint &middle)
{
	//zoom or unzoom
	if (in) 
	{
		zoomFaktor *= 2;
		unZoomButton->setDisabled(false);
		handButton->setDisabled(false);
		
		//max zoom in reached?
		if (zoomFaktor == 4)
		{
			if (currentTool == ZOOM)
			{
				currentTool = NOTHING;
				zoomButton->setOn(false);
				display->setCursor(QCursor());
			}
			zoomButton->setDisabled(true);
		}
	}
	else 
	{
		zoomFaktor /= 2;
		zoomButton->setDisabled(false);
		
		//max zoom out reached?
		if (zoomFaktor == 1)
		{
			if ((currentTool == UNZOOM) || (currentTool == HAND))
			{
				currentTool = NOTHING;
				unZoomButton->setOn(false);
				handButton->setOn(false);
				display->setCursor(QCursor());
			}
			
			unZoomButton->setDisabled(true);
			handButton->setDisabled(true);
		}
	}
		
	//calculate new zoomed Bitmap
	zoomedBitmap = orgBitmap.smoothScale(
		scaleValue*orgBitmap.width()*zoomFaktor,
		scaleValue*orgBitmap.height()*zoomFaktor);
	
	//calculate the new offset
	middle *= scaleValue;
	middle *= zoomFaktor;
	partPos.setX(middle.x()-display->width()/2);
	partPos.setY(middle.y()-display->height()/2);
	
	checkPartBounds();
				
}

/****************************************************************************
** BitmapNav checkPartBounds
**
** brings the coord. of the part Rect to right values
**  
** Author: Dirk Plate
****************************************************************************/

void BitmapNav::checkPartBounds()
{
	int width = display->width();
	int height = display->height();

	//check bounds
	if (partPos.x() < 0) partPos.setX(0);
	if (partPos.y() < 0) partPos.setY(0);
	
	if (partPos.x() > zoomedBitmap.width()-width) 
		partPos.setX(zoomedBitmap.width()-width);
	if (partPos.y() > zoomedBitmap.height()-height) 
		partPos.setY(zoomedBitmap.height()-height);
}

/****************************************************************************
** BitmapNav transformDisplayToBitmapCoordinates
**
** transform the pixel coordinates of display to the pixel coordinates
** of orgBitmap
**  
** Author: Dirk Plate
****************************************************************************/

QPoint BitmapNav::transformDisplayToBitmapCoordinates(const QPoint &displayCoor)
{
	QPoint bitmapCoor = displayCoor;

	//add the offset
	bitmapCoor += partPos;

	//unscale the displayCoor
	bitmapCoor /= scaleValue;

	//unzoom the displayCoor
	bitmapCoor /= zoomFaktor;

	return bitmapCoor;
}
