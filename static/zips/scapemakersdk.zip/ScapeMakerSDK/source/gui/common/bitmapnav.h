/****************************************************************************
** BitmapNav
**
** the bitmap-navigation widget
** 
** Author: Dirk Plate
****************************************************************************/

#if !defined(BITMAPNAV_H)
#define BITMAPNAV_H
#pragma warning(disable:4786)

#include <qpixmap.h>
#include <qimage.h>
#include <qlabel.h>
#include <qmessagebox.h>
#include <qapplication.h>
#include <qcursor.h>
#include <qbitmap.h>
#include <qtoolbutton.h>
#include "bitmapnavbase.h"

class BitmapNav : public BitmapNavBase  
{
Q_OBJECT

public:
	BitmapNav(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setBitmap(QImage newBitmap);

protected:
	void paintEvent(QPaintEvent *paintEvent);
	bool eventFilter(QObject *, QEvent *);

public slots:
    virtual void toggleZoomButton(bool);
	virtual void toggleUnZoomButton(bool);
	virtual void toggleHandButton(bool);
	virtual void togglePenButton(bool);
	virtual void toggleRubberButton(bool);

	//some control functions
	virtual void setHandButtonVisible(bool);
	virtual void setZoomButtonVisible(bool);
	virtual void setUnZoomButtonVisible(bool);
	virtual void setPenButtonVisible(bool);
	virtual void setRubberButtonVisible(bool);
	
	virtual void setHandButtonEnable(bool);
	virtual void setZoomButtonEnable(bool);
	virtual void setUnZoomButtonEnable(bool);
	virtual void setPenButtonEnable(bool);
	virtual void setRubberButtonEnable(bool);

signals:
	void positionWithPenClicked(QPoint);	//called a point clicked with pen (return position)
	void positionWithRubberClicked(QPoint);	//called a point clicked with rubber (return position)

private:
	void zoom(bool in, QPoint &middle);
	void checkPartBounds();
	QPoint transformDisplayToBitmapCoordinates(const QPoint &displayCoor);

	QImage orgBitmap;		//the real bitmap
	QImage zoomedBitmap;	//the bitmap with the resolution for display
	bool displayUpToDate;	//the display is uptodate and dont need new image data
	QPoint partPos;			//which pixel of orgBitmap is in upperleft position of display
	QPoint oldMouseCoor;	//the last coordinate of the mouse
	QImage orgMiniMap;		//the real minimap without the part-frame
	float miniMapScale;		//how much was the minimap scaled
	int zoomFaktor;			//how much zoom (1 = whole bitmap, 2 = double size ...)
	float scaleValue;		//the scale value at zoomFaktor 1

	enum Tools {NOTHING,HAND,ZOOM,UNZOOM,PEN,RUBBER} currentTool; //which is the current tool
};

#endif



















