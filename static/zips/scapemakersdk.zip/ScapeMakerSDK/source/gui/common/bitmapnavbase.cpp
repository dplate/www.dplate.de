/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\common\bitmapnavbase.ui'
**
** Created: Sun Feb 13 15:03:29 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "bitmapnavbase.h"

#include <qlabel.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".......#.........",
"......###........",
".....#####.......",
".......#.........",
".......#.........",
"..#....#....#....",
".##....#....##...",
"###############..",
".##....#....##...",
"..#....#....#....",
".......#.........",
".......#.........",
".....#####.......",
"......###........",
".......#.........",
".................",
"................."};

static const char* const image1_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
"....####.........",
"..###..###.......",
".##......##......",
".#...##...#......",
"##...##...##.....",
"#..######..#.....",
"#..######..#.....",
"##...##...##.....",
".#...##...#......",
".##......##......",
"..###..#####.....",
"....####..###....",
"...........###...",
"............###..",
".............##..",
".................",
"................."};

static const char* const image2_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
"....####.........",
"..###..###.......",
".##......##......",
".#........#......",
"##........##.....",
"#..######..#.....",
"#..######..#.....",
"##........##.....",
".#........#......",
".##......##......",
"..###..#####.....",
"....####..###....",
"...........###...",
"............###..",
".............##..",
".................",
"................."};

static const char* const image3_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
"............#....",
"...........###...",
"..........#####..",
".........######..",
"........#####.#..",
".......#####.#...",
"......#####.#....",
".....#####.#.....",
"....#####.#......",
"...#####.........",
"..#####..........",
".#####...........",
".####............",
"####.............",
"##...............",
".................",
"................."};

static const char* const image4_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".........##......",
"........####.....",
".......######....",
"......########...",
".....##########..",
"....###########..",
"...###########...",
"..###########....",
".##.########.....",
"##...######......",
"##....####.......",
".##....##........",
"..##..##.........",
"...####..........",
"....##...........",
".................",
"................."};


/* 
 *  Constructs a BitmapNavBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
BitmapNavBase::BitmapNavBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    QPixmap image1( ( const char** ) image1_data );
    QPixmap image2( ( const char** ) image2_data );
    QPixmap image3( ( const char** ) image3_data );
    QPixmap image4( ( const char** ) image4_data );
    if ( !name )
	setName( "BitmapNavBase" );
    resize( 308, 268 ); 
    setCaption( tr( "BitmapNav" ) );

    display = new QLabel( this, "display" );
    display->setEnabled( TRUE );
    display->setGeometry( QRect( 0, 0, 256, 256 ) ); 
    display->setMouseTracking( FALSE );
    display->setFrameShape( QLabel::NoFrame );
    display->setFrameShadow( QLabel::Sunken );
    display->setLineWidth( 1 );
    display->setMargin( 0 );
    display->setMidLineWidth( 0 );
    display->setScaledContents( FALSE );
    display->setAlignment( int( QLabel::AlignTop | QLabel::AlignLeft ) );

    handButton = new QToolButton( this, "handButton" );
    handButton->setGeometry( QRect( 260, 0, 20, 20 ) ); 
    handButton->setText( tr( "" ) );
    handButton->setPixmap( image0 );
    handButton->setToggleButton( TRUE );
    handButton->setTextLabel( tr( "" ) );
    handButton->setToggleButton( TRUE );
    QToolTip::add(  handButton, tr( "Move" ) );
    QWhatsThis::add(  handButton, tr( "Goes into scroll mode." ) );

    zoomButton = new QToolButton( this, "zoomButton" );
    zoomButton->setGeometry( QRect( 260, 25, 20, 20 ) ); 
    zoomButton->setText( tr( "" ) );
    zoomButton->setPixmap( image1 );
    zoomButton->setToggleButton( TRUE );
    zoomButton->setTextLabel( tr( "" ) );
    zoomButton->setToggleButton( TRUE );
    QToolTip::add(  zoomButton, tr( "Zoom" ) );
    QWhatsThis::add(  zoomButton, tr( "Zooms in with a click on the preview." ) );

    unZoomButton = new QToolButton( this, "unZoomButton" );
    unZoomButton->setGeometry( QRect( 260, 50, 20, 20 ) ); 
    QFont unZoomButton_font(  unZoomButton->font() );
    unZoomButton->setFont( unZoomButton_font ); 
    unZoomButton->setText( tr( "" ) );
    unZoomButton->setPixmap( image2 );
    unZoomButton->setToggleButton( TRUE );
    unZoomButton->setTextLabel( tr( "" ) );
    unZoomButton->setToggleButton( TRUE );
    QToolTip::add(  unZoomButton, tr( "UnZoom" ) );
    QWhatsThis::add(  unZoomButton, tr( "Zooms out with a click on the preview." ) );

    penButton = new QToolButton( this, "penButton" );
    penButton->setGeometry( QRect( 260, 75, 20, 20 ) ); 
    penButton->setText( tr( "" ) );
    penButton->setPixmap( image3 );
    penButton->setToggleButton( TRUE );
    penButton->setTextLabel( tr( "" ) );
    penButton->setToggleButton( TRUE );
    QToolTip::add(  penButton, tr( "Pen" ) );
    QWhatsThis::add(  penButton, tr( "A pen to manually set positions by clicking on the preview." ) );

    rubberButton = new QToolButton( this, "rubberButton" );
    rubberButton->setGeometry( QRect( 260, 100, 20, 20 ) ); 
    rubberButton->setText( tr( "" ) );
    rubberButton->setPixmap( image4 );
    rubberButton->setToggleButton( TRUE );
    rubberButton->setTextLabel( tr( "" ) );
    rubberButton->setToggleButton( TRUE );
    QToolTip::add(  rubberButton, tr( "Rubber" ) );
    QWhatsThis::add(  rubberButton, tr( "A rubber to delete positions by clicking on the preview." ) );

    miniMap = new QLabel( this, "miniMap" );
    miniMap->setGeometry( QRect( 260, 230, 26, 26 ) ); 
    miniMap->setCursor( QCursor( 0 ) );
    miniMap->setScaledContents( FALSE );
    miniMap->setAlignment( int( QLabel::AlignTop | QLabel::AlignLeft ) );
    QWhatsThis::add(  miniMap, tr( "Shows a smaller image of the preview The blue border shows the area that is shown in the main window." ) );

    // signals and slots connections
    connect( handButton, SIGNAL( toggled(bool) ), this, SLOT( toggleHandButton(bool) ) );
    connect( zoomButton, SIGNAL( toggled(bool) ), this, SLOT( toggleZoomButton(bool) ) );
    connect( unZoomButton, SIGNAL( toggled(bool) ), this, SLOT( toggleUnZoomButton(bool) ) );
    connect( penButton, SIGNAL( toggled(bool) ), this, SLOT( togglePenButton(bool) ) );
    connect( rubberButton, SIGNAL( toggled(bool) ), this, SLOT( toggleRubberButton(bool) ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
BitmapNavBase::~BitmapNavBase()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool BitmapNavBase::event( QEvent* ev )
{
    bool ret = QWidget::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont unZoomButton_font(  unZoomButton->font() );
	unZoomButton->setFont( unZoomButton_font ); 
    }
    return ret;
}

void BitmapNavBase::toggleHandButton(bool)
{
    qWarning( "BitmapNavBase::toggleHandButton(bool): Not implemented yet!" );
}

void BitmapNavBase::togglePenButton(bool)
{
    qWarning( "BitmapNavBase::togglePenButton(bool): Not implemented yet!" );
}

void BitmapNavBase::toggleRubberButton(bool)
{
    qWarning( "BitmapNavBase::toggleRubberButton(bool): Not implemented yet!" );
}

void BitmapNavBase::toggleUnZoomButton(bool)
{
    qWarning( "BitmapNavBase::toggleUnZoomButton(bool): Not implemented yet!" );
}

void BitmapNavBase::toggleZoomButton(bool)
{
    qWarning( "BitmapNavBase::toggleZoomButton(bool): Not implemented yet!" );
}

