/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\common\bitmapnavbase.ui'
**
** Created: Sun Feb 13 15:03:28 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef BITMAPNAVBASE_H
#define BITMAPNAVBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QToolButton;

class BitmapNavBase : public QWidget
{ 
    Q_OBJECT

public:
    BitmapNavBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~BitmapNavBase();

    QLabel* display;
    QToolButton* handButton;
    QToolButton* zoomButton;
    QToolButton* unZoomButton;
    QToolButton* penButton;
    QToolButton* rubberButton;
    QLabel* miniMap;

public slots:
    virtual void toggleHandButton(bool);
    virtual void togglePenButton(bool);
    virtual void toggleRubberButton(bool);
    virtual void toggleUnZoomButton(bool);
    virtual void toggleZoomButton(bool);

protected:
    bool event( QEvent* );
};

#endif // BITMAPNAVBASE_H
