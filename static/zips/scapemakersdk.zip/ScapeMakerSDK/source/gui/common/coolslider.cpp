/****************************************************************************
** CoolSlider
**
** the cool slider widget
**
** Author: Dirk Plate
****************************************************************************/

#include "coolslider.h"
#include "../../engine/common/enginehelpers.h"

/****************************************************************************
** CoolSlider Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

CoolSlider::CoolSlider(QWidget* parent, const char* name)
	: QWidget(parent, name)
{
	QPixmap pixmap;

	gridLineCount = 10;
	sliders = NULL;
	moveSlider = -1;
	oldSliderPos = -1;

	this->setBackgroundMode(NoBackground);
	this->setCursor(QCursor(SizeHorCursor));

	//install an eventfilter for field (so we gets the events for them)
	this->installEventFilter(this);

}

/****************************************************************************
** CoolSlider Destructor
**
** delete pointer vars
**
** Author: Dirk Plate
****************************************************************************/

CoolSlider::~CoolSlider()
{
	if (sliders != NULL)
		delete [] sliders;
}

//void CoolSlider::valueChanged();

/****************************************************************************
** CoolSlider setProperties
**
** initialise vars after creating widget
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::setProperties(Type typeSet, QString titleSet, 
							   int minValueSet, int maxValueSet, QString unitSet,
							   int numSlidersSet)
{
	type = typeSet;
	title = titleSet;
	minValue = minValueSet;
	maxValue = maxValueSet;
	unit = unitSet;
	numSliders = numSlidersSet;

	//degree is always between 0 and 90
	if (type == DEGREE)
	{
		minValue = 0;
		maxValue = 90;
	}

	//set max display value
	if (maxValue%10 != 0) maxDisplayValue = maxValue+(10-maxValue%10);
	else maxDisplayValue = maxValue;

	//set grapharea
	graphArea.setLeft(5);
	graphArea.setRight(this->width()-5);
	graphArea.setTop(15);
	graphArea.setBottom(this->height()-15);

	//calculate the const. parameters
	if (type == DEGREE)	calculateDegreeFunctionParameters();
	else if (type == LINEAR) calculateLinearFunctionParameters();

	//init sliders
	if (sliders != NULL)
		delete [] sliders;
	sliders = new int[numSliders];
	for (int i=0;i<numSliders;i++)
		sliders[i] = (maxValue-minValue)/2;
}

/****************************************************************************
** CoolSlider setValue
**
** set a value of a slider
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::setValue(int slider, int value)
{
	if (value < minValue) value = minValue;
	if (value > maxValue) value = maxValue;
	sliders[slider] = value;
	repaint();
	emit valueChanged(slider,value);
	emit valuesChanged();
}

/****************************************************************************
** CoolSlider getValue
**
** return a value of a slider
**
** Author: Dirk Plate
****************************************************************************/

int CoolSlider::getValue(int slider)
{
	return sliders[slider];
}


/****************************************************************************
** CoolSlider getMinValue
**
** return the min value
**
** Author: Dirk Plate
****************************************************************************/

int CoolSlider::getMinValue()
{
	return minValue;
}

/****************************************************************************
** CoolSlider getMaxValue
**
** return the max value
**
** Author: Dirk Plate
****************************************************************************/

int CoolSlider::getMaxValue()
{
	return maxValue;
}

/****************************************************************************
** CoolSlider paintEvent
**
** is called, just before the widget is redrawn
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::paintEvent(QPaintEvent *paintEvent)
{
	QRgb blackColor, redColor, darkGray, lightGray;
	
	QPixmap backBuffer(this->size());
	QPainter painter(&backBuffer);

	int width = graphArea.width();

	//if enabled -> normal colors
	if (isEnabled())
	{
		blackColor = qRgb(0,0,0);
		redColor = qRgb(200,0,0);
		darkGray = qRgb(100,100,100);
		lightGray = qRgb(150,150,150);
	}
	//if not enabled -> light colors
	else
	{
		blackColor = qRgb(150,150,150);
		redColor = qRgb(250, 150, 150);
		darkGray = qRgb(175,175,175);
		lightGray = qRgb(200,200,200);
	}

	//draw background
	painter.setBrush(this->backgroundColor());
	painter.fillRect(this->rect(),painter.brush());

	//draw gridlines
	QPen gridLinePen(lightGray,1,DotLine);
	painter.setPen(gridLinePen); 
	QPointArray gridPoints(gridLineCount*2);
	createGridLines(gridPoints);
	painter.drawLineSegments(gridPoints);

	//draw coordinate system
	painter.setPen(darkGray);
	painter.drawLine(graphArea.bottomLeft(),graphArea.bottomRight());
	painter.drawLine(graphArea.bottomLeft(),graphArea.topLeft());

	//draw graph
	QPen graphPen(blackColor,1,SolidLine);
	painter.setPen(graphPen); 
	QPointArray graphPoints(width*2-2);
	createGraphSegments(graphPoints);
	painter.drawLineSegments(graphPoints);

	//when moving slider... draw old position of moving slider
	if (moveSlider >= 0)
	{
		QPen sliderPen(lightGray,1,SolidLine);
		painter.setPen(sliderPen);
		int sliderPixelPosition;
		if (type == DEGREE)
			sliderPixelPosition =  calculateDegreeFunctionX(oldSliderPos)+graphArea.left();
		else if (type == LINEAR)
			sliderPixelPosition =  calculateLinearFunctionX(oldSliderPos)+graphArea.left();
		painter.drawLine(QPoint(sliderPixelPosition,graphArea.top()),
						 QPoint(sliderPixelPosition,graphArea.bottom()));
	}

	//draw sliders
	for (int i=0;i<numSliders;i++)
	{
		QPen sliderPen(redColor,1,SolidLine);
		painter.setPen(sliderPen);
		int sliderPixelPosition;
		if (type == DEGREE)
			sliderPixelPosition =  calculateDegreeFunctionX(sliders[i])+graphArea.left();
		else if (type == LINEAR)
			sliderPixelPosition =  calculateLinearFunctionX(sliders[i])+graphArea.left();
		painter.drawLine(QPoint(sliderPixelPosition,graphArea.top()),
						 QPoint(sliderPixelPosition,graphArea.bottom()));

		if (i<numSliders-1)
		{
			//mark segment between sliders
			QPen sliderPen(redColor,2,SolidLine);
			painter.setPen(sliderPen);
			int sliderPixelPosition2;
			if (type == DEGREE)
				sliderPixelPosition2 =  calculateDegreeFunctionX(sliders[i+1])+graphArea.left();
			else if (type == LINEAR)
				sliderPixelPosition2 =  calculateLinearFunctionX(sliders[i+1])+graphArea.left();
			int difference = sliderPixelPosition2-sliderPixelPosition;
			if (difference != 0)
				painter.drawLineSegments(graphPoints,(sliderPixelPosition-graphArea.left())*2,difference);
		}
	}

	//draw text
	QPen textPen(blackColor,1,SolidLine);
	painter.setPen(textPen);
	QFont font("courier",8);
	painter.setFont(font);
	//draw title	
	QRect titleRect(graphArea.left(),0,graphArea.width(),graphArea.top());
	painter.drawText(titleRect,AlignCenter,title);
	//build value string
	QString value = "";
	for (int j=0;j<numSliders;j++)
	{
		if (j!=0) value.append("-");
		value.append(QString("%1").arg(sliders[j]));
		value.append(unit);
	}
	//draw values
	QRect valueRect(graphArea.left(),graphArea.bottom(),graphArea.width(),this->height()-graphArea.bottom());
	painter.drawText(valueRect,AlignCenter,value);
	
	
	//draw backbuffer
	QPainter backBufferPainter(this);
	backBufferPainter.drawPixmap(QPoint(0,0),backBuffer);
}

/****************************************************************************
** CoolSlider eventFilter
**
** is called, when an the display receive an event
**
** Author: Dirk Plate
****************************************************************************/

bool CoolSlider::eventFilter ( QObject *targetObject, QEvent *currentEvent)
{
	//its an event for this!
	if (targetObject == this)
	{	
		//a mouse button was clicked
		if (currentEvent->type() == QEvent::MouseButtonPress)
		{
			QMouseEvent *mouseEvent = (QMouseEvent*)currentEvent;
			
			//only at left mouse button
			if (mouseEvent->button() == LeftButton)
			{
				//get x pixel position of area
				int mousePixel = mouseEvent->pos().x()-graphArea.left();
				if (mousePixel < 0) mousePixel = 0;
				if (mousePixel > graphArea.width()) mousePixel = graphArea.width();
				//calculate to degree value
				int mouseDegree;
				if (type == DEGREE)
					mouseDegree = calculateDegreeFunctionDegree(mousePixel);
				else if (type == LINEAR)
					mouseDegree = calculateLinearFunctionValue(mousePixel);
				//find slider which the nearest
				moveSlider = getNearestSlider(mouseDegree);
				//save original position
				oldSliderPos = sliders[moveSlider];
				return true;
			}
		}
		//the mouse was moved
		else if (currentEvent->type() == QEvent::MouseMove)
		{
			QMouseEvent *mouseEvent = (QMouseEvent*)currentEvent;
			
			//only if left mouse button down and we have a active slider
			if ((mouseEvent->state() ==	LeftButton) && (moveSlider != -1))
			{
				//get x pixel position of area
				int mousePixel = mouseEvent->pos().x()-graphArea.left();
				if (mousePixel < 0) mousePixel = 0;
				if (mousePixel > graphArea.width()) mousePixel = graphArea.width();
				
				//calculate to value
				int mouseValue;
				if (type == DEGREE)
					mouseValue = calculateDegreeFunctionDegree(mousePixel);
				else if (type == LINEAR)
					mouseValue = calculateLinearFunctionValue(mousePixel);

				//set value of slider to new value
				setSlider(moveSlider, mouseValue, true);

				return true;
			}
		}
		//a mouse button was released
		else if (currentEvent->type() == QEvent::MouseButtonRelease)
		{
			QMouseEvent *mouseEvent = (QMouseEvent*)currentEvent;
			
			//only at left mouse button
			if (mouseEvent->button() == LeftButton)
			{
				if (moveSlider >= 0)
				{
					//no active mouse slider
					int lastMovingSlider = moveSlider;
					moveSlider = -1;
					oldSliderPos = -1;

					setSlider(lastMovingSlider, sliders[lastMovingSlider], false);
				}
				return true;
			}

			//at right mouse button... show input dialog
			if (mouseEvent->button() == RightButton)
			{
				//get right slider and current value
				//get x pixel position of area
				int mousePixel = mouseEvent->pos().x()-graphArea.left();
				if (mousePixel < 0) mousePixel = 0;
				if (mousePixel > graphArea.width()) mousePixel = graphArea.width();
				//calculate to degree value
				int mouseDegree;
				if (type == DEGREE)
					mouseDegree = calculateDegreeFunctionDegree(mousePixel);
				else if (type == LINEAR)
					mouseDegree = calculateLinearFunctionValue(mousePixel);
				//find slider which the nearest
				int currentSlider = getNearestSlider(mouseDegree);

				//get the value from input dialog
				bool ok = FALSE;
				int newValue = QInputDialog::getInteger(tr("ScapeMaker"),tr("New value?"), sliders[currentSlider],
					minValue, maxValue, 1, &ok, this, "SliderInput");

				//if pressed ok
				if (ok)
				{
					//set value of slider to new value
					setSlider(currentSlider, newValue, false);
				}
				return true;
			}
		}
	}
	return false;
}

/****************************************************************************
** CoolSlider createGraphSegments
**
** calculate the points to draw graph
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::createGraphSegments(QPointArray &points)
{
	int xMax = graphArea.width();

	for (int i=0;i<xMax;i++)
	{
		int value;
		if (type == DEGREE)
			value = calculateDegreeFunctionValue((float)i);
		else if (type == LINEAR)
			value = calculateLinearFunctionY((float)i);
		QPoint point(i+graphArea.left(),value+graphArea.top());
		
		if (i<xMax-1) points.setPoint(i*2,point);
		if (i>0) points.setPoint(i*2-1,point);
	}
}

/****************************************************************************
** CoolSlider createGridLines
**
** calculate the points to draw grid lines
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::createGridLines(QPointArray &points)
{
	int valueDiff = maxDisplayValue;
	float gridDistance = (float)valueDiff/(float)gridLineCount;

	for (int i=0;i<gridLineCount;i++)
	{
		float degree = (float)i*gridDistance;
		int x;
		if (type == DEGREE)
			x = calculateDegreeFunctionX(degree);
		else if (type == LINEAR)
			x = calculateLinearFunctionX(degree);
		QPoint point(x+graphArea.left(),graphArea.top());
		points.setPoint(i*2,point);
		point.setY(graphArea.bottom());
		points.setPoint(i*2+1,point);
	}

}

/****************************************************************************
** CoolSlider calculateDegreeFunctionParameters
**
** calculate the const. parameter for the degree function
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::calculateDegreeFunctionParameters()
{
	float xMax = graphArea.width();
	float yMax = graphArea.height();

	//calculate y stretch value
	d=yMax/(-xMax+(xMax+SMALL_NUM)*logf(xMax+SMALL_NUM));
	//calculate y transition
	c=(xMax+SMALL_NUM)*logf(xMax+SMALL_NUM);
}

/****************************************************************************
** CoolSlider calculateDegreeFunctionValue
**
** calculate y coordinate of the degree function
**
** Author: Dirk Plate
****************************************************************************/

float CoolSlider::calculateDegreeFunctionValue(float x)
{
	float xMax = graphArea.width();
	float yMax = graphArea.height();

	//calculate y value
	float y=d*(-x-(xMax+SMALL_NUM)*logf(xMax+SMALL_NUM-x)+c);
	
	//return mirrored y value
	return yMax-y;
}

/****************************************************************************
** CoolSlider calculateDegreeFunctionX
**
** calculate x coordinate of the degree function
**
** Author: Dirk Plate
****************************************************************************/

float CoolSlider::calculateDegreeFunctionX(float degree)
{
	float xMax = graphArea.width();

	//workaround for big degree's
	if (degree > 90.0f-SMALL_NUM)
		return xMax;
	
	//calculate from degree to rad
	float degreeRad=(degree*2*PI)/360.0f;

	//calculate function value
	float y=tanf(degreeRad);
	
	//calculate x value
	float x=(y/d*(xMax+SMALL_NUM))/(1+y/d);
	
	//return x value
	return x;
}

/****************************************************************************
** CoolSlider calculateDegreeFunctionDegree
**
** calculate degree of the degree function
**
** Author: Dirk Plate
****************************************************************************/

float CoolSlider::calculateDegreeFunctionDegree(float x)
{
	float xMax = graphArea.width();

	//workaround to receive highest slope value
	if (x>(xMax-1.0f)-SMALL_NUM)
		return 90.0f;

	//calculate slope value
	float slope=d*(x/(xMax+SMALL_NUM-x));

	//calculate from slope to raddegree
	float degreeRad=atanf(slope);

	//calculate from rad to degree
	float degree=(degreeRad*360.0f)/(2*PI);
	
	//check bounds of value
	if (degree < minValue) degree = minValue;
	if (degree > maxValue) degree = maxValue;

	//return degree value
	return degree;
}


/****************************************************************************
** CoolSlider calculateLinearFunctionParameters
**
** calculate the const. parameter for the linear function
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::calculateLinearFunctionParameters()
{
	float xMax = graphArea.width();
	float yMax = graphArea.height();

	//calculate y stretch value
	d=yMax/xMax;
}

/****************************************************************************
** CoolSlider calculateLinearFunctionY
**
** calculate y coordinate of the linear function
**
** Author: Dirk Plate
****************************************************************************/

float CoolSlider::calculateLinearFunctionY(float x)
{
	float xMax = graphArea.width();
	float yMax = graphArea.height();

	//calculate y value
	float y=d*x;
	
	//return mirrored y value
	return yMax-y;
}

/****************************************************************************
** CoolSlider calculateLinearFunctionX
**
** calculate x coordinate of the linear function
**
** Author: Dirk Plate
****************************************************************************/

float CoolSlider::calculateLinearFunctionX(float value)
{
	float yMax = graphArea.height();

	//calculate from value to y Pixel
	float y=(value*yMax)/maxDisplayValue;

	//calculate x value
	float x=y/d;
	
	//return x value
	return x;
}

/****************************************************************************
** CoolSlider calculateLinearFunctionValue
**
** calculate value of the linear function
**
** Author: Dirk Plate
****************************************************************************/

float CoolSlider::calculateLinearFunctionValue(float x)
{
	float yMax = graphArea.height();

	//calculate y value
	float y=d*x;

	//calculate from y pixel to value
	float value = (y*maxDisplayValue)/yMax;
	
	//check bounds of value
	if (value < minValue) value = minValue;
	if (value > maxValue) value = maxValue;

	//return value
	return value;
}

/****************************************************************************
** CoolSlider getNearestSlider
**
** get the slider which is the nearest at this value
**
** Author: Dirk Plate
****************************************************************************/

int CoolSlider::getNearestSlider(int value)
{
	int nearestSlider = 0;
	
	int nearestDistance = (maxValue-minValue)*2;
	for (int i=0;i<numSliders;i++)
	{
		int distance = sliders[i]-value;
		int absDistance = abs(distance);
		//if two sliders has the same distance... take this one at the right side
		if ((absDistance < nearestDistance) ||
			((absDistance == nearestDistance) && (distance < 0)))
		{
			nearestDistance = absDistance;
			nearestSlider = i;
		}
	}

	return nearestSlider;
}

/****************************************************************************
** CoolSlider setSlider
**
** set a slider to a new value (maybe move other)
**
** Author: Dirk Plate
****************************************************************************/

void CoolSlider::setSlider(int slider, int value, bool silent)
{
	int i;
	
	sliders[slider] = value;
	if (!silent) emit valueChanged(slider,value);
	
	//set all left sliders with higher degrees to same degree as this slider
	for (i=0;i<slider;i++)
	{
		if (sliders[i] > sliders[slider]) 
		{
			sliders[i] = sliders[slider];
			if (!silent) emit valueChanged(i,sliders[slider]);
		}
	}
	//set all right sliders with lower degrees to same degree as this slider
	for (i=slider+1;i<numSliders;i++)
	{
		if (sliders[i] < sliders[slider]) 
		{
			sliders[i] = sliders[slider];
			if (!silent) emit valueChanged(i,sliders[slider]);
		}
	}
	repaint();
	if (!silent) emit valuesChanged();
}






















