/****************************************************************************
** CoolSlider
**
** the cool slider widget
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(COOLSLIDER_H)
#define COOLSLIDER_H
#pragma warning(disable:4786)

#include <qpixmap.h>
#include <qpainter.h>
#include <qimage.h>
#include <qlabel.h>
#include <qmessagebox.h>
#include <qapplication.h>
#include <qcursor.h>
#include <qbitmap.h>
#include <qtoolbutton.h>
#include <qmetaobject.h>
#include <qinputdialog.h>
#include <math.h>

#ifndef PI
	#define PI 3.1415926535897932384626433832795f
#endif

class CoolSlider : public QWidget
{
	Q_OBJECT
 
public:
	enum Type {LINEAR,DEGREE};

	CoolSlider(QWidget* parent = 0, const char* name = 0);
	~CoolSlider();
	void setProperties(Type typeSet, QString titleSet, 
						int minValueSet, int maxValueSet, QString unitSet,
						int numSlidersSet);
	int getMinValue();								//returns the minimum value
	int getMaxValue();								//returns the maximum value
	int getValue(int slider);						//returns a value of a slider

public slots:
	void setValue(int slider, int value);			//set a value of a slider

signals:
	void valueChanged(int slider, int value);		//called if one slider was changed (return the new value)
	void valuesChanged();							//called if one slider was changed

protected:
	void paintEvent(QPaintEvent *paintEvent);
	bool eventFilter(QObject *, QEvent *);

private:
	void createGraphSegments(QPointArray &points);	//create point array for drawing graph
	void createGridLines(QPointArray &points);		//calculate the points to draw grid lines

	void calculateDegreeFunctionParameters();		//calculate the const. parameter for the degree function
	float calculateDegreeFunctionValue(float x);	//calculate y coordinate of the degree function
	float calculateDegreeFunctionX(float degree);	//calculate x coordinate of the degree function
	float calculateDegreeFunctionDegree(float x);	//calculate degree of the degree function

	void calculateLinearFunctionParameters();		//calculate the const. parameter for the linear function
	float calculateLinearFunctionY(float x);		//calculate y coordinate of the linear function
	float calculateLinearFunctionX(float value);	//calculate x coordinate of the linear function
	float calculateLinearFunctionValue(float x);	//calculate value of the linear function

	int getNearestSlider(int value);				//get the slider which is the nearest at this value
	void setSlider(int slider, int value, bool silent);	//set a slider to a new value (maybe move other)

	QRect graphArea;				//in which area will the graph appear
	int minValue, maxValue;			//the min and max value of the function
	int maxDisplayValue;			//the max value displayed in slider
	QString unit;					//the unit of the value
	Type type;						//which is the current tool
	QString title;					//the title of this slider
	int numSliders;					//how many slider to move
	int gridLineCount;				//how many grid lines
	int *sliders;					//the position of the sliders
	int moveSlider;					//the currently moving slider
	int oldSliderPos;				//the position of the currently moving slider before moving
	
	float d,c;		//the const. parameter for degree function
};

#endif