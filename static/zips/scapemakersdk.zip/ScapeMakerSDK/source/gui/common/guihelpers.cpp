/****************************************************************************
** GUIHelpers
**
** help functions for gui
**
** Author: Dirk Plate
****************************************************************************/

#include "GUIHelpers.h"

/****************************************************************************
** GUIHelpers Constructor
**
** do nothing... you shouldn't make a object of this class
**
** Author: Dirk Plate
****************************************************************************/
GUIHelpers::GUIHelpers()
{

}

/****************************************************************************
** GUIHelpers copyFile
**
** copy a file 
**
** Author: Dirk Plate
****************************************************************************/

void GUIHelpers::copyFile(QFile sourceFile, QFile destFile)
{
	//open both files in right mode
	if(!sourceFile.open(IO_Raw | IO_ReadOnly)) return;
	if(!destFile.open(IO_Raw | IO_WriteOnly)) 
	{
		sourceFile.close();
		return;
	}
	
	//copy all bytes
	int bytesRead = 512;
	char bytes[512];
	while (bytesRead == 512)
	{
		bytesRead = sourceFile.readBlock(bytes,512);
		destFile.writeBlock(bytes,bytesRead);
	}

	//really write on disk
	destFile.flush();

	//close both files
	destFile.close();
	sourceFile.close();
}

/****************************************************************************
** GUIHelpers copyDir
**
** copy a directory with all sub-directories (recursive function)
**
** Author: Dirk Plate
****************************************************************************/

void GUIHelpers::copyDir(QDir sourcePath, QDir destPath)
{
	//copy all file/directories in the directory
	const QList<QFileInfo> *fileInfoListOrg = sourcePath.entryInfoList();
	QList<QFileInfo> fileInfoList = *fileInfoListOrg;
	for (uint i=0;i<fileInfoList.count();i++)
	{
		QFileInfo *fileInfo=fileInfoList.at(i);

		//file or directory?
		if (fileInfo->isDir())
		{
			//ignore the . and .. dir
			if ((fileInfo->fileName() == ".") ||
				(fileInfo->fileName() == "..")) continue;

			//create the directory
			destPath.mkdir(fileInfo->fileName());
			//change into this directory
			destPath.cd(fileInfo->fileName());
			sourcePath.cd(fileInfo->fileName());

			//recursive call
			copyDir(sourcePath,destPath);

			//get back to old directory
			destPath.cdUp();
			sourcePath.cdUp();
		}
		else if (fileInfo->isFile())
		{
			//copy the file
			QFile input(fileInfo->absFilePath());
			QFile output(destPath.absPath()+"/"+fileInfo->fileName());
			
			copyFile(input, output);
		}
	}
}

/****************************************************************************
** GUIHelpers deleteDir
**
** delete a directory with all sub-directories (recursive function)
**
** Author: Dirk Plate
****************************************************************************/

void GUIHelpers::deleteDir(QDir path)
{
	//security check (don't delete the whole hard disk)
	if (path.isRoot()) return;

	//check if path exist (and readable)
	if (!path.isReadable()) return;

	//delete all file/directories in the directory
	const QList<QFileInfo> *fileInfoListOrg = path.entryInfoList();
	QList<QFileInfo> fileInfoList = *fileInfoListOrg;
	for (uint i=0;i<fileInfoList.count();i++)
	{
		QFileInfo *fileInfo=fileInfoList.at(i);

		//file or directory?
		if (fileInfo->isDir())
		{
			//ignore the . and .. dir
			if ((fileInfo->fileName() == ".") ||
				(fileInfo->fileName() == "..")) continue;

			//change into this directory
			QDir nextPath(path);
			nextPath.cd(fileInfo->fileName());

			//recursive call
			deleteDir(nextPath);
		}
		else if (fileInfo->isFile())
		{
			path.remove(fileInfo->fileName());
		}
	}

	//wait a moment
	Sleep(100);

	//delete the directory also
	QString dirName = path.dirName();
	path.cdUp();
	path.rmdir(dirName);
}

/****************************************************************************
** GUIHelpers showLoadImageDialog
**
** shows the image loading dialog, load the image and returns it
**
** Author: Dirk Plate
****************************************************************************/

bool GUIHelpers::showLoadImageDialog(QString path, CxImage &image, QWidget *parent, QString *pFileName)
{
	//show the file-dialog
	QString fileName = QFileDialog::getOpenFileName(path, 
		tr("Images (*.bmp *.gif *.jpg *.png *.ico *.tif *.tga *.pcx *.wmf *.jp2 *.jpc *.pgx *.pnm *.ras)"), 
		parent);
    
	//no file selected?
	if (fileName.isNull())
		return false;
    
	//try loading the file
	if (!image.Load(fileName))
	{
		QMessageBox::information(parent, tr("ScapeMaker"),tr("Can't open file!"));
		return false;
	}

	//copy filename, if user want it
	if (pFileName != NULL)
		*pFileName = fileName;

	return true;
}

/****************************************************************************
** GUIHelpers showSaveImageDialog
**
** shows the image save dialog and save the image
**
** Author: Dirk Plate
****************************************************************************/

bool GUIHelpers::showSaveImageDialog(QString name, CxImage &image, QWidget *parent)
{
	//make a copy of image (because we might change the content for compression)
	CxImage imageToSave(image);

	//set settings for file dialog
	OPENFILENAME fileNameStruct;
	fileNameStruct.lStructSize = sizeof(fileNameStruct);
	fileNameStruct.hwndOwner = parent->winId();
	char filter[] = "Bitmap (*.bmp)\0"						"*.bmp\0"
					"JPEG (*.jpg)\0"						"*.jpg\0"
					"Portable Network Graphic (*.png)\0"	"*.png\0"
					"Windows Icon (*.ico)\0"				"*.ico\0"
					"Tagged Image Format (*.tif)\0"			"*.tif\0"
					"Truevision Targa (*.tga)\0"			"*.tga\0"
					"PC Paintbrush Bitmap (*.pcx)\0"		"*.pcx\0"
					"JPEG-2000 (*.jp2)\0"					"*.jp2\0"
					"JPEG-2000 Code Stream (*.jpc)\0"		"*.jpc\0"
					"Portable Any Map (*.pnm)\0"			"*.pnm\0"
					"Sun Raster Graphic (*.ras)\0"			"*.ras\0"
					"\0";
	fileNameStruct.lpstrFilter = filter;
	fileNameStruct.lpstrCustomFilter = NULL;
	fileNameStruct.nFilterIndex = 1;
	char cFileName[1024];
	strcpy(cFileName,name.latin1());
	fileNameStruct.lpstrFile = cFileName;
	fileNameStruct.nMaxFile = 1024;
	fileNameStruct.lpstrFileTitle = NULL;
	fileNameStruct.lpstrInitialDir = NULL;
	fileNameStruct.lpstrTitle = NULL;
	fileNameStruct.Flags = OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
	fileNameStruct.lpstrDefExt = NULL;

	//open dialog
	if (!GetSaveFileName(&fileNameStruct))
	{
		//show error message
		DWORD errorID = CommDlgExtendedError();
		if (errorID == 0)
		{
			//user canceled dialog
			return false;
		}
		else if (errorID == FNERR_INVALIDFILENAME)
		{
			//invalid file name
			QMessageBox::warning(parent, tr("ScapeMaker"),tr("Invalid file name!"));
			return false;
		}
		else 
		{
			//other error
			QMessageBox::warning(parent, tr("ScapeMaker"),tr("Unknown error!"));
			return false;
		}
	}

	//copy file name to qstring
	QString fileName = fileNameStruct.lpstrFile;

	//check extension
	QString extension = fileName.right(4);
	extension = extension.lower();
	int fileFormat;
	bool ok;
	int compression;
	switch (fileNameStruct.nFilterIndex)
	{
	case 1:
		if (extension != ".bmp") fileName += ".bmp";
		fileFormat = CXIMAGE_FORMAT_BMP;
		break;

	case 2:
		if (extension != ".jpg") fileName += ".jpg";
		fileFormat = CXIMAGE_FORMAT_JPG;
		//get compression from user
		ok = FALSE;
		compression = QInputDialog::getInteger(tr("ScapeMaker"),tr("Set compression quality (0=bad, 100=good):"), 
								75,	0, 100, 1, &ok, parent, "CompressionInput");
		//set compression
		if (ok) imageToSave.SetJpegQuality(compression);
		else return false;
		//set bit depth
		imageToSave.IncreaseBpp(24);
		break;

	case 3:
		if (extension != ".png") fileName += ".png";
		fileFormat = CXIMAGE_FORMAT_PNG;
		break;

	case 4:
		if (extension != ".ico") fileName += ".ico";
		fileFormat = CXIMAGE_FORMAT_ICO;
		//set size
		imageToSave.Resample(32,32);
		break;

	case 5:
		if (extension != ".tif") fileName += ".tif";
		fileFormat = CXIMAGE_FORMAT_TIF;
		//get compression from user
		ok = FALSE;
		compression = QInputDialog::getInteger(tr("ScapeMaker"),tr("Set compression quality (0=bad, 100=good):"), 
								75,	0, 100, 1, &ok, parent, "CompressionInput");
		//set compression
		if (ok) imageToSave.SetJpegQuality(compression);
		else return false;
		break;

	case 6:
		if (extension != ".tga") fileName += ".tga";
		fileFormat = CXIMAGE_FORMAT_TGA;
		break;

	case 7:
		if (extension != ".pcx") fileName += ".pcx";
		fileFormat = CXIMAGE_FORMAT_PCX;
		break;

	case 8:
		if (extension != ".jp2") fileName += ".jp2";
		fileFormat = CXIMAGE_FORMAT_JP2;
		break;

	case 9:
		if (extension != ".jpc") fileName += ".jpc";
		fileFormat = CXIMAGE_FORMAT_JPC;
		break;

	case 10:
		if (extension != ".pnm") fileName += ".pnm";
		fileFormat = CXIMAGE_FORMAT_PNM;
		break;

	case 11:
		if (extension != ".ras") fileName += ".ras";
		fileFormat = CXIMAGE_FORMAT_RAS;
		break;
		
	default:
		QMessageBox::warning(parent, tr("ScapeMaker"),tr("Invalid file extension!"));
		return false;
		break;		
	}

	//check for existing file
	QFileInfo fileInfo(fileName);
	if (fileInfo.exists() && fileInfo.isFile())
	{
		//check for read only
		if (!fileInfo.isWritable())
		{
			QMessageBox::warning(parent, tr("ScapeMaker"),tr("Existing file is read only!"));
			return false;
		}
		//ask the user if overwrite
		if(QMessageBox::warning(parent, tr("ScapeMaker"), tr("File already exists!\nDo you want to overwrite this file?"), 
				tr("Yes"), tr("No"), QString::null, 1) != 0) return false;
	}

	//save file
	if (!imageToSave.Save(fileName, fileFormat))
	{
		QMessageBox::warning(parent, tr("ScapeMaker"),tr("Can't save file!"));
		return false;
	}

	//show result message
	QMessageBox::information(parent, tr("ScapeMaker"),tr("Image successfully saved as\n\"%1\"").arg(fileName));
		
	return true;
}

/****************************************************************************
** GUIHelpers convertCxImageToQImage
**
** convert a cximage object to a qimage (deep copy)
**
** Author: Dirk Plate
****************************************************************************/

QImage GUIHelpers::convertCxImageToQImage(CxImage &srcImage)
{
	//create new qimage
	QImage destImage(srcImage.GetWidth(),srcImage.GetHeight(),32);

	for (DWORD y=0; y<srcImage.GetHeight(); y++)
		for (DWORD x=0;x<srcImage.GetWidth(); x++)
	{
		RGBQUAD color = srcImage.GetPixelColor(x,srcImage.GetHeight()-1-y);
		destImage.setPixel(x,y,qRgb(color.rgbRed, color.rgbGreen, color.rgbBlue));
	}

	return destImage;
}

/****************************************************************************
** GUIHelpers addDirToArchive
**
** add all files of a directory to a archive (not recursive)
**
** Author: Dirk Plate
****************************************************************************/

void GUIHelpers::addDirToArchive(CZipArchive *pZipArchive, QDir path, QString archiveDirectory)
{
	//add all files in the directory
	const QList<QFileInfo> *fileInfoListOrg = path.entryInfoList();
	QList<QFileInfo> fileInfoList = *fileInfoListOrg;
	for (uint i=0;i<fileInfoList.count();i++)
	{
		QFileInfo *fileInfo=fileInfoList.at(i);

		//add only files
		if (fileInfo->isFile())
		{
			pZipArchive->AddNewFile(CZipAddNewFileInfo(fileInfo->absFilePath().latin1(),
				(archiveDirectory+"/"+fileInfo->fileName()).latin1()));
		}
	}
}

/****************************************************************************
** GUIHelpers createLandscapeDirectories
**
** create all directories for the landscape
**
** Author: Dirk Plate
****************************************************************************/

void GUIHelpers::createLandscapeDirectories(QWidget *widget, QString projectPath, bool onlyName)
{
	//create directory-tree
	QDir directory;	
	QString path;
	QFileInfo fileInfo;

	if (onlyName)
	{
		path = "./landscapes/";
		fileInfo = QFileInfo(path);
		if (!fileInfo.exists() || !fileInfo.isDir())
		{
			if (!directory.mkdir(path))
			{
				QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
				return;
			}
		}

		path = "./landscapes/"+projectPath;
		fileInfo = QFileInfo(path);
		if (!fileInfo.exists() || !fileInfo.isDir())
		{
			if (!directory.mkdir(path))
			{
				QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
				return;
			}
		}
		projectPath = path;
	}

	path = projectPath+"/engine";
	fileInfo = QFileInfo(path);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		if (!directory.mkdir(path))
		{
			QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}

	path = projectPath+"/engine/textures";
	fileInfo = QFileInfo(path);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		if (!directory.mkdir(path))
		{
			QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}

	path = projectPath+"/engine/objects";
	fileInfo = QFileInfo(path);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		if (!directory.mkdir(path))
		{	
			QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}

	path = projectPath+"/engine/cloudlayer";
	fileInfo = QFileInfo(path);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		if (!directory.mkdir(path))
		{	
			QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}

	path = projectPath+"/textures";
	fileInfo = QFileInfo(path);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		if (!directory.mkdir(path))
		{
			QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}

	path = projectPath+"/objects";
	fileInfo = QFileInfo(path);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		if (!directory.mkdir(path))
		{
			QMessageBox::information(widget, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}

}