/****************************************************************************
** GUIHelpers
**
** helpfunctions for qui
**
** Author: Dirk Plate
****************************************************************************/

#if !defined(GUIHELPERS_H)
#define GUIHELPERS_H
#pragma warning(disable:4786)

#include "qdir.h"
#include "qurloperator.h"
#include "qtextstream.h"
#include "qmessagebox.h"
#include "qfiledialog.h"
#include "qinputdialog.h"
#include "ziparchive.h"
#include "ximage.h"
#include "qimage.h"

//compression quality for all jpg's (0-100)
#define JPG_QUALITY 100

class GUIHelpers : public QObject
{
Q_OBJECT

public:
	GUIHelpers();
	static void copyDir(QDir sourcePath, QDir destPath);
	static void copyFile(QFile sourceFile, QFile destFile);
	static void deleteDir(QDir path);
	static void addDirToArchive(CZipArchive *pZipArchive, QDir path, QString archiveDirectory);
	static bool showLoadImageDialog(QString path, CxImage &image, QWidget *parent, QString *pFileName = NULL);
	static bool showSaveImageDialog(QString name, CxImage &image, QWidget *parent);
	static QImage convertCxImageToQImage(CxImage &srcImage);
	static void createLandscapeDirectories(QWidget *widget, QString projectPath, bool onlyName);
};

#endif