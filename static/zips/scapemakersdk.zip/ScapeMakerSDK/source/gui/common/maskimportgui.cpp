/****************************************************************************
** MaskImportGUI
**
** the mask import window
**
** Author: Dirk Plate
****************************************************************************/

#include "maskimportgui.h"
#include "../../engine/common/enginehelpers.h"


/****************************************************************************
** MaskImportGUI Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/
MaskImportGUI::MaskImportGUI(QWidget* parent, const char* name, bool modal, WFlags f, CxImage &source1)
	: MaskImportGUIBase(parent, name, modal, f)
{
	//will be set to false at okClicked()
	canceled = true;

	//set 'and' as default operator
	combinationOperator->setCurrentItem(2);

	//set source 1 from outside
	this->source1 = source1;

	//show the preview of texture
	QImage image = GUIHelpers::convertCxImageToQImage(source1);
	QPixmap pixmap;
	pixmap.convertFromImage(image);
	source1View->setPixmap(pixmap);

	//reset source 2 to default ones
	resetSource(&source2, source2View, true);
}

/****************************************************************************
** MaskImportGUI Several buttons for sources
**
** only call the right method with right parameters
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::source1ImportClicked() {importSource(&source1, source1View);}
void MaskImportGUI::source2ImportClicked() {importSource(&source2, source2View);}
void MaskImportGUI::source1InvertClicked() {invertSource(&source1, source1View);}
void MaskImportGUI::source2InvertClicked() {invertSource(&source2, source2View);}
void MaskImportGUI::source1ResetClicked()  {resetSource(&source1, source1View, true);}
void MaskImportGUI::source2ResetClicked()  {resetSource(&source2, source2View, true);}

/****************************************************************************
** MaskImportGUI sourcesChanged
**
** calculates the new result (combine source1 and source2)
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::sourcesChanged()
{
	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//get right size for result (use max of both sources)
	int resultWidth = MAX(source1.GetWidth(),source2.GetWidth());
	int resultHeight = MAX(source1.GetHeight(),source2.GetHeight());

	//copy both sources and scale them to result size
	CxImage source1Scaled;
	source1.Resample(resultWidth,resultHeight,2,&source1Scaled);
	CxImage source2Scaled;
	source2.Resample(resultWidth,resultHeight,2,&source2Scaled);

	//use scaled source 1 as result
	result = source1Scaled;

	//choose right mixing
	CxImage::ImageOpType opType;
	switch(combinationOperator->currentItem())
	{
	case 0:
		opType = CxImage::ImageOpType::OpAdd;
		break;
	case 1:
		opType = CxImage::ImageOpType::OpSub;
		break;
	case 2:
		opType = CxImage::ImageOpType::OpAnd;
		break;
	case 3:
		opType = CxImage::ImageOpType::OpOr;
		break;
	case 4:
		opType = CxImage::ImageOpType::OpXor;
		break;
	default:
		opType = CxImage::ImageOpType::OpAdd;
	}

	//mix it, baby
	result.Mix(source2Scaled,opType);

	//show the preview of texture
	QImage image = GUIHelpers::convertCxImageToQImage(result);
	QPixmap pixmap;
	pixmap.convertFromImage(image);
	resultView->setPixmap(pixmap);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();
}

/****************************************************************************
** MaskImportGUI okClicked
**
** called if user clicked ok. Set flag, so result is valid.
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::okClicked()
{
	canceled = false;

	close();
}

/****************************************************************************
** MaskImportGUI cancelClicked
**
** called if user clicked cancel. 
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::cancelClicked()
{
	close();
}

/****************************************************************************
** MaskImportGUI importSource
**
** import a new image
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::importSource(CxImage *pMask, QLabel *pLabel)
{
	//show the file-dialog
	if (GUIHelpers::showLoadImageDialog(".",*pMask,this))
	{
		//make image to grayscale
		pMask->GrayScale();

		//show the preview of texture
		QImage image = GUIHelpers::convertCxImageToQImage(*pMask);
		QPixmap pixmap;
		pixmap.convertFromImage(image);
		pLabel->setPixmap(pixmap);

		//update result
		sourcesChanged();
	}
}

/****************************************************************************
** MaskImportGUI invertSource
**
** invert the image
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::invertSource(CxImage *pMask, QLabel *pLabel)
{
	//invert it
	pMask->Negative();

	//show the preview of texture
	QImage image = GUIHelpers::convertCxImageToQImage(*pMask);
	QPixmap pixmap;
	pixmap.convertFromImage(image);
	pLabel->setPixmap(pixmap);

	//update result
	sourcesChanged();
}

/****************************************************************************
** MaskImportGUI resetSource
**
** reset the image to default one
**
** Author: Dirk Plate
****************************************************************************/
void MaskImportGUI::resetSource(CxImage *pMask, QLabel *pLabel, bool updateResult)
{
	//create default file
	pMask->Create(256,256,24);
	pMask->Clear(0xff);

	//show the preview of texture
	QImage image = GUIHelpers::convertCxImageToQImage(*pMask);
	QPixmap pixmap;
	pixmap.convertFromImage(image);
	pLabel->setPixmap(pixmap);

	//update result
	if (updateResult)
		sourcesChanged();
}
