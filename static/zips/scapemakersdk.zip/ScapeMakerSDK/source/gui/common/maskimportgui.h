/****************************************************************************
** MaskImportGUI
**
** the mask import window
**
** Author: Dirk Plate
****************************************************************************/

#ifndef MASKIMPORTGUI_H
#define MASKIMPORTGUI_H

#pragma warning(disable:4786)

#include "maskimportguibase.h"
#include "../common/guihelpers.h"
#include "ximage.h"
#include <qlabel.h>
#include <qcombobox.h>
#include <qapplication.h>

class MaskImportGUI : public MaskImportGUIBase
{
	Q_OBJECT

public:
	MaskImportGUI(QWidget* parent, const char* name, bool modal, WFlags f, CxImage &source1);
	bool isCanceled() {return canceled;}
	CxImage& getResult() {return result;}

public slots:
	virtual void source1ImportClicked();
	virtual void source2ImportClicked();
	virtual void source1InvertClicked();
	virtual void source2InvertClicked();
	virtual void source1ResetClicked();
	virtual void source2ResetClicked();
	virtual void sourcesChanged();
	virtual void okClicked();
	virtual void cancelClicked();

private:
	//imports a new mask for source 1 or 2
	void importSource(CxImage *pMask, QLabel *pLabel);
	void invertSource(CxImage *pMask, QLabel *pLabel);
	void resetSource(CxImage *pMask, QLabel *pLabel, bool updateResult);

	//dialog exits with cancel
	bool canceled;

	//image of source1
	CxImage source1;

	//image of source2
	CxImage source2;

	//image of result
	CxImage result;
};

#endif
