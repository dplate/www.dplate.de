/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\common\maskimportguibase.ui'
**
** Created: Sun Feb 13 15:03:31 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "maskimportguibase.h"

#include <qcombobox.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a MaskImportGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
MaskImportGUIBase::MaskImportGUIBase( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "MaskImportGUIBase" );
    resize( 545, 200 ); 
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 545, 200 ) );
    setCaption( tr( "ScapeMaker - Import mask" ) );

    resultGroup = new QGroupBox( this, "resultGroup" );
    resultGroup->setGeometry( QRect( 380, 5, 150, 150 ) ); 
    resultGroup->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, resultGroup->sizePolicy().hasHeightForWidth() ) );
    resultGroup->setTitle( tr( "Result" ) );

    resultView = new QLabel( resultGroup, "resultView" );
    resultView->setEnabled( TRUE );
    resultView->setGeometry( QRect( 15, 20, 120, 120 ) ); 
    resultView->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, resultView->sizePolicy().hasHeightForWidth() ) );
    QFont resultView_font(  resultView->font() );
    resultView->setFont( resultView_font ); 
    resultView->setText( tr( "" ) );
    resultView->setScaledContents( TRUE );
    resultView->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    QWhatsThis::add(  resultView, tr( "Shows a picture of result mask." ) );

    source1Group = new QGroupBox( this, "source1Group" );
    source1Group->setGeometry( QRect( 10, 5, 95, 175 ) ); 
    source1Group->setTitle( tr( "Source 1" ) );

    source1ResetButton = new QPushButton( source1Group, "source1ResetButton" );
    source1ResetButton->setGeometry( QRect( 10, 145, 75, 23 ) ); 
    source1ResetButton->setText( tr( "Reset" ) );
    source1ResetButton->setFlat( FALSE );
    QToolTip::add(  source1ResetButton, tr( "Reset to default mask" ) );
    QWhatsThis::add(  source1ResetButton, tr( "Sets mask to default mask." ) );

    source1InvertButton = new QPushButton( source1Group, "source1InvertButton" );
    source1InvertButton->setGeometry( QRect( 10, 120, 75, 23 ) ); 
    source1InvertButton->setText( tr( "Invert" ) );
    source1InvertButton->setFlat( FALSE );
    QToolTip::add(  source1InvertButton, tr( "Invert a mask" ) );
    QWhatsThis::add(  source1InvertButton, tr( "Inverts the mask." ) );

    source1ImportButton = new QPushButton( source1Group, "source1ImportButton" );
    source1ImportButton->setGeometry( QRect( 10, 95, 75, 23 ) ); 
    source1ImportButton->setText( tr( "Import" ) );
    source1ImportButton->setFlat( FALSE );
    QToolTip::add(  source1ImportButton, tr( "Import a mask" ) );
    QWhatsThis::add(  source1ImportButton, tr( "Imports a mask from a image file." ) );

    source1View = new QLabel( source1Group, "source1View" );
    source1View->setGeometry( QRect( 15, 20, 65, 65 ) ); 
    source1View->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, source1View->sizePolicy().hasHeightForWidth() ) );
    QFont source1View_font(  source1View->font() );
    source1View->setFont( source1View_font ); 
    source1View->setText( tr( "" ) );
    source1View->setScaledContents( TRUE );
    source1View->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    QWhatsThis::add(  source1View, tr( "Shows a picture of the mask." ) );

    source2Group = new QGroupBox( this, "source2Group" );
    source2Group->setGeometry( QRect( 250, 5, 95, 175 ) ); 
    source2Group->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, source2Group->sizePolicy().hasHeightForWidth() ) );
    source2Group->setTitle( tr( "Source 2" ) );

    source2ResetButton = new QPushButton( source2Group, "source2ResetButton" );
    source2ResetButton->setGeometry( QRect( 10, 145, 75, 23 ) ); 
    source2ResetButton->setText( tr( "Reset" ) );
    source2ResetButton->setFlat( FALSE );
    QToolTip::add(  source2ResetButton, tr( "Reset to default mask" ) );
    QWhatsThis::add(  source2ResetButton, tr( "Sets mask to default mask." ) );

    source2InvertButton = new QPushButton( source2Group, "source2InvertButton" );
    source2InvertButton->setGeometry( QRect( 10, 120, 75, 23 ) ); 
    source2InvertButton->setText( tr( "Invert" ) );
    source2InvertButton->setFlat( FALSE );
    QToolTip::add(  source2InvertButton, tr( "Invert a mask" ) );
    QWhatsThis::add(  source2InvertButton, tr( "Inverts the mask." ) );

    source2ImportButton = new QPushButton( source2Group, "source2ImportButton" );
    source2ImportButton->setGeometry( QRect( 10, 95, 75, 23 ) ); 
    source2ImportButton->setText( tr( "Import" ) );
    source2ImportButton->setFlat( FALSE );
    QToolTip::add(  source2ImportButton, tr( "Import a mask" ) );
    QWhatsThis::add(  source2ImportButton, tr( "Imports a mask from a image file." ) );

    source2View = new QLabel( source2Group, "source2View" );
    source2View->setEnabled( TRUE );
    source2View->setGeometry( QRect( 15, 20, 65, 65 ) ); 
    source2View->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, source2View->sizePolicy().hasHeightForWidth() ) );
    QFont source2View_font(  source2View->font() );
    source2View->setFont( source2View_font ); 
    source2View->setText( tr( "" ) );
    source2View->setScaledContents( TRUE );
    source2View->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    QWhatsThis::add(  source2View, tr( "Shows a picture of the mask." ) );

    cancelButton = new QPushButton( this, "cancelButton" );
    cancelButton->setGeometry( QRect( 460, 165, 75, 25 ) ); 
    cancelButton->setText( tr( "Cancel" ) );

    okButton = new QPushButton( this, "okButton" );
    okButton->setGeometry( QRect( 380, 165, 75, 25 ) ); 
    okButton->setText( tr( "OK" ) );
    okButton->setDefault( TRUE );

    combinationOperator = new QComboBox( FALSE, this, "combinationOperator" );
    combinationOperator->insertItem( tr( "Add" ) );
    combinationOperator->insertItem( tr( "Subtract" ) );
    combinationOperator->insertItem( tr( "And" ) );
    combinationOperator->insertItem( tr( "Or" ) );
    combinationOperator->insertItem( tr( "Exclusive Or" ) );
    combinationOperator->setGeometry( QRect( 115, 75, 125, 20 ) ); 
    QWhatsThis::add(  combinationOperator, tr( "Sets the operator for combination of source 1 and source 2." ) );

    equalLabel = new QLabel( this, "equalLabel" );
    equalLabel->setGeometry( QRect( 355, 76, 16, 15 ) ); 
    equalLabel->setText( tr( "=" ) );
    equalLabel->setAlignment( int( QLabel::AlignCenter ) );

    // signals and slots connections
    connect( source1ImportButton, SIGNAL( clicked() ), this, SLOT( source1ImportClicked() ) );
    connect( source1InvertButton, SIGNAL( clicked() ), this, SLOT( source1InvertClicked() ) );
    connect( source1ResetButton, SIGNAL( clicked() ), this, SLOT( source1ResetClicked() ) );
    connect( combinationOperator, SIGNAL( activated(int) ), this, SLOT( sourcesChanged() ) );
    connect( source2ImportButton, SIGNAL( clicked() ), this, SLOT( source2ImportClicked() ) );
    connect( source2InvertButton, SIGNAL( clicked() ), this, SLOT( source2InvertClicked() ) );
    connect( source2ResetButton, SIGNAL( clicked() ), this, SLOT( source2ResetClicked() ) );
    connect( okButton, SIGNAL( clicked() ), this, SLOT( okClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
MaskImportGUIBase::~MaskImportGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool MaskImportGUIBase::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont resultView_font(  resultView->font() );
	resultView->setFont( resultView_font ); 
	QFont source1View_font(  source1View->font() );
	source1View->setFont( source1View_font ); 
	QFont source2View_font(  source2View->font() );
	source2View->setFont( source2View_font ); 
    }
    return ret;
}

void MaskImportGUIBase::cancelClicked()
{
    qWarning( "MaskImportGUIBase::cancelClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::okClicked()
{
    qWarning( "MaskImportGUIBase::okClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::source1ImportClicked()
{
    qWarning( "MaskImportGUIBase::source1ImportClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::source1InvertClicked()
{
    qWarning( "MaskImportGUIBase::source1InvertClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::source1ResetClicked()
{
    qWarning( "MaskImportGUIBase::source1ResetClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::source2ImportClicked()
{
    qWarning( "MaskImportGUIBase::source2ImportClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::source2InvertClicked()
{
    qWarning( "MaskImportGUIBase::source2InvertClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::source2ResetClicked()
{
    qWarning( "MaskImportGUIBase::source2ResetClicked(): Not implemented yet!" );
}

void MaskImportGUIBase::sourcesChanged()
{
    qWarning( "MaskImportGUIBase::sourcesChanged(): Not implemented yet!" );
}

