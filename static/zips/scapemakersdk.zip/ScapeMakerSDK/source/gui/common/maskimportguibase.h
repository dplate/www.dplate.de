/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\common\maskimportguibase.ui'
**
** Created: Sun Feb 13 15:03:31 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef MASKIMPORTGUIBASE_H
#define MASKIMPORTGUIBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QComboBox;
class QGroupBox;
class QLabel;
class QPushButton;

class MaskImportGUIBase : public QDialog
{ 
    Q_OBJECT

public:
    MaskImportGUIBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MaskImportGUIBase();

    QGroupBox* resultGroup;
    QLabel* resultView;
    QGroupBox* source1Group;
    QPushButton* source1ResetButton;
    QPushButton* source1InvertButton;
    QPushButton* source1ImportButton;
    QLabel* source1View;
    QGroupBox* source2Group;
    QPushButton* source2ResetButton;
    QPushButton* source2InvertButton;
    QPushButton* source2ImportButton;
    QLabel* source2View;
    QPushButton* cancelButton;
    QPushButton* okButton;
    QComboBox* combinationOperator;
    QLabel* equalLabel;

public slots:
    virtual void cancelClicked();
    virtual void okClicked();
    virtual void source1ImportClicked();
    virtual void source1InvertClicked();
    virtual void source1ResetClicked();
    virtual void source2ImportClicked();
    virtual void source2InvertClicked();
    virtual void source2ResetClicked();
    virtual void sourcesChanged();

protected:
    bool event( QEvent* );
};

#endif // MASKIMPORTGUIBASE_H
