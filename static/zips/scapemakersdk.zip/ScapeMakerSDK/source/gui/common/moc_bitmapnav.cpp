/****************************************************************************
** BitmapNav meta object code from reading C++ file 'bitmapnav.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_BitmapNav
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "bitmapnav.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *BitmapNav::className() const
{
    return "BitmapNav";
}

QMetaObject *BitmapNav::metaObj = 0;

void BitmapNav::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(BitmapNavBase::className(), "BitmapNavBase") != 0 )
	badSuperclassWarning("BitmapNav","BitmapNavBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString BitmapNav::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("BitmapNav",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* BitmapNav::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) BitmapNavBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(BitmapNav::*m1_t0)(bool);
    typedef void(BitmapNav::*m1_t1)(bool);
    typedef void(BitmapNav::*m1_t2)(bool);
    typedef void(BitmapNav::*m1_t3)(bool);
    typedef void(BitmapNav::*m1_t4)(bool);
    typedef void(BitmapNav::*m1_t5)(bool);
    typedef void(BitmapNav::*m1_t6)(bool);
    typedef void(BitmapNav::*m1_t7)(bool);
    typedef void(BitmapNav::*m1_t8)(bool);
    typedef void(BitmapNav::*m1_t9)(bool);
    typedef void(BitmapNav::*m1_t10)(bool);
    typedef void(BitmapNav::*m1_t11)(bool);
    typedef void(BitmapNav::*m1_t12)(bool);
    typedef void(BitmapNav::*m1_t13)(bool);
    typedef void(BitmapNav::*m1_t14)(bool);
    m1_t0 v1_0 = Q_AMPERSAND BitmapNav::toggleZoomButton;
    m1_t1 v1_1 = Q_AMPERSAND BitmapNav::toggleUnZoomButton;
    m1_t2 v1_2 = Q_AMPERSAND BitmapNav::toggleHandButton;
    m1_t3 v1_3 = Q_AMPERSAND BitmapNav::togglePenButton;
    m1_t4 v1_4 = Q_AMPERSAND BitmapNav::toggleRubberButton;
    m1_t5 v1_5 = Q_AMPERSAND BitmapNav::setHandButtonVisible;
    m1_t6 v1_6 = Q_AMPERSAND BitmapNav::setZoomButtonVisible;
    m1_t7 v1_7 = Q_AMPERSAND BitmapNav::setUnZoomButtonVisible;
    m1_t8 v1_8 = Q_AMPERSAND BitmapNav::setPenButtonVisible;
    m1_t9 v1_9 = Q_AMPERSAND BitmapNav::setRubberButtonVisible;
    m1_t10 v1_10 = Q_AMPERSAND BitmapNav::setHandButtonEnable;
    m1_t11 v1_11 = Q_AMPERSAND BitmapNav::setZoomButtonEnable;
    m1_t12 v1_12 = Q_AMPERSAND BitmapNav::setUnZoomButtonEnable;
    m1_t13 v1_13 = Q_AMPERSAND BitmapNav::setPenButtonEnable;
    m1_t14 v1_14 = Q_AMPERSAND BitmapNav::setRubberButtonEnable;
    QMetaData *slot_tbl = QMetaObject::new_metadata(15);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(15);
    slot_tbl[0].name = "toggleZoomButton(bool)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "toggleUnZoomButton(bool)";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "toggleHandButton(bool)";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "togglePenButton(bool)";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "toggleRubberButton(bool)";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "setHandButtonVisible(bool)";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "setZoomButtonVisible(bool)";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "setUnZoomButtonVisible(bool)";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "setPenButtonVisible(bool)";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Public;
    slot_tbl[9].name = "setRubberButtonVisible(bool)";
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl_access[9] = QMetaData::Public;
    slot_tbl[10].name = "setHandButtonEnable(bool)";
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl_access[10] = QMetaData::Public;
    slot_tbl[11].name = "setZoomButtonEnable(bool)";
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl_access[11] = QMetaData::Public;
    slot_tbl[12].name = "setUnZoomButtonEnable(bool)";
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl_access[12] = QMetaData::Public;
    slot_tbl[13].name = "setPenButtonEnable(bool)";
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl_access[13] = QMetaData::Public;
    slot_tbl[14].name = "setRubberButtonEnable(bool)";
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl_access[14] = QMetaData::Public;
    typedef void(BitmapNav::*m2_t0)(QPoint);
    typedef void(BitmapNav::*m2_t1)(QPoint);
    m2_t0 v2_0 = Q_AMPERSAND BitmapNav::positionWithPenClicked;
    m2_t1 v2_1 = Q_AMPERSAND BitmapNav::positionWithRubberClicked;
    QMetaData *signal_tbl = QMetaObject::new_metadata(2);
    signal_tbl[0].name = "positionWithPenClicked(QPoint)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].name = "positionWithRubberClicked(QPoint)";
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = QMetaObject::new_metaobject(
	"BitmapNav", "BitmapNavBase",
	slot_tbl, 15,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL positionWithPenClicked
void BitmapNav::positionWithPenClicked( QPoint t0 )
{
    // No builtin function for signal parameter type QPoint
    QConnectionList *clist = receivers("positionWithPenClicked(QPoint)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(QPoint);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL positionWithRubberClicked
void BitmapNav::positionWithRubberClicked( QPoint t0 )
{
    // No builtin function for signal parameter type QPoint
    QConnectionList *clist = receivers("positionWithRubberClicked(QPoint)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(QPoint);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}
