/****************************************************************************
** TextureExportGUI
**
** the terrain texture export window
**
** Author: Dirk Plate
****************************************************************************/

#include "textureexportgui.h"
#include "ximage.h"

/****************************************************************************
** TextureExportGUI Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

TextureExportGUI::TextureExportGUI(QWidget* parent, const char* name, bool modal, WFlags f,
								   QString texturePathSet, int tilesPerSideSet, int preSelectedType)
	: TextureExportGUIBase(parent, name, modal, f)
{
	texturePath = texturePathSet;
	tilesPerSide = tilesPerSideSet;
	type->setCurrentItem(preSelectedType);
	progressBar->setProgress(0);
}

/****************************************************************************
** TextureExportGUI exportClicked
**
** Is called, when a the export button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void TextureExportGUI::exportClicked()
{
	//retrieve the current resolution
	int currentResolution;
	if (resolution->currentItem() == 0)
		currentResolution = 256;
	else if (resolution->currentItem() == 1)
		currentResolution = 512;
	else if (resolution->currentItem() == 2)
		currentResolution = 1024;
	else if (resolution->currentItem() == 3)
		currentResolution = 2048;
	else if (resolution->currentItem() == 4)
		currentResolution = 4096;
	else if (resolution->currentItem() == 5)
		currentResolution = 8192;

	//reset progress bar to 0%
	progressBar->reset();

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//create new bitmap in right resolution
	CxImage result(currentResolution,currentResolution,24,CXIMAGE_FORMAT_BMP);

	//calculate requested size for one tile
	int requestedTileResolution = currentResolution/tilesPerSide;

	//calculate progress per tile
	float exactProgressPerTile = 100.0f/float(tilesPerSide*tilesPerSide);
	float exactProgress = 0.0f;
	
	//go through all terrain textures
	for (int tileY=0; tileY<tilesPerSide; tileY++)
		for (int tileX=0; tileX<tilesPerSide; tileX++)
	{
		//open terrain texture
		CxImage tileTexture;
		QString tileTextureName;
		if (type->currentItem() == 0)
			tileTextureName = QString("terrain_tmp_%1_%2.jpg").arg(tileX).arg(tileY);
		else tileTextureName = QString("terrain_%1_%2.jpg").arg(tileX).arg(tileY);
		if (!tileTexture.Load(texturePath+"/"+tileTextureName,CXIMAGE_FORMAT_JPG))
		{
			//if texture not exist... create a white texture with minimal size
			tileTexture.Create(256,256,24);			
			tileTexture.Clear(0xff);
		}
		
		//transform tile texture to right size
		tileTexture.Resample(requestedTileResolution,requestedTileResolution,2);
		
		//copy pixel of transformed tile texture to right position in result image
		int offsetX = tileX*requestedTileResolution;
		int offsetY = tileY*requestedTileResolution;
		for (int y=0; y<requestedTileResolution; y++)
			for (int x=0; x<requestedTileResolution; x++)
		{
			result.SetPixelColor(offsetX+x, offsetY+y, tileTexture.GetPixelColor(x,y));
		}

		//update progress
		exactProgress += exactProgressPerTile;
		progressBar->setProgress(exactProgress);
	}

	//update the progress bar to 100%
	progressBar->setProgress(100);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();

	//save result
	GUIHelpers::showSaveImageDialog("terraintexture",result,this);
}
