/****************************************************************************
** TextureExportGUI
**
** the terrain texture export window
**
** Author: Dirk Plate
****************************************************************************/

#ifndef TEXTUREEXPORTGUI_H
#define TEXTUREEXPORTGUI_H

#pragma warning(disable:4786)

#include "textureexportguibase.h"
#include "qprogressbar.h"
#include "qpushbutton.h"
#include "qcombobox.h"
#include "qlabel.h"
#include "qapplication.h"
#include "qfiledialog.h"
#include "qimage.h"
#include "../common/guihelpers.h"

class TextureExportGUI : public TextureExportGUIBase
{
	Q_OBJECT

public:
	TextureExportGUI(QWidget* parent, const char* name, bool modal, WFlags f,
					 QString texturePathSet, int tilesPerSideSet, int preSelectedType);

public slots:
	virtual void exportClicked();

private:
	//path to source textures
	QString texturePath;
	//count of tile per side of terrain	
	int tilesPerSide;
};

#endif
