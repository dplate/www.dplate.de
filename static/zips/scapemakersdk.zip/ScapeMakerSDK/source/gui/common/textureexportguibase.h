/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\common\textureexportguibase.ui'
**
** Created: Sun Feb 13 15:03:31 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef TEXTUREEXPORTGUIBASE_H
#define TEXTUREEXPORTGUIBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QComboBox;
class QLabel;
class QProgressBar;
class QPushButton;

class TextureExportGUIBase : public QDialog
{ 
    Q_OBJECT

public:
    TextureExportGUIBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TextureExportGUIBase();

    QLabel* typeLabel;
    QLabel* resolutionLabel;
    QComboBox* type;
    QComboBox* resolution;
    QPushButton* exportButton;
    QProgressBar* progressBar;

public slots:
    virtual void exportClicked();

};

#endif // TEXTUREEXPORTGUIBASE_H
