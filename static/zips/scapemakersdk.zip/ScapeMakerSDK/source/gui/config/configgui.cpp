/****************************************************************************
** ConfigGUI
**
** configuration of the technical aspect of scapemaker
**
** Author: Dirk Plate
****************************************************************************/

#include "configgui.h"

/****************************************************************************
** ConfigGUI Constructor
**
** Init vars
**
** Author: Dirk Plate
****************************************************************************/
ConfigGUI::ConfigGUI( QWidget* parent, const char* name, bool modal, WFlags f )
	: ConfigGUIBase( parent, name, modal, f )
{
	allDisplayModes.clear();
	allAntialiasing.clear();
}

/****************************************************************************
** ConfigGUI showEvent
**
** Is called, when the ConfigGUIGUI will be shown.
** Load all old settings
**
** Author: Dirk Plate
****************************************************************************/

void ConfigGUI::showEvent(QShowEvent *showEvent)
{
	//will be set to false in okClicked when user didn't canceled the dialog
	canceledDialog = true;

	//will be set to true in okClicked when user changed something critical
	restartRequired = false;

	LPDIRECT3D9 pD3D = Direct3DCreate9(D3D_SDK_VERSION);

	//get adapter information
	D3DADAPTER_IDENTIFIER9 adapterInfos;
	pD3D->GetAdapterIdentifier(D3DADAPTER_DEFAULT,NULL, &adapterInfos);
	type->setText(adapterInfos.Description);

	//fill the resolution list
	uint i;
	bool R5G6B5Used = false;
	for (i=0; i<pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT, D3DFMT_R5G6B5); i++)
	{
		//get mode
		D3DDISPLAYMODE mode;
		pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT, D3DFMT_R5G6B5, i, &mode);
		DWORD bitDepth = 16;
		
		//fill in nice string in list
		resolution->insertItem(QString("%1x%2px %3bit %4hz").arg(mode.Width).arg(mode.Height).arg(bitDepth).arg(mode.RefreshRate));
	
		//save mode in list
		allDisplayModes.push_back(mode);
		R5G6B5Used = true;
	}
	bool X1R5G5B5Used = false;
	for (i=0; i<pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT, D3DFMT_X1R5G5B5); i++)
	{
		//get mode
		D3DDISPLAYMODE mode;
		pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT, D3DFMT_X1R5G5B5, i, &mode);
		DWORD bitDepth = 16;
		
		//fill in nice string in list
		resolution->insertItem(QString("%1x%2px %3bit %4hz").arg(mode.Width).arg(mode.Height).arg(bitDepth).arg(mode.RefreshRate));
	
		//save mode in list
		allDisplayModes.push_back(mode);
		X1R5G5B5Used = true;
	}
	bool X8R8G8B8Used = false;
	for (i=0; i<pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8); i++)
	{
		//get mode
		D3DDISPLAYMODE mode;
		pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8, i, &mode);
		DWORD bitDepth = 32;
		
		//fill in nice string in list
		resolution->insertItem(QString("%1x%2px %3bit %4hz").arg(mode.Width).arg(mode.Height).arg(bitDepth).arg(mode.RefreshRate));
	
		//save mode in list
		allDisplayModes.push_back(mode);
		X8R8G8B8Used = true;
	}

	//check anti aliasing capabilities
	antialiasing->insertItem(tr("disabled"));
	allAntialiasing.push_back(D3DMULTISAMPLE_NONE);
	for (int samples=D3DMULTISAMPLE_2_SAMPLES;samples<D3DMULTISAMPLE_16_SAMPLES;samples++)
	{
		//check all formats (only fullscreen)
		if (R5G6B5Used)
			if (FAILED(pD3D->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
				D3DFMT_R5G6B5, false, (D3DMULTISAMPLE_TYPE)samples, NULL))) 
					continue;
		if (X1R5G5B5Used)
			if (FAILED(pD3D->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
				D3DFMT_X1R5G5B5, false, (D3DMULTISAMPLE_TYPE)samples, NULL))) 
					continue;
		if (X8R8G8B8Used)
			if (FAILED(pD3D->CheckDeviceMultiSampleType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
				D3DFMT_X8R8G8B8, false, (D3DMULTISAMPLE_TYPE)samples, NULL))) 
					continue;

		//add to drop down
		antialiasing->insertItem(QString("%1x").arg(samples));
		//add to list
		allAntialiasing.push_back((D3DMULTISAMPLE_TYPE)samples);
	}

	//check for right vertex and pixelshader support
	bool waterReflectionSupport = false;
	bool heightBasedFogSupport = false;
	D3DCAPS9 caps;
	pD3D->GetDeviceCaps(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,&caps);

	//fog possible?
	if ((D3DSHADER_VERSION_MAJOR(caps.PixelShaderVersion) >= 2) &&
		(D3DSHADER_VERSION_MAJOR(caps.VertexShaderVersion) >= 2) &&
		(X8R8G8B8Used))
		heightBasedFogSupport = true;

	//water reflection possible
    if (( 0 != (caps.TextureOpCaps & D3DTEXOPCAPS_BUMPENVMAP)) &&
		(D3DSHADER_VERSION_MAJOR(caps.PixelShaderVersion) >= 1) &&
		(D3DSHADER_VERSION_MAJOR(caps.VertexShaderVersion) >= 1))
		waterReflectionSupport = true;

	//check texture capabilities
	bool pureAlphaTextureSupport = true;
	D3DDISPLAYMODE displayMode;
	pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&displayMode);
	if (FAILED(pD3D->CheckDeviceFormat(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,displayMode.Format,0,D3DRTYPE_TEXTURE,D3DFMT_A8)))
		pureAlphaTextureSupport = false;

    //release Direct3d object
	SAFE_RELEASE(pD3D);

	//first set default values for all settings
	D3DDISPLAYMODE loadedMode;
	loadedMode.Width = 1024;
	loadedMode.Height = 768;
	loadedMode.Format = D3DFMT_X8R8G8B8;
	loadedMode.RefreshRate = 60;
	D3DMULTISAMPLE_TYPE loadedAntialiasing = D3DMULTISAMPLE_NONE;
	bool loadedDetailTexture = true;
	int loadedTerrainLOD = 2;
	bool loadedHeightBasedFog = true;
	bool loadedWaterReflection = true;
	loadedLanguageID = 0;
	loadedExpert = false;
	int loadedSeaReflection = 1;
	bool loadedCloudShading = false;

	//load old settings from file
	MiniXML xmlFile;
	if (xmlFile.openFile("./enginefiles/config.txt",MiniXML::Modus::READ))
	{
		int value;
		bool bValue;

		//load display mode
		if (xmlFile.readInteger("width",&value))
			loadedMode.Width = value;
		if (xmlFile.readInteger("height",&value))
			loadedMode.Height = value;
		if (xmlFile.readInteger("format",&value))
			loadedMode.Format = D3DFORMAT(value);
		if (xmlFile.readInteger("refreshRate",&value))
			loadedMode.RefreshRate = value;

		//load antialiasing
		if (xmlFile.readInteger("antialiasing",&value))
			loadedAntialiasing = (D3DMULTISAMPLE_TYPE)value;

		//load other setting
		if (xmlFile.readBoolean("detailTexture",&bValue))
			loadedDetailTexture = bValue;
		if (xmlFile.readInteger("terrainLOD",&value))
			loadedTerrainLOD = value;
		if (xmlFile.readBoolean("heightBasedFog",&bValue))
			loadedHeightBasedFog = bValue;
		if (xmlFile.readBoolean("cloudShading",&bValue))
			loadedCloudShading = bValue;
		if (xmlFile.readBoolean("waterReflection",&bValue))
			loadedWaterReflection = bValue;
		if (xmlFile.readBoolean("skyReflection", &bValue))
			if (bValue) loadedSeaReflection = 0;
		if (xmlFile.readBoolean("terrainReflection", &bValue))
			if (bValue) loadedSeaReflection = 1;
		if (xmlFile.readBoolean("subMeshesReflection", &bValue))
			if (bValue) loadedSeaReflection = 2;
	}
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		int value;
		bool bValue;

		//load language
		if (xmlFile.readInteger("language", &value))
			loadedLanguageID = value;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}

	//find the right display mode index for the saved one
	int bestWidthHeightDifference = INT_MAX;
	int bestFormatDifference = INT_MAX;
	int bestRefreshRateDifference = INT_MAX;
	uint bestMode=-1;

	for (i=0;i<allDisplayModes.size();i++)
	{
		int widthHeightDifference = abs((allDisplayModes[i].Width-loadedMode.Width)+
										(allDisplayModes[i].Height-loadedMode.Height));
		int formatDifference = abs(allDisplayModes[i].Format-loadedMode.Format);
		int refreshRateDifference = abs(allDisplayModes[i].RefreshRate-loadedMode.RefreshRate);

		//if the resolution is nearer best one -> take this
		if (widthHeightDifference < bestWidthHeightDifference)
		{
			bestWidthHeightDifference = widthHeightDifference;
			bestFormatDifference = formatDifference;
			bestRefreshRateDifference = refreshRateDifference;
			bestMode = i;
		}
		//if the resolution is equal good than best one -> maybe take this
		else if (widthHeightDifference == bestWidthHeightDifference)
		{
			//if format is nearer best one -> take this
			if (formatDifference < bestFormatDifference)
			{
				bestWidthHeightDifference = widthHeightDifference;
				bestFormatDifference = formatDifference;
				bestRefreshRateDifference = refreshRateDifference;
				bestMode = i;
			}
			//if format is equal good than best one -> maybe take this
			else if (formatDifference == bestFormatDifference)
			{
				//if refreshrate is nearer best one -> take this
				if (refreshRateDifference < bestRefreshRateDifference)
				{
					bestWidthHeightDifference = widthHeightDifference;
					bestFormatDifference = formatDifference;
					bestRefreshRateDifference = refreshRateDifference;
					bestMode = i;
				}
			}
		}
	}

	//if no mode found... show error message and cancel
	if (bestMode == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't find a display mode!"));
		close();
		return;
	}

	//find the right antialiasing value
	//in default select none
	antialiasing->setCurrentItem(0);
	for (i=0;i<allAntialiasing.size();i++)
	{
		if (allAntialiasing[i] == loadedAntialiasing)
			antialiasing->setCurrentItem(i);
	}

	//select the gui to right values
	resolution->setCurrentItem(bestMode);
	detailTexture->setChecked(loadedDetailTexture);
	terrainLODGroup->setButton(loadedTerrainLOD);
	language->setCurrentItem(loadedLanguageID);
	expert->setChecked(loadedExpert);
	seaReflectionGroup->setButton(loadedSeaReflection);

	//if card support fog -> use settings from file
	if (heightBasedFogSupport)
	{
		fog->setChecked(loadedHeightBasedFog);
	}
	//else disable and uncheck checkboxes 
	else
	{
		fog->setChecked(false);
		fog->setEnabled(false);
	}

	//if card support disabling clouds shading -> use settings from file
	if (pureAlphaTextureSupport)
	{
		cloudShading->setChecked(loadedCloudShading);
	}
	//else disable and check checkbox
	else
	{
		cloudShading->setChecked(true);
		cloudShading->setEnabled(false);
	}

	//if card support water reflection -> use settings from file
	if (waterReflectionSupport)
	{
		waterReflection->setChecked(loadedWaterReflection);
		seaReflectionGroup->setEnabled(loadedWaterReflection);
	}
	//else disable and uncheck checkboxes 
	else
	{
		waterReflection->setChecked(false);
		waterReflection->setEnabled(false);
		seaReflectionGroup->setEnabled(false);
	}
}

/****************************************************************************
** ConfigGUI hideEvent
**
** Is called, when the ConfigGUIGUI will be hidden.
** delete all allocated memory
**
** Author: Dirk Plate
****************************************************************************/
void ConfigGUI::hideEvent(QHideEvent *hideEvent)
{
	//delete display mode list
	allDisplayModes.clear();

	//delete antialiasing types
	allAntialiasing.clear();
}

/****************************************************************************
** ConfigGUI okClicked
**
** Is called, when the ok button is clicked
** Save all settings
**
** Author: Dirk Plate
****************************************************************************/
void ConfigGUI::okClicked()
{
	//save the engine settings
	MiniXML xmlFile;
	if (xmlFile.openFile("./enginefiles/config.txt",MiniXML::Modus::WRITE))
	{
		int modeIndex = resolution->currentItem();

		//save resolution
		xmlFile.writeInteger("width",allDisplayModes[modeIndex].Width);
		xmlFile.writeInteger("height",allDisplayModes[modeIndex].Height);
		xmlFile.writeInteger("format",allDisplayModes[modeIndex].Format);
		xmlFile.writeInteger("refreshRate",allDisplayModes[modeIndex].RefreshRate);

		//save antialiasing
		xmlFile.writeInteger("antialiasing",allAntialiasing[antialiasing->currentItem()]);

		//save detail texture
		xmlFile.writeBoolean("detailTexture",detailTexture->isChecked());

		//save terrain lod
		xmlFile.writeInteger("terrainLOD",terrainLODGroup->id(terrainLODGroup->selected()));

		//save fog flag
		xmlFile.writeBoolean("heightBasedFog",fog->isChecked());

		//save cloud shading flag
		xmlFile.writeBoolean("cloudShading",cloudShading->isChecked());

		//save water reflection flag
		xmlFile.writeBoolean("waterReflection",waterReflection->isChecked());

		//save sea reflection option
		if (seaReflectionGroup->id(seaReflectionGroup->selected()) == 0)
		{
			xmlFile.writeBoolean("skyReflection", true);
			xmlFile.writeBoolean("terrainReflection", false);
			xmlFile.writeBoolean("subMeshesReflection", false);
		}
		else if (seaReflectionGroup->id(seaReflectionGroup->selected()) == 1)
		{
			xmlFile.writeBoolean("skyReflection", true);
			xmlFile.writeBoolean("terrainReflection", true);
			xmlFile.writeBoolean("subMeshesReflection", false);
		}
		else if (seaReflectionGroup->id(seaReflectionGroup->selected()) == 2)
		{
			xmlFile.writeBoolean("skyReflection", true);
			xmlFile.writeBoolean("terrainReflection", true);
			xmlFile.writeBoolean("subMeshesReflection", true);
		}
	
		//close xml file
		xmlFile.closeFile();
	}

	//save gui settings
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::WRITE))
	{
		//save language
		xmlFile.writeInteger("language",language->currentItem());

		//save language
		xmlFile.writeBoolean("expert",expert->isChecked());

		//close xml file
		xmlFile.closeFile();
	}
	
	//the user didn't canceled the dialog
	canceledDialog = false;

	//restart required?
	if ((language->currentItem() != loadedLanguageID) ||
		(expert->isChecked() != loadedExpert))
		restartRequired = true;

	close();
}
 
/****************************************************************************
** ConfigGUI cancelClicked
**
** Is called, when the cancel button is clicked
** close dialog
**
** Author: Dirk Plate
****************************************************************************/
void ConfigGUI::cancelClicked()
{
	close();
}

/****************************************************************************
** ConfigGUI resolutionChanged
**
** Is called, when the user chose a resolution
**
** Author: Dirk Plate
****************************************************************************/
void ConfigGUI::resolutionChanged(int modeIndex)
{
	//check, if user chose a 16 bit resolution
	if (allDisplayModes[modeIndex].Format != D3DFMT_X8R8G8B8)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Height based fog will only be visible at 32bit color depth."));
	}
}

