/****************************************************************************
** ConfigGUI
**
** configuration of the technical aspect of scapemaker
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "configguibase.h"
#include "../../common/minixml.h"
#include <d3d9.h>
#include "../../engine/common/dxutil.h"
#include <qcombobox.h>
#include <qmessagebox.h>
#include <qlabel.h>
#include <qcheckbox.h>
#include <qbuttongroup.h>
#include <vector>
#include "math.h"

class ConfigGUI : public ConfigGUIBase
{
	Q_OBJECT

public:
	ConfigGUI( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags f = 0 );
	bool isCanceledDialog() {return canceledDialog;}
	bool isRestartRequired() {return restartRequired;}

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);

public slots:
	virtual void okClicked();
    virtual void cancelClicked();
	virtual void resolutionChanged(int modeIndex);

private:
	std::vector<D3DDISPLAYMODE> allDisplayModes;			//list of all available display modes of the current adapter
	std::vector<D3DMULTISAMPLE_TYPE> allAntialiasing;	//list with all available antialiasing types

	

	//loaded language
	int loadedLanguageID;

	//loaded expert setting
	bool loadedExpert;

	bool canceledDialog;	//the user canceled the dialog
	bool restartRequired;	//the user changed something critical, so restart is required
};

