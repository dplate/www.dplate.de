/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\config\configguibase.ui'
**
** Created: Sun Feb 13 15:03:30 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef CONFIGGUIBASE_H
#define CONFIGGUIBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QButtonGroup;
class QCheckBox;
class QComboBox;
class QGroupBox;
class QLabel;
class QPushButton;
class QRadioButton;

class ConfigGUIBase : public QDialog
{ 
    Q_OBJECT

public:
    ConfigGUIBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~ConfigGUIBase();

    QGroupBox* performanceGroup;
    QCheckBox* detailTexture;
    QButtonGroup* terrainLODGroup;
    QRadioButton* terrainLODHigh;
    QRadioButton* terrainLODMiddle;
    QRadioButton* terrainLODLow;
    QRadioButton* terrainLODFull;
    QCheckBox* cloudShading;
    QCheckBox* waterReflection;
    QButtonGroup* seaReflectionGroup;
    QRadioButton* reflectionSkyTerrainSubMeshes;
    QRadioButton* reflectionSky;
    QRadioButton* reflectionSkyTerrain;
    QCheckBox* fog;
    QPushButton* cancelButton;
    QPushButton* okButton;
    QGroupBox* hardwareGroup;
    QLabel* typeLabel;
    QLabel* antialiasingLabel;
    QLabel* type;
    QLabel* resolutionLabel;
    QComboBox* resolution;
    QComboBox* antialiasing;
    QGroupBox* infoGroup;
    QLabel* infoText;
    QGroupBox* GuiGroup;
    QLabel* languageLabel;
    QComboBox* language;
    QCheckBox* expert;

public slots:
    virtual void cancelClicked();
    virtual void resolutionChanged(int);
    virtual void okClicked();

};

#endif // CONFIGGUIBASE_H
