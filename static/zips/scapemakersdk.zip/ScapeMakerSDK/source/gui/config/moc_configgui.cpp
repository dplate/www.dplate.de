/****************************************************************************
** ConfigGUI meta object code from reading C++ file 'configgui.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_ConfigGUI
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "configgui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *ConfigGUI::className() const
{
    return "ConfigGUI";
}

QMetaObject *ConfigGUI::metaObj = 0;

void ConfigGUI::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(ConfigGUIBase::className(), "ConfigGUIBase") != 0 )
	badSuperclassWarning("ConfigGUI","ConfigGUIBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString ConfigGUI::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("ConfigGUI",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* ConfigGUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) ConfigGUIBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(ConfigGUI::*m1_t0)();
    typedef void(ConfigGUI::*m1_t1)();
    typedef void(ConfigGUI::*m1_t2)(int);
    m1_t0 v1_0 = Q_AMPERSAND ConfigGUI::okClicked;
    m1_t1 v1_1 = Q_AMPERSAND ConfigGUI::cancelClicked;
    m1_t2 v1_2 = Q_AMPERSAND ConfigGUI::resolutionChanged;
    QMetaData *slot_tbl = QMetaObject::new_metadata(3);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(3);
    slot_tbl[0].name = "okClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "cancelClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "resolutionChanged(int)";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"ConfigGUI", "ConfigGUIBase",
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
