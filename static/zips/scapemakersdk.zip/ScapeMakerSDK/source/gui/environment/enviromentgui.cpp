/****************************************************************************
** EnviromentGUI
**
** the enviroment-tab window
**
** Author: Dirk Plate
****************************************************************************/

#include "enviromentgui.h"

/****************************************************************************
** EnviromentGUI Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

EnviromentGUI::EnviromentGUI( QWidget* parent, const char* name, WFlags f )
	: EnviromentGUIBase(parent, name, f)
{
	generatingProgress = 0;

	generatingShadowPreviewTimer = false;
	generatingShadowPreviewTimerID = -1;
	generatingShadowTimerID = -1;

	dontRecalculate = false;

	defaultSkyColors = NULL;

	cancelButton->hide();	//hide the cancel button
}

/****************************************************************************
** EnviromentGUI showEvent
**
** Is called, when the EnviromentGUI will be shown.
** Load everything for this panel!
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::showEvent(QShowEvent *showEvent)
{
	//ignore spontaneous show events (come from iconified)
	if (showEvent->spontaneous())
		return;

	//get a pointer to the widget with the tab bar (we need this for disabling other tabs while generating)
	topParent =	(ScapeMakerDialog*)(parentWidget()->parentWidget()->parentWidget()->parentWidget());

	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//hide tool in bitmapnav
	bitmapNavContainer->setPenButtonVisible(false);
	bitmapNavContainer->setRubberButtonVisible(false);

	//prepare sliders
	sunDirectionSlider->setProperties(CoolSlider::LINEAR,tr("Direction"),0,360,"�",1);
	timeSlider->setProperties(CoolSlider::LINEAR,tr("Time"),0,23,":00",1);
	fogSlider->setProperties(CoolSlider::LINEAR,tr("Height"),0,3000,"m",2);
	fogDensitySlider->setProperties(CoolSlider::LINEAR,tr("Density"),0,100,"%",1);
	dustSlider->setProperties(CoolSlider::LINEAR,tr("Distance"),0,200,"%",2);

	//set currentSkyColors to right values
	timeValueChanged();

	//dont recalculate during initialising
	dontRecalculate = true;

	//set default values for sliders first
	sunDirectionSlider->setValue(0,45);
	timeSlider->setValue(0,16);
	fogSlider->setValue(0,400);
	fogSlider->setValue(1,1000);
	fogDensitySlider->setValue(0,0);
	dustSlider->setValue(0,50);
	dustSlider->setValue(1,100);
	fastShadow->setChecked(false);
	ignoreObjects->setChecked(false);
	calcSegment->setChecked(false);
	segmentBegin->setMinValue(0);
	segmentBegin->setMaxValue(10000);
	segmentBegin->setValue(0);
	segmentEnd->setMinValue(0);
	segmentEnd->setMaxValue(10000);
	segmentEnd->setValue(10000);
	
	int r, g, b;

	//load all settings from text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/enviroment.txt",MiniXML::READ))
	{
		int value;
		bool bValue;

		if (xmlFile.readInteger("fogLowerLayer",&value))
			fogSlider->setValue(0,value);
		
		if (xmlFile.readInteger("fogHigherLayer",&value))
			fogSlider->setValue(1,value);

		if (xmlFile.readInteger("fogDensity",&value))
			fogDensitySlider->setValue(0,value);

		if (xmlFile.readInteger("dustStart",&value))
			dustSlider->setValue(0,value);

		if (xmlFile.readInteger("dustEnd",&value))
			dustSlider->setValue(1,value);

		if (xmlFile.readInteger("sunDirection",&value))
			sunDirectionSlider->setValue(0,value);

		if (xmlFile.readBoolean("ignoreObjects",&bValue))
			ignoreObjects->setChecked(bValue);

		if (xmlFile.readBoolean("fastShadow",&bValue))
			fastShadow->setChecked(bValue);

		if (xmlFile.readBoolean("calcSegment",&bValue))
			calcSegment->setChecked(bValue);

		if (xmlFile.readInteger("segmentBegin",&value))
			segmentBegin->setValue(value);

		if (xmlFile.readInteger("segmentEnd",&value))
			segmentEnd->setValue(value);

		if (xmlFile.readInteger("time",&value))
			timeSlider->setValue(0,value);

		if (xmlFile.readInteger("rFrom",&value))
			r = value;
		if (xmlFile.readInteger("gFrom",&value))
			g = value;
		if (xmlFile.readInteger("bFrom",&value))
			b = value;
		currentSkyColors.from.setRgb(r, g, b);

		if (xmlFile.readInteger("rTo",&value))
			r = value;
		if (xmlFile.readInteger("gTo",&value))
			g = value;
		if (xmlFile.readInteger("bTo",&value))
			b = value;
		currentSkyColors.to.setRgb(r, g, b);

		if (xmlFile.readInteger("rAmbient",&value))
			r = value;
		if (xmlFile.readInteger("gAmbient",&value))
			g = value;
		if (xmlFile.readInteger("bAmbient",&value))
			b = value;
		currentSkyColors.ambient.setRgb(r, g, b);

		if (xmlFile.readInteger("rDiffuse",&value))
			r = value;
		if (xmlFile.readInteger("gDiffuse",&value))
			g = value;
		if (xmlFile.readInteger("bDiffuse",&value))
			b = value;
		currentSkyColors.diffuse.setRgb(r, g, b);

		xmlFile.closeFile();
	}

	// set the color buttons
	fillColorButton(colorFromButton,currentSkyColors.from.rgb());
	fillColorButton(colorToButton,currentSkyColors.to.rgb());
	fillColorButton(colorAmbientButton,currentSkyColors.ambient.rgb());
	fillColorButton(colorDiffuseButton,currentSkyColors.diffuse.rgb());

	//load the heightmap file from project
	if (!hMapBitmap.Load(projectPath+"/engine/heightmap.png"))
	{
		//if file not exist, create a new bitmap
		hMapBitmap.Create(256,256,24);
		//save the heightmap in project (we need a heightmap!)
		hMapBitmap.Save(projectPath+"/engine/heightmap.png",CXIMAGE_FORMAT_PNG);
	}

	//create terrain class
	QString enginePath = projectPath+"/engine/";
	char *enginePath2 = new char[enginePath.length()+1];
	strcpy(enginePath2,enginePath.latin1());
	pTerrain = new Terrain();
	pTerrain->createGeometryForShadowGen(enginePath2);

	//create preview bitmap
	previewBitmap.Create(hMapBitmap.GetWidth(),hMapBitmap.GetHeight(),24);
	previewBitmap.AlphaCreate();

	//show the heightmap in bitmapNav
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));

	//correct segment values
	//get number of texture tiles
	textureTilesPerSide = hMapBitmap.GetWidth()/32;
	int textureTileCount = textureTilesPerSide*textureTilesPerSide;
	segmentBegin->setMaxValue(textureTileCount-1);
	if (segmentBegin->value() >= textureTileCount)
		segmentBegin->setValue(textureTileCount-1);
	segmentEnd->setMaxValue(textureTileCount-1);
	if (segmentEnd->value() >= textureTileCount)
		segmentEnd->setValue(textureTileCount-1);

	//now recalculate again
	dontRecalculate = false;

	//update progress bar
	generatingProgress = 0;
	progressBar->setProgress(generatingProgress);

	//create first shadow preview
	createShadowPreview();

	//disable fog
	heightBasedFogEnabled = true;
	
	//get it from config file
	if (xmlFile.openFile("./enginefiles/config.txt",MiniXML::READ))
	{
		bool bValue;

		if (xmlFile.readBoolean("heightBasedFog",&bValue))
			heightBasedFogEnabled = bValue;

		xmlFile.closeFile();
	}

	//disable these groups
	heightBasedGroup->setEnabled(heightBasedFogEnabled);

	//set export mode
	filterExpertFunctions();
}

/****************************************************************************
** EnviromentGUI hideEvent
**
** Is called, when the EnviromentGUI will be hide.
** Save everything for this panel!
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::hideEvent(QHideEvent *hideEvent)
{
	//save the properties of sliders
	saveValues();

	//ignore hide events with minimizing
	if (!topParent->isMinimized())
	{
		//wait till shadow generation is done
		shadowGen.cancel();
		while (shadowGen.running()) 
		{
			Sleep(100);
		}

		//delete terrain-class
		pTerrain->destroyGeometryForShadowGen();
		SAFE_DELETE(pTerrain);
	}

	//delete default sky colors
	SAFE_DELETE_ARRAY(defaultSkyColors);
}


/****************************************************************************
** EnviromentGUI setProjectPath
**
** set the current project
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}


/****************************************************************************
** EnviromentGUI shadowValuesChanged
**
** Is called, when a value of the shadow group changed
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::shadowValuesChanged()
{
	//generate the distribution
	if (!dontRecalculate)
		createShadowPreview();
}

/****************************************************************************
** EnviromentGUI generateClicked
**
** Is called, when the generate button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::generateClicked()
{
	//reset the generatingProgress
	generatingProgress = 0;
	progressBar->reset();

	//prepare the preview image
	currentBitmap = CxImage(hMapBitmap);
	currentBitmap.IncreaseBpp(24);

	//save the properties of sliders in engine-directory
	saveValues();

	//retrieve segment to calculate
	generateButton->setFocus();
	int sBegin = 0;
	int sEnd = (textureTilesPerSide*textureTilesPerSide)-1;
	if (calcSegment->isChecked())
	{
		sBegin = segmentBegin->value();
		sEnd = segmentEnd->value();
	}
	else
	{
		segmentBegin->setValue(sBegin);
		segmentEnd->setValue(sEnd);
	}

	//start the generation thread
	shadowGen.generate(
		topParent->winId(),
		pTerrain,
		&generatingProgress,
		&generatingCurrentTextureTile,
		&currentBitmap,
		projectPath+"/engine/",
		projectPath+"/engine/textures/",
		ignoreObjects->isChecked(),
		fastShadow->isChecked(),
		sBegin,
		sEnd);

	//hide the generatebutton and show the cancelbutton
	generateButton->hide();
	cancelButton->show();

	//disable all tabs except the own
	enableTabs(false);

	heightBasedGroup->setEnabled(false);
	dustGroup->setEnabled(false);
	timeSlider->setEnabled(false);
	colorFromButton->setEnabled(false);
	colorToButton->setEnabled(false);
	colorDiffuseButton->setEnabled(false);
	colorAmbientButton->setEnabled(false);
	TextLabel1->setEnabled(false);
	sunDirectionSlider->setEnabled(false);
	optionsGroup->setEnabled(false);

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//start timer for updating the image and progressbar
	generatingShadowTimerID = startTimer(1000);
}

/****************************************************************************
** EnviromentGUI cancelClicked
**
** Is called, when the cancel-Button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::cancelClicked()
{
	//stop the generating-thread
	shadowGen.cancel();

	//delete timer
	killTimer(generatingShadowTimerID);
	generatingShadowTimerID = -1;

	//update the image
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));

	//update the progressbar
	progressBar->setProgress(generatingProgress);

	//update segment begin
	segmentBegin->setValue(generatingCurrentTextureTile);

	//hide the cancelbutton and show the generatebutton
	cancelButton->hide();
	generateButton->show();

	//enable all tabs except the own
	enableTabs(true);

	heightBasedGroup->setEnabled(heightBasedFogEnabled);
	dustGroup->setEnabled(true);
	timeSlider->setEnabled(true);
	colorFromButton->setEnabled(true);
	colorToButton->setEnabled(true);
	colorDiffuseButton->setEnabled(true);
	colorAmbientButton->setEnabled(true);
	TextLabel1->setEnabled(true);
	sunDirectionSlider->setEnabled(true);
	optionsGroup->setEnabled(true);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();
}

/****************************************************************************
** EnviromentGUI createCurrentBitmap
**
** create the bitmap and put it in bitmapNav
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::createCurrentBitmap()
{
	//copy the heightmap as nice background
	currentBitmap = CxImage(hMapBitmap);
	currentBitmap.IncreaseBpp(24);

	//add the distribution
	for(DWORD y=0;y<currentBitmap.GetHeight();y++)
		for (DWORD x=0;x<currentBitmap.GetWidth();x++)
	{
		//get the color on the background
		RGBQUAD background = currentBitmap.GetPixelColor(x,y);
			
		//get the color on the shadow
		RGBQUAD distribution = previewBitmap.GetPixelColor(x,y);
		
		//calculate factor
		float blendFactor = float(distribution.rgbReserved)/255.0f;
		float blendFactorInv = 1.0f-blendFactor;
		
		//calculate new color
		RGBQUAD newColor;
		newColor.rgbRed = blendFactor*distribution.rgbRed+blendFactorInv*background.rgbRed;
		newColor.rgbGreen = blendFactor*distribution.rgbGreen+blendFactorInv*background.rgbGreen;
		newColor.rgbBlue = blendFactor*distribution.rgbBlue+blendFactorInv*background.rgbBlue;
		
		//set new color
		currentBitmap.SetPixelColor(x,y,newColor);
	}

	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));
}

/****************************************************************************
** EnviromentGUI createShadowPreview
**
** create shadow preview
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::createShadowPreview()
{
	//delete old timer
	if (generatingShadowPreviewTimer)
	{
		killTimer(generatingShadowPreviewTimerID);
		
		//stop old preview calculating
		shadowGen.cancel();
	}

	//disable tabs
	enableTabs(false);

	shadowGen.generatePreview(pTerrain,&previewBitmap,calculateSunPos());

	generatingShadowPreviewTimerID = startTimer(100);
	generatingShadowPreviewTimer = true;
}

/****************************************************************************
** EnviromentGUI timerEvent
**
** Is called, at timer event
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::timerEvent(QTimerEvent *timerEvent)
{
	//only its our shadow preview timer
	if (timerEvent->timerId() == generatingShadowPreviewTimerID)
	{
		//generating done?
		if (!shadowGen.running())
		{
			//delete timer
			killTimer(generatingShadowPreviewTimerID);
			generatingShadowPreviewTimerID = -1;
			generatingShadowPreviewTimer = false;
			//create the current bitmap for bitmapNav
			createCurrentBitmap();

			//enable tabs
			enableTabs(true);
		}
	}
	//its the real shadow generation
	else if (timerEvent->timerId() == generatingShadowTimerID)
	{
		//update the image
		bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));

		//update the progressbar
		progressBar->setProgress(generatingProgress);

		//update segment begin
		segmentBegin->setValue(generatingCurrentTextureTile);

		//generating done?
		if (!shadowGen.running())
		{
			//use cancelClicked for doing the work
			cancelClicked();
		}
	}
}

/****************************************************************************
** EnviromentGUI calculateSunPos
**
** calculate the position of sun from current parameters
**
** Author: Dirk Plate
****************************************************************************/
D3DXVECTOR3 EnviromentGUI::calculateSunPos()
{
	float radius = 10000.0f;
	float alpha = D3DXToRadian(sunDirectionSlider->getValue(0));
	float beta = D3DXToRadian(90-((timeSlider->getValue(0)-6)*360)/24);

	D3DXVECTOR3 position = D3DXVECTOR3(radius*sinf(beta)*cosf(alpha),
					                   radius*cosf(beta),
					                   radius*sinf(beta)*sinf(alpha));

	//move middle of sphere to middle of landscape
	position.x += hMapBitmap.GetWidth()/2;
	position.z += hMapBitmap.GetHeight()/2;

	return position;
}

/****************************************************************************
** EnviromentGUI saveValues
**
** save the values of all sliders
**
** Author: Dirk Plate
****************************************************************************/
void EnviromentGUI::saveValues()
{
	//save the settings to the text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/enviroment.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("sunDirection",sunDirectionSlider->getValue(0));
		xmlFile.writeBoolean("ignoreObjects",ignoreObjects->isChecked());
		xmlFile.writeBoolean("fastShadow",fastShadow->isChecked());
		xmlFile.writeBoolean("calcSegment",calcSegment->isChecked());
		xmlFile.writeInteger("segmentBegin",segmentBegin->value());
		xmlFile.writeInteger("segmentEnd",segmentEnd->value());
		xmlFile.writeInteger("time",timeSlider->getValue(0));
		xmlFile.writeInteger("rFrom",currentSkyColors.from.red());
		xmlFile.writeInteger("gFrom",currentSkyColors.from.green());
		xmlFile.writeInteger("bFrom",currentSkyColors.from.blue());
		xmlFile.writeInteger("rTo",currentSkyColors.to.red());
		xmlFile.writeInteger("gTo",currentSkyColors.to.green());
		xmlFile.writeInteger("bTo",currentSkyColors.to.blue());
		xmlFile.writeInteger("rAmbient",currentSkyColors.ambient.red());
		xmlFile.writeInteger("gAmbient",currentSkyColors.ambient.green());
		xmlFile.writeInteger("bAmbient",currentSkyColors.ambient.blue());
		xmlFile.writeInteger("rDiffuse",currentSkyColors.diffuse.red());
		xmlFile.writeInteger("gDiffuse",currentSkyColors.diffuse.green());
		xmlFile.writeInteger("bDiffuse",currentSkyColors.diffuse.blue());
		xmlFile.writeInteger("fogLowerLayer",fogSlider->getValue(0));
		xmlFile.writeInteger("fogHigherLayer",fogSlider->getValue(1));
		xmlFile.writeInteger("fogDensity",fogDensitySlider->getValue(0));
		xmlFile.writeInteger("dustStart",dustSlider->getValue(0));
		xmlFile.writeInteger("dustEnd",dustSlider->getValue(1));

		xmlFile.closeFile();
	}

	//save the properties of the sun in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/sky.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("sunDirection",sunDirectionSlider->getValue(0));
		xmlFile.writeInteger("time",timeSlider->getValue(0));
		xmlFile.writeInteger("rFrom",currentSkyColors.from.red());
		xmlFile.writeInteger("gFrom",currentSkyColors.from.green());
		xmlFile.writeInteger("bFrom",currentSkyColors.from.blue());
		xmlFile.writeInteger("rTo",currentSkyColors.to.red());
		xmlFile.writeInteger("gTo",currentSkyColors.to.green());
		xmlFile.writeInteger("bTo",currentSkyColors.to.blue());
		xmlFile.writeInteger("rAmbient",currentSkyColors.ambient.red());
		xmlFile.writeInteger("gAmbient",currentSkyColors.ambient.green());
		xmlFile.writeInteger("bAmbient",currentSkyColors.ambient.blue());
		xmlFile.writeInteger("rDiffuse",currentSkyColors.diffuse.red());
		xmlFile.writeInteger("gDiffuse",currentSkyColors.diffuse.green());
		xmlFile.writeInteger("bDiffuse",currentSkyColors.diffuse.blue());

		xmlFile.closeFile();
	}

	//save the properties of the fog in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/heightbasedfog.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("lowerLayer",fogSlider->getValue(0));
		xmlFile.writeInteger("higherLayer",fogSlider->getValue(1));
		xmlFile.writeInteger("density",fogDensitySlider->getValue(0));
			
		xmlFile.closeFile();
	}

	//save the properties of the dust in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/dust.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("start",dustSlider->getValue(0));
		xmlFile.writeInteger("end",dustSlider->getValue(1));
			
		xmlFile.closeFile();
	}
}

/****************************************************************************
** EnviromentGUI timeValueChanged
**
** Is called, when the time is changed
**
** Author: Matthias Buchetics / Dirk Plate
****************************************************************************/

void EnviromentGUI::timeValueChanged()
{
	// don't change colors if only switched to the panel
	// only change, if user changed the slider
	if(dontRecalculate)	return;

	//if default values not loaded -> load them
	if (defaultSkyColors == NULL)
	{
		defaultSkyColors = new SkyColorsStruct[24];
		
		int r, g, b;
		int value;
		QString skyColorsPath = "./guifiles/sky.txt";
		MiniXML xmlFile;
		if (xmlFile.openFile(skyColorsPath,MiniXML::READ))
		{
			if (xmlFile.startReadList("skycolors"))
			{
				for (int i=0;i<24;i++)
				{
					if (xmlFile.startReadListElement(i))
					{
						if (xmlFile.readInteger("rFrom",&value))
							r = value;
						if (xmlFile.readInteger("gFrom",&value))
							g = value;
						if (xmlFile.readInteger("bFrom",&value))
							b = value;
						defaultSkyColors[i].from.setRgb(r, g, b);
						
						if (xmlFile.readInteger("rTo",&value))
							r = value;
						if (xmlFile.readInteger("gTo",&value))
							g = value;
						if (xmlFile.readInteger("bTo",&value))
							b = value;
						defaultSkyColors[i].to.setRgb(r, g, b);
						
						if (xmlFile.readInteger("rAmbient",&value))
							r = value;
						if (xmlFile.readInteger("gAmbient",&value))
							g = value;
						if (xmlFile.readInteger("bAmbient",&value))
							b = value;
						defaultSkyColors[i].ambient.setRgb(r, g, b);
						
						if (xmlFile.readInteger("rDiffuse",&value))
							r = value;
						if (xmlFile.readInteger("gDiffuse",&value))
							g = value;
						if (xmlFile.readInteger("bDiffuse",&value))
							b = value;
						defaultSkyColors[i].diffuse.setRgb(r, g, b);
						
						xmlFile.endReadListElement();
					}
				}
				xmlFile.endReadList();
			}
			xmlFile.closeFile();
		}
	}

	//set current color to right value
	int time = timeSlider->getValue(0);

	currentSkyColors = defaultSkyColors[time];

	//fill buttons with right color
	fillColorButton(colorFromButton,currentSkyColors.from.rgb());
	fillColorButton(colorToButton,currentSkyColors.to.rgb());
	fillColorButton(colorAmbientButton,currentSkyColors.ambient.rgb());
	fillColorButton(colorDiffuseButton,currentSkyColors.diffuse.rgb());

}

/****************************************************************************
** EnviromentGUI colorFromClicked
**
** called when the color button is clicked -> show color dialog
**
** Author: Matthias Buchetics
****************************************************************************/

void EnviromentGUI::colorFromClicked()
{
	QColor newColor = QColorDialog::getColor(currentSkyColors.from,this,tr("ScapeMaker"));
	if (newColor.isValid())
	{
		currentSkyColors.from = newColor;
		fillColorButton(colorFromButton,currentSkyColors.from.rgb());
	}
}

/****************************************************************************
** EnviromentGUI colorToClicked
**
** called when the color button is clicked -> show color dialog
**
** Author: Matthias Buchetics
****************************************************************************/

void EnviromentGUI::colorToClicked()
{
	QColor newColor = QColorDialog::getColor(currentSkyColors.to,this,tr("ScapeMaker"));
	if (newColor.isValid())
	{
		currentSkyColors.to = newColor;
		fillColorButton(colorToButton,currentSkyColors.to.rgb());
	}
}

/****************************************************************************
** EnviromentGUI colorAmbientClicked
**
** called when the color button is clicked -> show color dialog
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::colorAmbientClicked()
{
	QColor newColor = QColorDialog::getColor(currentSkyColors.ambient,this,tr("ScapeMaker"));
	if (newColor.isValid())
	{
		currentSkyColors.ambient = newColor;
		fillColorButton(colorAmbientButton, currentSkyColors.ambient.rgb());
	}
}

/****************************************************************************
** EnviromentGUI colorDiffuseClicked
**
** called when the color button is clicked -> show color dialog
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::colorDiffuseClicked()
{
	QColor newColor = QColorDialog::getColor(currentSkyColors.diffuse,this,tr("ScapeMaker"));
	if (newColor.isValid())
	{
		currentSkyColors.diffuse = newColor;
		fillColorButton(colorDiffuseButton, currentSkyColors.diffuse.rgb());
	}
}

/****************************************************************************
** EnvironmentGUI segmentBeginChanged
**
** called if segmentBegin is changed
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::segmentBeginChanged(int newValue)
{
	if (segmentEnd->value() < newValue)
		segmentEnd->setValue(newValue);
}

/****************************************************************************
** EnvironmentGUI segmentEndChanged
**
** called if segmentEnd is changed
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::segmentEndChanged(int newValue)
{
	if (segmentBegin->value() > newValue)
		segmentBegin->setValue(newValue);
}

/****************************************************************************
** EnvironmentGUI exportClicked
**
** called if export button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::exportClicked()
{
	//open terrain texture export dialog
	TextureExportGUI dialog(this, "textureExportGUI", true, WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu | WStyle_ContextHelp,
		projectPath+"/engine/textures/", textureTilesPerSide,1);
	dialog.show();

}

/****************************************************************************
** EnvironmentGUI fillColorButton
**
** fill a color button with the specified color
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::fillColorButton(QButton *button, QRgb color)
{
	QPixmap backBuffer(button->size());
	QPainter painter(&backBuffer);

	//draw
	painter.setBrush(color);
	painter.fillRect(button->rect(),painter.brush());

	//set backbuffer
	button->setPixmap(backBuffer);
}

/****************************************************************************
** EnvironmentGUI enableTabs
**
** en or disable the tabs
**
** Author: Dirk Plate
****************************************************************************/

void EnviromentGUI::enableTabs(bool enable)
{
	topParent->tabContainer->setTabEnabled(topParent->topografie, enable);
	topParent->tabContainer->setTabEnabled(topParent->texture, enable);
	topParent->tabContainer->setTabEnabled(topParent->objects, enable);
	topParent->tabContainer->setTabEnabled(topParent->clouds, enable);
	topParent->tabContainer->setTabEnabled(topParent->water, enable);
	topParent->tabContainer->setTabEnabled(topParent->preview, enable);
	topParent->menuBar->setEnabled(enable);
}

/****************************************************************************
** EnviromentGUI filterExpertFunctions
**
** Hides or show all sliders for expert or beginner mode
**  
** Author: Dirk Plate
****************************************************************************/
void EnviromentGUI::filterExpertFunctions()
{
	//load settings from file
	MiniXML xmlFile;
	bool loadedExpert = false;
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		bool bValue;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}	

	//set visibility for all functions
	if (!loadedExpert)
	{
		dustGroup->hide();
		calcSegment->hide();
		segmentBegin->hide();
		segmentArrow->hide();
		segmentEnd->hide();
		exportButton->hide();
	}
	else
	{
		dustGroup->show();
		calcSegment->show();
		segmentBegin->show();
		segmentArrow->show();
		segmentEnd->show();
		exportButton->show();
	}
}