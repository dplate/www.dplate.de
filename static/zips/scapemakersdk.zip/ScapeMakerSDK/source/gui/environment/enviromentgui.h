/****************************************************************************
** EnviromentGUI
**
** the enviroment-tab window
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "enviromentguibase.h"
#include "../common/coolslider.h"
#include "../scapemakerdialog.h"
#include "../../common/minixml.h"
#include "../common/bitmapnav.h"
#include "qpushbutton.h"
#include "shadowgen.h"
#include "../../engine/terrain/terrain.h"
#include "qprogressbar.h"
#include "qtabwidget.h"
#include "qcheckbox.h"
#include "qgroupbox.h"
#include "qcolordialog.h"
#include "qspinbox.h"
#include "../common/textureexportgui.h"
#include "../common/guihelpers.h"

class EnviromentGUI : public EnviromentGUIBase
{
	Q_OBJECT

public:
	EnviromentGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setProjectPath(QString projectPathSet);

public slots:
	virtual void shadowValuesChanged();
	virtual void generateClicked();
	virtual void cancelClicked();
	virtual void timeValueChanged();
	virtual void colorFromClicked();
	virtual void colorToClicked();
	virtual void colorAmbientClicked();
	virtual void colorDiffuseClicked();
	virtual void segmentBeginChanged(int newValue);
	virtual void segmentEndChanged(int newValue);
	virtual void exportClicked();

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);

private:
	void filterExpertFunctions();
	void createCurrentBitmap();
	void createShadowPreview();
	D3DXVECTOR3 calculateSunPos();//calculate the position of sun from current parameters
	void saveValues();				//save the values of all sliders
	void fillColorButton(QButton *button, QRgb color);//fill a color button with the specified color
	void enableTabs(bool enable);	//en or disable the tabs

	QString projectPath;			//the path to the project-directory
	ScapeMakerDialog *topParent;	//direct pointer to main window

	CxImage hMapBitmap;				//the heightmap
	CxImage previewBitmap;			//the preview of the current settings
	CxImage currentBitmap;			//this bitmap will be shown in bitmapNav
	int textureTilesPerSide;		//how many texture tiles to calculate

	bool dontRecalculate;			//is this flag set, the shadow preview wont recalculate
	ShadowGen shadowGen;			//the shadow-generator
	Terrain *pTerrain;				//the terrain class

	bool generatingShadowPreviewTimer;	//shadow preview timer on or not
	int generatingShadowPreviewTimerID;	//the id of the timer while generating the shadow preview
	int generatingShadowTimerID;		//the id of the timer while generating the shadow
	int generatingProgress;				//the progress of generating
	int generatingCurrentTextureTile;	//current generating texture tile

	struct SkyColorsStruct
	{
		QColor from;				// color for the skydome
		QColor to;					// color for the skydome
		QColor ambient;				// color for the light
		QColor diffuse;
	};
	SkyColorsStruct currentSkyColors; //the current choosen colors
	SkyColorsStruct *defaultSkyColors;//the default sky colors

	bool heightBasedFogEnabled;		//the settings from config.txt
};
