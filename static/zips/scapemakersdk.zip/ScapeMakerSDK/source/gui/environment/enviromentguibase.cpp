/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\environment\enviromentguibase.ui'
**
** Created: Sun Feb 13 15:03:32 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "enviromentguibase.h"

#include <qcheckbox.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qprogressbar.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a EnviromentGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
EnviromentGUIBase::EnviromentGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "EnviromentGUIBase" );
    resize( 511, 501 ); 
    setCaption( tr( "EnviromentGUI" ) );

    shadowGroup = new QGroupBox( this, "shadowGroup" );
    shadowGroup->setGeometry( QRect( 0, 265, 500, 190 ) ); 
    shadowGroup->setTitle( tr( "Sky, sun and shadow" ) );

    progressBar = new QProgressBar( shadowGroup, "progressBar" );
    progressBar->setGeometry( QRect( 110, 160, 380, 21 ) ); 
    progressBar->setFrameShape( QProgressBar::Box );
    progressBar->setFrameShadow( QProgressBar::Sunken );
    progressBar->setCenterIndicator( TRUE );

    cancelButton = new QPushButton( shadowGroup, "cancelButton" );
    cancelButton->setGeometry( QRect( 8, 160, 95, 23 ) ); 
    cancelButton->setCaption( tr( "" ) );
    cancelButton->setText( tr( "Cancel" ) );
    cancelButton->setFlat( FALSE );
    QToolTip::add(  cancelButton, tr( "Cancel generating lightmaps" ) );

    TextLabel1 = new QLabel( shadowGroup, "TextLabel1" );
    TextLabel1->setGeometry( QRect( 80, 95, 20, 25 ) ); 
    TextLabel1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, TextLabel1->sizePolicy().hasHeightForWidth() ) );
    TextLabel1->setText( tr( "-->" ) );
    TextLabel1->setScaledContents( FALSE );

    timeSlider = new CoolSlider( shadowGroup, "timeSlider" );
    timeSlider->setGeometry( QRect( 10, 20, 150, 65 ) ); 
    QWhatsThis::add(  timeSlider, tr( "Sets the time of day (and so the height of the sun). It also changes the colors of light and sky." ) );

    colorToButton = new QPushButton( shadowGroup, "colorToButton" );
    colorToButton->setGeometry( QRect( 100, 95, 61, 25 ) ); 
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 243, 243, 243) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setDisabled( cg );
    colorToButton->setPalette( pal );
    colorToButton->setText( tr( "" ) );
    colorToButton->setFlat( TRUE );
    QToolTip::add(  colorToButton, tr( "Second color of sky" ) );
    QWhatsThis::add(  colorToButton, tr( "The main color of of the sky. A click changes the color." ) );

    colorAmbientButton = new QPushButton( shadowGroup, "colorAmbientButton" );
    colorAmbientButton->setGeometry( QRect( 10, 125, 61, 25 ) ); 
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 243, 243, 243) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setDisabled( cg );
    colorAmbientButton->setPalette( pal );
    colorAmbientButton->setText( tr( "" ) );
    colorAmbientButton->setFlat( TRUE );
    QToolTip::add(  colorAmbientButton, tr( "Ambient light color" ) );
    QWhatsThis::add(  colorAmbientButton, tr( "The color of the shadows. A click changes the color." ) );

    colorDiffuseButton = new QPushButton( shadowGroup, "colorDiffuseButton" );
    colorDiffuseButton->setGeometry( QRect( 100, 125, 61, 25 ) ); 
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 243, 243, 243) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setDisabled( cg );
    colorDiffuseButton->setPalette( pal );
    colorDiffuseButton->setText( tr( "" ) );
    colorDiffuseButton->setFlat( TRUE );
    QToolTip::add(  colorDiffuseButton, tr( "Diffuse light color" ) );
    QWhatsThis::add(  colorDiffuseButton, tr( "The color of the sunlight. A click changes the color." ) );

    sunDirectionSlider = new CoolSlider( shadowGroup, "sunDirectionSlider" );
    sunDirectionSlider->setGeometry( QRect( 170, 20, 165, 130 ) ); 
    QWhatsThis::add(  sunDirectionSlider, tr( "Defines the direction of the sun. That is, where the sun rises and sets." ) );

    optionsGroup = new QGroupBox( shadowGroup, "optionsGroup" );
    optionsGroup->setGeometry( QRect( 345, 15, 145, 135 ) ); 
    optionsGroup->setTitle( tr( "Options" ) );

    segmentArrow = new QLabel( optionsGroup, "segmentArrow" );
    segmentArrow->setEnabled( FALSE );
    segmentArrow->setGeometry( QRect( 65, 80, 16, 16 ) ); 
    segmentArrow->setText( tr( "-->" ) );
    segmentArrow->setAlignment( int( QLabel::AlignCenter ) );

    fastShadow = new QCheckBox( optionsGroup, "fastShadow" );
    fastShadow->setGeometry( QRect( 10, 35, 125, 20 ) ); 
    fastShadow->setText( tr( "Fast shadow" ) );
    fastShadow->setChecked( FALSE );
    QWhatsThis::add(  fastShadow, tr( "Activates a faster way of calculating shadows, which looks much worse than the normal mode." ) );

    calcSegment = new QCheckBox( optionsGroup, "calcSegment" );
    calcSegment->setGeometry( QRect( 10, 55, 125, 20 ) ); 
    calcSegment->setText( tr( "Calculate segment" ) );
    calcSegment->setChecked( FALSE );
    QWhatsThis::add(  calcSegment, tr( "Allows to only render shadows for defined parts of the landscape. If this is not ticked, shadows for the whole landscape are generated" ) );

    segmentBegin = new QSpinBox( optionsGroup, "segmentBegin" );
    segmentBegin->setEnabled( FALSE );
    segmentBegin->setGeometry( QRect( 10, 80, 50, 20 ) ); 
    QWhatsThis::add(  segmentBegin, tr( "Sets the first tile for which shadows are to be generated." ) );

    segmentEnd = new QSpinBox( optionsGroup, "segmentEnd" );
    segmentEnd->setEnabled( FALSE );
    segmentEnd->setGeometry( QRect( 85, 80, 50, 20 ) ); 
    QWhatsThis::add(  segmentEnd, tr( "Sets the last tile for which shadows are to be generated." ) );

    exportButton = new QPushButton( optionsGroup, "exportButton" );
    exportButton->setGeometry( QRect( 10, 105, 95, 23 ) ); 
    exportButton->setText( tr( "Export texture" ) );
    exportButton->setFlat( FALSE );
    QToolTip::add(  exportButton, tr( "Export terrain texture" ) );
    QWhatsThis::add(  exportButton, tr( "Opens the texture export dialog. There the generated ground textures can be exported as a single image file." ) );

    ignoreObjects = new QCheckBox( optionsGroup, "ignoreObjects" );
    ignoreObjects->setGeometry( QRect( 10, 15, 125, 20 ) ); 
    ignoreObjects->setText( tr( "Ignore objects" ) );
    QWhatsThis::add(  ignoreObjects, tr( "If activated, objects don't cast shadows. Speeds up the generation process." ) );

    generateButton = new QPushButton( shadowGroup, "generateButton" );
    generateButton->setGeometry( QRect( 8, 160, 95, 23 ) ); 
    generateButton->setText( tr( "Generate" ) );
    generateButton->setFlat( FALSE );
    QToolTip::add(  generateButton, tr( "Start generating lightmaps" ) );
    QWhatsThis::add(  generateButton, tr( "Generates shadows." ) );

    colorFromButton = new QPushButton( shadowGroup, "colorFromButton" );
    colorFromButton->setGeometry( QRect( 10, 95, 61, 25 ) ); 
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 243, 243, 243) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setDisabled( cg );
    colorFromButton->setPalette( pal );
    colorFromButton->setText( tr( "" ) );
    colorFromButton->setFlat( TRUE );
    QToolTip::add(  colorFromButton, tr( "First color of sky" ) );
    QWhatsThis::add(  colorFromButton, tr( "The color of the sky at the horizon. A click changes the color. This is also the color of the heightbased fog, als well as dust/haze." ) );

    heightBasedGroup = new QGroupBox( this, "heightBasedGroup" );
    heightBasedGroup->setGeometry( QRect( 0, 0, 205, 155 ) ); 
    heightBasedGroup->setTitle( tr( "Height based fog" ) );

    fogSlider = new CoolSlider( heightBasedGroup, "fogSlider" );
    fogSlider->setGeometry( QRect( 10, 20, 185, 55 ) ); 
    QWhatsThis::add(  fogSlider, tr( "Defines the range of height for the height based fog. Only inside this range, fog occurs." ) );

    fogDensitySlider = new CoolSlider( heightBasedGroup, "fogDensitySlider" );
    fogDensitySlider->setGeometry( QRect( 10, 85, 185, 60 ) ); 
    QWhatsThis::add(  fogDensitySlider, tr( "Sets the density of the height based fog. If set to 0, no fog appears at all." ) );

    dustGroup = new QGroupBox( this, "dustGroup" );
    dustGroup->setGeometry( QRect( 0, 160, 205, 100 ) ); 
    dustGroup->setTitle( tr( "Dust" ) );

    dustSlider = new CoolSlider( dustGroup, "dustSlider" );
    dustSlider->setGeometry( QRect( 10, 20, 185, 70 ) ); 
    QWhatsThis::add(  dustSlider, tr( "Sets the haze of landscape. The left slider defines the beginning ot the haze, the right slider the end. This also affects the visible distance, so you will get a higher performance in 3d mode with small values of the right slider." ) );

    bitmapNavContainer = new BitmapNav( this, "bitmapNavContainer" );
    bitmapNavContainer->setGeometry( QRect( 210, 0, 290, 260 ) ); 
    QWhatsThis::add(  bitmapNavContainer, tr( "Shows a preview of the shadows. Areas that lie in shadow are shown in red." ) );

    // signals and slots connections
    connect( sunDirectionSlider, SIGNAL( valuesChanged() ), this, SLOT( shadowValuesChanged() ) );
    connect( generateButton, SIGNAL( clicked() ), this, SLOT( generateClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( colorFromButton, SIGNAL( clicked() ), this, SLOT( colorFromClicked() ) );
    connect( colorToButton, SIGNAL( clicked() ), this, SLOT( colorToClicked() ) );
    connect( timeSlider, SIGNAL( valuesChanged() ), this, SLOT( shadowValuesChanged() ) );
    connect( timeSlider, SIGNAL( valuesChanged() ), this, SLOT( timeValueChanged() ) );
    connect( colorAmbientButton, SIGNAL( clicked() ), this, SLOT( colorAmbientClicked() ) );
    connect( colorDiffuseButton, SIGNAL( clicked() ), this, SLOT( colorDiffuseClicked() ) );
    connect( calcSegment, SIGNAL( toggled(bool) ), segmentBegin, SLOT( setEnabled(bool) ) );
    connect( calcSegment, SIGNAL( toggled(bool) ), segmentArrow, SLOT( setEnabled(bool) ) );
    connect( calcSegment, SIGNAL( toggled(bool) ), segmentEnd, SLOT( setEnabled(bool) ) );
    connect( segmentBegin, SIGNAL( valueChanged(int) ), this, SLOT( segmentBeginChanged(int) ) );
    connect( segmentEnd, SIGNAL( valueChanged(int) ), this, SLOT( segmentEndChanged(int) ) );
    connect( exportButton, SIGNAL( clicked() ), this, SLOT( exportClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
EnviromentGUIBase::~EnviromentGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

void EnviromentGUIBase::cancelClicked()
{
    qWarning( "EnviromentGUIBase::cancelClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::colorAmbientClicked()
{
    qWarning( "EnviromentGUIBase::colorAmbientClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::colorDiffuseClicked()
{
    qWarning( "EnviromentGUIBase::colorDiffuseClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::colorFromClicked()
{
    qWarning( "EnviromentGUIBase::colorFromClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::colorToClicked()
{
    qWarning( "EnviromentGUIBase::colorToClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::exportClicked()
{
    qWarning( "EnviromentGUIBase::exportClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::generateClicked()
{
    qWarning( "EnviromentGUIBase::generateClicked(): Not implemented yet!" );
}

void EnviromentGUIBase::segmentBeginChanged(int)
{
    qWarning( "EnviromentGUIBase::segmentBeginChanged(int): Not implemented yet!" );
}

void EnviromentGUIBase::segmentEndChanged(int)
{
    qWarning( "EnviromentGUIBase::segmentEndChanged(int): Not implemented yet!" );
}

void EnviromentGUIBase::shadowValuesChanged()
{
    qWarning( "EnviromentGUIBase::shadowValuesChanged(): Not implemented yet!" );
}

void EnviromentGUIBase::timeValueChanged()
{
    qWarning( "EnviromentGUIBase::timeValueChanged(): Not implemented yet!" );
}

