/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\environment\enviromentguibase.ui'
**
** Created: Sun Feb 13 15:03:32 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef ENVIROMENTGUIBASE_H
#define ENVIROMENTGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class BitmapNav;
class CoolSlider;
class QCheckBox;
class QGroupBox;
class QLabel;
class QProgressBar;
class QPushButton;
class QSpinBox;

class EnviromentGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    EnviromentGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~EnviromentGUIBase();

    QGroupBox* shadowGroup;
    QProgressBar* progressBar;
    QPushButton* cancelButton;
    QLabel* TextLabel1;
    CoolSlider* timeSlider;
    QPushButton* colorToButton;
    QPushButton* colorAmbientButton;
    QPushButton* colorDiffuseButton;
    CoolSlider* sunDirectionSlider;
    QGroupBox* optionsGroup;
    QLabel* segmentArrow;
    QCheckBox* fastShadow;
    QCheckBox* calcSegment;
    QSpinBox* segmentBegin;
    QSpinBox* segmentEnd;
    QPushButton* exportButton;
    QCheckBox* ignoreObjects;
    QPushButton* generateButton;
    QPushButton* colorFromButton;
    QGroupBox* heightBasedGroup;
    CoolSlider* fogSlider;
    CoolSlider* fogDensitySlider;
    QGroupBox* dustGroup;
    CoolSlider* dustSlider;
    BitmapNav* bitmapNavContainer;

public slots:
    virtual void cancelClicked();
    virtual void colorAmbientClicked();
    virtual void colorDiffuseClicked();
    virtual void colorFromClicked();
    virtual void colorToClicked();
    virtual void exportClicked();
    virtual void generateClicked();
    virtual void segmentBeginChanged(int);
    virtual void segmentEndChanged(int);
    virtual void shadowValuesChanged();
    virtual void timeValueChanged();

};

#endif // ENVIROMENTGUIBASE_H
