/****************************************************************************
** ShadowGen
**
** The texture generator class
**
** Author: Dirk Plate
****************************************************************************/

#include "shadowgen.h"
#include "math.h"
#include "../../engine/terrain/terraintile.h"
#include "../common/guihelpers.h"

#define SHADOWGEN_MAXCLOUDLAYERDEPTH 20.0f
#define SHADOWGEN_CLOUDLAYERTHICKNESS 0.025f

/****************************************************************************
** ShadowGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

ShadowGen::ShadowGen()
{
	preview = false;

	pD3D = NULL;
	pD3DDevice = NULL;
	pObjects = NULL;
	pRiversMap = NULL;
	pSky = NULL;
	pHeightBasedFog = NULL;

	//load sun and moon image
	sun.Load("./guifiles/sun.png");
	moon.Load("./guifiles/moon.png");
}

ShadowGen::~ShadowGen()
{

}

/****************************************************************************
** ShadowGen generatePreview
**
** starts the generation of shadow preview
**
** Author: Dirk Plate
****************************************************************************/

void ShadowGen::generatePreview(Terrain *pTerrainSet, CxImage *pPreviewBitmapSet, D3DXVECTOR3 lightPosSet)
{
	//stop a old thread
	cancel();

	//wait till thread stopped
	while (running()) Sleep(100);

	//save all settings intern
	pTerrain = pTerrainSet;
	pPreviewBitmap = pPreviewBitmapSet;
	lightPos = lightPosSet;

	//this is only the  preview
	preview = true;

	//start the generate thread
	start();
}

/****************************************************************************
** ShadowGen generate
**
** starts the generation of the shadows on textures
**
** Author: Dirk Plate
****************************************************************************/

void ShadowGen::generate(HWND hWndSet, Terrain *pTerrainSet, int *pProgressSet,  int *pCurrentTextureTileSet,
						 CxImage *pPreviewBitmapSet, QString enginePathSet,QString texturePathSet, 
						 bool ignoreObjectsSet, bool fastShadowSet, int segmentBeginSet, int segmentEndSet)
{
	//save all settings intern
	hWnd = hWndSet;
	pTerrain = pTerrainSet;
	pProgress = pProgressSet;
	pCurrentTextureTile = pCurrentTextureTileSet;
	pPreviewBitmap = pPreviewBitmapSet;
	enginePath = enginePathSet;
	texturePath = texturePathSet;
	ignoreObjects = ignoreObjectsSet;
	fastShadow = fastShadowSet;
	segmentBegin = segmentBeginSet;
	segmentEnd = segmentEndSet;

	//we are making the real shadow texture
	preview = false;

	//current first texture tile
	*pCurrentTextureTile = segmentBegin;

	//start the generate thread
	start();
}

/****************************************************************************
** ShadowGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void ShadowGen::cancel()
{
	//set flag true, so the thread will stop
	if (running()) cancelFlag = true;
}

/****************************************************************************
** ShadowGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void ShadowGen::run()
{
	//reset cancel flag
	cancelFlag = false;

	if (preview) doPreview();
	else doGeneration();
}

/****************************************************************************
** ShadowGen doPreview
**
** this is the real generation of the shadow preview
**
** Author: Dirk Plate
****************************************************************************/

void ShadowGen::doPreview()
{
	int heightMapX,heightMapY;
	float lightShadow;
	float slopeShadow;
	D3DXVECTOR3 rayPos;
	D3DXVECTOR3 rayDir;
	D3DXVECTOR3 terrainPos;
	int heightMapSize = pPreviewBitmap->GetWidth();
	RGBQUAD red;
	red.rgbRed = 255;
	red.rgbGreen = 0;
	red.rgbBlue = 0;
	
	//calculate the position of the sun
	rayPos = lightPos;

	for (heightMapY=0;heightMapY<heightMapSize;heightMapY++)
		for (heightMapX=0;heightMapX<heightMapSize;heightMapX++)
	{
		if (cancelFlag) return;
	
		//get coordinates for current position on terrain
		terrainPos = D3DXVECTOR3((float)heightMapX+0.5f,0.0f,(float)heightMapY+0.5f);
		terrainPos.y = pTerrain->getHeightInterpolatedSmooth(terrainPos.x,terrainPos.z)+SMALL_NUM;

		//intersect with terrain?
		if (pTerrain->intersectSunRay(rayPos,terrainPos,NULL,false) == S_FALSE)
			lightShadow = 1.0f;
		else
			lightShadow = 0.0f;

		//calculate slope depend shadow
		slopeShadow = calcSlopeShadow(&terrainPos, &lightPos);
			
		//combine boths light values
		lightShadow = MAX(slopeShadow,1.0f-lightShadow);
		
		//set this pixel in the shadow preview bitmap
		red.rgbReserved = lightShadow*255.0f;
		pPreviewBitmap->SetPixelColor(heightMapX,heightMapY,red,true);
	}

	//scale sun and moon to right size (bigger at bigger terrains)
	float scaling = float(heightMapSize)/256.0f;
	CxImage scaledSun = sun;
	scaledSun.Resample(sun.GetWidth()*scaling, sun.GetWidth()*scaling);
	CxImage scaledMoon = moon;
	scaledMoon.Resample(moon.GetWidth()*scaling, moon.GetWidth()*scaling);

	//check if sun or moon
	CxImage *pLightSource = &scaledSun;
	if (lightPos.y < -1.0f)
		pLightSource = &scaledMoon;

	//calculate position of sun or moon
	D3DXVECTOR2 lightPos2D(lightPos.x,lightPos.z);
	lightPos2D -= D3DXVECTOR2(heightMapSize/2.0f,heightMapSize/2.0f);

	D3DXVECTOR2 lightIconPos;
	//check special cases (0 o'clock and 12 o'clock)
	if ((fabs(lightPos2D.x) < 1.0f) && (fabs(lightPos2D.y) < 1.0f))
		lightIconPos = D3DXVECTOR2(0.0f,0.0f);
	else D3DXVec2Normalize(&lightIconPos,&lightPos2D);
	
	//scale to pixel distance
	lightIconPos *= heightMapSize/2.0f-pLightSource->GetWidth()/2.0f;

	//moon on other side
	if (pLightSource == &scaledMoon)
		lightIconPos *= -1.0f;

	//calculate position on bitmap
	lightIconPos += D3DXVECTOR2(heightMapSize/2.0f-pLightSource->GetWidth()/2.0f,
							    heightMapSize/2.0f-pLightSource->GetHeight()/2.0f);

	//insert icon of sun or moon
	for (int y=0; y<pLightSource->GetHeight(); y++)
		for (int x=0; x<pLightSource->GetWidth(); x++)
	{
		int dstX = x+lightIconPos.x;
		int dstY = y+lightIconPos.y;

		//color colors and alpha from src and dst
		RGBQUAD srcColor = pLightSource->GetPixelColor(x,y);
		int srcAlpha = pLightSource->AlphaGet(x,y);
		RGBQUAD dstColor = pPreviewBitmap->GetPixelColor(dstX,dstY);
		int dstAlpha = pPreviewBitmap->AlphaGet(dstX,dstY);

		//calculate new color
		RGBQUAD newColor;
		float alpha = float(srcAlpha)/256.0f;
		float invAlpha = 1.0f-alpha;
		newColor.rgbRed = dstColor.rgbRed*invAlpha+srcColor.rgbRed*alpha;
		newColor.rgbGreen = dstColor.rgbGreen*invAlpha+srcColor.rgbGreen*alpha;
		newColor.rgbBlue = dstColor.rgbBlue*invAlpha+srcColor.rgbBlue*alpha;
		newColor.rgbReserved = MAX(srcAlpha,dstAlpha);

		//set new color
		pPreviewBitmap->SetPixelColor(dstX,dstY,newColor,true);
	}
}

/****************************************************************************
** ShadowGen doGeneration
**
** this is the real generation of the shadow on the textures
**
** Author: Dirk Plate
****************************************************************************/

void ShadowGen::doGeneration()
{
	int heightMapSize = pPreviewBitmap->GetWidth();
	int maxTile = heightMapSize/TILE_SIZE;
	int lastHeightMapX;
	int lastHeightMapY;
	
	*pProgress = 0;
	exactProgress = 0.0f;

	//create D3DDevice for loading objects with textures
	if (FAILED(createD3DStuff()))
		return;

	//load rivers
	loadRivers();
	
	//load sea
	loadSea();

	//retrieve ambient and diffuse color
	D3DXCOLOR ambientColor = pSky->getAmbientColor();
	D3DXCOLOR diffuseColor = pSky->getDiffuseColor();

	//calculate cloud shading
	if (segmentBegin == 0)
		doCloudLayerShading();

	//calculate the progress value
	float progressValue=(100.0f-exactProgress)/(segmentEnd-segmentBegin+1);

	//calculate the right transparency factor
	float transparencyFactor = float((100-waterTransparency)*5)/100.0f;

	//get the positions of the sun
	int sunPositionsCount;
	const D3DXVECTOR3 *sunPositions = pSky->getSun()->getVertices(&sunPositionsCount);

	//if fast shadow... only one ray to sun
	if (fastShadow) sunPositionsCount = 1;

	//try to load existing lightmap, if not calculating from begin
	CxImage lightMap;
	bool lightMapLoadingSuccess = lightMap.Load(enginePath+"/lightmap.jpg",CXIMAGE_FORMAT_JPG);
	if ((!lightMapLoadingSuccess) || 
		(lightMap.GetWidth() != heightMapSize) || (lightMap.GetHeight() != heightMapSize))
	{
		//if loading failed... create a new lightmap
		lightMap.Create(heightMapSize,heightMapSize,24);
		lightMap.Clear(0xff);
	}

	//try to load existing water lightmap, if not calculating from begin
	CxImage waterLightMap;
	bool waterLightMapLoadingSuccess = waterLightMap.Load(enginePath+"/waterlightmap_tmp.jpg",CXIMAGE_FORMAT_JPG);
	if ((!waterLightMapLoadingSuccess) || 
		(waterLightMap.GetWidth() != heightMapSize) || (waterLightMap.GetHeight() != heightMapSize))
	{
		//if loading failed... create a new water lightmap
		waterLightMap.Create(heightMapSize,heightMapSize,24);
		waterLightMap.Clear(0xff);
	}

	//try to load existing minimap, if not calculating from begin
	CxImage miniMap;
	bool miniMapLoadingSuccess = miniMap.Load(enginePath+"/minimap.jpg",CXIMAGE_FORMAT_JPG);
	if ((!miniMapLoadingSuccess) || 
		(miniMap.GetWidth() != heightMapSize) || (miniMap.GetHeight() != heightMapSize))
	{
		//if loading failed... create a new minimap
		miniMap.Create(heightMapSize,heightMapSize,24);
		miniMap.Clear(0x00);
	}

	//init last heightmap coordinate
	lastHeightMapX = -1;
	lastHeightMapY = -1;

	//modify terrain texture (add detail light and shadow)
	for (int tileY=0;tileY<maxTile && !cancelFlag;tileY++)
		for (int tileX=0;tileX<maxTile && !cancelFlag;tileX++)
	{
		if (cancelFlag) break;

		//ignore tiles not in segment
		int currentTile = tileY*maxTile+tileX;
		if ((currentTile < segmentBegin) ||
			(currentTile > segmentEnd))
			continue;
		
		//update current texture tile indicator
		*pCurrentTextureTile = currentTile;

		//load texture
		CxImage tileTexture;
		if (!tileTexture.Load(QString(texturePath+"/terrain_tmp_%1_%2.jpg").arg(tileX).arg(tileY),
							  CXIMAGE_FORMAT_JPG))
		{
			//if texture not exist... create a white texture with minimal size
			tileTexture.Create(256,256,24);
			tileTexture.Clear(0xff);

		}
		int resolution = tileTexture.GetWidth();

		//go through all pixels of texture
		for (int tileTextureY=0;tileTextureY<resolution && !cancelFlag;tileTextureY++)
			for (int tileTextureX=0;tileTextureX<resolution && !cancelFlag;tileTextureX++)
		{
			//calculate the coordinate on the heightmap
			float heightMapX = (float)(tileX*TILE_SIZE)+
				(float)tileTextureX*(float)TILE_SIZE/(float)resolution;
			float heightMapY = (float)(tileY*TILE_SIZE)+
				(float)tileTextureY*(float)TILE_SIZE/(float)resolution;

			//calculate int values
			int heightMapXInt = int(heightMapX);
			int heightMapYInt = int(heightMapY);

			//get coordinates for current position on terrain
			D3DXVECTOR3 terrainPos = D3DXVECTOR3(heightMapX,0.0f,heightMapY);
			terrainPos.y = pTerrain->getHeightInterpolatedSmooth(terrainPos.x,terrainPos.z)+SMALL_NUM;
			float terrainPosRealY = pTerrain->getHeightInterpolated(terrainPos.x,terrainPos.z);

			//get coordinates for current position on sea or river
			D3DXVECTOR3 waterPos = terrainPos;
			bool atSea = false;
			bool atRiver = false;
			if (seaHeight >= terrainPosRealY)
			{
				atSea = true;
				waterPos.y = seaHeight+SMALL_NUM;
			}
			float riverWaterAmount = pRiversMap->getInterpolatedAmount/*Smooth*/(heightMapX, heightMapY);
			if (riverWaterAmount > SMALL_NUM)
			{
				float riverAbsHeight = terrainPosRealY+riverWaterAmount;
				if (riverAbsHeight >= waterPos.y)
				{
					atSea = false;
					atRiver = true;
					waterPos.y = riverAbsHeight+SMALL_NUM;
				}
			}

			//retrieve light color on this position
			D3DXCOLOR lightColor = getLightColor(&terrainPos, 
				sunPositions, sunPositionsCount,
				&ambientColor,&diffuseColor,
				false, false);

			//get old color on the texture
			RGBQUAD color = tileTexture.GetPixelColor(tileTextureX,tileTextureY);

			//multiply light color
			color.rgbRed *= lightColor.r;
			color.rgbGreen *= lightColor.g;
			color.rgbBlue *= lightColor.b;

			//change color of terrain under water
			if (atSea || atRiver)
			{
				//calculate water depth
				float waterDepth = waterPos.y-terrainPos.y;

				//calculate water intensity
				float waterIntensity = atanf(transparencyFactor * waterDepth) * 2.0f / D3DX_PI;
				
				//check illegal values
				if (waterIntensity < 0.0f)
					waterIntensity = 0.0f;

				//very deep
				if (waterIntensity > 1.0f)
				{
					//use only water color
					color.rgbRed = qRed(waterColor);
					color.rgbGreen = qGreen(waterColor);
					color.rgbBlue = qBlue(waterColor);
				}
				else
				{	
					//modulate water color in calculated new color
					float invWaterIntensity = 1.0f-waterIntensity;
					color.rgbRed	= color.rgbRed*invWaterIntensity+
									  qRed(waterColor)*waterIntensity;
					color.rgbGreen	= color.rgbGreen*invWaterIntensity+
									  qGreen(waterColor)*waterIntensity;
					color.rgbBlue	= color.rgbBlue*invWaterIntensity+
									  qBlue(waterColor)*waterIntensity;
				}
			}
			
			//set the pixel to new color
			tileTexture.SetPixelColor(tileTextureX,tileTextureY,color);

			//new position on heightmap reached?
			if (((heightMapXInt != lastHeightMapX) || 
				 (heightMapYInt != lastHeightMapY)) &&
				((heightMapX - heightMapXInt >= 0.5f) || 
				 (heightMapX - heightMapYInt >= 0.5f)))
			{
				//generate pixel on lightmap
				RGBQUAD rgbQuadLightColor;
				rgbQuadLightColor.rgbRed = lightColor.r*255.0f;
				rgbQuadLightColor.rgbGreen = lightColor.g*255.0f;
				rgbQuadLightColor.rgbBlue = lightColor.b*255.0f;
				lightMap.SetPixelColor(heightMapXInt,heightMapYInt,rgbQuadLightColor);

				//set pixel in preview
				pPreviewBitmap->SetPixelColor(heightMapXInt,heightMapYInt,color,true);

				//set pixel in minimap
				miniMap.SetPixelColor(heightMapXInt,heightMapYInt,color);

				//generate pixel on water lightmap
				lightColor = getLightColor(&waterPos,
					sunPositions,sunPositionsCount,
					&ambientColor,&diffuseColor,
					false, true);	

				//set pixel in lightmap
				color.rgbRed = lightColor.r*255.0f;
				color.rgbGreen = lightColor.g*255.0f;
				color.rgbBlue = lightColor.b*255.0f;
				waterLightMap.SetPixelColor(heightMapXInt,heightMapYInt,color);

				//save last written height map coordinate
				lastHeightMapX = heightMapXInt;
				lastHeightMapY = heightMapYInt;
			}
		}
		if (cancelFlag) break;

		//save this new tileTexture on disc
		tileTexture.SetJpegQuality(JPG_QUALITY); 
		tileTexture.Save((texturePath+"/terrain_%1_%2.jpg").arg(tileX).arg(tileY),CXIMAGE_FORMAT_JPG);
		
		//set progress
		exactProgress += progressValue;
		*pProgress = (int)exactProgress;
	}

	//finish lightmap
	lightMap.SetJpegQuality(JPG_QUALITY); 
	lightMap.Save(enginePath+"/lightmap.jpg",CXIMAGE_FORMAT_JPG);

	//finish waterlightmap
	waterLightMap.SetJpegQuality(JPG_QUALITY);
	waterLightMap.Save(enginePath+"/waterlightmap_tmp.jpg",CXIMAGE_FORMAT_JPG);

	//smooth waterlight map with gaussian filter
	smoothImage(waterLightMap);
	waterLightMap.Save(enginePath+"/waterlightmap.jpg",CXIMAGE_FORMAT_JPG);

	//finish minimap
	miniMap.SetJpegQuality(JPG_QUALITY); 
	miniMap.Save(enginePath+"/minimap.jpg",CXIMAGE_FORMAT_JPG);

	if (!cancelFlag)
		*pProgress = 100;

	//delete rivers
	SAFE_DELETE(pRiversMap);

	//remove D3D stuff
	removeD3DStuff();
}

/****************************************************************************
** ShadowGen loadRivers
**
** load the rivers from disc
** 
** Author: Dirk Plate
****************************************************************************/
void ShadowGen::loadRivers()
{
	//load some settings from rivers for water lightmap generation
	pRiversMap = new RiversMap(pPreviewBitmap->GetWidth());
	MiniXML xmlFile;
	if (xmlFile.openFile(enginePath+"/rivers.txt", MiniXML::READ))
	{
		if (xmlFile.startReadList("rivers"))
		{
			int no=0;
			while (xmlFile.startReadListElement(no))
			{
				int value;
				bool bValue;
				float fValue;
				int x = 0, y = 0;

				if (xmlFile.readInteger("x", &value))
					x = value;
				if (xmlFile.readInteger("y", &value))
					y = value;

				//get element
				RiversMap::OneWaterElement *pElement;
				if (pRiversMap->getElement(x,y,&pElement))
				{
					pElement->used = true;

					if (xmlFile.readFloat("amount", &fValue))
						pElement->amount = 
							pTerrain->transformHeightInMetersToEngineCoor(fValue,false);
					if (xmlFile.readBoolean("border", &bValue))
						pElement->border = bValue;
				}
				xmlFile.endReadListElement();
				no++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}
}

/****************************************************************************
** ShadowGen loadSea
**
** load the sea from disc
** 
** Author: Dirk Plate
****************************************************************************/
void ShadowGen::loadSea()
{
	//load some settings for water lightmap generation
	seaHeight = 0;
	waterTransparency = 90;
	waterColor = qRgb(0,0,255);
	MiniXML xmlFile;
	int value;
	if (xmlFile.openFile(enginePath+"/water.txt",MiniXML::READ))
	{
		if (xmlFile.readInteger("transparency",&value))
			waterTransparency = value;

		int r=0;
		int g=0;
		int b=255;
		if (xmlFile.readInteger("rColor",&value))
			r = value;
		if (xmlFile.readInteger("gColor",&value))
			g = value;
		if (xmlFile.readInteger("bColor",&value))
			b = value;
		waterColor = qRgb(r,g,b);
	
		xmlFile.closeFile();
	}

	if (xmlFile.openFile(enginePath+"/sea.txt",MiniXML::READ))
	{

		if (xmlFile.readInteger("height",&value))
			seaHeight = pTerrain->transformHeightInMetersToEngineCoor(value,true);
	}
}

/****************************************************************************
** ShadowGen createD3DStuff
**
** returns the light color on position of terrain
** 
** Author: Dirk Plate
****************************************************************************/
inline D3DCOLOR ShadowGen::getLightColor(D3DXVECTOR3 *terrainPos,
							 const D3DXVECTOR3 *sunPositions,int sunPositionsCount,
							 D3DXCOLOR *pAmbientColor,D3DXCOLOR *pDiffuseColor,
							 bool forceIgnoreObjects, bool seaMode)
{
	
	//calculate invAlpha-Value
	float invAlpha = 1.0f;

	//for each position of the sun (sun is not only a point)
	for (int i=0;i<sunPositionsCount;i++)
	{
		float oneRayInvAlpha = 1.0f;

		//intersect with terrain?
		bool intersect = true;
		if (pTerrain->intersectSunRay(sunPositions[i],*terrainPos,NULL,true) == S_FALSE)
			intersect = false;

		//not intersection with terrain... maybe with objects?
		if (!intersect)
		{
			float oneObjectsInvAlpha;
			D3DXVECTOR3 rayDir = *terrainPos-sunPositions[i];

			if ((!ignoreObjects) && (!forceIgnoreObjects))
			{
				D3DXVECTOR3 intersections[100];
				int intersectionCount;
				intersect = pObjects->intersectRay(&(sunPositions[i]),&rayDir,100,
					intersections,&intersectionCount,
					true,&oneObjectsInvAlpha,SMALL_NUM,true);

				//if intersection... then add invalphavalue
				if (intersect)
					oneRayInvAlpha *= oneObjectsInvAlpha;
			}

			//heightbased fog?
			if (HeightBasedFog::instance->intersectRay(&(sunPositions[i]),&rayDir,
				&oneObjectsInvAlpha,true))
				oneRayInvAlpha *= oneObjectsInvAlpha;
		}
		else oneRayInvAlpha = 0.0f;

		//sub oneRayInvAlpha to main invAlpha
		invAlpha -= ((1.0f-oneRayInvAlpha)/((float)sunPositionsCount));

		//if invAlpha small enough -> break
		if (invAlpha < SMALL_NUM) break;
	}

	//add some slope dependens shadow (differently... if sea or terrain)
	float slopeShadow;
	if (!seaMode)
		slopeShadow = calcSlopeShadow(terrainPos, &(sunPositions[0]));
	else
		slopeShadow = 0.25f;

	//combine both values
	invAlpha = MIN(1.0f-slopeShadow,invAlpha);

	//calculate color
	return invAlpha*(*pDiffuseColor)+(1.0f-invAlpha)*(*pAmbientColor);
}

/****************************************************************************
** ShadowGen calcSlopeShadow
**
** calculate the slope depend shadow
** 
** Author: Dirk Plate
****************************************************************************/
float ShadowGen::calcSlopeShadow(const D3DXVECTOR3 *pTerrainPos, const D3DXVECTOR3 *pSunPos)
{
	//retrieve normal vector on terrain
	D3DXVECTOR3 normalVector = pTerrain->getNormalInterpolatedSmooth(pTerrainPos->x, pTerrainPos->z);
	
	//calculate sun vector
	D3DXVECTOR3 lightVector = *pTerrainPos-*pSunPos;
	D3DXVec3Normalize(&lightVector, &lightVector);
	
	//calculate angle value (not a real angle)
	D3DXVECTOR3 middleVector = normalVector-lightVector;	
	float middleVecLength=D3DXVec3Length(&middleVector);
	float slopeShadow = 2.0f*acos(middleVecLength/2.0f);
	
	//normalize it to nice values /between 0 and 1.0
	slopeShadow=1.0f-cos(slopeShadow);

	if (slopeShadow < 0.0f) slopeShadow = 0.0f;
	if (slopeShadow > 1.0f) slopeShadow = 1.0f;
	
	return slopeShadow;
}

/****************************************************************************
** ShadowGen doCloudLayerShading
**
** calculate the bump mapping effect of the cloud layer
** 
** Author: Dirk Plate
****************************************************************************/
void ShadowGen::doCloudLayerShading()
{
	//get properties of cloud layer
	MiniXML xmlFile;
	if (!xmlFile.openFile(enginePath+"/clouds.txt",MiniXML::READ))
		return;

	//read count of frames
	int frameCount;
	if (!xmlFile.readInteger("cirrusFrames",&frameCount))
		return;

	//close file
	xmlFile.closeFile();

	//get vector of sun
	float dX = -pSky->getSun()->getPosition().x-pTerrain->getWidth()/2;
	float dY = pSky->getSun()->getPosition().y;
	float dZ = pSky->getSun()->getPosition().z-pTerrain->getWidth()/2;

	//calculate step width for point/sun ray walking
	float sX,sY,sZ;
	if (fabs(dX)>fabs(dZ))
	{
		if (dX>0) sX = -1; 
		else sX = 1;
		if ((fabs(dX) > -SMALL_NUM) && (fabs(dX) < SMALL_NUM))  
		{
			sZ = 0; 
			sY = dY;
		}
		else 
		{
			sZ = dZ/(dX*sX);
			sY = dY/fabs(dX);
		}
	}
	else
	{
		if (dZ>0)  sZ = -1; else sZ = 1;
		if ((fabs(dZ) > -SMALL_NUM) && (fabs(dZ) < SMALL_NUM))    
		{
			sX = 0; 
			sY = dY;
		}	
		else 
		{
			sX = (float)dX/((float)(dZ*sZ));
			sY = dY/fabs(dZ);
		}
	}	

	//calculate the length of one step
	float sLength = sqrtf(sX*sX+sY*sY+sZ*sZ);

	//calculate factor to convert alpha to depth
	float convertAlphaFactor = SHADOWGEN_MAXCLOUDLAYERDEPTH/255.0f;

	//calculate color for areas with alpha = 0 (needed for nicer blending)
	RGBQUAD backColor;
	backColor.rgbRed = pSky->getDiffuseColor().r * 255.0f;
	backColor.rgbGreen = pSky->getDiffuseColor().g * 255.0f;
	backColor.rgbBlue =	pSky->getDiffuseColor().b * 255.0f;;

	//shade every frame
	for (int currentFrame = 0; currentFrame < frameCount; currentFrame++)
	{
		if (cancelFlag) break;

		//load cloud layer
		CxImage cloudLayer;
		if (!cloudLayer.Load(QString(enginePath+"/cloudlayer/frame_%1.png").arg(currentFrame),CXIMAGE_FORMAT_PNG))
			return;

		//go through all pixels
		for (int z=0;z<cloudLayer.GetHeight();z++)
			for (int x=0;x<cloudLayer.GetWidth();x++)
		{
			//retrieve alpha component at this position
			int alpha = cloudLayer.AlphaGet(x,z);

			//no cloud at this position? no shading needed
			if (alpha == 0)
			{
				//set to background color
				cloudLayer.SetPixelColor(x,z,backColor);
				continue;
			}

			//calculate start position of ray
			float rX = x;
			float rY = -float(alpha)*convertAlphaFactor;
			float rZ = z;
			float currentCloudHeight = -rY;

			//make one step
			rX += sX; rY += sY; rZ += sZ;

			//save absolute moved way in x and z direction
			float mX = sX;
			float mZ = sZ;

			//check way of ray from this point to sun
			float lengthInCloud = 0.0f;
			bool lastInCloud = true;
			while((rY > -SHADOWGEN_MAXCLOUDLAYERDEPTH) && (rY < SHADOWGEN_MAXCLOUDLAYERDEPTH) &&
				(fabs(mX) < cloudLayer.GetWidth()) && (fabs(mZ) < cloudLayer.GetHeight()))
			{
				//check extend of texture
				if (rX < 0.0f) rX += cloudLayer.GetWidth();
				else if (rX >= cloudLayer.GetWidth()) rX -= cloudLayer.GetWidth();
				if (rZ < 0.0f) rZ += cloudLayer.GetHeight();
				else if (rZ >= cloudLayer.GetHeight()) rZ -= cloudLayer.GetHeight();
				
				//new pixel in cloud?
				currentCloudHeight = float(cloudLayer.AlphaGet(rX,rZ))*convertAlphaFactor;
				if ((rY > -currentCloudHeight) && (rY < +currentCloudHeight))
				{
					//pixel before already in cloud?
					if (lastInCloud)
					{
						//add way of step to lengthInCloud
						lengthInCloud += sLength;
					}
					//next step this is lastInCloud
					lastInCloud = true;
				}
				else lastInCloud = false;

				//make one step
				rX += sX; rY += sY; rZ += sZ;
				mX += sX;			mZ += sZ;
			}

			//last pixel was in cloud?
			if (lastInCloud)
			{
				//add length of this pixel
				if (rY > 0.0f)
					lengthInCloud += fabs(currentCloudHeight-(rY-sY));
				else
					lengthInCloud += fabs(-currentCloudHeight-(rY-sY));
			}	


			//convert length in cloud to a nice factor
			float shadowFactor = lengthInCloud*SHADOWGEN_CLOUDLAYERTHICKNESS;
			if (shadowFactor < 0.0f) shadowFactor = 0.0f;
			else if (shadowFactor > 1.0f) shadowFactor = 1.0f;

			//set right color for cloud pixel
			RGBQUAD color;
			color.rgbRed =		((1.0f-shadowFactor)*pSky->getDiffuseColor().r+
								 shadowFactor		*pSky->getAmbientColor().r) * 255.0f;
			color.rgbGreen =	((1.0f-shadowFactor)*pSky->getDiffuseColor().g+
								 shadowFactor       *pSky->getAmbientColor().g) * 255.0f;
			color.rgbBlue =		((1.0f-shadowFactor)*pSky->getDiffuseColor().b+
								 shadowFactor		*pSky->getAmbientColor().b) * 255.0f;
			cloudLayer.SetPixelColor(x,z,color);
		}

		//save cloud layer
		cloudLayer.Save(QString(enginePath+"/cloudlayer/frame_%1.png").arg(currentFrame),CXIMAGE_FORMAT_PNG);
	
		//make progress
		exactProgress += 0.25f;
		*pProgress = int(exactProgress);
	}
}

/****************************************************************************
** ShadowGen smoothImage
**
** smooth a image with a gaussian filter
**
** Author: Dirk Plate
****************************************************************************/
void ShadowGen::smoothImage(CxImage &image)
{
	int x,y;
	int sumRed, sumGreen, sumBlue;
	RGBQUAD color;
	int width = image.GetWidth();
	int height = image.GetHeight();

	//go through every pixel
	for (y=0;y<height;y++)
		for (x=0;x<width;x++)
	{
		//take all pixels around the current and itself
		sumRed = 0;
		sumGreen = 0;
		sumBlue = 0;

		color = image.GetPixelColor(mod(x-1,width),mod(y-1,height));
		sumRed += color.rgbRed;
		sumGreen += color.rgbGreen;
		sumBlue += color.rgbBlue;

		color = image.GetPixelColor(x,mod(y-1,height));
		sumRed += 2*color.rgbRed;
		sumGreen += 2*color.rgbGreen;
		sumBlue += 2*color.rgbBlue;

		color = image.GetPixelColor(mod(x+1,width),mod(y-1,height));
		sumRed += color.rgbRed;
		sumGreen += color.rgbGreen;
		sumBlue += color.rgbBlue;

		color = image.GetPixelColor(mod(x-1,width),y);
		sumRed += 2*color.rgbRed;
		sumGreen += 2*color.rgbGreen;
		sumBlue += 2*color.rgbBlue;

		color = image.GetPixelColor(x,y);
		sumRed += 4*color.rgbRed;
		sumGreen += 4*color.rgbGreen;
		sumBlue += 4*color.rgbBlue;

		color = image.GetPixelColor(mod(x+1,width),y);
		sumRed += 2*color.rgbRed;
		sumGreen += 2*color.rgbGreen;
		sumBlue += 2*color.rgbBlue;

		color = image.GetPixelColor(mod(x-1,width),mod(y+1,height));
		sumRed += color.rgbRed;
		sumGreen += color.rgbGreen;
		sumBlue += color.rgbBlue;

		color = image.GetPixelColor(x,mod(y+1,height));
		sumRed += 2*color.rgbRed;
		sumGreen += 2*color.rgbGreen;
		sumBlue += 2*color.rgbBlue;

		color = image.GetPixelColor(mod(x+1,width),mod(y+1,height));
		sumRed += color.rgbRed;
		sumGreen += color.rgbGreen;
		sumBlue += color.rgbBlue;
		
		//set the pixel on new value
		color.rgbRed = sumRed/16;
		color.rgbGreen = sumGreen/16;
		color.rgbBlue = sumBlue/16;
		image.SetPixelColor(x,y,color);
	}
}

/****************************************************************************
** ShadowGen mod
**
** special mod which handles negative numbers
**
** Author: Dirk Plate
****************************************************************************/

int ShadowGen::mod(int src, int size)
{
	if (src >= 0) return src%size;
	else 
	{
		while (src < 0) src += size;
		return src;
	}
}

/****************************************************************************
** ShadowGen createD3DStuff
**
** creates the minimal d3d device 
** 
** Author: Dirk Plate
****************************************************************************/
HRESULT ShadowGen::createD3DStuff()
{
	HRESULT hr;

	//already created?
	if (pD3D != NULL) return S_OK;

	//create D3D
	pD3D = Direct3DCreate9(D3D_SDK_VERSION);

	//create the device
	D3DDISPLAYMODE			currentMode;
	D3DPRESENT_PARAMETERS   presentParameters;
	if (FAILED(hr=pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&currentMode)))
		return hr;

	ZeroMemory(&presentParameters, sizeof(D3DPRESENT_PARAMETERS));
	presentParameters.Windowed = true;
	presentParameters.SwapEffect = D3DSWAPEFFECT_DISCARD;
	presentParameters.BackBufferCount = 1;
	presentParameters.BackBufferFormat = currentMode.Format;
	presentParameters.EnableAutoDepthStencil = true;
	presentParameters.AutoDepthStencilFormat = D3DFMT_D24S8;
	presentParameters.hDeviceWindow = hWnd;

	if (FAILED(hr=pD3D->CreateDevice(D3DADAPTER_DEFAULT , 
		                          D3DDEVTYPE_HAL,
								  hWnd,
								  D3DCREATE_SOFTWARE_VERTEXPROCESSING,
								  &presentParameters,
								  &pD3DDevice)))
		return hr;

	//create sky class
	QString projectPath = enginePath+"/../";
	const char *path = projectPath.latin1();
	pConfig = new Config();
	pConfig->init(path);
	pSky = new Sky();
	pSky->createGeometry(pD3DDevice);
	pHeightBasedFog = new HeightBasedFog();
	pHeightBasedFog->createGeometry(pD3DDevice,true);

	//create objects class
	if (!ignoreObjects)
	{
		pObjects = new Objects();
		if (FAILED(hr=pObjects->createGeometry(pD3DDevice,true)))
			return hr;
	}

	return S_OK;
}

/****************************************************************************
** ShadowGen removeD3DStuff
**
** remove the minimal d3d device 
** 
** Author: Dirk Plate
****************************************************************************/
void ShadowGen::removeD3DStuff()
{
	//if ignoring objects... we have no objects
	if (!ignoreObjects)
	{
		if (pObjects != NULL)
			pObjects->destroyGeometry();
		SAFE_DELETE(pObjects);
	}

	if (pSky != NULL)
		pSky->destroyGeometry();
	SAFE_DELETE(pSky);

	if (pHeightBasedFog != NULL)
		pHeightBasedFog->destroyGeometry();
	SAFE_DELETE(pHeightBasedFog);
		
	SAFE_DELETE(pConfig);
	
	if (pD3DDevice)
	{
		int references = pD3DDevice->Release();
		pD3DDevice = NULL;
	}
	if (pD3D)
	{
		int references = pD3D->Release();
		pD3D = NULL;
	}
}

