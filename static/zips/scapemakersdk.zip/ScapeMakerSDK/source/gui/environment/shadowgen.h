/****************************************************************************
** ShadowGen
**
** The shadow generator class
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include <qthread.h>
#include <stdlib.h>
#include <time.h>
#include "../../engine/terrain/terrain.h"
#include "../../engine/objects/objects.h"
#include "../../engine/water/riversmap.h"
#include "../../engine/sky/sky.h"
#include "../../engine/postprocessing/heightbasedfog.h"
#include "../../engine/common/config.h"
#include "ximage.h"

class ShadowGen : public QThread
{
public:
	ShadowGen();
	~ShadowGen();

	void generatePreview(Terrain *pTerrainSet, CxImage *pPreviewBitmapSet, D3DXVECTOR3 lightPosSet);
	void generate(HWND hWndSet, Terrain *pTerrainSet, int *pProgressSet, int *pCurrentTextureTileSet, 
		CxImage *pPreviewBitmapSet, QString enginePathSet, QString texturePathSet, 
		bool ignoreObjectsSet, bool fastShadowSet, int segmentBeginSet, int segmentEndSet);
	void cancel();

protected:
	virtual void run();

private:
	void doPreview();			//the real generation of the shadow-preview
	void doGeneration();		//the real generation of the shadow
	void loadRivers();			//load the rivers from disc
	void loadSea();				//load the sea from disc
	D3DCOLOR getLightColor(D3DXVECTOR3 *terrainPos,
		const D3DXVECTOR3 *sunPositions,int sunPositionsCount,
		D3DXCOLOR *pAmbientColor,D3DXCOLOR *pDiffuseColor,
		bool forceIgnoreObjects, bool seaMode);	//calculate the color on a point of terrain
	float calcSlopeShadow(const D3DXVECTOR3 *pTerrainPos, 
		const D3DXVECTOR3 *pSunPos);			//calculate the slope dependens shadow
	void doCloudLayerShading();	//calculate the bump mapping effect of the cloud layer
	void smoothImage(CxImage &image);
	int mod(int src, int size);
	HRESULT createD3DStuff();	//create d3d stuff
	void removeD3DStuff();		//remove d3d stuff

	CxImage sun;				//image to represent the position of sun
	CxImage moon;				//image to represent the position of moon

	int *pProgress;
	int *pCurrentTextureTile;	//current calculating texture tile
	float exactProgress;
	Terrain *pTerrain;			//pointer to terrain class
	bool cancelFlag;			//is true, if the generate-thread should stop

	D3DXVECTOR3 lightPos;		//the position of the light
	bool ignoreObjects;			//don't calculate shadows of objects?
	bool fastShadow;			//calculate fast shadow (only one ray to sun)
	int segmentBegin;			//begin calculation with this segment
	int segmentEnd;				//end calculation with this segment
	int seaHeight;				//the height of sea for waterLightmap generation
	int waterTransparency;		//the transparency of water for waterLightmap generation
	QRgb waterColor;			//the color of water
	RiversMap *pRiversMap;		//the water amount of rivers for waterLightmap generation

	CxImage *pPreviewBitmap;		//the generated shadow-preview
	bool preview;				//making the shadow preview or the real shadow on texture?
	QString enginePath;			//the path to the engine directory
	QString texturePath;		//the path where all textures should saved

	HWND			  hWnd;			//window handle
	LPDIRECT3DDEVICE9 pD3DDevice;	//pointer to the D3D device
	LPDIRECT3D9       pD3D;			//pointer to our D3D object
	Sky				  *pSky;		//pointer to sky (sun position)
	HeightBasedFog	  *pHeightBasedFog; //pointer to height based fog object
	Config			  *pConfig;		//pointer to config (needed for Sky creation)
	Objects			  *pObjects;	//pointer to objects on terrain
};
