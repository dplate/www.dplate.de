/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\info\infoguibase.ui'
**
** Created: Sun Feb 13 15:03:29 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef INFOGUIBASE_H
#define INFOGUIBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QGroupBox;
class QLabel;

class InfoGUIBase : public QDialog
{ 
    Q_OBJECT

public:
    InfoGUIBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~InfoGUIBase();

    QGroupBox* versionGroup;
    QLabel* version;
    QGroupBox* developerGroup;
    QLabel* matthias;
    QLabel* dirk;
    QLabel* PixmapLabel1;
    QGroupBox* testerGroup;
    QLabel* tester5;
    QLabel* tester1;
    QLabel* tester2;
    QLabel* tester3;
    QLabel* tester4;
    QLabel* tester6;
    QLabel* websiteLabel;

protected:
    bool event( QEvent* );
};

#endif // INFOGUIBASE_H
