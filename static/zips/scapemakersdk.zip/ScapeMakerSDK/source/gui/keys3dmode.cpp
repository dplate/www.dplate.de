/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\keys3dmode.ui'
**
** Created: Sun Feb 13 15:03:29 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "keys3dmode.h"

#include <qlabel.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a Keys3DMode which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
Keys3DMode::Keys3DMode( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "Keys3DMode" );
    resize( 250, 210 ); 
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 250, 210 ) );
    setCaption( tr( "Keys in 3d mode" ) );

    TextLabel2 = new QLabel( this, "TextLabel2" );
    TextLabel2->setGeometry( QRect( 110, 5, 135, 170 ) ); 
    TextLabel2->setText( tr( "Exit 3d mode\nOpen console\nMake screenshot\nToggle walk mode\nStrafe left\nStrafe right\nMove forward\nMove backward\nMove up\nMove down\nShow minimap\nShow debug output\nSwitch debug output" ) );
    TextLabel2->setAlignment( int( QLabel::AlignTop | QLabel::AlignLeft ) );

    TextLabel3 = new QLabel( this, "TextLabel3" );
    TextLabel3->setGeometry( QRect( 0, 185, 245, 16 ) ); 
    TextLabel3->setText( tr( "Press mouse button to look around" ) );
    TextLabel3->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel1 = new QLabel( this, "TextLabel1" );
    TextLabel1->setGeometry( QRect( 5, 5, 95, 170 ) ); 
    TextLabel1->setText( tr( "ESC\n^\nC\nO\nA or LEFT\nD or RIGHT\nW or UP\nS or DOWN\nR\nF\nM\nN\nB" ) );
    TextLabel1->setAlignment( int( QLabel::AlignTop | QLabel::AlignLeft ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
Keys3DMode::~Keys3DMode()
{
    // no need to delete child widgets, Qt does it all for us
}

