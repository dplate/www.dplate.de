/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\keys3dmode.ui'
**
** Created: Sun Feb 13 15:03:29 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef KEYS3DMODE_H
#define KEYS3DMODE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;

class Keys3DMode : public QDialog
{ 
    Q_OBJECT

public:
    Keys3DMode( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~Keys3DMode();

    QLabel* TextLabel2;
    QLabel* TextLabel3;
    QLabel* TextLabel1;

};

#endif // KEYS3DMODE_H
