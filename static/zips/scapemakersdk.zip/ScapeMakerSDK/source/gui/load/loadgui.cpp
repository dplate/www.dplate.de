/****************************************************************************
** LoadGUI
**
** load or create a landscape
**
** Author: Dirk Plate
****************************************************************************/

#include "loadgui.h"

/****************************************************************************
** LoadGUI Constructor
**
** Init vars
**
** Author: Dirk Plate
****************************************************************************/
LoadGUI::LoadGUI( QWidget* parent, const char* name, bool modal, WFlags f )
	: LoadGUIBase( parent, name, modal, f )
{

}

/****************************************************************************
** LoadGUI showEvent
**
** Is called, when the LoadGUI will be shown. 
** Fills the landscapeList
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::showEvent(QShowEvent *showEvent)
{
	//fill all available landscape-directory in landscapeList
	QDir directory("./landscapes");
	QStringList landscapes;
	
	//sort out the right directories
	const QList<QFileInfo> *fileInfoListOrg = directory.entryInfoList();
	QList<QFileInfo> fileInfoList = *fileInfoListOrg;
	for (uint i=0;i<fileInfoList.count();i++)
	{
		QFileInfo *fileInfo=fileInfoList.at(i);

		//only directory?
		if (fileInfo->isDir())
		{
			//ignore the . and .. dir
			if ((fileInfo->fileName() == ".") ||
				(fileInfo->fileName() == "..")) continue;

			landscapes.append(fileInfo->fileName());
		}
	}

	//add the list to the gui-selectionlist
	landscapesList->insertStringList(landscapes);
}

/****************************************************************************
** LoadGUI hideEvent
**
** Is called, when the LoadGUI will be hide. 
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::hideEvent(QHideEvent *hideEvent)
{
}

/****************************************************************************
** LoadGUI hideEvent
**
** returns the selected landscape
**  
** Author: Dirk Plate
****************************************************************************/

QString LoadGUI::getSelectedLandscape()
{
	return selectedLandscape;
}

/****************************************************************************
** LoadGUI deleteClicked
**
** called when the user clicked the delete button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::deleteClicked()
{
	//clicked an item?
	if (landscapesList->currentItem() == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an item in the list first!"));
		return;
	}
	
	//get the selected text
	QString toDelete = landscapesList->currentText();

	//ask the user if delete
	if(QMessageBox::warning (this, tr("ScapeMaker"), tr("Delete landscape")+" \""+toDelete+"\"?", 
				tr("Yes"), tr("No"), QString::null, 1) != 0) return;

	//delete landscape
	GUIHelpers::deleteDir(QDir("./landscapes/"+toDelete));

	//remove the landscape from gui-list
	landscapesList->removeItem(landscapesList->currentItem());
}

/****************************************************************************
** LoadGUI duplicateClicked
**
** called when the user clicked the duplicate button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::duplicateClicked()
{
	//clicked an item?
	if (landscapesList->currentItem() == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an item in the list first!"));
		return;
	}
	
	//get the selected text
	QString toDuplicate = landscapesList->currentText();

	//get the text from input dialog
	bool ok = FALSE;
	QString newLandscape = QInputDialog::getText(tr("ScapeMaker"),tr("Name of landscape?"), "Copy of "+toDuplicate, &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newLandscape.isNull() || newLandscape.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name"));
		return;
	}

	//directory already exist?
	QFileInfo fileInfo("./landscapes/"+newLandscape);
	if (fileInfo.exists() && fileInfo.isDir())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Directory already exists!\nPlease choose another name."));
		return;
	}

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//create the directory
	QDir destPath = ("./landscapes/");
	destPath.mkdir(newLandscape);
	destPath.cd(newLandscape);

	//copy the directory
	GUIHelpers::copyDir(QDir("./landscapes/"+toDuplicate+"/"),destPath);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();
	
	//add the item to the gui-list
	landscapesList->insertItem(newLandscape);

	//select item in gui-list
	landscapesList->setSelected(landscapesList->count()-1,true);
}

/****************************************************************************
** LoadGUI newClicked
**
** called when the user clicked the new button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::newClicked()
{
	//get the text from input dialog
	bool ok = FALSE;
	QString newLandscape = QInputDialog::getText(tr("ScapeMaker"),tr("Name of landscape?"), QString::null, &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newLandscape.isNull() || newLandscape.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name"));
		return;
	}

	//directory already exist?
	QFileInfo fileInfo("./landscapes/"+newLandscape);
	if (fileInfo.exists() && fileInfo.isDir())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Directory already exists!\nPlease choose another name."));
		return;
	}

	//create directory-tree
	GUIHelpers::createLandscapeDirectories(this,newLandscape,true);

	//add the item to the gui-list
	landscapesList->insertItem(newLandscape);

	//select item in gui-list
	landscapesList->setSelected(landscapesList->count()-1,true);
}

/****************************************************************************
** LoadGUI editClicked
**
** called when the user clicked the edit button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::editClicked()
{
	//clicked an item?
	if (landscapesList->currentItem() == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an item in the list first!"));
		return;
	}
	
	//set the selected item as selectedLandscape
	selectedLandscape = landscapesList->currentText();

	//close the modal window
	close();
}

/****************************************************************************
** LoadGUI renameClicked
**
** called when the user clicked the rename button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::renameClicked()
{
	//clicked an item?
	if (landscapesList->currentItem() == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an item in the list first!"));
		return;
	}

	//get the selected text
	QString toRename = landscapesList->currentText();

	//get the text from input dialog
	bool ok = FALSE;
	QString newName = QInputDialog::getText(tr("ScapeMaker"),tr("New name of landscape?"), toRename, &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newName.isNull() || newName.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name"));
		return;
	}

	//directory already exist?
	QFileInfo fileInfo("./landscapes/"+newName);
	if (fileInfo.exists() && fileInfo.isDir())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Directory already exists!\nPlease choose another name."));
		return;
	}

	//rename the directory
	QDir("./landscapes").rename(toRename,newName);

	//remove the landscape from gui-list
	landscapesList->removeItem(landscapesList->currentItem());

	//add the new item to the gui-list
	landscapesList->insertItem(newName);

	//select item in gui-list
	landscapesList->setSelected(landscapesList->count()-1,true);
}

/****************************************************************************
** LoadGUI exportClicked
**
** called when the user clicked the export button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::exportClicked()
{
	//clicked an item?
	if (landscapesList->currentItem() == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an item in the list first!"));
		return;
	}

	//get the name of the archive
    QString archiveFileName = QFileDialog::getSaveFileName(QString::null, "*.zip",this);

	//cancel clicked
	if (archiveFileName.isEmpty()) return;

	//archive already exist
	QFileInfo fileInfo(archiveFileName);
	if (fileInfo.exists() && fileInfo.isFile())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Archive already exists!\nPlease choose another file."));
		return;
	}

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//not the right extension?
	if (fileInfo.extension() != "zip")
		archiveFileName += ".zip";

	//get the selected text
	QString toExport = landscapesList->currentText();

	//create archive
	CZipArchive zipArchive;
	zipArchive.Open(archiveFileName.latin1(),CZipArchive::OpenMode::zipCreate);
	
	//add files
	QString rootDirectory = "./landscapes/"+toExport+"/";
	
	//all files of the root directory
	QString currentFile = "clouds.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "enviroment.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "objects.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "texture.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "topografie.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "water.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());

	//all terrain textures (and masks)
	currentFile = "textures";
	GUIHelpers::addDirToArchive(&zipArchive,rootDirectory+currentFile,currentFile);

	//all objects additional files (masks)
	currentFile = "objects";
	GUIHelpers::addDirToArchive(&zipArchive,rootDirectory+currentFile,currentFile);

	//add heightmap
	currentFile = "engine/heightmap.png";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/heightmap_tmp.png";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());

	//add minimap
	currentFile = "engine/minimap.jpg";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());

	//add wavestexture
	currentFile = "engine/waves.dds";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());

	//add detailmap
	currentFile = "engine/detailmap.jpg";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());

	//add settings files
	currentFile = "engine/clouds.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/dust.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/heightbasedfog.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/heightmap.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/rivers.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/sea.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/sky.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());
	currentFile = "engine/water.txt";
	zipArchive.AddNewFile((rootDirectory+currentFile).latin1(),currentFile.latin1());


	//all objects from engine directory
	QDir objectPath = rootDirectory+"engine/objects/";
	const QList<QFileInfo> *fileInfoListOrg = objectPath.entryInfoList();
	QList<QFileInfo> fileInfoList = *fileInfoListOrg;
	for (uint i=0;i<fileInfoList.count();i++)
	{
		QFileInfo *fileInfo=fileInfoList.at(i);

		//add only object directories
		if (fileInfo->isDir())
		{
			//ignore the . and .. dir
			if ((fileInfo->fileName() == ".") ||
				(fileInfo->fileName() == "..")) continue;

			//add all files from this directory
			currentFile = "engine/objects/"+fileInfo->fileName();
			GUIHelpers::addDirToArchive(&zipArchive,rootDirectory+currentFile,currentFile);
		}
	}	
	
	zipArchive.Close();

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();
}

/****************************************************************************
** LoadGUI importClicked
**
** called when the user clicked the import button
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::importClicked()
{
	//ask the user to select the archive
	QString archiveFileName = QFileDialog::getOpenFileName(QString::null, "*.zip", this);

	//user cancel dialog?
    if (archiveFileName.isEmpty()) return;

	//try load archive
	CZipArchive zipArchive;
	try
	{
		zipArchive.Open(archiveFileName.latin1(),CZipArchive::OpenMode::zipOpenReadOnly);
	}
	catch (CZipException  err)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't open archive!"));
		return;
	}
	QFileInfo fileInfo(archiveFileName);

	//let user choose a name for the landscape
	bool ok = FALSE;
	QString newLandscape = QInputDialog::getText(tr("ScapeMaker"),tr("Name of landscape?"), fileInfo.baseName(), &ok, this );

	//the user cancel the dialog
	if (!ok)
	{
		zipArchive.Close();
		return;
	}

	//no name written?
	if (newLandscape.isNull() || newLandscape.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name"));
		zipArchive.Close();
		return;
	}

	//directory already exist?
	QFileInfo fileInfo2("./landscapes/"+newLandscape);
	if (fileInfo2.exists() && fileInfo2.isDir())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Directory already exists!\nPlease choose another name."));
		zipArchive.Close();
		return;
	}

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//create directory tree
	GUIHelpers::createLandscapeDirectories(this,newLandscape,true);
	QFileInfo destPathInfo("./landscapes/"+newLandscape);

	//get indexes of all files
	CZipStringArray names;
	CZipWordArray indexes;
	zipArchive.GetIndexes(names,indexes);  

	//extract files
	for (int i=0;i<zipArchive.GetCount();i++)
		zipArchive.ExtractFile(i,destPathInfo.absFilePath());

	zipArchive.Close();

	//add the item to the gui-list
	landscapesList->insertItem(newLandscape);

	//select item in gui-list
	landscapesList->setSelected(landscapesList->count()-1,true);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();
}


/****************************************************************************
** LoadGUI landscapeSelected
**
** called when the user clicked on a landscape in landscape-list
**  
** Author: Dirk Plate
****************************************************************************/

void LoadGUI::landscapeSelected(QListBoxItem* pItem)
{
	//get path to landscape
	QString projectPath = "./landscapes/"+pItem->text();

	//load preview or heightmap
	CxImage hMap;
	//try to load minimap
	if (!hMap.Load(projectPath+"/engine/minimap.jpg"))
	{
		//try to load heightmap instead
		if (!hMap.Load(projectPath+"/engine/heightmap.png"))
		{
			//if file not exist, dont something heightmap
			hMapPreview->setText(tr("<error>"));
			length->setText("-");
			width->setText("-");
			return;
		}
	}
	
	//show the heightmap in bitmapNav
	QPixmap pixmap;
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(hMap));
	hMapPreview->setPixmap(pixmap);

	//show attributs
	length->setText(QString("%1px").arg(hMap.GetHeight()));
	width->setText(QString("%1px").arg(hMap.GetWidth()));
}
