/****************************************************************************
** LoadGUI
**
** load or create a landscape
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "loadguibase.h"
#include "qstringlist.h"
#include "qfile.h"
#include "qfileinfo.h"
#include "qlistbox.h"
#include "qmessagebox.h"
#include "qlineedit.h"
#include "qdir.h"
#include "qimage.h"
#include "qlabel.h"
#include "qinputdialog.h"
#include "qfiledialog.h"
#include "../common/guihelpers.h"
#include "ZipArchive.h"
#include "qapplication.h"


class LoadGUI : public LoadGUIBase
{
	Q_OBJECT
public:
	LoadGUI( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags f = 0 );
	QString getSelectedLandscape();

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);

public slots:
    virtual void deleteClicked();
    virtual void duplicateClicked();
    virtual void newClicked();
    virtual void editClicked();
    virtual void renameClicked();
	virtual void exportClicked();
	virtual void importClicked();
	virtual void landscapeSelected( QListBoxItem* );

public:
	QString selectedLandscape;

};

