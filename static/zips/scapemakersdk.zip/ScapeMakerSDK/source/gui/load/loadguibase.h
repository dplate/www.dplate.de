/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\load\loadguibase.ui'
**
** Created: Sun Feb 13 15:03:33 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef LOADGUIBASE_H
#define LOADGUIBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QGroupBox;
class QLabel;
class QListBox;
class QListBoxItem;
class QPushButton;

class LoadGUIBase : public QDialog
{ 
    Q_OBJECT

public:
    LoadGUIBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~LoadGUIBase();

    QGroupBox* infoGroup;
    QLabel* heightLabel;
    QLabel* widthLabel;
    QLabel* width;
    QLabel* length;
    QLabel* hMapPreview;
    QListBox* landscapesList;
    QPushButton* newButton;
    QPushButton* duplicateButton;
    QPushButton* renameButton;
    QPushButton* deleteButton;
    QPushButton* importButton;
    QPushButton* exportButton;
    QPushButton* editButton;

public slots:
    virtual void deleteClicked();
    virtual void duplicateClicked();
    virtual void editClicked();
    virtual void exportClicked();
    virtual void importClicked();
    virtual void landscapeSelected( QListBoxItem* );
    virtual void newClicked();
    virtual void renameClicked();

};

#endif // LOADGUIBASE_H
