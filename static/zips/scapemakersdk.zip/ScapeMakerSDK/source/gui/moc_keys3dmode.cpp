/****************************************************************************
** Keys3DMode meta object code from reading C++ file 'keys3dmode.h'
**
** Created: Sun Feb 13 15:03:29 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_Keys3DMode
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "keys3dmode.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *Keys3DMode::className() const
{
    return "Keys3DMode";
}

QMetaObject *Keys3DMode::metaObj = 0;

void Keys3DMode::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("Keys3DMode","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString Keys3DMode::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("Keys3DMode",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* Keys3DMode::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"Keys3DMode", "QDialog",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
