/****************************************************************************
** ScapeMakerDialog meta object code from reading C++ file 'scapemakerdialog.h'
**
** Created: Sun Feb 13 15:03:34 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_ScapeMakerDialog
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "scapemakerdialog.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *ScapeMakerDialog::className() const
{
    return "ScapeMakerDialog";
}

QMetaObject *ScapeMakerDialog::metaObj = 0;

void ScapeMakerDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(ScapeMakerDialogBase::className(), "ScapeMakerDialogBase") != 0 )
	badSuperclassWarning("ScapeMakerDialog","ScapeMakerDialogBase");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString ScapeMakerDialog::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("ScapeMakerDialog",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* ScapeMakerDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) ScapeMakerDialogBase::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(ScapeMakerDialog::*m1_t0)();
    typedef void(ScapeMakerDialog::*m1_t1)();
    typedef void(ScapeMakerDialog::*m1_t2)();
    typedef void(ScapeMakerDialog::*m1_t3)();
    typedef void(ScapeMakerDialog::*m1_t4)();
    typedef void(ScapeMakerDialog::*m1_t5)();
    typedef void(ScapeMakerDialog::*m1_t6)();
    typedef void(ScapeMakerDialog::*m1_t7)();
    m1_t0 v1_0 = Q_AMPERSAND ScapeMakerDialog::selectLandscapeClicked;
    m1_t1 v1_1 = Q_AMPERSAND ScapeMakerDialog::configClicked;
    m1_t2 v1_2 = Q_AMPERSAND ScapeMakerDialog::manualClicked;
    m1_t3 v1_3 = Q_AMPERSAND ScapeMakerDialog::tutorialClicked;
    m1_t4 v1_4 = Q_AMPERSAND ScapeMakerDialog::websiteClicked;
    m1_t5 v1_5 = Q_AMPERSAND ScapeMakerDialog::infoClicked;
    m1_t6 v1_6 = Q_AMPERSAND ScapeMakerDialog::keys3DModeClicked;
    m1_t7 v1_7 = Q_AMPERSAND ScapeMakerDialog::exitClicked;
    QMetaData *slot_tbl = QMetaObject::new_metadata(8);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(8);
    slot_tbl[0].name = "selectLandscapeClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "configClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "manualClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "tutorialClicked()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "websiteClicked()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "infoClicked()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "keys3DModeClicked()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "exitClicked()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"ScapeMakerDialog", "ScapeMakerDialogBase",
	slot_tbl, 8,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
