/****************************************************************************
** ObjectGen
**
** The objectsgenerator class
**
** Author: Dirk Plate
****************************************************************************/

#include "objectgen.h"
#include "math.h"
#include <time.h>		//F�rs Random
#include "../../engine/common/enginehelpers.h"

/****************************************************************************
** ObjectGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

ObjectGen::ObjectGen()
{
	distribution = false;
}

/****************************************************************************
** ObjectGen generate
**
** starts the generation of the object distribution
**
** Author: Dirk Plate
****************************************************************************/

void ObjectGen::generateDistributionPreview(Heightmap *pHeightMapSet, CxImage *pDistributionBitmapSet,
	OneObject *parameter)
{
	//stop a old thread
	cancel();

	//save all settings intern
	pHeightMap = pHeightMapSet;
	pDistributionBitmap = pDistributionBitmapSet;
	currentParameter = parameter;
	parameter->heightSmoothRange =
		(int)((float)MAXHEIGHTSMOOTHRANGE*((float)currentParameter->smoothness/100.0f));
	parameter->slopeSmoothRange =
		(int)((float)MAXSLOPESMOOTHRANGE*((float)currentParameter->smoothness/100.0f));

	//this is only the distribution preview
	distribution = true;

	//start the generate thread
	start();
}

/****************************************************************************
** ObjectGen generate
**
** starts the generation of the objects
**
** Author: Dirk Plate
****************************************************************************/

void ObjectGen::generate(Heightmap *pHeightMapSet, int *pProgressSet, CxImage *pPreviewBitmapSet, 
		OneObject *parameter)
{
	//save all settings intern
	pHeightMap = pHeightMapSet;
	pProgress = pProgressSet;
	pPreviewBitmap = pPreviewBitmapSet;
	currentParameter = parameter;
	parameter->heightSmoothRange = 
		(int)((float)MAXHEIGHTSMOOTHRANGE*((float)currentParameter->smoothness/100.0f));
	parameter->slopeSmoothRange = 
		(int)((float)MAXSLOPESMOOTHRANGE*((float)currentParameter->smoothness/100.0f));
	
	//we are postioning to objects
	distribution = false;

	//start the generate thread
	start();
}

/****************************************************************************
** ObjectGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void ObjectGen::cancel()
{
	//set flag true, so the thread will stop
	if (running()) cancelFlag = true;
}

/****************************************************************************
** ObjectGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void ObjectGen::run()
{
	//init cancel-flag
	cancelFlag = false;

	if (distribution) doDistributionPreview();
	else doGeneration();
}

/****************************************************************************
** ObjectGen doDistribution
**
** this is the real generation of the distribution
**
** Author: Dirk Plate
****************************************************************************/

void ObjectGen::doDistributionPreview()
{
	int x,y;
	int height;
	float slope;
	float propability;
	float mask;
	float maskX, maskY;
	int heightMapSize = pHeightMap->getSize();
	RGBQUAD color;
	color.rgbRed = 255;
	color.rgbGreen = 0;
	color.rgbBlue = 0;

	for (y=0;y<heightMapSize;y++)
		for (x=0;x<heightMapSize;x++)
	{
		if (cancelFlag) return;
		
		//retrieve ground parameters
		height = pHeightMap->getHeightInMeters(x,y);
		slope = pHeightMap->getSlope(x,y);

		//retrieve mask value
		maskX = (float)(x*currentParameter->maskBitmap.GetWidth())/pHeightMap->getSize();
		maskY = (float)(y*currentParameter->maskBitmap.GetHeight())/pHeightMap->getSize();
		mask = getInterpolatedMaskValue(maskX, maskY);
		
		//calculate the intensity
		propability = getObjectProbability(height,slope,mask);

		//add the density factor
		propability *= ((float)currentParameter->density)/100.0f;

		//set this pixel in the distribution bitmap
		color.rgbReserved = (int)(propability*255);
		pDistributionBitmap->SetPixelColor(x,y,color,true);
	}
}

/****************************************************************************
** ObjectGen doGeneration
**
** this is the real positioning of the objects
**
** Author: Dirk Plate
****************************************************************************/

void ObjectGen::doGeneration()
{
	int j;
	float height;
	float slope;
	float propability;
	float x,y;
	float progressValue;
	int previewX, previewY;
	int tries;
	int randValue;
	int densityFactor;
	int maxSize = pHeightMap->getSize();
	float maskX,maskY;
	float mask;
	RGBQUAD red;
	red.rgbRed = 255;
	red.rgbGreen = 0;
	red.rgbBlue = 0;
	red.rgbReserved = 255;

	densityFactor = int((((float)maxSize)/256.0f)+0.5f);

	*pProgress = 0;
	exactProgress = 0.0f;

	//init random generator
	srand((unsigned)time(NULL));

	//calculate current segment in mask
	currentParameter->maskFactorX = (float)(currentParameter->maskBitmap.GetWidth())/maxSize;
	currentParameter->maskFactorY = (float)(currentParameter->maskBitmap.GetHeight())/maxSize;

	//calculate the number of tries
	tries = MAXOBJECTSETTRIES*densityFactor*densityFactor*(((float)currentParameter->density)/100.0f);
	
	//calculate the progress value
	progressValue=100.0f/((float)tries);

	//prepare positions field
	if (currentParameter->count > 0)
	{
		if (currentParameter->positions != NULL)
			delete [] currentParameter->positions;
	}
	currentParameter->count = 0;
	currentParameter->positions = new OneObject::OnePosition[tries];

	//try to set object
	for (j=0;j<tries;j++)
	{
		if (cancelFlag) return;

		//retrieve a random position
		x = ((float)(rand()*(maxSize-3)))/((float)RAND_MAX);
		y = ((float)(rand()*(maxSize-3)))/((float)RAND_MAX);
		x += 1.0f;
		y += 1.0f;
		if (x > (maxSize-2))
			x = maxSize-2;
		if (x < 1.0f) x = 1.0f;
		if (y > (maxSize-2))
			y = maxSize-2;
		if (y < 1.0f) y = 1.0f;

		//get terrain parameters
		height = pHeightMap->getInterpolatedHeightInMetersSmooth(x,y);
		slope = pHeightMap->getInterpolatedSlopeSmooth(x,y);

		//calculate coordinate on mask
		maskX = (currentParameter->maskFactorX*x)-0.5f;
		maskY = (currentParameter->maskFactorY*y)-0.5f;

		//retrieve mask value
		mask = getInterpolatedMaskValue(maskX, maskY);

		//get propability for this terrain
		propability = getObjectProbability(height, slope, mask);

		//set object or not?
		randValue = rand();
		if (randValue < propability*((float)RAND_MAX))
		{
			//calculate coordinate on preview bitmap
			previewX = (int)((x*((float)pPreviewBitmap->GetWidth()))/((float)maxSize));
			previewY = (int)((y*((float)pPreviewBitmap->GetHeight()))/((float)maxSize));
			if (previewX > pPreviewBitmap->GetWidth()-1)
				previewX = pPreviewBitmap->GetWidth()-1;
			if (previewX < 0) previewX = 0;
			if (previewY > pPreviewBitmap->GetHeight()-1)
				previewY = pPreviewBitmap->GetHeight()-1;
			if (previewY < 0) previewY = 0;

			pPreviewBitmap->SetPixelColor(previewX,previewY,red,true);

			//save position in list
			currentParameter->positions[currentParameter->count].x = x;
			currentParameter->positions[currentParameter->count].y = y;

			//make a random rotation
			currentParameter->positions[currentParameter->count].rotation =
				((float)rand())/((float)RAND_MAX)*2*3.1415926535897932384626433832795f;

			//make a random scale
			float minScale = ((float)currentParameter->minimalScale)/100.0f;
			float scaleRange = ((float)(currentParameter->maximalScale-currentParameter->minimalScale))/100.0f;
			currentParameter->positions[currentParameter->count].scale = minScale+
				((float)rand())/((float)RAND_MAX)*scaleRange;

			currentParameter->count++;
		}

		//set progress
		exactProgress += progressValue;
		*pProgress = (int)exactProgress;
	}
	
	*pProgress = 100;
}

/****************************************************************************
** ObjectGen getObjectProbability
**
** returns the probability for an object on this ground parameters
**
** Author: Dirk Plate
****************************************************************************/

float ObjectGen::getObjectProbability(int height, float slope, float mask)
{
	int heightDiff;
	int slopeDiff;
	int slopeDegree;
	float heightIntensity;
	float slopeIntensity;
	float intensity;

	//convert slope (arc) to slope (deg)
	slopeDegree = (int)(slope/(3.1415926535897932384626433832795f)*180.0f);
	
	//calculate the intensity for height only
	if ((height >= currentParameter->lowestHeight) &&
		(height <= currentParameter->highestHeight)) heightIntensity = 1.0f;
	else
	{
		if (height < currentParameter->lowestHeight) 
			heightDiff = currentParameter->lowestHeight-height;
		else heightDiff = height-currentParameter->highestHeight;
		//pixel is in soft border area of height
		if (heightDiff <= currentParameter->heightSmoothRange)
			heightIntensity = 1.0f-((float)heightDiff/(float)currentParameter->heightSmoothRange);
		else heightIntensity = 0.0f;
	}

	//calculate the intensity for slope only
	if ((slopeDegree >= currentParameter->flattestSlope) &&
		(slopeDegree <= currentParameter->steepestSlope)) slopeIntensity = 1.0f;
	else
	{
		if (slopeDegree < currentParameter->flattestSlope) 
			slopeDiff = currentParameter->flattestSlope-slopeDegree;
		else slopeDiff = slopeDegree-currentParameter->steepestSlope;
		//pixel is in soft border area of slope
		if (slopeDiff <= currentParameter->slopeSmoothRange)
			slopeIntensity = 1.0f-((float)slopeDiff/(float)currentParameter->slopeSmoothRange);
		else slopeIntensity = 0.0f;
		
	}

	//take the lowest intensity
	if (heightIntensity < slopeIntensity)
		intensity = heightIntensity;
	else intensity = slopeIntensity;

	//multiply with mask value
	intensity *= mask;

	//be sure a small mask value will return 0
	if (mask < SMALL_NUM)
		intensity = 0.0f;
	
	//return value
	return intensity;
}

/****************************************************************************
** TextureGen getInterpolatedMaskValue
**
** returns a interpolated value of mask bitmap
**
** Author: Dirk Plate
****************************************************************************/

float ObjectGen::getInterpolatedMaskValue(float x, float y)
{
	//no negative values!
	if (x < 0.0f) x = 0.0f;
	if (y < 0.0f) y = 0.0f;

	float strengthLeftTop;
	float strengthRightTop;
	float strengthLeftBottom;
	float strengthRightBottom;
	int xInt = int(x);
	int yInt = int(y);
	bool lastCol = false;
	if (xInt >= currentParameter->maskBitmap.GetWidth()-1) lastCol = true;
	bool lastRow = false;
	if (yInt >= currentParameter->maskBitmap.GetHeight()-1) lastRow = true;

	//get strength from all edges around this point
	EngineHelpers::getInterpolationStrengths(x, y,&strengthLeftTop, &strengthRightTop, &strengthLeftBottom, &strengthRightBottom);

	//get values from edges
	float valueLeftTop = currentParameter->maskBitmap.GetPixelGray(xInt, yInt);
	
	float valueRightTop = valueLeftTop;
	if (!lastCol) 
		valueRightTop = currentParameter->maskBitmap.GetPixelGray(xInt+1, yInt);

	float valueLeftBottom = valueLeftTop;
	if (!lastRow) 
		valueLeftBottom = currentParameter->maskBitmap.GetPixelGray(xInt, yInt+1);

	float valueRightBottom = valueLeftBottom;
	if (!lastCol && !lastRow) 
		valueRightBottom = currentParameter->maskBitmap.GetPixelGray(xInt+1, yInt+1);
	
	//calculate mean value
	float valueMiddle = (strengthLeftTop*valueLeftTop+
						 strengthRightTop*valueRightTop+
						 strengthLeftBottom*valueLeftBottom+
						 strengthRightBottom*valueRightBottom);

	//return value between 0 and 1
	return valueMiddle/256.0f;
}