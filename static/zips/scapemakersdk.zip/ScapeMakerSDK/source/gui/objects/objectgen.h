/****************************************************************************
** ObjectGen
**
** The object generator class
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include <qthread.h>
#include <stdlib.h>
#include <time.h>
#include "../../engine/terrain/heightmap.h"
#include "../../engine/terrain/terraintile.h"
#include "ximage.h"

#define MAXHEIGHTSMOOTHRANGE 500	//how many meters will the smoothness at 100% reach
#define MAXSLOPESMOOTHRANGE 30		//how many degree will the smoothness at 100% reach
#define MAXOBJECTSETTRIES 25000.0f	//how many tries mean density of 100%

//all attributes of one object
struct OneObject
{
	struct OnePosition
	{
		float x;
		float y;
		float rotation;
		float scale;
	};

	QString name;
	QString orgName;
	CxImage maskBitmap;
	float maskFactorX;
	float maskFactorY;
	enum Types{STATIC,DYNAMIC} type;
	int lowestHeight;
	int highestHeight;
	int flattestSlope;
	int steepestSlope;
	int smoothness;
	int density;
	int minimalScale;
	int maximalScale;
	int heightSmoothRange;
	int slopeSmoothRange;
	int distributionType;
	OnePosition *positions;	//the positions of this object (only for type STATIC)
	CxImage positionsBitmap;//the position distribution    (only for type DYNAMIC)
	int count;				//how many positions of this objects are set
	int newPositionData;
};

class ObjectGen : public QThread
{
public:
	ObjectGen();

	void generateDistributionPreview(Heightmap *pHeightMapSet, CxImage *pDistributionBitmapSet,
		OneObject *parameter);
	void generate(Heightmap *pHeightMapSet, int *pProgressSet, CxImage *pPreviewBitmapSet, 
		OneObject *parameter);
	void cancel();

protected:
	virtual void run();

private:
	void doDistributionPreview();	//the real generation of the distribution
	void doGeneration();			//the real generation of the object
	float getObjectProbability(int height,float slope, float mask);	//calculate the intensity of the texture on this ground
	float getInterpolatedMaskValue(float x, float y);

	int *pProgress;
	float exactProgress;
	Heightmap *pHeightMap;		//pointer to heighmap class
	bool cancelFlag;			//is true, if the generate-thread should stop

	CxImage *pPreviewBitmap;		//the generated distribution-preview
	CxImage *pDistributionBitmap;	//the distribution-preview
	bool distribution;				//making the distributionpreview or the real texture?

	//all attributes need for generation
	OneObject *currentParameter;
};
