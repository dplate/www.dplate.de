/****************************************************************************
** ObjectsGUI
**
** the objects-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#include "objectsgui.h"
#include "../common/guihelpers.h"
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include "../common/maskimportgui.h"

/****************************************************************************
** ObjectsGUI Constructor
**
** initialise vars
**  
** Author: Dirk Plate
****************************************************************************/

ObjectsGUI::ObjectsGUI( QWidget* parent, const char* name, WFlags f )
	: ObjectsGUIBase(parent, name, f)
{
    connect( manualDistribution, SIGNAL(toggled(bool)), bitmapNavContainer, SLOT(setPenButtonEnable(bool)));
	connect( manualDistribution, SIGNAL(toggled(bool)), bitmapNavContainer, SLOT(setRubberButtonEnable(bool)));
	connect( bitmapNavContainer, SIGNAL(positionWithPenClicked(QPoint)), this, SLOT(newManualPosition(QPoint)));
	connect( bitmapNavContainer, SIGNAL(positionWithRubberClicked(QPoint)), this, SLOT(deleteManualPosition(QPoint)));

	objectsCount=0;
	currentObject=-1;
	pHeightMap = NULL;
	generatingDistributionTimer = false;
	generatingProgress = 0;
	generatingDistributionTimerID = -1;
	generatingObjectTimerID = -1;
	dontRecalculate = false;
	loadedExpert = false;

	cancelButton->hide();	//hide the cancel button
}

/****************************************************************************
** ObjectsGUI setProjectPath
**
** set the current project
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}

/****************************************************************************
** ObjectsGUI addClicked
**
** called when the add button is clicked -> add a object to list
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::addClicked()
{
	int i;
	OneObject newObject;
	
	//show the file-dialog
	QString file = QFileDialog::getOpenFileName("./objects", "settings.txt", 
		this, tr("Select Object"), tr("ScapeMaker"));
    
	//canceled
	if (file.isNull()) return;

	//check if settings.txt is valid
	if (!checkSettingsFile(file))
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("This is not a valid object!\nPlease check the \"settings.txt\""));
		return;
	}

	//get the text from input dialog
	bool ok = FALSE;
	QFileInfo fileInfo(file);
	newObject.name = QInputDialog::getText(tr("ScapeMaker"),tr("Name of object?"), 
		fileInfo.dir().dirName(), &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newObject.name.isNull() || newObject.name.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name"));
		return;
	}

	//object with this name already exists?
	for (i=0;i<objectsCount;i++)
	{
		if (objects[i].name == newObject.name)
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Object with this name already exists!\nPlease choose another name."));
			return;
		}	
	}

	//directory already exists?
	QFileInfo fileInfo2(projectPath+"/engine/objects/"+newObject.name);
	if (fileInfo2.exists() && fileInfo2.isDir())
	{
		//directory is not empty?
		QDir fileInfoDir = fileInfo2.dir();
		fileInfoDir.cd(newObject.name);
		if (fileInfoDir.entryInfoList("*.*",QDir::Files)->count() > 0)	
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("The directory \"%1\" already exists!\nPlease delete it and try again, or choose another name.").arg(projectPath+"/engine/objects/"+newObject.name));
			return;
		}
		
	}
	else
	{
		//create directory
		QDir newDirectory;
		if (!newDirectory.mkdir(projectPath+"/engine/objects/"+newObject.name))
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}
	
	//get directory of string
	QDir orgNameDir(file);
	orgNameDir.cdUp();
	QString directory = orgNameDir.absPath();

	//copy this directory to project dir
	GUIHelpers::copyDir(directory,projectPath+"/engine/objects/"+newObject.name);

	//set the rest of the values to default
	initObject(newObject);

	//create default file
	newObject.maskBitmap.Create(256,256,24);
	newObject.maskBitmap.Clear(0xff);

	//save this image in project dir
	newObject.maskBitmap.Save(projectPath+"/objects/"+newObject.name+"_mask.png",CXIMAGE_FORMAT_PNG);

	int index=addObject(newObject);

	if (objectsCount == 1)
	{
		//unhide all gui elements for object
		hideObjectGUIElements(false);
	}

	//get the type of the object (static or dynamic)
	if (!getObjectType(index)) return;
	
	//select the new object
	objectList->setSelected(index,true);

	//show type text in gui
	typeTextLabel->setText(getTypeText(objects[currentObject].type));

	//save the original name
	objects[currentObject].orgName = orgNameDir.dirName();

	//show orginal name in gui
	orgNameLabel->setText(objects[currentObject].orgName);
}

/****************************************************************************
** ObjectsGUI removeClicked
**
** called when the remove button is clicked -> remove a object from list
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::removeClicked()
{
	int index = objectList->currentItem();

	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an object in the list first!"));
		return;
	}

	//get the selected text
	QString toDelete = objectList->currentText();

	//ask the user if delete
	if(QMessageBox::warning (this, tr("ScapeMaker"), tr("Delete object")+" \""+toDelete+"\"?", 
				tr("Yes"), tr("No"), QString::null, 1) != 0) return;

	//delete object on hard disc
	GUIHelpers::deleteDir(projectPath+"/engine/objects/"+objects[index].name);

	//delete not good?
	QFileInfo fileInfo(projectPath+"/engine/objects/"+objects[index].name);
	if (fileInfo.exists() && fileInfo.isDir())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't delete directory \"%1\"!\nPlease remove it to avoid further errors.").arg(projectPath+"/engine/objects/"+objects[index].name));
	}

	QDir path(projectPath+"/objects/");
	path.remove(objects[index].name+"_mask.png");

	//delete position array
	if (objects[index].positions != NULL)
		delete [] objects[index].positions;
	
	//delete object
	//move all other up
	for (int i=index+1; i<objectsCount; i++)
		objects[i-1] = objects[i];
	objectsCount--;

	//remove object from gui-list
	objectList->removeItem(objectList->currentItem());

	if (objectsCount == 0)
	{
		//hide gui
		hideObjectGUIElements(true);
		currentObject = -1;
	}
	else
	{
		//select element below the removed one
		if (index < objectsCount)
			objectList->setSelected(index,true);
		else objectList->setSelected(objectsCount-1,true);
	}
}

/****************************************************************************
** ObjectsGUI renameClicked
**
** called when the rename button is clicked -> rename a object (and directory)
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::renameClicked()
{
	int i;
	int index = objectList->currentItem();

	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an object in the list first!"));
		return;
	}

	//get the selected text
	QString toRename = objectList->currentText();

	//ask the user for new name
	bool ok = FALSE;
	QString newName = QInputDialog::getText(tr("ScapeMaker"),tr("New name of object?"), toRename, &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newName.isNull() || newName.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name!"));
		return;
	}

	//object with this name already exist?
	for (i=0;i<objectsCount;i++)
	{
		if ((objects[i].name == newName) && (i != index))
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Object with this name already exists!\nPlease choose another name."));
			return;
		}	
	}

	//rename files
	QDir directory(projectPath+"/engine/objects/");
	if (!directory.rename(objects[index].name, newName))
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't rename object!"));
		return;
	}
	QDir directory2(projectPath+"/objects/");
	if (!directory2.rename(objects[index].name+"_mask.png", newName+"_mask.png"))
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't rename mask of object!"));
		return;
	}



	//rename name in list
	objectList->changeItem(newName,index);

	//rename object
	objects[index].name = newName;
}

/****************************************************************************
** ObjectsGUI editClicked
**
** called when the edit button is clicked -> open object settings file
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::editClicked()
{
	int index = objectList->currentItem();

	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select an object in the list first!"));
		return;
	}

	//get the selected text
	QString toEdit = projectPath+"/engine/objects/"+objectList->currentText()+"/settings.txt";

	//open file with default text editor
	if ((unsigned int)::ShellExecute(qApp->mainWidget()->winId(), NULL, toEdit, NULL, NULL, SW_SHOW) <= 32)
	{
		QMessageBox::critical(this, tr("Error"), tr("Unable to open a \"settings.txt\". Ensure that you have a text editor installed."));
	}
}


/****************************************************************************
** ObjectsGUI newManualPosition
**
** Is called, the user clicked a position with pen
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::newManualPosition(QPoint position)
{
	//transform position (y flip)
	position.setY(hMapBitmap.GetHeight()-1-position.y());

	OneObject::OnePosition *newPositions;

	//check if a good position
	if ((position.x() < 0) ||
		(position.x() >= hMapBitmap.GetWidth()-1) ||
		(position.y() < 0) ||
		(position.y() >= hMapBitmap.GetHeight()-1))
		return;

	//copy existing positions
	if (objects[currentObject].positions != NULL)
	{
		//create new array, one bigger
		newPositions = new OneObject::OnePosition[objects[currentObject].count+1];

		for (int i=0; i<objects[currentObject].count; i++)
			newPositions[i] = objects[currentObject].positions[i];

		//delete old array
		delete [] objects[currentObject].positions;
	}
	else
	{
		objects[currentObject].count = 0;
		newPositions = new OneObject::OnePosition[1];
	}

	//keep new array
	objects[currentObject].positions = newPositions;

	//add position to list
	objects[currentObject].positions[objects[currentObject].count].x = position.x();
	objects[currentObject].positions[objects[currentObject].count].y = position.y();
	objects[currentObject].positions[objects[currentObject].count].rotation = 
		((float)rand())/((float)RAND_MAX)*2*3.1415926535897932384626433832795f;
	objects[currentObject].positions[objects[currentObject].count].scale = 1.0f;

	//add some random jitter to position (not all position exactly on integer values)
	float jitterX=((float)(rand()))/((float)RAND_MAX);
	objects[currentObject].positions[objects[currentObject].count].x += jitterX;
	float jitterY=((float)(rand()))/((float)RAND_MAX);
	objects[currentObject].positions[objects[currentObject].count].y += jitterY;

	//paint point in distribution bitmap
	RGBQUAD color;
	color.rgbRed = 255;
	color.rgbGreen = 0;
	color.rgbBlue = 0;
	color.rgbReserved = 255;
	objectDistribution.SetPixelColor(position.x(),position.y(),color,true);

	//one position more now
	objects[currentObject].count++;

	//something changed
	objects[currentObject].newPositionData = true;

	//repaint preview
	createCurrentBitmap();

	//update count display
	countTextLabel->setText(QString("%1").arg(objects[currentObject].count));
}

/****************************************************************************
** ObjectsGUI deleteManualPosition
**
** Is called, the user clicked a position with rubber
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::deleteManualPosition(QPoint position)
{
	int i;
	
	//transform position (y flip)
	position.setY(hMapBitmap.GetHeight()-1-position.y());

	//find nearest position (because user cant click exactly one pixel)
	float bestDistance = (float)INT_MAX;
	int bestPosition = -1;
	for (i=0; i<objects[currentObject].count; i++)
	{
		float diffX = objects[currentObject].positions[i].x - position.x();
		float diffY = objects[currentObject].positions[i].y - position.y();
		float distance = sqrtf(diffX*diffX+diffY*diffY);
		if (distance < bestDistance)
		{
			bestDistance = distance;
			bestPosition = i;
		}
	}
	//no position found? -> do nothing
	if (bestPosition < 0)
		return;

	//position to far away
	if (bestDistance > 10.0f)
		return;

	//Ask user
	/*if(QMessageBox::warning (this, tr("ScapeMaker"), tr("Do you want to delete the position for this object?"), 
		tr("Yes"), tr("No"), QString::null, 1) != 0) return;*/

	//no other object on this position?
	for (i=0; i<objects[currentObject].count; i++)
	{
		if (((int)objects[currentObject].positions[i].x == 
			 (int)objects[currentObject].positions[bestPosition].x) &&
			((int)objects[currentObject].positions[i].y == 
			 (int)objects[currentObject].positions[bestPosition].y) &&
			(i != bestPosition))
			 break;
	}
	if (i >= objects[currentObject].count)
	{
		//paint point in distribution bitmap
		RGBQUAD color;
		color.rgbRed = 0;
		color.rgbGreen = 0;
		color.rgbBlue = 0;
		color.rgbReserved = 0;
		objectDistribution.SetPixelColor(
			objects[currentObject].positions[bestPosition].x,
			objects[currentObject].positions[bestPosition].y,color,true);
	}

	//overwrite position with last one
	objects[currentObject].positions[bestPosition] = 
		objects[currentObject].positions[objects[currentObject].count-1];

	//now one position less
	objects[currentObject].count--;

	//something changed
	objects[currentObject].newPositionData = true;

	//repaint preview
	createCurrentBitmap();

	//update count display
	countTextLabel->setText(QString("%1").arg(objects[currentObject].count));
}

/****************************************************************************
** ObjectsGUI clearClicked
**
** Is called, when if clear button in manual distribution is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::clearClicked()
{
	//Ask user
	if(QMessageBox::warning (this, tr("ScapeMaker"), tr("Do you want to clear all positions for this object?"), 
				tr("Yes"), tr("No"), QString::null, 1) != 0) return;

	//delete list
	if (objects[currentObject].count > 0)
	{
		if (objects[currentObject].positions != NULL)
			delete [] objects[currentObject].positions;

		objects[currentObject].positions = NULL;
		objects[currentObject].count = 0;
	}

	//recreate object distribution
	createObjectDistribution();

	//update count display
	countTextLabel->setText(QString("%1").arg(objects[currentObject].count));

	//new positionData now available
	objects[currentObject].newPositionData = true;
}

/****************************************************************************
** ObjectsGUI objectSelected
**
** Is called, when a object in the list was selected
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::objectSelected()
{
	//get index of selected item
	currentObject = objectList->currentItem();

	if (currentObject == -1) return;

	dontRecalculate = true;

	//update gui with new values
	//set all gui elements with more than one slider first to uncritical values (bug fix)
	int distributionTypeTmp = objects[currentObject].distributionType;
	int lowestHeightTmp = objects[currentObject].lowestHeight;
	int highestHeightTmp = objects[currentObject].highestHeight;
	int flattestSlopeTmp = objects[currentObject].flattestSlope;
	int steepestSlopeTmp = objects[currentObject].steepestSlope;
	int densityTmp = objects[currentObject].density;
	int smoothnessTmp = objects[currentObject].smoothness;
	int minimalScaleTmp = objects[currentObject].minimalScale;
	int maximalScaleTmp = objects[currentObject].maximalScale;
	
	heightSlider->setValue(0,heightSlider->getMinValue());
	heightSlider->setValue(1,heightSlider->getMaxValue());
	slopeSlider->setValue(0,slopeSlider->getMinValue());
	slopeSlider->setValue(1,slopeSlider->getMaxValue());
	densitySlider->setValue(0,densitySlider->getMinValue());
	smoothnessSlider->setValue(0,smoothnessSlider->getMinValue());
	scaleSlider->setValue(0,scaleSlider->getMinValue());
	scaleSlider->setValue(1,scaleSlider->getMaxValue());

	//set all gui elements to the new values
	distributionGroup->setButton(distributionTypeTmp);
	heightSlider->setValue(0,lowestHeightTmp);
	heightSlider->setValue(1,highestHeightTmp);
	slopeSlider->setValue(0,flattestSlopeTmp);
	slopeSlider->setValue(1,steepestSlopeTmp);
	densitySlider->setValue(0,densityTmp);
	smoothnessSlider->setValue(0,smoothnessTmp);
	scaleSlider->setValue(0,minimalScaleTmp);
	scaleSlider->setValue(1,maximalScaleTmp);
	
	orgNameLabel->setText(objects[currentObject].orgName);
	typeTextLabel->setText(getTypeText(objects[currentObject].type));

	//Update mask image
	QImage image = GUIHelpers::convertCxImageToQImage(objects[currentObject].maskBitmap);
	QPixmap pixmap;
	pixmap.convertFromImage(image);
	maskView->setPixmap(pixmap);

	//change things, if manual
	if (manualDistribution->isChecked())
	{
		bitmapNavContainer->setPenButtonEnable(true);
		bitmapNavContainer->setRubberButtonEnable(true);
	}
	else 
	{
		bitmapNavContainer->setPenButtonEnable(false);
		bitmapNavContainer->setRubberButtonEnable(false);
	}

	//change things, if dynamic
	if (objects[currentObject].type == OneObject::DYNAMIC)
	{
		distributionGroup->setEnabled(false);
		generateButton->setEnabled(false);
		countTextLabel->setText(QString()+QChar(0x221E));
	}
	else 
	{
		distributionGroup->setEnabled(true);
		generateButton->setEnabled(true);
		
		//set count display to right value
		countTextLabel->setText(QString("%1").arg(objects[currentObject].count));
	}

	dontRecalculate = false;

	//generate the distribution
	createObjectDistribution();
}


/****************************************************************************
** ObjectsGUI importClicked
**
** Is called, when the import button is clicked
**  
** Author: Dirk Plate
****************************************************************************/
void ObjectsGUI::importObjectClicked()
{
	//show the file-dialog
	QString file = QFileDialog::getOpenFileName("./objects", "settings.txt", 
		this, tr("Select Object"), tr("ScapeMaker"));
    
	//canceled
	if (file.isNull()) return;

	//check if settings.txt is valid
	if (!checkSettingsFile(file))
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("This is not a valid object!\nPlease check the \"settings.txt\""));
		return;
	}

	//if not already loaded... load positions to backup
	if (objects[currentObject].positions == NULL)
		loadPositions(objects[currentObject]);
	
	//get directory of string
	QDir orgNameDir(file);
	orgNameDir.cdUp();
	QString directory = orgNameDir.absPath();
	
	//delete old directory
	GUIHelpers::deleteDir(projectPath+"/engine/objects/"+objects[currentObject].name);

	//directory exists?
	QFileInfo fileInfo2(projectPath+"/engine/objects/"+objects[currentObject].name);
	if (fileInfo2.exists() && fileInfo2.isDir())
	{
		//directory is not empty?
		QDir fileInfoDir = fileInfo2.dir();
		fileInfoDir.cd(objects[currentObject].name);
		if (fileInfoDir.entryInfoList("*.*",QDir::Files)->count() > 0)	
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Can't remove directory \"%1\"!\nYou have to remove the object and to add it again to avoid further errors.").arg(projectPath+"/engine/objects/"+objects[currentObject].name));
			return;
		}
	}
	else
	{
		//create directory again
		QDir newDirectory;
		if (!newDirectory.mkdir(projectPath+"/engine/objects/"+objects[currentObject].name))
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Can't create directory!"));
			return;
		}
	}
		
	//copy this directory to project dir
	GUIHelpers::copyDir(directory,projectPath+"/engine/objects/"+objects[currentObject].name);

	//get the type of the object (static or dynamic)
	if (!getObjectType()) return;
		
	//show type text in gui
	typeTextLabel->setText(getTypeText(objects[currentObject].type));

	//save the original name
	objects[currentObject].orgName = orgNameDir.dirName();

	//show orginal name in gui
	orgNameLabel->setText(objects[currentObject].orgName);

	//set new position data... so old data is written again
	objects[currentObject].newPositionData = true;
}

/****************************************************************************
** ObjectsGUI importMaskClicked
**
** Is called, when the import button in mask group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::importMaskClicked()
{
	//show the import mask dialog
	MaskImportGUI dialog(this, "maskImportGUI", true, WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu | WStyle_ContextHelp,
		objects[currentObject].maskBitmap);
	dialog.show();

	//user clicked ok?
	if (!dialog.isCanceled())
	{
		//copy result
		objects[currentObject].maskBitmap = dialog.getResult();
		
		//save this image in project dir
		objects[currentObject].maskBitmap.Save(
			projectPath+"/objects/"+objects[currentObject].name+"_mask.png",CXIMAGE_FORMAT_PNG);

		//show the preview of texture
		QImage image = GUIHelpers::convertCxImageToQImage(objects[currentObject].maskBitmap);
		QPixmap pixmap;
		pixmap.convertFromImage(image);
		maskView->setPixmap(pixmap);

		//update distribution
		valuesChanged();
	}
}


/****************************************************************************
** ObjectsGUI resetMaskClicked
**
** Is called, when the reset button in mask group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::resetMaskClicked()
{
	//create default file
	objects[currentObject].maskBitmap.Create(256,256,24);
	objects[currentObject].maskBitmap.Clear(0xff);

	//save this image in project dir
	objects[currentObject].maskBitmap.Save(
		projectPath+"/objects/"+objects[currentObject].name+"_mask.png",
		CXIMAGE_FORMAT_PNG);

	//show the preview of texture
	QImage image = GUIHelpers::convertCxImageToQImage(objects[currentObject].maskBitmap);
	QPixmap pixmap;
	pixmap.convertFromImage(image);
	maskView->setPixmap(pixmap);

	//update distribution
	valuesChanged();
}

/****************************************************************************
** ObjectsGUI generateClicked
**
** Is called, when the generate button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::generateClicked()
{
	//reset the generatingProgress
	generatingProgress = 0;		
	progressBar->reset();

	//prepare the preview image
	currentBitmap = CxImage(hMapBitmap);
	currentBitmap.IncreaseBpp(24);

	generator.generate(
		pHeightMap,
		&generatingProgress,
		&currentBitmap,
		objects+currentObject);

	//hide the generatebutton and show the cancelbutton
	generateButton->hide();
	cancelButton->show();

	//disable all tabs except the own
	enableTabs(false);

	//disable gui elements
	objectList->setEnabled(false);
	addButton->setEnabled(false);
	removeButton->setEnabled(false);
	renameButton->setEnabled(false);
	infoGroup->setEnabled(false);
	distributionGroup->setEnabled(false);
	heightSlider->setEnabled(false);
	slopeSlider->setEnabled(false);
	densitySlider->setEnabled(false);
	smoothnessSlider->setEnabled(false);
	scaleSlider->setEnabled(false);
	
	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//start timer for updating the image and progressbar
	generatingObjectTimerID = startTimer(100);
	
}

/****************************************************************************
** ObjectsGUI cancelClicked
**
** Is called, when the cancel-Button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::cancelClicked()
{
	//stop the generating-thread
	generator.cancel();

	//delete timer
	killTimer(generatingObjectTimerID);
	generatingObjectTimerID = -1;

	//update the image
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));

	//update the progressbar
	progressBar->setProgress(generatingProgress);

	//hide the cancelbutton and show the generatebutton
	cancelButton->hide();
	generateButton->show();

	//enable all tabs except the own
	enableTabs(true);

	//enable gui elements
	objectList->setEnabled(true);
	addButton->setEnabled(true);
	removeButton->setEnabled(true);
	renameButton->setEnabled(true);
	infoGroup->setEnabled(true);
	distributionGroup->setEnabled(true);
	heightSlider->setEnabled(true);
	slopeSlider->setEnabled(true);
	densitySlider->setEnabled(true);
	smoothnessSlider->setEnabled(true);
	scaleSlider->setEnabled(true);

	//set count display to right value
	countTextLabel->setText(QString("%1").arg(objects[currentObject].count));

	//if dynamic object... make nice preview image
	if (objects[currentObject].type == OneObject::DYNAMIC)
		createObjectDistribution();

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();	
}

/****************************************************************************
** ObjectsGUI valuesChanged
**
** Is called, when a value changed
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::valuesChanged()
{
	//save the properties of all sliders in texture data
	objects[currentObject].lowestHeight = heightSlider->getValue(0);
	objects[currentObject].highestHeight = heightSlider->getValue(1);
	objects[currentObject].flattestSlope = slopeSlider->getValue(0);
	objects[currentObject].steepestSlope = slopeSlider->getValue(1);
	objects[currentObject].smoothness = smoothnessSlider->getValue(0);
	objects[currentObject].density = densitySlider->getValue(0);
	objects[currentObject].minimalScale = scaleSlider->getValue(0);
	objects[currentObject].maximalScale = scaleSlider->getValue(1);
	objects[currentObject].distributionType = distributionGroup->id(distributionGroup->selected());

	//generate the distribution
	if (!dontRecalculate)
		createObjectDistribution();
}

/****************************************************************************
** ObjectsGUI showEvent
**
** Is called, when the ObjectsGUI will be shown. 
** Load everything for this panel!
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::showEvent(QShowEvent *showEvent)
{
	//ignore spontaneous show events (come from iconified)
	if (showEvent->spontaneous())
		return;

	//get a pointer to the widget with the tab bar (we need this for disabling other tabs while generating)
	topParent =	(ScapeMakerDialog*)(parentWidget()->parentWidget()->parentWidget()->parentWidget());

	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//prepare sliders
	heightSlider->setProperties(CoolSlider::LINEAR,tr("Height"),0,3000,"m",2);
	slopeSlider->setProperties(CoolSlider::DEGREE,tr("Slope"),0,90,"�",2);
	smoothnessSlider->setProperties(CoolSlider::LINEAR,tr("Smoothness"),0,100,"",1);
	densitySlider->setProperties(CoolSlider::LINEAR,tr("Density"),1,100,"",1);
	scaleSlider->setProperties(CoolSlider::LINEAR,tr("Scaling"),1,200,"%",2);

	//delete all old objects
	if (objectsCount > 0)
	{
		objectList->clear();
		for (int i=0;i<objectsCount;i++)
		{
			if (objects[i].positions != NULL)
				delete [] objects[i].positions;
		}
		delete [] objects;
		objectsCount = 0;
		currentObject = -1;
	}

	//load the heightmap file from project
	if (!hMapBitmap.Load(projectPath+"/engine/heightmap.png"))
	{
		//if file not exist, create a new bitmap
		hMapBitmap.Create(256,256,24);
		//save the heightmap in project (we need a heightmap!)
		hMapBitmap.Save(projectPath+"/engine/heightmap.png",CXIMAGE_FORMAT_PNG);
	}

	//create object distribution
	objectDistribution.Create(hMapBitmap.GetWidth(),hMapBitmap.GetHeight(),24);
	objectDistribution.AlphaCreate();

	//create heightmap class
	QString enginePath = projectPath+"/engine/";
	char *enginePath2 = new char[enginePath.length()+1];
	strcpy(enginePath2,enginePath.latin1());
	pHeightMap = new Heightmap(enginePath2,"heightmap.png");

	//load all settings from text file 
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/objects.txt",MiniXML::READ))
	{
		if (xmlFile.startReadList("objects"))
		{
			OneObject newObject;
			int i=0;
			char string[512];
			int value;
		
			while (xmlFile.startReadListElement(i))
			{	
				initObject(newObject);

				if (xmlFile.readString("name",string,512))
					newObject.name = string;

				if (xmlFile.readString("orgName",string,512))
					newObject.orgName = string;
				
				if (xmlFile.readInteger("lowestHeight",&value))
					newObject.lowestHeight = value;
				
				if (xmlFile.readInteger("highestHeight",&value))
					newObject.highestHeight = value;

				if (xmlFile.readInteger("flattestSlope",&value))
					newObject.flattestSlope = value;

				if (xmlFile.readInteger("steepestSlope",&value))
					newObject.steepestSlope = value;

				if (xmlFile.readInteger("smoothness",&value))
					newObject.smoothness = value;

				if (xmlFile.readInteger("density",&value))
					newObject.density = value;

				if (xmlFile.readInteger("minimalScale",&value))
					newObject.minimalScale = value;

				if (xmlFile.readInteger("maximalScale",&value))
					newObject.maximalScale = value;

				if (xmlFile.readInteger("count",&value))
					newObject.count = value;

				if (xmlFile.readInteger("distributionType",&value))
					newObject.distributionType = value;

				//load mask from file					
				if (!newObject.maskBitmap.Load(projectPath+"/objects/"+newObject.name+"_mask.png"))
				{
					//if file not exist, create a new bitmap
					newObject.maskBitmap.Create(256,256,24);
					newObject.maskBitmap.Clear(0xff);
				}

				addObject(newObject);

				//retrieve type from settings file
				getObjectType(i);

				//if type == dynamic... load position distribution bitmap
				if (objects[i].type == OneObject::DYNAMIC)
				{
					objects[i].positionsBitmap.Load(projectPath+"/engine/objects/"+objects[i].name+"/positions.jpg",CXIMAGE_FORMAT_JPG);
				}

				xmlFile.endReadListElement();
				i++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	//show the heightmap in bitmapNav
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));

	//set expert mode
	filterExpertFunctions();

	if (objectsCount == 0)
	{
		//hide all gui elements for objects
		hideObjectGUIElements(true);

		//disable tools in bitmapnav
		bitmapNavContainer->setPenButtonEnable(false);
		bitmapNavContainer->setRubberButtonEnable(false);

	}
	else
	{
		//select the first object
		objectList->setSelected(0,true);
	}
}

/****************************************************************************
** ObjectsGUI hideEvent
**
** Is called, when the ObjectsGUI will be hide. 
** Save everything for this panel!
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::hideEvent(QHideEvent *hideEvent)
{
	//save the settings to the text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/objects.txt",MiniXML::WRITE))
	{
		if (xmlFile.startWriteList("objects"))
		{
			for (int i=0;i<objectsCount;i++)
			{
				if (xmlFile.startWriteListElement(i))
				{
					xmlFile.writeString("name",objects[i].name);
					xmlFile.writeString("orgName",objects[i].orgName);
					xmlFile.writeInteger("lowestHeight",objects[i].lowestHeight);
					xmlFile.writeInteger("highestHeight",objects[i].highestHeight); 
					xmlFile.writeInteger("flattestSlope",objects[i].flattestSlope);
					xmlFile.writeInteger("steepestSlope",objects[i].steepestSlope);
					xmlFile.writeInteger("smoothness",objects[i].smoothness);
					xmlFile.writeInteger("density",objects[i].density);
					xmlFile.writeInteger("minimalScale",objects[i].minimalScale);
					xmlFile.writeInteger("maximalScale",objects[i].maximalScale);
					xmlFile.writeInteger("count",objects[i].count);
					xmlFile.writeInteger("distributionType",objects[i].distributionType);

					xmlFile.endWriteListElement();
				}
			}
			xmlFile.endWriteList();
		}
		xmlFile.closeFile();
	}

	//ignore hide events with minimizing
	if (!topParent->isMinimized())
	{
		//save the position datas for the objects in engine directory
		for (int i=0;i<objectsCount;i++)
		{
			//if type == static -> write positions.txt
			if (objects[i].type == OneObject::STATIC)
			{
				if (objects[i].newPositionData)
				{
					if (xmlFile.openFile(projectPath+"/engine/objects/"+objects[i].name+"/positions.txt",MiniXML::WRITE))
					{
						if (xmlFile.startWriteList("positions"))
						{
							for (int j=0;j<objects[i].count;j++)
							{
								if (xmlFile.startWriteListElement(j))
								{
									xmlFile.writeFloat("positionX",objects[i].positions[j].x);
									xmlFile.writeFloat("positionY",objects[i].positions[j].y);
									xmlFile.writeFloat("rotationY",objects[i].positions[j].rotation);
									xmlFile.writeFloat("scale",objects[i].positions[j].scale);
															
									xmlFile.endWriteListElement();
								}
							}
							xmlFile.endWriteList();
						}
						xmlFile.closeFile();
					}
				}
			}
			//else type == dynamic -> write positions.bmp
			else if (objects[i].type == OneObject::DYNAMIC)
			{
				objects[i].positionsBitmap.SetJpegQuality(JPG_QUALITY); 
				objects[i].positionsBitmap.Save(projectPath+"/engine/objects/"+objects[i].name+"/positions.jpg",CXIMAGE_FORMAT_JPG);
			
				//and some additional infos about distribution in positions.txt
				if (xmlFile.openFile(projectPath+"/engine/objects/"+objects[i].name+"/positions.txt",MiniXML::WRITE))
				{
					xmlFile.writeFloat("minimalScale",((float)objects[i].minimalScale)/100.0f);
					xmlFile.writeFloat("maximalScale",((float)objects[i].maximalScale)/100.0f);
					xmlFile.closeFile();
				}
			}
		}

		//delete all old objects
		if (objectsCount > 0)
		{
			objectList->clear();
			for (int i=0;i<objectsCount;i++)
			{
				if (objects[i].positions != NULL)
					delete [] objects[i].positions;
			}
			delete [] objects;
			objectsCount = 0;
			currentObject = -1;
		}

		//delete heightmap-class
		if (pHeightMap != NULL) 
		{
			delete pHeightMap;
			pHeightMap = NULL;
		}
	}
}

/****************************************************************************
** ObjectsGUI addObject
**
** adds a object to intern and GUI list and return the index of the list
**  
** Author: Dirk Plate
****************************************************************************/

int ObjectsGUI::addObject(OneObject &values)
{
	int i;
	int index;

	//read in positions of object, if manual distribution
	if (values.distributionType == 0)
	{
		//load existing positions
		loadPositions(values);

		//filter positions list (delete position outside terrain)
		i=0;
		while (i<values.count)
		{
			//position outside terrain?
			if ((values.positions[i].x < 0) ||
				(values.positions[i].x >= hMapBitmap.GetWidth()-1) ||
				(values.positions[i].y < 0) ||
				(values.positions[i].y >= hMapBitmap.GetHeight()-1))
			{
				//overwrite position with last one
				values.positions[i] = values.positions[values.count-1];

				//now one position less
				values.count--;
			}
			else i++;
		}
	}

	//add this texture to the list
	//make a new array (one bigger)
	OneObject *newArray = new OneObject[objectsCount+1];
	
	//copy all items
	for (i=0;i<objectsCount;i++)
		newArray[i] = objects[i];
	
	//insert the new one
	index = objectsCount;
	newArray[index] = values;

	//delete the old list
	if (objectsCount > 0)
		delete [] objects;

	//link the new array to the old list
	objects = newArray;
	objectsCount++;

	//update the gui-list
	objectList->insertItem(values.name,objectsCount-1);

	return objectsCount-1;
}

/****************************************************************************
** ObjectsGUI loadPositions
**
** load all positions of one object in memory
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::loadPositions(OneObject &values)
{
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/engine/objects/"+values.name+"/positions.txt",MiniXML::READ))
	{
		if (xmlFile.startReadList("positions"))
		{
			float value;
			values.count = 0;
								
			//get count of positions
			while (xmlFile.startReadListElement(values.count))
			{	
				xmlFile.endReadListElement();
				values.count++;
			}

			//create position list
			values.positions = new OneObject::OnePosition[values.count];

			//fill list
			int i = 0;
			while (xmlFile.startReadListElement(i))
			{	
				values.positions[i].x = 0.0f;
				if (xmlFile.readFloat("positionX",&value))
					values.positions[i].x = value;
		
				values.positions[i].y = 0.0f;
				if (xmlFile.readFloat("positionY",&value))
					values.positions[i].y = value;

				values.positions[i].rotation = 0.0f;
				if (xmlFile.readFloat("rotationY",&value))
					values.positions[i].rotation = value;

				values.positions[i].scale = 1.0f;
				if (xmlFile.readFloat("scale",&value))
					values.positions[i].scale = value;

				xmlFile.endReadListElement();
				i++;
			}
		}
		xmlFile.endReadList();
	}
	xmlFile.closeFile();
}


/****************************************************************************
** ObjectsGUI initObject
**
** init a object with default values
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::initObject(OneObject &object)
{
	object.orgName="";
	object.type=OneObject::STATIC;
	object.lowestHeight=0;
	object.highestHeight=3000;
	object.flattestSlope=0;
	object.steepestSlope=90;
	object.smoothness=50;
	object.density=50;
	object.minimalScale=80;
	object.maximalScale=120;
	object.positions=NULL;
	object.count=0;
	object.distributionType=1;
	object.newPositionData=false;
}

/****************************************************************************
** ObjectsGUI hideObjectGUIElements
**
** hides (or shows) all gui elements, which belongs to objects
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::hideObjectGUIElements(bool hide)
{
	if (hide)
	{
		infoGroup->hide();
		distributionGroup->hide();
		randomGroup->hide();
	}
	else
	{
		infoGroup->show();
		if (loadedExpert)
			distributionGroup->show();
		else distributionGroup->hide();
		randomGroup->show();
	}
}

/****************************************************************************
** ObjectsGUI createCurrentBitmap
**
** create the bitmap and put it in bitmapNav
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::createCurrentBitmap()
{
	//copy the heightmap as nice background
	currentBitmap = CxImage(hMapBitmap);
	currentBitmap.IncreaseBpp(24);

	//add the distribution
	for(DWORD y=0;y<currentBitmap.GetHeight();y++)
		for (DWORD x=0;x<currentBitmap.GetWidth();x++)
	{
		//get the color on the background
		RGBQUAD background = currentBitmap.GetPixelColor(x,y);
			
		//get the color on the distribution
		RGBQUAD distribution = objectDistribution.GetPixelColor(x,y);
		
		//calculate factor
		float blendFactor = float(distribution.rgbReserved)/255.0f;
		float blendFactorInv = 1.0f-blendFactor;
		
		//calculate new color
		RGBQUAD newColor;
		newColor.rgbRed = blendFactor*distribution.rgbRed+blendFactorInv*background.rgbRed;
		newColor.rgbGreen = blendFactor*distribution.rgbGreen+blendFactorInv*background.rgbGreen;
		newColor.rgbBlue = blendFactor*distribution.rgbBlue+blendFactorInv*background.rgbBlue;
		
		//set new color
		currentBitmap.SetPixelColor(x,y,newColor);
	}

	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));
}

/****************************************************************************
** ObjectsGUI createPositionsBitmap
**
** create the positions bitmap from currentBitmap
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::createPositionsBitmap()
{
	int x,y;
	byte distribution;
	RGBQUAD newColor;

	objects[currentObject].positionsBitmap.Create(currentBitmap.GetWidth(),currentBitmap.GetHeight(),24,CXIMAGE_FORMAT_JPG);

	//add the objectdistribution
	for(y=0;y<currentBitmap.GetHeight();y++)
		for (x=0;x<currentBitmap.GetWidth();x++)
	{
		//get the color on the distribution
		distribution = objectDistribution.AlphaGet(x,y);
		
		//calculate new color
		newColor.rgbRed = distribution;
		newColor.rgbGreen = distribution;
		newColor.rgbBlue = distribution;
		//set new color
		objects[currentObject].positionsBitmap.SetPixelColor(x,y,newColor);
	}
}

/****************************************************************************
** ObjectsGUI createObjectDistribution
**
** create distribution preview for current object
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::createObjectDistribution()
{
	//if manual distribution
	if (manualDistribution->isChecked())
	{
		RGBQUAD red;
		red.rgbRed = 255;
		red.rgbGreen = 0;
		red.rgbBlue = 0;
		red.rgbReserved = 255;
		RGBQUAD invisible;
		invisible.rgbRed = 0;
		invisible.rgbGreen = 0;
		invisible.rgbBlue = 0;
		invisible.rgbReserved = 0;

		//redraw distribution manual from existing positions
		//clear object distribution of all position
		for (int y=0;y<objectDistribution.GetHeight();y++)
			for (int x=0;x<objectDistribution.GetWidth();x++)
				objectDistribution.SetPixelColor(x,y,invisible, true);

		//insert all positions
		if ( objects[currentObject].positions != NULL )
		{
			for (int j=0;j<objects[currentObject].count;j++)
				objectDistribution.SetPixelColor(
					objects[currentObject].positions[j].x,
					objects[currentObject].positions[j].y, red, true);
		}
			
		//recreate current preview
		createCurrentBitmap();
	}
	//if random distribution
	else if (randomDistribution->isChecked())
	{
		//disable all tabs
		enableTabs(false);

		//delete old timer
		if (generatingDistributionTimer)
			killTimer(generatingDistributionTimerID);
		
		generator.generateDistributionPreview(pHeightMap,&objectDistribution,
			&(objects[currentObject]));
		
		generatingDistributionTimerID = startTimer(100);
		generatingDistributionTimer = true;
	}
}

/****************************************************************************
** ObjectsGUI timerEvent
**
** Is called, at timer event
**  
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::timerEvent(QTimerEvent *timerEvent)
{
	//only its our generatingTimer
	if (timerEvent->timerId() == generatingDistributionTimerID)
	{
		//generating done?
		if (!generator.running())
		{
			//delete timer
			killTimer(generatingDistributionTimerID);
			generatingDistributionTimerID = -1;
			generatingDistributionTimer = false;
			//create the current bitmap for bitmapNav
			createCurrentBitmap();
			//create positionsBitmap, if dynamic
			if (objects[currentObject].type == OneObject::DYNAMIC)
				createPositionsBitmap();

			//enable all tabs
			enableTabs(true);
		}
	}
	else if (timerEvent->timerId() == generatingObjectTimerID)
	{
		//update the image
		bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));
		
		//update the progressbar
		progressBar->setProgress(generatingProgress);
		
		//generating done?
		if (!generator.running())
		{
			//use cancelClicked for doing the work
			cancelClicked();

			//now the new position data are valid
			objects[currentObject].newPositionData = true;
		}
	}
}

/****************************************************************************
** ObjectsGUI getTypeText
**
** return string of type
**  
** Author: Dirk Plate
****************************************************************************/

QString ObjectsGUI::getTypeText(OneObject::Types type)
{
	if (type == OneObject::STATIC) return tr("static");
	else if (type == OneObject::DYNAMIC) return tr("dynamic");
	else return tr("unknown");
}

/****************************************************************************
** ObjectsGUI getObjectType
**
** retrieve type of object from settings file
**  
** Author: Dirk Plate
****************************************************************************/

bool ObjectsGUI::getObjectType(int objectIndex)
{
	if (objectIndex == -1) objectIndex = currentObject;

	//read settings
	MiniXML xmlFile;
	//read settings
	QString settingsFilePath = projectPath+"/engine/objects/"+objects[objectIndex].name+"/settings.txt";
	if (xmlFile.openFile(settingsFilePath,MiniXML::READ))
	{
		int type = 0;
		xmlFile.readInteger("type",&type);
		objects[objectIndex].type = OneObject::Types(type);

		xmlFile.closeFile();
	}
	else 
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't load \"settings.txt\"!\nYou shouldn't ignore this."));
		return false;
	}
	return true;
}

/****************************************************************************
** ObjectsGUI checkSettingsFile
**
** check a directory, if its a valid object
**  
** Author: Dirk Plate
****************************************************************************/

bool ObjectsGUI::checkSettingsFile(QString settingsFile)
{
	//read settings
	MiniXML xmlFile;
	//read settings
	if (xmlFile.openFile(settingsFile,MiniXML::READ))
	{
		int tmp;

		//if type not exist... its not valid
		if (!xmlFile.readInteger("type",&tmp))
			return false;

		xmlFile.closeFile();
	}

	//its valid
	return true;
}

/****************************************************************************
** ObjectsGUI enableTabs
**
** en or disable the tabs
**
** Author: Dirk Plate
****************************************************************************/

void ObjectsGUI::enableTabs(bool enable)
{
	topParent->tabContainer->setTabEnabled(topParent->topografie, enable);
	topParent->tabContainer->setTabEnabled(topParent->texture, enable);
	topParent->tabContainer->setTabEnabled(topParent->clouds, enable);
	topParent->tabContainer->setTabEnabled(topParent->water, enable);
	topParent->tabContainer->setTabEnabled(topParent->enviroment, enable);
	topParent->tabContainer->setTabEnabled(topParent->preview, enable);
	topParent->menuBar->setEnabled(enable);
}

/****************************************************************************
** ObjectsGUI filterExpertFunctions
**
** Hides or show all sliders for expert or beginner mode
**  
** Author: Dirk Plate
****************************************************************************/
void ObjectsGUI::filterExpertFunctions()
{
	//load settings from file
	MiniXML xmlFile;
	loadedExpert = false;
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		bool bValue;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}	

	//set visibility for all functions
	if (!loadedExpert)
	{
		editButton->hide();
		distributionGroup->hide();
		scaleSlider->hide();
		maskGroup->hide();
		bitmapNavContainer->setPenButtonVisible(false);
		bitmapNavContainer->setRubberButtonVisible(false);
	}
	else
	{
		editButton->show();
		distributionGroup->show();
		scaleSlider->show();
		maskGroup->show();
		bitmapNavContainer->setPenButtonVisible(true);
		bitmapNavContainer->setRubberButtonVisible(true);
	}
}
