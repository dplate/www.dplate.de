/****************************************************************************
** ObjectsGUI
**
** the objects-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "objectsguibase.h"
#include "objectgen.h"
#include "qinputdialog.h"
#include "qlistbox.h"
#include "qmessagebox.h"
#include "qfiledialog.h"
#include "qlabel.h"
#include "qpushbutton.h"
#include "../scapemakerdialog.h"
#include "qprogressbar.h"
#include "qtabwidget.h"
#include "qcolordialog.h"
#include "qradiobutton.h"
#include "ximage.h"

#define MAX_MANUAL_POSITIONS 25000

class ObjectsGUI : public ObjectsGUIBase  
{
	Q_OBJECT

public:
	ObjectsGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setProjectPath(QString projectPathSet);

public slots:
    virtual void addClicked();
    virtual void removeClicked();
	virtual void renameClicked();
	virtual void importObjectClicked();
	virtual void importMaskClicked();
	virtual void resetMaskClicked();
	virtual void generateClicked();
	virtual void cancelClicked();
	virtual void objectSelected();
	virtual void valuesChanged();
	virtual void editClicked();
	virtual void clearClicked();
	virtual void newManualPosition(QPoint);
	virtual void deleteManualPosition(QPoint);

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);

private:
	void filterExpertFunctions();

	int addObject(OneObject &values);		//add a object to list
	void initObject(OneObject &object);		//init object with default value
	void hideObjectGUIElements(bool hide);
	void createCurrentBitmap();
	void createPositionsBitmap();
	void createObjectDistribution();
	QString getTypeText(OneObject::Types type); //return string of type
	bool getObjectType(int objectIndex = -1);	//retrieve type of object from settings file
	bool checkSettingsFile(QString settingsFile); //check a directory, if its a valid object
	void loadPositions(OneObject &values);		//load all positions of one object in memory
	void enableTabs(bool enable);

	QString projectPath;			//the path to the project-directory
	ScapeMakerDialog *topParent;	//direct pointer to main window

	//a array of all objects with all attributes
	OneObject *objects;
	int objectsCount;				//count of objects
	int currentObject;				//index of the current selected object

	CxImage hMapBitmap;				//the heightmap
	CxImage objectDistribution;		//the distribution of current object
	CxImage currentBitmap;			//this bitmap will be shown in bitmapNav
	Heightmap *pHeightMap;			//the heightmapclass
	ObjectGen generator;			//the object distribution-generator
	bool generatingDistributionTimer;   //distribution timer on or not
	int generatingDistributionTimerID;	//the id of the timer while generating the distribution
	int generatingObjectTimerID;		//the id of the timer while generating the exact object distribution
	int generatingProgress;			//the progress of generating
	bool dontRecalculate;			//is this flag set, the distribution wont recalculate

	bool loadedExpert;				//expert mode in config set
};
