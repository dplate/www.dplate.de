/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\objects\objectsguibase.ui'
**
** Created: Sun Feb 13 15:03:32 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "objectsguibase.h"

#include <qbuttongroup.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qprogressbar.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qtoolbutton.h>
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
".#############...",
".#############...",
".#############...",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
".................",
".................",
"................."};

static const char* const image1_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
".................",
".................",
".................",
".................",
".................",
".#############...",
".#############...",
".#############...",
".................",
".................",
".................",
".................",
".................",
".................",
".................",
"................."};

static const char* const image2_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"..#########......",
"..##########.....",
"..###########....",
"..####...####....",
"..####...####....",
"..###########....",
"..##########.....",
"..#########......",
"..####..####.....",
"..####..####.....",
"..####...####....",
"..####...####....",
"..####...#####...",
".................",
".................",
"................."};

static const char* const image3_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"..###########....",
"..###########....",
"..###########....",
"..####...........",
"..####...........",
"..#########......",
"..#########......",
"..#########......",
"..####...........",
"..####...........",
"..###########....",
"..###########....",
"..###########....",
".................",
".................",
"................."};


/* 
 *  Constructs a ObjectsGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
ObjectsGUIBase::ObjectsGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    QPixmap image1( ( const char** ) image1_data );
    QPixmap image2( ( const char** ) image2_data );
    QPixmap image3( ( const char** ) image3_data );
    if ( !name )
	setName( "ObjectsGUIBase" );
    resize( 527, 480 ); 
    setCaption( tr( "ObjectsGUI" ) );
    QWhatsThis::add(  this, tr( "Here, objects are placed on the landscape." ) );

    randomGroup = new QGroupBox( this, "randomGroup" );
    randomGroup->setEnabled( FALSE );
    randomGroup->setGeometry( QRect( 0, 260, 501, 195 ) ); 
    randomGroup->setTitle( tr( "Random distribution" ) );

    maskGroup = new QGroupBox( randomGroup, "maskGroup" );
    maskGroup->setGeometry( QRect( 400, 10, 95, 150 ) ); 
    maskGroup->setTitle( tr( "Mask" ) );

    maskView = new QLabel( maskGroup, "maskView" );
    maskView->setGeometry( QRect( 15, 20, 65, 65 ) ); 
    maskView->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, maskView->sizePolicy().hasHeightForWidth() ) );
    QFont maskView_font(  maskView->font() );
    maskView->setFont( maskView_font ); 
    maskView->setText( tr( "" ) );
    maskView->setScaledContents( TRUE );
    maskView->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    QWhatsThis::add(  maskView, tr( "Shows a picture of a mask, used to limit the distribution of the object." ) );

    resetMaskButton = new QPushButton( maskGroup, "resetMaskButton" );
    resetMaskButton->setGeometry( QRect( 10, 120, 75, 23 ) ); 
    resetMaskButton->setText( tr( "Reset" ) );
    resetMaskButton->setFlat( FALSE );
    QToolTip::add(  resetMaskButton, tr( "Reset to default mask" ) );
    QWhatsThis::add(  resetMaskButton, tr( "Sets mask for the selected object to default mask." ) );

    importMaskButton = new QPushButton( maskGroup, "importMaskButton" );
    importMaskButton->setGeometry( QRect( 10, 95, 75, 23 ) ); 
    importMaskButton->setText( tr( "Change" ) );
    importMaskButton->setFlat( FALSE );
    QToolTip::add(  importMaskButton, tr( "Changes a mask" ) );
    QWhatsThis::add(  importMaskButton, tr( "Changes the mask for the selected object." ) );

    progressBar = new QProgressBar( randomGroup, "progressBar" );
    progressBar->setGeometry( QRect( 105, 165, 385, 21 ) ); 
    progressBar->setFrameShape( QProgressBar::Box );
    progressBar->setFrameShadow( QProgressBar::Sunken );
    progressBar->setCenterIndicator( TRUE );

    cancelButton = new QPushButton( randomGroup, "cancelButton" );
    cancelButton->setGeometry( QRect( 8, 165, 90, 23 ) ); 
    cancelButton->setText( tr( "Cancel" ) );
    cancelButton->setFlat( FALSE );
    QToolTip::add(  cancelButton, tr( "Cancel generating object distribution" ) );

    slopeSlider = new CoolSlider( randomGroup, "slopeSlider" );
    slopeSlider->setGeometry( QRect( 10, 15, 145, 145 ) ); 
    QWhatsThis::add(  slopeSlider, tr( "Sets the range of slope in which the selected object will occur. For grass a low value would be good, for example." ) );

    densitySlider = new CoolSlider( randomGroup, "densitySlider" );
    densitySlider->setGeometry( QRect( 165, 15, 110, 70 ) ); 
    QWhatsThis::add(  densitySlider, tr( "Sets the density of the selected object, that is how often it will appear." ) );

    smoothnessSlider = new CoolSlider( randomGroup, "smoothnessSlider" );
    smoothnessSlider->setGeometry( QRect( 285, 15, 110, 70 ) ); 
    QWhatsThis::add(  smoothnessSlider, tr( QString::fromUtf8( "Sets the width of the edge of the area in which the objects occurs. A higher value results in smoother blendings between the are where objects occur and the where where they don’t occur." ) ) );

    heightSlider = new CoolSlider( randomGroup, "heightSlider" );
    heightSlider->setGeometry( QRect( 165, 90, 110, 70 ) ); 
    QWhatsThis::add(  heightSlider, tr( "Sets the range of height in which the selected object will occur. For pine trees a high value would be good, for example." ) );

    scaleSlider = new CoolSlider( randomGroup, "scaleSlider" );
    scaleSlider->setGeometry( QRect( 285, 90, 110, 70 ) ); 
    QWhatsThis::add(  scaleSlider, tr( "Sets the range in size of the object. If the range is very big, high variations in size occur." ) );

    generateButton = new QPushButton( randomGroup, "generateButton" );
    generateButton->setGeometry( QRect( 10, 165, 90, 23 ) ); 
    generateButton->setText( tr( "Generate" ) );
    generateButton->setFlat( FALSE );
    QToolTip::add(  generateButton, tr( "Start generating object distribution" ) );
    QWhatsThis::add(  generateButton, tr( "Distributes the objects." ) );

    infoGroup = new QGroupBox( this, "infoGroup" );
    infoGroup->setGeometry( QRect( 0, 100, 195, 110 ) ); 
    infoGroup->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, infoGroup->sizePolicy().hasHeightForWidth() ) );
    infoGroup->setTitle( tr( "Informations" ) );
    QToolTip::add(  infoGroup, tr( "Add texture" ) );

    typeLabel = new QLabel( infoGroup, "typeLabel" );
    typeLabel->setGeometry( QRect( 10, 70, 50, 16 ) ); 
    typeLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, typeLabel->sizePolicy().hasHeightForWidth() ) );
    typeLabel->setText( tr( "Type:" ) );
    typeLabel->setScaledContents( FALSE );

    countLabel = new QLabel( infoGroup, "countLabel" );
    countLabel->setGeometry( QRect( 10, 90, 50, 16 ) ); 
    countLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, countLabel->sizePolicy().hasHeightForWidth() ) );
    countLabel->setText( tr( "Count:" ) );
    countLabel->setScaledContents( FALSE );

    objectLabel = new QLabel( infoGroup, "objectLabel" );
    objectLabel->setGeometry( QRect( 10, 20, 50, 16 ) ); 
    objectLabel->setText( tr( "Object:" ) );

    orgNameLabel = new QLabel( infoGroup, "orgNameLabel" );
    orgNameLabel->setGeometry( QRect( 70, 20, 115, 16 ) ); 
    orgNameLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, orgNameLabel->sizePolicy().hasHeightForWidth() ) );
    orgNameLabel->setText( tr( "-" ) );
    orgNameLabel->setScaledContents( FALSE );
    orgNameLabel->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );
    QWhatsThis::add(  orgNameLabel, tr( "Shows the original name of the selected object." ) );

    importObjectButton = new QPushButton( infoGroup, "importObjectButton" );
    importObjectButton->setGeometry( QRect( 70, 40, 80, 23 ) ); 
    importObjectButton->setText( tr( "Import" ) );
    importObjectButton->setFlat( FALSE );
    QToolTip::add(  importObjectButton, tr( "Import a object" ) );
    QWhatsThis::add(  importObjectButton, tr( "Allows changing the used \"settings.txt\" for the selected object." ) );

    typeTextLabel = new QLabel( infoGroup, "typeTextLabel" );
    typeTextLabel->setGeometry( QRect( 70, 70, 115, 16 ) ); 
    typeTextLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, typeTextLabel->sizePolicy().hasHeightForWidth() ) );
    typeTextLabel->setText( tr( "unknown" ) );
    typeTextLabel->setScaledContents( FALSE );
    QWhatsThis::add(  typeTextLabel, tr( "Shows the type of the object.\n\"Static\": The object is given static positions on the landscape. These positions are defined once and saved. This makes sense with objects, which appear rarely but can be seen over a long distance, e.g. trees. \n\"Dynamic\": Just the settings for the object are saved, and dynamic objects are displayed only near to the camera." ) );

    countTextLabel = new QLabel( infoGroup, "countTextLabel" );
    countTextLabel->setGeometry( QRect( 70, 90, 115, 16 ) ); 
    countTextLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, countTextLabel->sizePolicy().hasHeightForWidth() ) );
    countTextLabel->setText( tr( "unknown" ) );
    countTextLabel->setScaledContents( FALSE );
    QWhatsThis::add(  countTextLabel, tr( "Shows the count of places where the selected object will appear. Only for static objects." ) );

    distributionGroup = new QButtonGroup( this, "distributionGroup" );
    distributionGroup->setGeometry( QRect( 0, 210, 205, 45 ) ); 
    distributionGroup->setFrameShape( QButtonGroup::NoFrame );
    distributionGroup->setFrameShadow( QButtonGroup::Plain );
    distributionGroup->setLineWidth( 0 );
    distributionGroup->setTitle( tr( "" ) );

    manualDistribution = new QRadioButton( distributionGroup, "manualDistribution" );
    manualDistribution->setGeometry( QRect( 5, 5, 135, 16 ) ); 
    manualDistribution->setText( tr( "Manual distribution" ) );
    manualDistribution->setChecked( TRUE );
    QWhatsThis::add(  manualDistribution, tr( "The object can be positioned manually, using the pen tool. This is suitable for objects that appear only rarely, e.g. buildings." ) );

    randomDistribution = new QRadioButton( distributionGroup, "randomDistribution" );
    randomDistribution->setGeometry( QRect( 5, 25, 135, 16 ) ); 
    randomDistribution->setText( tr( "Random distribution" ) );
    QWhatsThis::add(  randomDistribution, tr( "Positions for the object will be set randomly by the distribution generator. Suitable for objects that appear frequently and have positions depending on the landscape." ) );

    clearButton = new QPushButton( distributionGroup, "clearButton" );
    clearButton->setGeometry( QRect( 145, 3, 55, 23 ) ); 
    clearButton->setText( tr( "Clear" ) );
    clearButton->setFlat( FALSE );
    QToolTip::add(  clearButton, tr( "Clear manual distribution" ) );
    QWhatsThis::add(  clearButton, tr( "Clears all positions of the selected object." ) );

    bitmapNavContainer = new BitmapNav( this, "bitmapNavContainer" );
    bitmapNavContainer->setGeometry( QRect( 210, 0, 290, 260 ) ); 
    QWhatsThis::add(  bitmapNavContainer, tr( "Shows the distribution for the selected object." ) );

    addButton = new QToolButton( this, "addButton" );
    addButton->setGeometry( QRect( 170, 0, 20, 20 ) ); 
    addButton->setText( tr( "" ) );
    addButton->setPixmap( image0 );
    addButton->setToggleButton( FALSE );
    addButton->setTextLabel( tr( "" ) );
    addButton->setToggleButton( FALSE );
    QToolTip::add(  addButton, tr( "Add object" ) );
    QWhatsThis::add(  addButton, tr( "Adds a new object. Therefor a \"settings.txt\" must be chosen and a name must be given." ) );

    removeButton = new QToolButton( this, "removeButton" );
    removeButton->setGeometry( QRect( 170, 25, 20, 20 ) ); 
    removeButton->setText( tr( "" ) );
    removeButton->setPixmap( image1 );
    removeButton->setToggleButton( FALSE );
    removeButton->setTextLabel( tr( "" ) );
    removeButton->setToggleButton( FALSE );
    QToolTip::add(  removeButton, tr( "Remove object" ) );
    QWhatsThis::add(  removeButton, tr( "Deletes the selected object." ) );

    renameButton = new QToolButton( this, "renameButton" );
    renameButton->setGeometry( QRect( 170, 50, 20, 20 ) ); 
    renameButton->setText( tr( "" ) );
    renameButton->setPixmap( image2 );
    renameButton->setToggleButton( FALSE );
    renameButton->setTextLabel( tr( "" ) );
    renameButton->setToggleButton( FALSE );
    QToolTip::add(  renameButton, tr( "Rename object" ) );
    QWhatsThis::add(  renameButton, tr( "Allows changing the name of the selected object." ) );

    editButton = new QToolButton( this, "editButton" );
    editButton->setGeometry( QRect( 170, 75, 20, 20 ) ); 
    editButton->setText( tr( "" ) );
    editButton->setPixmap( image3 );
    editButton->setToggleButton( FALSE );
    editButton->setTextLabel( tr( "" ) );
    editButton->setToggleButton( FALSE );
    QToolTip::add(  editButton, tr( "Edit object" ) );
    QWhatsThis::add(  editButton, tr( "Shows the \"settings.txt\" in the default text editor. Only make changes if you know what you are doing!" ) );

    objectList = new QListBox( this, "objectList" );
    objectList->setGeometry( QRect( 5, 0, 160, 95 ) ); 
    QWhatsThis::add(  objectList, tr( "A list of all objects used in the current landscape. A click on the name of an object selects it." ) );

    // signals and slots connections
    connect( objectList, SIGNAL( selectionChanged() ), this, SLOT( objectSelected() ) );
    connect( addButton, SIGNAL( clicked() ), this, SLOT( addClicked() ) );
    connect( removeButton, SIGNAL( clicked() ), this, SLOT( removeClicked() ) );
    connect( renameButton, SIGNAL( clicked() ), this, SLOT( renameClicked() ) );
    connect( editButton, SIGNAL( clicked() ), this, SLOT( editClicked() ) );
    connect( slopeSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( densitySlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( heightSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( smoothnessSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( scaleSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( generateButton, SIGNAL( clicked() ), this, SLOT( generateClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( manualDistribution, SIGNAL( toggled(bool) ), clearButton, SLOT( setEnabled(bool) ) );
    connect( randomDistribution, SIGNAL( toggled(bool) ), randomGroup, SLOT( setEnabled(bool) ) );
    connect( clearButton, SIGNAL( clicked() ), this, SLOT( clearClicked() ) );
    connect( randomDistribution, SIGNAL( clicked() ), this, SLOT( valuesChanged() ) );
    connect( manualDistribution, SIGNAL( clicked() ), this, SLOT( valuesChanged() ) );
    connect( importObjectButton, SIGNAL( clicked() ), this, SLOT( importObjectClicked() ) );
    connect( importMaskButton, SIGNAL( clicked() ), this, SLOT( importMaskClicked() ) );
    connect( resetMaskButton, SIGNAL( clicked() ), this, SLOT( resetMaskClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ObjectsGUIBase::~ObjectsGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool ObjectsGUIBase::event( QEvent* ev )
{
    bool ret = QWidget::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont maskView_font(  maskView->font() );
	maskView->setFont( maskView_font ); 
    }
    return ret;
}

void ObjectsGUIBase::addClicked()
{
    qWarning( "ObjectsGUIBase::addClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::cancelClicked()
{
    qWarning( "ObjectsGUIBase::cancelClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::clearClicked()
{
    qWarning( "ObjectsGUIBase::clearClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::editClicked()
{
    qWarning( "ObjectsGUIBase::editClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::generateClicked()
{
    qWarning( "ObjectsGUIBase::generateClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::importMaskClicked()
{
    qWarning( "ObjectsGUIBase::importMaskClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::importObjectClicked()
{
    qWarning( "ObjectsGUIBase::importObjectClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::objectSelected()
{
    qWarning( "ObjectsGUIBase::objectSelected(): Not implemented yet!" );
}

void ObjectsGUIBase::removeClicked()
{
    qWarning( "ObjectsGUIBase::removeClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::renameClicked()
{
    qWarning( "ObjectsGUIBase::renameClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::resetMaskClicked()
{
    qWarning( "ObjectsGUIBase::resetMaskClicked(): Not implemented yet!" );
}

void ObjectsGUIBase::valuesChanged()
{
    qWarning( "ObjectsGUIBase::valuesChanged(): Not implemented yet!" );
}

