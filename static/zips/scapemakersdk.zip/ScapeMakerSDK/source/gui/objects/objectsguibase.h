/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\objects\objectsguibase.ui'
**
** Created: Sun Feb 13 15:03:32 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef OBJECTSGUIBASE_H
#define OBJECTSGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class BitmapNav;
class CoolSlider;
class QButtonGroup;
class QGroupBox;
class QLabel;
class QListBox;
class QListBoxItem;
class QProgressBar;
class QPushButton;
class QRadioButton;
class QToolButton;

class ObjectsGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    ObjectsGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~ObjectsGUIBase();

    QGroupBox* randomGroup;
    QGroupBox* maskGroup;
    QLabel* maskView;
    QPushButton* resetMaskButton;
    QPushButton* importMaskButton;
    QProgressBar* progressBar;
    QPushButton* cancelButton;
    CoolSlider* slopeSlider;
    CoolSlider* densitySlider;
    CoolSlider* smoothnessSlider;
    CoolSlider* heightSlider;
    CoolSlider* scaleSlider;
    QPushButton* generateButton;
    QGroupBox* infoGroup;
    QLabel* typeLabel;
    QLabel* countLabel;
    QLabel* objectLabel;
    QLabel* orgNameLabel;
    QPushButton* importObjectButton;
    QLabel* typeTextLabel;
    QLabel* countTextLabel;
    QButtonGroup* distributionGroup;
    QRadioButton* manualDistribution;
    QRadioButton* randomDistribution;
    QPushButton* clearButton;
    BitmapNav* bitmapNavContainer;
    QToolButton* addButton;
    QToolButton* removeButton;
    QToolButton* renameButton;
    QToolButton* editButton;
    QListBox* objectList;

public slots:
    virtual void addClicked();
    virtual void cancelClicked();
    virtual void clearClicked();
    virtual void editClicked();
    virtual void generateClicked();
    virtual void importMaskClicked();
    virtual void importObjectClicked();
    virtual void objectSelected();
    virtual void removeClicked();
    virtual void renameClicked();
    virtual void resetMaskClicked();
    virtual void valuesChanged();

protected:
    bool event( QEvent* );
};

#endif // OBJECTSGUIBASE_H
