/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\preview\previewfullscreenbase.ui'
**
** Created: Sun Feb 13 15:03:32 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "previewfullscreenbase.h"

#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a PreviewFullscreenBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
PreviewFullscreenBase::PreviewFullscreenBase( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "PreviewFullscreenBase" );
    resize( 193, 134 ); 
    setCaption( tr( "Fullscreen Preview" ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
PreviewFullscreenBase::~PreviewFullscreenBase()
{
    // no need to delete child widgets, Qt does it all for us
}

