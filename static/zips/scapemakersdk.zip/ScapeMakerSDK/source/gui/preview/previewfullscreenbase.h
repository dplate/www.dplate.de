/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\preview\previewfullscreenbase.ui'
**
** Created: Sun Feb 13 15:03:32 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef PREVIEWFULLSCREENBASE_H
#define PREVIEWFULLSCREENBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 

class PreviewFullscreenBase : public QDialog
{ 
    Q_OBJECT

public:
    PreviewFullscreenBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~PreviewFullscreenBase();


};

#endif // PREVIEWFULLSCREENBASE_H
