/****************************************************************************
** PreviewGUI
**
** the preview-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#include "PreviewGUI.h"
#include <qframe.h>
#include <qapplication.h>

/****************************************************************************
** PreviewGUI Constructor
**
** initialise vars
**  
** Author: Dirk Plate
****************************************************************************/

PreviewGUI::PreviewGUI( QWidget* parent, const char* name, WFlags f )
	: PreviewGUIBase(parent, name, f)
{
	pEngine = NULL;
	fullscreenPreview = NULL;
	timerID = -1;

	//find the top widget (we need the hwnd for fullscreen)
	topParent = this;
	while(topParent->parentWidget() != NULL) topParent = topParent->parentWidget();
}

/****************************************************************************
** PreviewGUI setProjectPath
**
** set the current project
**  
** Author: Dirk Plate
****************************************************************************/

void PreviewGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}

/****************************************************************************
** PreviewGUI showEvent
**
** Is called, when the preview gui will be shown. Must create and start the 
** engine.
**  
** Author: Dirk Plate
****************************************************************************/

void PreviewGUI::showEvent(QShowEvent *showEvent)
{	
	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//no character written up to now
	keyCount = 0;

	//check for all necessary files
	if (!checkNecessaryFiles()) 
	{
		fullscreen->setEnabled(false);
		window->setEnabled(false);
		return;
	}
	fullscreen->setEnabled(true);
	window->setEnabled(true);

	fullscreenPreview = new PreviewFullscreenBase(NULL,"fullscreenPreview",false,WGroupLeader | WStyle_Customize | WStyle_DialogBorder | WStyle_Title);

	//install event filter for render target
	renderTarget->installEventFilter(this);
	topParent->installEventFilter(this);
	fullscreenPreview->installEventFilter(this);
}

/****************************************************************************
** PreviewGUI hideEvent
**
** is called, when the preview gui will be hide. Must stop and delete the
** engine.
**  
** Author: Dirk Plate
****************************************************************************/

void PreviewGUI::hideEvent(QHideEvent *hideEvent)
{
	//if there is a engine -> stop and delete
	terminateEngine();

	SAFE_DELETE(fullscreenPreview);
}

/****************************************************************************
** PreviewGUI timerEvent
**
** is called every time, we call the Engine Update function to start
** the update and rendering process.
** 
** Author: Dirk Plate
****************************************************************************/
void PreviewGUI::timerEvent(QTimerEvent * timerEvent)
{	
	HRESULT hr;

	if (pEngine != NULL)
	{
		UpdateReturns returnValues; 
		if(FAILED(hr = pEngine->update(keyBuffer,keyCount,&returnValues)))
		{
			MessageBox(NULL,tr("A critical error during update loop of 3d engine occured, check log file.\nError: ")+ 
				DXGetErrorString9(hr)+"("+DXGetErrorDescription9(hr)+")", tr("Critical error"), MB_OK);
			exit(1);
		}

		//reset keys 
		keyCount = 0;

		//check return values
		if (returnValues.switchRenderTarget)
			switchRenderTargetEngine();
		if (returnValues.terminate)
			terminateEngine();
	}
}

/****************************************************************************
** PreviewGUI keyPressEvent
**
** called when pressing a key on the keyboard. handle the needed keys.
** 
** Author: Dirk Plate
****************************************************************************/
void PreviewGUI::keyPressEvent(QKeyEvent *k)
{
	//save character
	if (keyCount < KEY_BUFFER_SIZE)
	{
		keyBuffer[keyCount] = k->ascii();
		keyCount++;
	}
}

/****************************************************************************
** PreviewGUI eventFilter
**
** filter events of render target
** 
** Author: Dirk Plate
****************************************************************************/
bool PreviewGUI::eventFilter(QObject *pObject, QEvent *pEvent)
{
	//render target
	if (pObject == renderTarget)
	{
		//don't let loose focus
		if (pEvent->type() == QEvent::FocusOut)
		{
			renderTarget->setFocus();
			return true;
		}

		//if mouse leave render area
		else if (pEvent->type() == QEvent::Leave)
		{
			if (pEngine != NULL)
			{
				//only do something... if not fullscreen
				if (pEngine->windowed)
				{
					//disable mouse
					pEngine->enableMouse(false);
				}
			}
		}

		//if mouse enter render area
		else if (pEvent->type() == QEvent::Enter)
		{
			if (pEngine != NULL)
			{
				//only do something... if not fullscreen
				if (pEngine->windowed)
				{
					//activate mouse
					pEngine->enableMouse(true);
				}
			}
		}
	}
	//window
	else if (pObject == topParent)
	{
		//window is activated
		if (pEvent->type() == QEvent::WindowActivate)
		{
			if (pEngine != NULL)
			{
				//only do something... if not fullscreen
				if (pEngine->windowed)
				{
					//activate mouse
					pEngine->enableMouse(true);

					//activate keyboard
					pEngine->enableKeyboard(true);
				}
			}
		}

		//window is deactivated
		else if (pEvent->type() == QEvent::WindowDeactivate)
		{
			if (pEngine != NULL)
			{
				//if not fullscreen
				if (pEngine->windowed)
				{
					//deactivate mouse
					pEngine->enableMouse(false);

					//deactivate keyboard
					pEngine->enableKeyboard(false);
				}
			}
		}
	}

	//full screen
	else if (pObject == fullscreenPreview)
	{
		//key pressed
		if (pEvent->type() == QEvent::KeyPress)
		{
			keyPressEvent((QKeyEvent*)pEvent);
		}
		//prevent window moving
		else if (pEvent->type() == QEvent::Move)
		{
			fullscreenPreview->move(0,0);
		}

		return true;
	}

	return false;
}

/****************************************************************************
** PreviewGUI switchRenderTargetEngine
**
** toggle the engine to fullscreen (or to window)
** 
** Author: Dirk Plate
****************************************************************************/
void PreviewGUI::switchRenderTargetEngine()
{
	HRESULT hr;

	if (pEngine != NULL) 
	{
		if (pEngine->windowed)
		{
			fullscreenPreview->show();
			pEngine->enableKeyboard(true);
			pEngine->enableMouse(true);
		}

		//change the mouse-cursor to waiting	
		QApplication::setOverrideCursor(Qt::waitCursor);
		
		//switch
		if(FAILED(hr = pEngine->switchRenderTarget()))
		{
			MessageBox(NULL,tr("A critical error during switch of render target occured, check log file.\nError: ")+ 
				DXGetErrorString9(hr)+"("+DXGetErrorDescription9(hr)+")", tr("Critical error"), MB_OK);
			exit(1);
		}

		//restore old mouse-cursor
		QApplication::restoreOverrideCursor();	

		if (pEngine->windowed)
		{
			fullscreenPreview->hide();
			topParent->show();
		}
		else
		{
			fullscreenPreview->setActiveWindow();
		}
	}
}

/****************************************************************************
** PreviewGUI terminateEngine
**
** terminate the engine
** 
** Author: Dirk Plate
****************************************************************************/
void PreviewGUI::terminateEngine()
{
	HRESULT hr;

	if (pEngine != NULL) 
	{
		//delete engine
		killTimer(timerID);		// stop continuous timer

		if (FAILED(hr=pEngine->terminate()))	// terminate engine
		{
			MessageBox(NULL,tr("A critical error during terminate 3d engine occured, check log file.\nError: ")+ 
				DXGetErrorString9(hr)+"("+DXGetErrorDescription9(hr)+")", tr("Critical error"), MB_OK);
			exit(1);
		}
			
		delete pEngine;			// delete engine
		pEngine = NULL;			// initialise engine pointer

		fullscreenPreview->hide();
		topParent->show();

		//enable window button again
		window->setEnabled(true);

		//refresh render target
		renderTarget->update();
	}
}

/****************************************************************************
** PreviewGUI fullscreenClicked
**
** user clicked the fullscreen button
** 
** Author: Dirk Plate
****************************************************************************/
void PreviewGUI::fullscreenClicked()
{
	HRESULT hr;

	//engine already exists?
	if (pEngine != NULL) 
	{
		//easy... only switch render target
		switchRenderTargetEngine();
	}
	//engine not exists... create new one
	else
	{
		//change the mouse-cursor to waiting
		QApplication::setOverrideCursor(Qt::waitCursor);

		pEngine = new Engine();	// create the engine

		pEngine->enableKeyboard(true);
		pEngine->enableMouse(true);

		//set size of fullscreen preview
		QSize fullscreenResolution(pEngine->getFullscreenWidth(),pEngine->getFullscreenHeight());
		fullscreenPreview->setMinimumSize(fullscreenResolution);
		fullscreenPreview->setMaximumSize(fullscreenResolution);
		fullscreenPreview->setSizePolicy(QSizePolicy(QSizePolicy::SizeType::Fixed, QSizePolicy::SizeType::Fixed));
		fullscreenPreview->move(0,0);
		fullscreenPreview->show();

		const char *path = projectPath.latin1();

		pEngine->setProjectPath(path);
		if(FAILED(hr = pEngine->start(renderTarget->winId(), fullscreenPreview->winId(), topParent->winId(), false)))
		{
			fullscreenPreview->hide();
			MessageBox(NULL,tr("A critical error during initialising 3d engine occured, check log file.\nError: ")+ 
				DXGetErrorString9(hr)+"("+DXGetErrorDescription9(hr)+")", tr("Critical error"), MB_OK);
			exit(1);
		}

		// run continuous timer
		timerID = startTimer( 0 );	

		//set focus on other control than tab bar
		fullscreenPreview->setActiveWindow();

		//restore old mouse-cursor
		QApplication::restoreOverrideCursor();
	}
}

/****************************************************************************
** PreviewGUI windowClicked
**
** show the preview in window
** 
** Author: Dirk Plate
****************************************************************************/
void PreviewGUI::windowClicked()
{
	HRESULT hr;

	if (pEngine == NULL) 
	{
		//change the mouse-cursor to waiting
		QApplication::setOverrideCursor(Qt::waitCursor);

		pEngine = new Engine();	// create the engine
		timerID = startTimer( 0 );	// run continuous timer

		const char *path = projectPath.latin1();

		//set size of fullscreen preview
		QSize fullscreenResolution(pEngine->getFullscreenWidth(),pEngine->getFullscreenHeight());
		fullscreenPreview->setMinimumSize(fullscreenResolution);
		fullscreenPreview->setMaximumSize(fullscreenResolution);
		fullscreenPreview->setSizePolicy(QSizePolicy(QSizePolicy::SizeType::Fixed, QSizePolicy::SizeType::Fixed));
		fullscreenPreview->move(0,0);

		pEngine->setProjectPath(path);
		if(FAILED(hr = pEngine->start(renderTarget->winId(), fullscreenPreview->winId(), topParent->winId(), true)))
		{
			MessageBox(NULL,tr("A critical error during initialising 3d engine occured, check log file.\nError: ")+ 
				DXGetErrorString9(hr)+"("+DXGetErrorDescription9(hr)+")", tr("Critical error"), MB_OK);
			exit(1);
		}
	
		//set focus on other control than tab bar
		renderTarget->setFocus();

		//restore old mouse-cursor
		QApplication::restoreOverrideCursor();	

		//disable window button
		window->setEnabled(false);
	}
}

/****************************************************************************
** PreviewGUI checkNecessaryFiles
**
** check if all files for the engine are available (else show help message)
** 
** Author: Dirk Plate
****************************************************************************/
bool PreviewGUI::checkNecessaryFiles()
{
	//try to load the heightmap file from project
	QBitmap hMapBitmap;
	if (!hMapBitmap.load(projectPath+"/engine/heightmap.png"))
	{
		QMessageBox::information(this, tr("ScapeMaker"),
			tr("No heightmap is available!\nPlease generate a heightmap at \"Topography\" first."));
		return false;
	}
	
	//get number of necessary texture tiles
	int textureCount = (hMapBitmap.size().width()-1)/32;

	//check of all texture tiles exist
	for (int x=0;x<textureCount;x++)
		for (int y=0;y<textureCount;y++)
	{
		QString path = (projectPath+"/engine/textures/terrain_%1_%2.jpg").arg(x).arg(y);
		QFileInfo fileInfo(path);
		if (!fileInfo.exists() || !fileInfo.isFile())
		{
			QMessageBox::information(this, tr("ScapeMaker"),
				tr("Not all terrain textures are available!\nPlease generate terrain textures at \"Texture\" first."));
			return false;
		}
	}

	//check if all cloud layer textures exists
	int cirrusFrames = 1;
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/engine/clouds.txt",MiniXML::READ))
	{
		int value;
		if (xmlFile.readInteger("cirrusFrames",&value))
			cirrusFrames = value;
		xmlFile.closeFile();
	}

	for (int currentFrame=0; currentFrame<cirrusFrames; currentFrame++)
	{
		QString path = (projectPath+"/engine/cloudlayer/frame_%1.png").arg(currentFrame);
		QFileInfo fileInfo(path);
		if (!fileInfo.exists() || !fileInfo.isFile())
		{
			QMessageBox::information(this, tr("ScapeMaker"),
				tr("Not all cloud layer textures are available!\nPlease generate cloud layer textures at \"Clouds\" first."));
			return false;
		}
	}

	//check for water files
	//check if sea is enabled
	int seaHeight = 0;
	if (xmlFile.openFile(projectPath+"/engine/sea.txt",MiniXML::READ))
	{
		int value;
		if (xmlFile.readInteger("height",&value))
			seaHeight = value;
		xmlFile.closeFile();
	}
	//check if a rivers is set
	bool riversSet = false;
	if (xmlFile.openFile(projectPath+"/engine/rivers.txt",MiniXML::READ))
	{
		if (xmlFile.startReadList("rivers"))
		{
			if (xmlFile.startReadListElement(0))
			{
				riversSet = true;

				xmlFile.endReadListElement();
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	//if sea height > 0 or a river set... check if all water files exist
	if ((seaHeight > 0) || (riversSet))
	{
		QFileInfo fileInfo(projectPath+"/engine/waterlightmap.jpg");
		if (!fileInfo.exists() || !fileInfo.isFile())
		{
			QMessageBox::information(this, tr("ScapeMaker"),
				tr("No lightmap for water is available!\nPlease generate shadows at \"Environment\" first."));
			return false;
		}
	}
	return true;
}


