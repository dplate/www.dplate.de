/****************************************************************************
** PreviewGUI
**
** the preview-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#if !defined(PREVIEWGUI_H)
#define PREVIEWGUI_H
#pragma warning(disable:4786)

#define KEY_BUFFER_SIZE 256

#include "previewguibase.h"
#include "../../engine/engine.h"
#include "previewfullscreenbase.h"
#include "../common/guihelpers.h"
#include <qbitmap.h>
#include <qpushbutton.h>
#include <qlabel.h>

class PreviewGUI : public PreviewGUIBase  
{
	Q_OBJECT

public:
	PreviewGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);

	void setProjectPath(QString projectPathSet);

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);
	void keyPressEvent(QKeyEvent *keyEvent);
	bool eventFilter(QObject *pObject, QEvent *pEvent);

private:
	bool checkNecessaryFiles();
	void switchRenderTargetEngine();
	void terminateEngine();
	
	QString projectPath;//the path to the project-directory
	Engine *pEngine;	//pointer to the 3d-engine
	int		timerID;	//the no of the continous timer
	QWidget *topParent;	//the top parent (the main window)

	PreviewFullscreenBase *fullscreenPreview; // the fullscreen window

	//all written characters
	char keyBuffer[KEY_BUFFER_SIZE];
	//number of written characters
	int keyCount;

public slots:
	void windowClicked();
	void fullscreenClicked();
};

#endif
