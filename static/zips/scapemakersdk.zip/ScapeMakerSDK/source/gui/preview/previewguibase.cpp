/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\preview\previewguibase.ui'
**
** Created: Sun Feb 13 15:03:33 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "previewguibase.h"

#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a PreviewGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
PreviewGUIBase::PreviewGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "PreviewGUIBase" );
    resize( 501, 479 ); 
    setCaption( tr( "PreviewGUI" ) );
    QWhatsThis::add(  this, tr( "The 3D-Mode displays the landscape in 3d and allows the user to move around freely in it." ) );

    renderTarget = new QLabel( this, "renderTarget" );
    renderTarget->setGeometry( QRect( 0, 0, 500, 420 ) ); 
    renderTarget->setText( tr( "Choose your render target..." ) );
    renderTarget->setScaledContents( FALSE );
    renderTarget->setAlignment( int( QLabel::AlignCenter ) );

    fullscreen = new QPushButton( this, "fullscreen" );
    fullscreen->setGeometry( QRect( 0, 430, 80, 25 ) ); 
    fullscreen->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, fullscreen->sizePolicy().hasHeightForWidth() ) );
    fullscreen->setText( tr( "Fullscreen" ) );
    QWhatsThis::add(  fullscreen, tr( "Shows the 3d scene in fullscreen." ) );

    window = new QPushButton( this, "window" );
    window->setGeometry( QRect( 85, 430, 80, 25 ) ); 
    window->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, window->sizePolicy().hasHeightForWidth() ) );
    window->setText( tr( "Window" ) );
    window->setDefault( FALSE );
    QWhatsThis::add(  window, tr( "Shows the 3d scene in this window." ) );

    // signals and slots connections
    connect( window, SIGNAL( clicked() ), this, SLOT( windowClicked() ) );
    connect( fullscreen, SIGNAL( clicked() ), this, SLOT( fullscreenClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
PreviewGUIBase::~PreviewGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

void PreviewGUIBase::fullscreenClicked()
{
    qWarning( "PreviewGUIBase::fullscreenClicked(): Not implemented yet!" );
}

void PreviewGUIBase::windowClicked()
{
    qWarning( "PreviewGUIBase::windowClicked(): Not implemented yet!" );
}

