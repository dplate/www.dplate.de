/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\preview\previewguibase.ui'
**
** Created: Sun Feb 13 15:03:33 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef PREVIEWGUIBASE_H
#define PREVIEWGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QPushButton;

class PreviewGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    PreviewGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~PreviewGUIBase();

    QLabel* renderTarget;
    QPushButton* fullscreen;
    QPushButton* window;

public slots:
    virtual void fullscreenClicked();
    virtual void windowClicked();

};

#endif // PREVIEWGUIBASE_H
