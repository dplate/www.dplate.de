/****************************************************************************
** Base Dialog
**
** main window of the application, handles the events
** 
** Author: Matthias Buchetics
****************************************************************************/

#include "scapemakerdialog.h"
#include "./topography/topografiegui.h"
#include "./texture/texturegui.h"
#include "./environment/enviromentgui.h"
#include "./clouds/cloudsgui.h"
#include "./water/watergui.h"
#include "./objects/objectsgui.h"
#include "./preview/previewgui.h"
#include "./load/loadgui.h"
#include <qstring.h>
#include <qlabel.h>
#include <qcheckbox.h>
#include <qgroupbox.h>
#include <qpushbutton.h>
#include <qbutton.h>
#include <qradiobutton.h>
#include <qbuttongroup.h>
#include <process.h>

/****************************************************************************
** ScapeMakerDialog Constructor
**
** show the load landscape dialog
** 
** Author: Matthias Buchetics / Dirk Plate
****************************************************************************/
ScapeMakerDialog::ScapeMakerDialog( QWidget* parent, const char* name, bool modal, WFlags f )
	: ScapeMakerDialogBase( parent, name, modal, f )
{
	//create menu bar
  	QPopupMenu *fileMenu = new QPopupMenu(this);
    fileMenu->insertItem( tr("&Manage landscapes"), this, SLOT(selectLandscapeClicked()));
	fileMenu->insertItem( tr("&Config"), this, SLOT(configClicked()));
    fileMenu->insertSeparator();
    fileMenu->insertItem( tr("E&xit"), this, SLOT(exitClicked()));

	QPopupMenu *helpMenu = new QPopupMenu(this);
	helpMenu->insertItem( tr("&Manual"), this, SLOT(manualClicked()));
	helpMenu->insertItem( tr("T&utorial"), this, SLOT(tutorialClicked()));
	helpMenu->insertItem( tr("&Keys in 3d mode"), this, SLOT(keys3DModeClicked()));
	helpMenu->insertItem( tr("Official &website"), this, SLOT(websiteClicked()));
    helpMenu->insertItem( tr("&About"), this, SLOT(infoClicked()));
	
	menuBar = new QMenuBar(this);
	menuBar->insertItem(tr("&File"),fileMenu);
	menuBar->insertItem(tr("&Help"),helpMenu);
	
	//at the beginning... the tab container is invisible
	tabContainer->hide();

	startUpTimerId = -1;
	autoStartProject = "";
	projectPath = "";
	projectName = "";
	autoStartTab = 0;
}

/****************************************************************************
** ScapeMakerDialog selectLandscapeClicked
**
** called if select landscape in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::selectLandscapeClicked()
{
	LoadGUI dialog(this,"loadGUI",true,WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu | WStyle_ContextHelp);
	dialog.show();

	QString projectName = dialog.getSelectedLandscape();
	
	//try to load landscape
	if (!loadLandscape(projectName,0))
	{
		tabContainer->hide();	//hide tab container
		return;
	}
}

/****************************************************************************
** ScapeMakerDialog configClicked
**
** called if config in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::configClicked()
{
	ConfigGUI dialog(this,"configGUI",true,WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu | WStyle_ContextHelp);
	dialog.show();

	//check if restart is required
	if (dialog.isRestartRequired())
	{
		tabContainer->hide();	//hide tab container (saving current tab)

		//do a restart
		const char* parameter1 =  projectName.latin1();
		int currentTab = tabContainer->currentPageIndex();
		QString currentTabString = QString("%1").arg(currentTab);
		const char* parameter2 =  currentTabString.latin1();
		_execl("./scapemaker.exe", " ", parameter1, parameter2, NULL);
	}
}

/****************************************************************************
** ScapeMakerDialog manualEnglishClicked
**
** called if manual in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::manualClicked()
{
	openURL(tr("manual_e.html"));
}


/****************************************************************************
** ScapeMakerDialog tutorialClicked
**
** called if tutorial in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::tutorialClicked()
{
	openURL(tr("tutorial_e.html"));
}

/****************************************************************************
** ScapeMakerDialog website Clicked
**
** called if website in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::websiteClicked()
{
	openURL("http://www.scapemaker.de.vu");
}

/****************************************************************************
** ScapeMakerDialog openURL
**
** open an url in the local browser
** 
** Author: Dirk Plate
****************************************************************************/

void ScapeMakerDialog::openURL( QString url )
{
	if ((unsigned int)::ShellExecute(qApp->mainWidget()->winId(), NULL, url, NULL, NULL, SW_SHOW) <= 32)
	{
		QMessageBox::critical(this, tr("Error"), tr("Unable to open a web browser. Ensure that you have a web browser installed."));
	}
}

/****************************************************************************
** ScapeMakerDialog infoClicked
**
** called if info in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/

void ScapeMakerDialog::infoClicked()
{
	InfoGUIBase dialog(this,"infoGUI",true,WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu);
	dialog.show();
}

/****************************************************************************
** ScapeMakerDialog keys3dmodeClicked
**
** show the keys in 3d mode help
** 
** Author: Dirk Plate
****************************************************************************/

void ScapeMakerDialog::keys3DModeClicked()
{
	Keys3DMode dialog(this,"keys3DMode",true,WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu);
	dialog.show();
}

/****************************************************************************
** ScapeMakerDialog exitClicked
**
** called if exit in menu bar was clicked
** 
** Author: Dirk Plate
****************************************************************************/

void ScapeMakerDialog::exitClicked()
{
	//hide tab container
	tabContainer->hide();	

	//quit application
	qApp->quit();
}

/****************************************************************************
** ScapeMakerDialog showEvent
**
** Is called, when the main Window will be shown. 
**   
** Author: Dirk Plate
****************************************************************************/

void ScapeMakerDialog::showEvent(QShowEvent *showEvent)
{
	if (startUpTimerId == -1)
	{
		//show the select landscape dialog after the specified time (because there is no event *after* the dialog is shown)
		startUpTimerId = startTimer(1000);
	}
}


/****************************************************************************
** ScapeMakerDialog timerEvent
**
** is called every time, when timer hits
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::timerEvent(QTimerEvent * timer)
{
	if (timer->timerId() == startUpTimerId)
	{
		//only once
		killTimer(startUpTimerId);
		startUpTimerId = -2;

		//auto start project set? ... try to load it
		if (!loadLandscape(autoStartProject,autoStartTab))
		{
			//show select landscape dialog
			selectLandscapeClicked();
		}
	}
}

/****************************************************************************
** ScapeMakerDialog setAutoStartProject
**
** set a project name with this method. The project is auto loaded at start up
** 
** Author: Dirk Plate
****************************************************************************/
void ScapeMakerDialog::setAutoStartProject(QString project, int tab)
{
	autoStartProject = project;
	autoStartTab = tab;
}

/****************************************************************************
** ScapeMakerDialog loadLandscape
**
** try to load a landscape
** 
** Author: Dirk Plate
****************************************************************************/
bool ScapeMakerDialog::loadLandscape(QString name, int tab)
{
	//wrong name ... return false
	if ((name.isNull() || name.isEmpty() || name == "") || (tab < 0))
	{
		projectPath = "";
		projectName = "";
		return false;
	}
		
	//make a real path out of this
	projectPath = "./landscapes/"+name;

	//check if path exist
	QFileInfo fileInfo(projectPath);
	if (!fileInfo.exists() || !fileInfo.isDir())
	{
		projectPath = "";
		projectName = "";
		return false;
	}
	projectName = name;

	//save old properties
	tabContainer->hide();		

	//set the project path for all tabs
	topografieContainer->setProjectPath(projectPath);
	textureContainer->setProjectPath(projectPath);
	cloudsContainer->setProjectPath(projectPath);
	waterContainer->setProjectPath(projectPath);
	enviromentContainer->setProjectPath(projectPath);
	objectsContainer->setProjectPath(projectPath);
	previewContainer->setProjectPath(projectPath);

	//show the first page of the tab container
	tabContainer->setCurrentPage(tab);
	tabContainer->show();

	return true;
}