/****************************************************************************
** Base Dialog
**
** main window of the application, handles the events
** 
** Author: Matthias Buchetics
****************************************************************************/
#ifndef SCAPEMAKERDIALOG_H
#define SCAPEMAKERDIALOG_H
#pragma warning(disable:4786)

#include "scapemakerdialogbase.h"
#include "./config/configgui.h"
#include "./info/infoguibase.h"
#include "./keys3dmode.h"
#include <qpopupmenu.h>
#include <qmenubar.h>

class ScapeMakerDialog : public ScapeMakerDialogBase
{
	Q_OBJECT
public:
	ScapeMakerDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags f = 0 );
	void setAutoStartProject(QString projectName, int tab);

	QMenuBar *menuBar;

public slots:
	void selectLandscapeClicked();	//show the landscape administration dialog
	void configClicked();			//show the config dialog
	void manualClicked();			//open the  manual
	void tutorialClicked();			//open the tutorial
	void websiteClicked();			//open the scapemaker website
	void infoClicked();				//show the info dialog
	void keys3DModeClicked();		//show the keys in 3d mode help
	void exitClicked();				//exit program

protected:
    void timerEvent(QTimerEvent *);
	void showEvent(QShowEvent *showEvent);
	void openURL( QString url );	//open an url in the local browser

private:
	bool loadLandscape(QString name, int tab);

	QString autoStartProject;		//the name of a project which is auto started
	int autoStartTab;				//tab which will be displayed after auto start
	QString projectPath;			//the path to the project-directory
	QString projectName;			//the name of the project
	int startUpTimerId;
};

#endif // SCAPEMAKERDIALOG_H