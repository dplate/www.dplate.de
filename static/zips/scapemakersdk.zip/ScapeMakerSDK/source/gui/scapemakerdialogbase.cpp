/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\scapemakerdialogbase.ui'
**
** Created: Sun Feb 13 15:03:30 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "scapemakerdialogbase.h"

#include <qlabel.h>
#include <qtabwidget.h>
#include <qwidget.h>
#include "./clouds/cloudsgui.h"
#include "./environment/enviromentgui.h"
#include "./objects/objectsgui.h"
#include "./preview/previewgui.h"
#include "./texture/texturegui.h"
#include "./topography/topografiegui.h"
#include "./water/watergui.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"32 32 254 2",
"bf c #080808",
"bA c #090909",
"aR c #0a0a0a",
"aX c #0b0b0b",
"#X c #0c0c0c",
"bH c #0d0d0d",
"#r c #0e0e0e",
".J c #101010",
"## c #111111",
".9 c #121212",
".N c #131313",
".O c #141414",
"#Y c #151515",
".j c #161616",
"a0 c #171717",
"av c #181818",
"ax c #191919",
".7 c #1a1a1a",
"a# c #1b1b1b",
"#1 c #1c1c1c",
"bo c #1d1d1d",
"bk c #1e1e1e",
".k c #1f1f1f",
"#. c #202020",
"be c #212121",
"bS c #222222",
"bi c #232323",
"#U c #242424",
"a1 c #252525",
".6 c #262626",
"#J c #282828",
"bE c #292929",
"am c #2a2a2a",
"ba c #2b2b2b",
"a9 c #2c2c2c",
"bj c #2d2d2d",
"aZ c #2e2e2e",
".8 c #2f2f2f",
"#q c #303030",
"#s c #313131",
"#H c #323232",
"aJ c #333333",
"#7 c #343434",
"bm c #353535",
"#K c #363636",
"#a c #363637",
"#T c #373737",
"#V c #383838",
".M c #383839",
"aw c #393939",
"aY c #3a3a3a",
"ab c #3b3b3b",
"#0 c #3c3c3c",
".P c #3d3d3d",
".K c #3e3e3e",
"#L c #404040",
"aI c #414141",
"bg c #424242",
"bl c #434343",
"az c #444444",
".I c #464646",
"#8 c #474747",
"bX c #484848",
"br c #494949",
"#p c #4a4a4a",
"ar c #4b4b4b",
"bq c #4c4c4c",
"aa c #4d4d4d",
"bp c #4e4e4e",
"a5 c #4f4f4f",
"#Z c #505050",
"bd c #515151",
"aj c #525252",
"#E c #535353",
"aS c #545453",
"aA c #545454",
"bn c #555555",
"a4 c #565656",
"bs c #575757",
"bt c #585858",
"#2 c #585859",
"aH c #595959",
"#I c #5a5a5a",
"#M c #5b5b5b",
"bu c #5c5c5c",
".p c #5d5d5d",
".i c #5e5e5e",
".o c #5f5f5f",
"ay c #606060",
".l c #616161",
"#F c #636362",
"#D c #636363",
"bB c #646464",
"#9 c #656565",
"an c #666666",
".L c #676767",
"bc c #686868",
"aT c #696969",
"#S c #6a6a6a",
"a. c #6b6b6b",
"#W c #6c6c6c",
"bO c #6d6d6c",
"al c #6d6d6d",
"ac c #6e6e6e",
"as c #6f6f6f",
"aG c #707070",
".q c #717171",
".n c #727271",
"ak c #737373",
"#o c #747474",
"#j c #757575",
"aF c #767676",
"bh c #767677",
"#6 c #777776",
"a7 c #777777",
"ad c #787878",
"bw c #797978",
"#N c #797979",
"bv c #7a7a79",
"#i c #7a7a7a",
"aq c #7b7b7b",
"#t c #7c7c7c",
"#u c #7d7d7d",
"bF c #7e7e7d",
".H c #7e7e7e",
"au c #7f7f7f",
"b# c #80807f",
"ai c #808080",
".Q c #818181",
"bz c #828282",
"ae c #838383",
"ap c #848484",
"#n c #858584",
"#w c #858585",
".r c #868686",
"a8 c #878786",
"aO c #878787",
"#G c #888888",
"bb c #898988",
"ao c #898989",
"bZ c #8a8a89",
".m c #8a8a8a",
"by c #8b8b8a",
"#C c #8b8b8b",
"#k c #8c8c8c",
"#v c #8d8d8d",
".0 c #8e8e8d",
"ah c #8e8e8e",
"aC c #8f8f8f",
"a6 c #919190",
".Z c #919191",
"bG c #929291",
"bx c #929292",
"bV c #939393",
"#l c #949493",
"ag c #949494",
"aP c #959595",
"aB c #969696",
"#x c #979797",
"af c #989898",
"#R c #999998",
"aW c #999999",
"aN c #9a9a9a",
"#h c #9b9b9b",
"bI c #9b9b9c",
".Y c #9c9c9c",
"#m c #9d9d9d",
"#4 c #9e9e9e",
"bY c #9f9f9f",
"#5 c #a0a0a0",
"aQ c #a1a1a1",
".3 c #a2a2a2",
"#O c #a3a3a2",
"#B c #a3a3a3",
"#d c #a4a4a4",
"bC c #a5a5a5",
".B c #a6a6a6",
"b0 c #a7a7a6",
".1 c #a7a7a7",
"aE c #a8a8a8",
".C c #a9a9a9",
"#3 c #a9a9aa",
"b. c #aaaaa9",
"#b c #aaaaaa",
"bD c #ababaa",
".2 c #ababab",
".s c #acacac",
".X c #adadad",
"b1 c #adadae",
".A c #aeaeae",
"at c #afafaf",
".4 c #b0b0b0",
".S c #b1b1b1",
"aK c #b2b2b2",
"#Q c #b3b3b2",
"#A c #b3b3b3",
".D c #b4b4b4",
"#c c #b5b5b5",
".G c #b6b6b6",
".z c #b7b7b7",
".h c #b8b8b8",
"#g c #b9b9b9",
".a c #bababa",
"aD c #bababb",
".y c #bbbbbb",
".T c #bcbcbc",
".E c #bdbdbd",
"bJ c #bebebe",
"#y c #bfbfbf",
"#e c #c0c0c0",
".F c #c1c1c1",
".b c #c2c2c2",
"Qt c #c3c3c3",
"#z c #c4c4c4",
"bT c #c5c5c5",
".5 c #c6c6c6",
".R c #c7c7c7",
".c c #c8c8c8",
".U c #c9c9c9",
".# c #cacaca",
"aV c #cbcbcb",
".v c #cccccc",
".f c #cdcdcd",
"aM c #cecece",
".V c #cfcfcf",
".e c #d0d0d0",
".w c #d1d1d1",
"#P c #d2d2d2",
".W c #d3d3d3",
"bU c #d4d4d4",
"#f c #d5d5d5",
".d c #d6d6d6",
".x c #d7d7d7",
"aL c #d8d8d8",
"bW c #d9d9d9",
".t c #dadada",
"bK c #dbdbdb",
".g c #dddddd",
"bN c #dfdfdf",
"bR c #e0e0e0",
"bM c #e1e1e1",
".u c #e2e2e2",
"bQ c #e3e3e3",
"a2 c #e5e5e5",
"a3 c #e6e6e6",
"bL c #e9e9e9",
"b2 c #ebebeb",
"aU c #ededed",
"b5 c #f0f0f0",
"b3 c #f1f1f1",
"b4 c #f3f3f3",
"bP c #f6f6f6",
"b7 c #f8f8f8",
"b6 c #fafafa",
"Qt.#Qt.a.b.c.#.d.e.f.g.h.i.j.k.l.m.n.o.p.q.r.s.t.u.v.b.#.w.w.w.x",
".y.z.A.B.C.D.E.F.D.yQt.G.H.I.J.K.L.M.N.O.P.Q.z.R.eQt.S.T.c.U.V.W",
".T.X.Y.Z.0.1.2.3.4.5.4.1.B.q.6.7.8.9#.###a.0#b.C#c#d.4.R.R#e.U#f",
"#g#c#h#i#j#k#k#l.B.4.E#m#n#o#p#####q.P#r#s#t#u#v#w#x#y#z#A.z#y.v",
"Qt#e#B#C#D#E#F.q.Q.B.R.z#G#E#q.J#H#I#J.N.P#K#L#M#N#OQt.F.1#g.##P",
"#P.b#Q#R#S#T#U#V#W.3.4.A.3.o.N#X#Y#Z#0##.k.9#1#K#2#G#d#3#4#d.z.v",
".v.z#5#w#6#M#7.9#8#S#9.L#Na.#Ta##Yaa#D#0.6.Pab#qab#Macadaeaf.GQt",
"Qt#bag.Zahai.L.k.7a#.9.kajakalam.J.6an.m#Caoapaq.laras.mag.A.y#y",
".T.A.s#bat.Cau#Vavamawaxav#Tayaza###aA.B.U.#.b.S#4aBaC.4#zaDaE.E",
"#y.E#e.5.yaEaF.i#SaGaH#1.9##aIaJ#r.k#paCaK.W.uaL.f#g#d.C.D#m.Y.4",
".U#z.vaM.TaNaOaPaQ#t#saR.8am#Y.k.9aSaT#N#d#eaUaUaV.AaW#G.H.n.maP",
".v.T.b#y#e.D#A.Aao#Wa#aXaYaAaZa0a1.o#x.2.FaVa2a3.e#y#A#ka4#8aG.Y",
".w.h.z.4aE.h#g.C.ra5.6#X#1.Lac.i#9aGa6#A#d#g.E.V.WaV.y.raI#Ha7aK",
".f.A#B#4a8#kaN#Gad.P.Ja0a9.qae#E#VaraF#Na7aB.C#z.4#cb.b#ba#q.H.S",
".c#BbbahaqaH#Ebcbdbebfaw#pbg.K#1#r#Yam#L.Laoaf#h.r#5#bbh#7bi#SaP",
"#yaQapaT.objav#Hbk.7axava0#Y.9a#bl#V.9#J.oac#I#8#pae.2#ubmavbnap",
".a#AaNay#qambm.Jbobpbq.k.7br.lbs#oaqaZ.Jbi.k#Y#r#U#Sagak#qaX#Hbt",
"#zQt#h.oazbu#S#EbsbvbwbnaHa7#4aNbxbyaA#7.6.6a9###U#ubz#8a#bA##.J",
".T.C.rbB.Hbx#4.Y.mbx#hafaW.X.ybC.naT.q.HacbB#E.NawadaGbaaXbj.P#U",
".c#d.H#v#baK.D#c#x.Q.ZbD#bat#m.rajbeaYan#M#sbE##.kaw#U.Ja9.LbFas",
".##b#4#AaM.5.s#5bGad#D#ua8aN.m.p#sbA#XbjbEbHaX#1a###.J.NaZ.LbI#d",
".TbJ.T#gbK.x.4#x.3apbpaIbtal#Saa.9a1bE.O#Xa9bl#Z.pa5bgbqaj#pad.X",
".f.w.RQt.W.W.y.a.4aWa7#Z#T.8#1av#YaAas#p#Y#Jan#N#v.Z#GaO#v#ja7.A",
"bLa2bM.t.tbNaM.D#b.s#vbO#T#rbe#1aYan.raT#7#rbi#0#D#4#z.z.D.saW.s",
"bPbQ#fbRbR.d.R#5aO.m#WaY##a9aH#8bd#uaPae.l#0bSbHaz#x.X.s.y.c.v.f",
"bR#fbTbU#f.b.CbVaF.i#7.Ja9.oaiad#M#S.Y.Cahas#s.Oa5bc.i#u#5.baMbW",
".x#e.hbT.G.3ahaGbl.6.Jam#MapaQaNap.HaC.AaN#N#Va#aZam#Ja4ah.3at.v",
"aL.TbCaN.ZaFbs#La9#J#s.i#taCaE#5#4bCaNb..B.H.laY#H.PbXbladaB.2#e",
"aM.a.1#wa.bsajbd.l#o#Sacafat.Sat.a.T.S.2#xahai#i#G#G#obu#SbY.y.R",
"#zaKafbZ.H#6#C#x#l.1.B#vahbJ.dbT.F.cQt#z.z.zb0#h.4b1bG#G#tbV.zaM",
".aaE.3.2aQ.YaK.z.4at.R.E#dQtb2bK.e.V.tbMbN.x.v#c#c#e.A#m#m#4#b.5",
".E#A#g.5.b#y.5.v.V#z.VaL#e.Rb2b3b4b2b5b6b7aU.gaMaMaMQt#g.4#c.SbT"};


/* 
 *  Constructs a ScapeMakerDialogBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
ScapeMakerDialogBase::ScapeMakerDialogBase( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    if ( !name )
	setName( "ScapeMakerDialogBase" );
    resize( 540, 546 ); 
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 540, 545 ) );
    setMaximumSize( QSize( 540, 550 ) );
    setCaption( tr( "ScapeMaker" ) );
    setIcon( image0 );
    setSizeGripEnabled( FALSE );

    tabContainer = new QTabWidget( this, "tabContainer" );
    tabContainer->setGeometry( QRect( 10, 25, 521, 501 ) ); 
    tabContainer->setTabPosition( QTabWidget::Top );
    tabContainer->setTabShape( QTabWidget::Rounded );

    topografie = new QWidget( tabContainer, "topografie" );

    topografieContainer = new TopografieGUI( topografie, "topografieContainer" );
    topografieContainer->setGeometry( QRect( 10, 10, 500, 460 ) ); 
    tabContainer->insertTab( topografie, tr( "Topography" ) );

    water = new QWidget( tabContainer, "water" );

    waterContainer = new WaterGUI( water, "waterContainer" );
    waterContainer->setGeometry( QRect( 10, 10, 500, 460 ) ); 
    tabContainer->insertTab( water, tr( "Water" ) );

    texture = new QWidget( tabContainer, "texture" );

    textureContainer = new TextureGUI( texture, "textureContainer" );
    textureContainer->setGeometry( QRect( 10, 10, 501, 461 ) ); 
    tabContainer->insertTab( texture, tr( "Texture" ) );

    objects = new QWidget( tabContainer, "objects" );

    objectsContainer = new ObjectsGUI( objects, "objectsContainer" );
    objectsContainer->setGeometry( QRect( 10, 10, 501, 461 ) ); 
    tabContainer->insertTab( objects, tr( "Objects" ) );

    clouds = new QWidget( tabContainer, "clouds" );

    cloudsContainer = new CloudsGUI( clouds, "cloudsContainer" );
    cloudsContainer->setGeometry( QRect( 10, 10, 501, 461 ) ); 
    tabContainer->insertTab( clouds, tr( "Clouds" ) );

    enviroment = new QWidget( tabContainer, "enviroment" );

    enviromentContainer = new EnviromentGUI( enviroment, "enviromentContainer" );
    enviromentContainer->setGeometry( QRect( 10, 10, 501, 461 ) ); 
    tabContainer->insertTab( enviroment, tr( "Environment" ) );

    preview = new QWidget( tabContainer, "preview" );

    previewContainer = new PreviewGUI( preview, "previewContainer" );
    previewContainer->setGeometry( QRect( 10, 10, 500, 460 ) ); 
    previewContainer->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, previewContainer->sizePolicy().hasHeightForWidth() ) );
    tabContainer->insertTab( preview, tr( "3D" ) );

    copyrightText = new QLabel( this, "copyrightText" );
    copyrightText->setGeometry( QRect( 120, 525, 400, 20 ) ); 
    QFont copyrightText_font(  copyrightText->font() );
    copyrightText_font.setFamily( "Arial" );
    copyrightText_font.setPointSize( 7 );
    copyrightText->setFont( copyrightText_font ); 
    copyrightText->setText( tr( QString::fromUtf8( "© Matthias Buchetics, Dirk Plate 2005" ) ) );
    copyrightText->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignRight ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ScapeMakerDialogBase::~ScapeMakerDialogBase()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool ScapeMakerDialogBase::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont copyrightText_font(  copyrightText->font() );
	copyrightText_font.setFamily( "Arial" );
	copyrightText_font.setPointSize( 7 );
	copyrightText->setFont( copyrightText_font ); 
    }
    return ret;
}

