/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\scapemakerdialogbase.ui'
**
** Created: Sun Feb 13 15:03:30 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef SCAPEMAKERDIALOGBASE_H
#define SCAPEMAKERDIALOGBASE_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class CloudsGUI;
class EnviromentGUI;
class ObjectsGUI;
class PreviewGUI;
class QLabel;
class QTabWidget;
class QWidget;
class TextureGUI;
class TopografieGUI;
class WaterGUI;

class ScapeMakerDialogBase : public QDialog
{ 
    Q_OBJECT

public:
    ScapeMakerDialogBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~ScapeMakerDialogBase();

    QTabWidget* tabContainer;
    QWidget* topografie;
    TopografieGUI* topografieContainer;
    QWidget* water;
    WaterGUI* waterContainer;
    QWidget* texture;
    TextureGUI* textureContainer;
    QWidget* objects;
    ObjectsGUI* objectsContainer;
    QWidget* clouds;
    CloudsGUI* cloudsContainer;
    QWidget* enviroment;
    EnviromentGUI* enviromentContainer;
    QWidget* preview;
    PreviewGUI* previewContainer;
    QLabel* copyrightText;

protected:
    bool event( QEvent* );
};

#endif // SCAPEMAKERDIALOGBASE_H
