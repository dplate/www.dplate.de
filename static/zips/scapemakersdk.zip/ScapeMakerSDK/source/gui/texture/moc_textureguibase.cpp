/****************************************************************************
** TextureGUIBase meta object code from reading C++ file 'textureguibase.h'
**
** Created: Sun Feb 13 15:03:31 2005
**      by: The Qt MOC ($Id: //depot/qt/main/src/moc/moc.y#178 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#define Q_MOC_TextureGUIBase
#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 8
#elif Q_MOC_OUTPUT_REVISION != 8
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "textureguibase.h"
#include <qmetaobject.h>
#include <qapplication.h>

#if defined(Q_SPARCWORKS_FUNCP_BUG)
#define Q_AMPERSAND
#else
#define Q_AMPERSAND &
#endif


const char *TextureGUIBase::className() const
{
    return "TextureGUIBase";
}

QMetaObject *TextureGUIBase::metaObj = 0;

void TextureGUIBase::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("TextureGUIBase","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION
QString TextureGUIBase::tr(const char* s)
{
    return ((QNonBaseApplication*)qApp)->translate("TextureGUIBase",s);
}

#endif // QT_NO_TRANSLATION
QMetaObject* TextureGUIBase::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void(TextureGUIBase::*m1_t0)();
    typedef void(TextureGUIBase::*m1_t1)();
    typedef void(TextureGUIBase::*m1_t2)();
    typedef void(TextureGUIBase::*m1_t3)();
    typedef void(TextureGUIBase::*m1_t4)();
    typedef void(TextureGUIBase::*m1_t5)();
    typedef void(TextureGUIBase::*m1_t6)();
    typedef void(TextureGUIBase::*m1_t7)();
    typedef void(TextureGUIBase::*m1_t8)();
    typedef void(TextureGUIBase::*m1_t9)();
    typedef void(TextureGUIBase::*m1_t10)();
    typedef void(TextureGUIBase::*m1_t11)();
    typedef void(TextureGUIBase::*m1_t12)();
    typedef void(TextureGUIBase::*m1_t13)();
    typedef void(TextureGUIBase::*m1_t14)();
    m1_t0 v1_0 = Q_AMPERSAND TextureGUIBase::addClicked;
    m1_t1 v1_1 = Q_AMPERSAND TextureGUIBase::cancelClicked;
    m1_t2 v1_2 = Q_AMPERSAND TextureGUIBase::downClicked;
    m1_t3 v1_3 = Q_AMPERSAND TextureGUIBase::exportClicked;
    m1_t4 v1_4 = Q_AMPERSAND TextureGUIBase::generateClicked;
    m1_t5 v1_5 = Q_AMPERSAND TextureGUIBase::importDetailClicked;
    m1_t6 v1_6 = Q_AMPERSAND TextureGUIBase::importMaskClicked;
    m1_t7 v1_7 = Q_AMPERSAND TextureGUIBase::importTextureClicked;
    m1_t8 v1_8 = Q_AMPERSAND TextureGUIBase::resetDetailClicked;
    m1_t9 v1_9 = Q_AMPERSAND TextureGUIBase::removeClicked;
    m1_t10 v1_10 = Q_AMPERSAND TextureGUIBase::renameClicked;
    m1_t11 v1_11 = Q_AMPERSAND TextureGUIBase::resetMaskClicked;
    m1_t12 v1_12 = Q_AMPERSAND TextureGUIBase::textureSelected;
    m1_t13 v1_13 = Q_AMPERSAND TextureGUIBase::upClicked;
    m1_t14 v1_14 = Q_AMPERSAND TextureGUIBase::valuesChanged;
    QMetaData *slot_tbl = QMetaObject::new_metadata(15);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(15);
    slot_tbl[0].name = "addClicked()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "cancelClicked()";
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "downClicked()";
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "exportClicked()";
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "generateClicked()";
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "importDetailClicked()";
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "importMaskClicked()";
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "importTextureClicked()";
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "resetDetailClicked()";
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl_access[8] = QMetaData::Public;
    slot_tbl[9].name = "removeClicked()";
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl_access[9] = QMetaData::Public;
    slot_tbl[10].name = "renameClicked()";
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl_access[10] = QMetaData::Public;
    slot_tbl[11].name = "resetMaskClicked()";
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl_access[11] = QMetaData::Public;
    slot_tbl[12].name = "textureSelected()";
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl_access[12] = QMetaData::Public;
    slot_tbl[13].name = "upClicked()";
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl_access[13] = QMetaData::Public;
    slot_tbl[14].name = "valuesChanged()";
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl_access[14] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"TextureGUIBase", "QWidget",
	slot_tbl, 15,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
