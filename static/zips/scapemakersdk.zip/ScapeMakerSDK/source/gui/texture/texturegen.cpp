/****************************************************************************
** TextureGen
**
** The texture generator class
**
** Author: Dirk Plate
****************************************************************************/

#include "texturegen.h"
#include "math.h"
#include "../../engine/common/enginehelpers.h"
#include "ximage.h"
#include "../common/guihelpers.h"

/****************************************************************************
** TextureGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

TextureGen::TextureGen()
{
	distribution = false;
}

/****************************************************************************
** TextureGen generate
**
** starts the generation of the textures
**
** Author: Dirk Plate
****************************************************************************/

void TextureGen::generateDistributionPreview(Heightmap *pHeightMapSet, CxImage *pDistributionBitmapSet,
	OneTexture *parameter)
{
	//stop a old thread
	cancel();
	
	//save all settings intern
	pHeightMap = pHeightMapSet;
	pDistributionBitmap = pDistributionBitmapSet;
	currentParameter = parameter;
	parameter->heightSmoothRange = 
		(int)((float)MAXHEIGHTSMOOTHRANGE*((float)currentParameter->smoothness/100.0f));
	parameter->slopeSmoothRange = 
		(int)((float)MAXSLOPESMOOTHRANGE*((float)currentParameter->smoothness/100.0f));

	//this is only the distribution preview
	distribution = true;

	//start the generate thread
	start();
}

/****************************************************************************
** TextureGen generate
**
** starts the generation of the textures
**
** Author: Dirk Plate
****************************************************************************/

void TextureGen::generate(Heightmap *pHeightMapSet, int *pProgressSet, CxImage *pPreviewBitmapSet, 
		QString texturePathSet,int resolutionSet,	OneTexture *parameter, int count)
{
	//save all settings intern
	pHeightMap = pHeightMapSet;
	pProgress = pProgressSet;
	pPreviewBitmap = pPreviewBitmapSet;
	texturePath = texturePathSet;
	currentParameter = parameter;
	resolution = resolutionSet;
	currentCount = count;
	for (int i=0;i<count;i++)
	{
		parameter[i].heightSmoothRange = 
			(int)((float)MAXHEIGHTSMOOTHRANGE*((float)currentParameter[i].smoothness/100.0f));
		parameter[i].slopeSmoothRange = 
			(int)((float)MAXSLOPESMOOTHRANGE*((float)currentParameter[i].smoothness/100.0f));
	}

	//we are making the real texture
	distribution = false;

	//start the generate thread
	start();
}

/****************************************************************************
** TextureGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void TextureGen::cancel()
{
	//set flag true, so the thread will stop
	if (running()) cancelFlag = true;
}

/****************************************************************************
** TextureGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void TextureGen::run()
{
	//init cancel-flag
	cancelFlag = false;
	
	if (distribution) doDistributionPreview();
	else doGeneration();
}

/****************************************************************************
** TextureGen doDistributionPreview
**
** this is the real generation of the distribution preview
**
** Author: Dirk Plate
****************************************************************************/

void TextureGen::doDistributionPreview()
{
	int x,y;
	int height;
	float slope;
	float alpha;
	float mask;
	float maskX, maskY;
	RGBQUAD color;

	for (y=0;y<pHeightMap->getSize();y++)
		for (x=0;x<pHeightMap->getSize();x++)
	{
		if (cancelFlag) return;

		//retrieve ground parameters
		height = pHeightMap->getHeightInMeters(x,y);
		slope = pHeightMap->getSlope(x,y);

		//retrieve mask value
		maskX = (float)(x*currentParameter[0].maskBitmap.GetWidth())/pHeightMap->getSize();
		maskY = (float)(y*currentParameter[0].maskBitmap.GetHeight())/pHeightMap->getSize();
		mask = getInterpolatedMaskValue(maskX,maskY,0);

		//calculate the intensity
		alpha = getTextureIntensity(height,slope,mask,0);

		//set this pixel in the distribution bitmap
		color.rgbRed = 255;
		color.rgbGreen = 0;
		color.rgbBlue = 0;
		color.rgbReserved = (int)(alpha*255);
		pDistributionBitmap->SetPixelColor(x,y,color,true);
	}
}

/****************************************************************************
** TextureGen doGeneration
**
** this is the real generation of the texture
**
** Author: Dirk Plate
****************************************************************************/

void TextureGen::doGeneration()
{
	int tileX,tileY;
	int maxTile = (pHeightMap->getSize())/TILE_SIZE;
	int tileTextureX,tileTextureY;
	int absTextureX, absTextureY;
	float heightMapX,heightMapY;
	int textureX,textureY;
	float maskX,maskY;
	int x,y;
	int i;
	float height;
	float slope;
	float mask;
	float alpha;
	float invAlpha;
	RGBQUAD color;
	RGBQUAD newColor;
	CxImage tileTexture; 
	CxImage previewTile;
	float progressValue;

	*pProgress = 0;
	exactProgress = 0.0f;

	//create the tile texture
	tileTexture.Create(resolution,resolution,24);

	//calculate the progress value
	progressValue=100.0f/(maxTile*maxTile);

	//prepare all textures
	for (i=0;i<currentCount;i++)
	{
		//calculate current segment in mask
		currentParameter[i].maskFactorX = (float)(currentParameter[i].maskBitmap.GetWidth())/
										  (maxTile*resolution);
		currentParameter[i].maskFactorY = (float)(currentParameter[i].maskBitmap.GetHeight())/
										  (maxTile*resolution);
	}

	//go through all tiles
	for (tileY=0;tileY<maxTile;tileY++)
		for (tileX=0;tileX<maxTile;tileX++)
	{
		//init tile texture
		tileTexture.Clear(0);

		//go through all pixels of texture
		for (tileTextureY=0;tileTextureY<resolution;tileTextureY++)
			for (tileTextureX=0;tileTextureX<resolution;tileTextureX++)
		{
			//calculate absolute pixel coordinate of texture
			absTextureX = tileX*resolution+tileTextureX;
			absTextureY = tileY*resolution+tileTextureY;

			//calculate the coordinate on the heightmap
			heightMapX = (float)(tileX*TILE_SIZE)+
				(float)tileTextureX*(float)TILE_SIZE/(float)resolution;
			heightMapY = (float)(tileY*TILE_SIZE)+
				(float)tileTextureY*(float)TILE_SIZE/(float)resolution;
			
			//retrieve ground parameters
			height = pHeightMap->getInterpolatedHeightInMetersSmooth(heightMapX,heightMapY);
			slope = pHeightMap->getInterpolatedSlopeSmooth(heightMapX,heightMapY);

			//ground color is black
			color = tileTexture.GetPixelColor(tileTextureX,tileTextureY);
			
			//go through all textures (backwards)
			for (i=currentCount-1;i>=0;i--)
			{
				if (cancelFlag) return;
				
				//calculate coordinate on the texture
				textureX = absTextureX%currentParameter[i].textureBitmap.GetWidth();
				textureY = absTextureY%currentParameter[i].textureBitmap.GetHeight();

				//calculate coordinate on mask
				maskX = -0.5f+currentParameter[i].maskFactorX*(absTextureX+0.5f);
				maskY = -0.5f+currentParameter[i].maskFactorY*(absTextureY+0.5f);

				//retrieve mask value
				mask = getInterpolatedMaskValue(maskX, maskY, i);

				//calculate the intensity
				alpha = getTextureIntensity(height,slope,mask,i);
				invAlpha = 1.0f-alpha;

				//get color from overlay texture
				newColor = currentParameter[i].textureBitmap.GetPixelColor(textureX,textureY);

				//calculate the color of the pixel in the texture tile bitmap
				color.rgbRed = (float)color.rgbRed*invAlpha+(float)newColor.rgbRed*alpha;
				color.rgbGreen = (float)color.rgbGreen*invAlpha+(float)newColor.rgbGreen*alpha;
				color.rgbBlue = (float)color.rgbBlue*invAlpha+(float)newColor.rgbBlue*alpha;
			}

			//set the new pixel
			tileTexture.SetPixelColor(tileTextureX,tileTextureY,color);
		}

		//save this tileTexture on disc
		tileTexture.SetJpegQuality(JPG_QUALITY); 
		tileTexture.Save(QString(texturePath+"/terrain_tmp_%1_%2.jpg").arg(tileX).arg(tileY), 
						 CXIMAGE_FORMAT_JPG);
		tileTexture.Save(QString(texturePath+"/terrain_%1_%2.jpg").arg(tileX).arg(tileY), 
						 CXIMAGE_FORMAT_JPG);

		//put tile in preview bitmap
		previewTile.Copy(tileTexture);
		previewTile.Resample(TILE_SIZE, TILE_SIZE, 0);
		for (y=0;y<TILE_SIZE;y++)
			for (x=0;x<TILE_SIZE;x++)
		{
			pPreviewBitmap->SetPixelColor(tileX*TILE_SIZE+x,tileY*TILE_SIZE+y,
				previewTile.GetPixelColor(x,y));
		}

		//set progress
		exactProgress += progressValue;
		*pProgress = (int)exactProgress;
	}
	*pProgress = 100;
}

/****************************************************************************
** TextureGen getTextureIntensity
**
** returns the intensity of the texture on this ground parameters
**
** Author: Dirk Plate
****************************************************************************/

float TextureGen::getTextureIntensity(int height, float slope, float mask, int currentIndex)
{
	int heightDiff;
	int slopeDiff;
	int slopeDegree;
	float heightIntensity;
	float slopeIntensity;
	float intensity;

	//convert slope (arc) to slope (deg)
	slopeDegree = (int)(slope/(3.1415926535897932384626433832795f)*180.0f);
	
	//calculate the intensity for height only
	if ((height >= currentParameter[currentIndex].lowestHeight) &&
		(height <= currentParameter[currentIndex].highestHeight)) heightIntensity = 1.0f;
	else
	{
		if (height < currentParameter[currentIndex].lowestHeight) 
			heightDiff = currentParameter[currentIndex].lowestHeight-height;
		else heightDiff = height-currentParameter[currentIndex].highestHeight;
		//pixel is in soft border area of height
		if (heightDiff <= currentParameter[currentIndex].heightSmoothRange)
			heightIntensity = 1.0f-((float)heightDiff/(float)currentParameter[currentIndex].heightSmoothRange);
		else heightIntensity = 0.0f;
	}

	//calculate the intensity for slope only
	if ((slopeDegree >= currentParameter[currentIndex].flattestSlope) &&
		(slopeDegree <= currentParameter[currentIndex].steepestSlope)) slopeIntensity = 1.0f;
	else
	{
		if (slopeDegree < currentParameter[currentIndex].flattestSlope) 
			slopeDiff = currentParameter[currentIndex].flattestSlope-slopeDegree;
		else slopeDiff = slopeDegree-currentParameter[currentIndex].steepestSlope;
		//pixel is in soft border area of slope
		if (slopeDiff <= currentParameter[currentIndex].slopeSmoothRange)
			slopeIntensity = 1.0f-((float)slopeDiff/(float)currentParameter[currentIndex].slopeSmoothRange);
		else slopeIntensity = 0.0f;
		
	}

	//take the lowest intensity
	if (heightIntensity < slopeIntensity)
		intensity = heightIntensity;
	else intensity = slopeIntensity;

	//multiply with mask value
	intensity *= mask;
	
	//return value
	return intensity;
}

/****************************************************************************
** TextureGen getInterpolatedMaskValue
**
** returns a interpolated value of mask bitmap
**
** Author: Dirk Plate
****************************************************************************/

float TextureGen::getInterpolatedMaskValue(float x, float y, int currentIndex)
{
	//no negative values!
	if (x < 0.0f) x = 0.0f;
	if (y < 0.0f) y = 0.0f;

	float strengthLeftTop;
	float strengthRightTop;
	float strengthLeftBottom;
	float strengthRightBottom;
	int xInt = int(x);
	int yInt = int(y);
	bool lastCol = false;
	if (xInt >= currentParameter[currentIndex].maskBitmap.GetWidth()-1) lastCol = true;
	bool lastRow = false;
	if (yInt >= currentParameter[currentIndex].maskBitmap.GetHeight()-1) lastRow = true;

	//get strength from all edges around this point
	EngineHelpers::getInterpolationStrengths(x, y,&strengthLeftTop, &strengthRightTop, &strengthLeftBottom, &strengthRightBottom);

	//get values from edges
	float valueLeftTop = currentParameter[currentIndex].maskBitmap.GetPixelGray(xInt, yInt);
	
	float valueRightTop = valueLeftTop;
	if (!lastCol) 
		valueRightTop = currentParameter[currentIndex].maskBitmap.GetPixelGray(xInt+1, yInt);

	float valueLeftBottom = valueLeftTop;
	if (!lastRow) 
		valueLeftBottom = currentParameter[currentIndex].maskBitmap.GetPixelGray(xInt, yInt+1);

	float valueRightBottom = valueLeftBottom;
	if (!lastCol && !lastRow) 
		valueRightBottom = currentParameter[currentIndex].maskBitmap.GetPixelGray(xInt+1, yInt+1);
	
	//calculate mean value
	float valueMiddle = (strengthLeftTop*valueLeftTop+
						 strengthRightTop*valueRightTop+
						 strengthLeftBottom*valueLeftBottom+
						 strengthRightBottom*valueRightBottom);

	//return value between 0 and 1
	return valueMiddle/256.0f;
}