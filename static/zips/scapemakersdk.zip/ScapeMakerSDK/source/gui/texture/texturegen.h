/****************************************************************************
** TextureGen
**
** The texture generator class
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include <qthread.h>
#include <stdlib.h>
#include <time.h>
#include "../../engine/terrain/heightmap.h"
#include "../../engine/terrain/terraintile.h"
#include "ximage.h"

#define MAXHEIGHTSMOOTHRANGE 500	//how many meters will the smoothness at 100% reach
#define MAXSLOPESMOOTHRANGE 30		//how many degree will the smoothness at 100% reach

//all attributes of one texture
struct OneTexture
{
	QString name;
	CxImage textureBitmap;
	CxImage maskBitmap;
	float maskFactorX;
	float maskFactorY;
	int lowestHeight;
	int highestHeight;
	int flattestSlope;
	int steepestSlope;
	int smoothness;
	int heightSmoothRange;
	int slopeSmoothRange;
};

class TextureGen : public QThread
{
public:
	TextureGen();

	void generateDistributionPreview(Heightmap *pHeightMapSet, CxImage *pDistributionBitmapSet,
		OneTexture *parameter);
	void generate(Heightmap *pHeightMapSet, int *pProgressSet, CxImage *pPreviewBitmapSet, 
		QString texturePathSet,int resolutionSet,OneTexture *parameter, int count);
	void cancel();
	
protected:
	virtual void run();

private:
	void doDistributionPreview();	//the real generation of the distribution-preview
	void doGeneration();			//the real generation of the texture
	float getTextureIntensity(int height, float slope, float mask, int currentIndex);	//calculate the intensity of the texture on this ground
	float getInterpolatedMaskValue(float x, float y, int currentIndex);

	int *pProgress;
	float exactProgress;
	Heightmap *pHeightMap;	//pointer to heighmap class
	bool cancelFlag;		//is true, if the generate-thread should stop

	CxImage *pPreviewBitmap;		//the generated texture-preview
	CxImage *pDistributionBitmap;	//the distribution-preview
	bool distribution;			//making the distributionpreview or the real texture?
	int resolution;				//the resolution for each tile
	QString texturePath;		//the path where all textures should saved

	//all attributes need for generation
	OneTexture *currentParameter;
	int currentCount;					//how many parameter (textures)
};
