/****************************************************************************
** TextureGUI
**
** the texture-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#include "texturegui.h"
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include "../common/maskimportgui.h"

/****************************************************************************
** TextureGUI Constructor
**
** initialise vars
**  
** Author: Dirk Plate
****************************************************************************/

TextureGUI::TextureGUI( QWidget* parent, const char* name, WFlags f )
	: TextureGUIBase(parent, name, f)
{
	texturesCount=0;
	currentTexture=-1;
	pHeightMap = NULL;
	generatingDistributionTimer = false;
	generatingProgress = 0;
	generatingDistributionTimerID = -1;
	generatingTextureTimerID = -1;
	dontRecalculate = false;
	loadedExpert = false;

	cancelButton->hide();	//hide the cancel button
}

/****************************************************************************
** TextureGUI setProjectPath
**
** set the current project
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}

/****************************************************************************
** TextureGUI addClicked
**
** called when the add button is clicked -> add a texture to list
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::addClicked()
{
	int i;
	OneTexture newTexture;
	QString fileName;
	
	//show the file-dialog
	if (!GUIHelpers::showLoadImageDialog("./groundtextures/",newTexture.textureBitmap,this,&fileName))
		return;

	//get the text from input dialog
	bool ok = FALSE;
	QFileInfo fileInfo(fileName); 
	newTexture.name = QInputDialog::getText(tr("ScapeMaker"),tr("Name of texture?"), 
		fileInfo.baseName(), &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newTexture.name.isNull() || newTexture.name.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name"));
		return;
	}

	//texture with this name already exist?
	for (i=0;i<texturesCount;i++)
	{
		if (textures[i].name == newTexture.name)
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Texture with this name already exists!\nPlease choose another name."));
			return;
		}	
	}

	//set the rest of the values to default
	initTexture(newTexture);
	int index=addTexture(newTexture,true);

	if (texturesCount == 1)
	{
		//unhide all gui elements for textures
		hideTextureGUIElements(false);
	}

	//save this image in project dir
	newTexture.textureBitmap.SetJpegQuality(JPG_QUALITY); 
	newTexture.textureBitmap.Save(
		projectPath+"/textures/"+newTexture.name+".jpg",
		CXIMAGE_FORMAT_JPG);

	//select the new texture
	textureList->setSelected(index,true);
	
/*	//show the preview of texture
	QPixmap pixmap;
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(textures[currentTexture].textureBitmap));
	textureView->setPixmap(pixmap);*/

	//create default mask
	resetMaskClicked();
}

/****************************************************************************
** TextureGUI removeClicked
**
** called when the remove button is clicked -> remove a texture from list
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::removeClicked()
{
	int index = textureList->currentItem();

	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select a texture in the list first!"));
		return;
	}

	//get the selected text
	QString toDelete = textureList->currentText();

	//ask the user if delete
	if(QMessageBox::warning (this, tr("ScapeMaker"), tr("Delete texture")+" \""+toDelete+"\"?", 
				tr("Yes"), tr("No"), QString::null, 1) != 0) return;

	//delete texture on hard disc
	QDir path(projectPath+"/textures/");
	path.remove(textures[index].name+".jpg");
	path.remove(textures[index].name+"_mask.png");
	
	//delete texture
	//move all other up
	for (int i=index+1; i<texturesCount; i++)
		textures[i-1] = textures[i];
	texturesCount--;

	//remove texture from gui-list
	textureList->removeItem(textureList->currentItem());

	if (texturesCount == 0)
	{
		//hide gui
		hideTextureGUIElements(true);
		currentTexture = -1;
	}
	else
	{
		//select element below the removed one
		if (index < texturesCount)
			textureList->setSelected(index,true);
		else textureList->setSelected(texturesCount-1,true);
	}
}

/****************************************************************************
** TextureGUI renameClicked
**
** called when the rename button is clicked -> rename a texture (and directory)
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::renameClicked()
{
	int i;
	int index = textureList->currentItem();

	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select a texture in the list first!"));
		return;
	}

	//get the selected text
	QString toRename = textureList->currentText();

	//ask the user for new name
	bool ok = FALSE;
	QString newName = QInputDialog::getText(tr("ScapeMaker"),tr("New name of texture?"), toRename, &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newName.isNull() || newName.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name!"));
		return;
	}

	//texture with this name already exist?
	for (i=0;i<texturesCount;i++)
	{
		if ((textures[i].name == newName) && (i != index))
		{
			QMessageBox::information(this, tr("ScapeMaker"),tr("Texture with this name already exists!\nPlease choose another name."));
			return;
		}	
	}

	//rename files
	QDir directory(projectPath+"/textures/");
	if (!directory.rename(textures[index].name+".jpg", newName+".jpg"))
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't rename texture!"));
		return;
	}
	if (!directory.rename(textures[index].name+"_mask.png", newName+"_mask.png"))
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Can't rename mask of texture!"));
		return;
	}

	//rename name in list
	textureList->changeItem(newName,index);

	//rename object
	textures[index].name = newName;
}


/****************************************************************************
** TextureGUI upClicked
**
** called when the up button is clicked -> move texture up in list
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::upClicked()
{
	int index;
	
	index = textureList->currentItem();
	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select a texture in the list first!"));
		return;
	}

	//get the selected text
	QString toMove = textureList->currentText();

	//the top one can't moved
	if (index > 0)
	{
		//swap the item
		OneTexture tmp = textures[index-1];
		textures[index-1] = textures[index];
		textures[index] = tmp;

		//update the gui list
		textureList->removeItem(index);
		textureList->insertItem(toMove,index-1);

		//select the same item
		textureList->setSelected(index-1,true);
	}
}

/****************************************************************************
** TextureGUI downClicked
**
** called when the down button is clicked -> move texture down in list
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::downClicked()
{
	int index;
	
	index = textureList->currentItem();
	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select a texture in the list first!"));
		return;
	}

	//get the selected text
	QString toMove = textureList->currentText();

	//the lowest one can't moved
	if (index < texturesCount-1)
	{
		//swap the item
		OneTexture tmp = textures[index+1];
		textures[index+1] = textures[index];
		textures[index] = tmp;

		//update the gui list
		textureList->removeItem(index);
		textureList->insertItem(toMove,index+1);

		//select the same item
		textureList->setSelected(index+1,true);
	}
}

/****************************************************************************
** TextureGUI importTextureClicked
**
** Is called, when the import button in texture group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::importTextureClicked()
{
	//show the file-dialog
	if (GUIHelpers::showLoadImageDialog("./groundtextures/",textures[currentTexture].textureBitmap,this))
    {
		//save this image in project dir
		textures[currentTexture].textureBitmap.SetJpegQuality(JPG_QUALITY); 
		textures[currentTexture].textureBitmap.Save(
			projectPath+"/textures/"+textures[currentTexture].name+".jpg",
			CXIMAGE_FORMAT_JPG);

		//show the preview of texture
		QPixmap pixmap;
		pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(textures[currentTexture].textureBitmap));
		textureView->setPixmap(pixmap);
	}
}

/****************************************************************************
** TextureGUI importMaskClicked
**
** Is called, when the import button in mask group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::importMaskClicked()
{
	//show the import mask dialog
	MaskImportGUI dialog(this, "maskImportGUI", true, WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu | WStyle_ContextHelp,
		textures[currentTexture].maskBitmap);
	dialog.show();

	//user clicked ok?
	if (!dialog.isCanceled())
	{
		//copy result
		textures[currentTexture].maskBitmap = dialog.getResult();
		
		//save this image in project dir
		textures[currentTexture].maskBitmap.Save(
			projectPath+"/textures/"+textures[currentTexture].name+"_mask.png",CXIMAGE_FORMAT_PNG);

		//show the preview of texture
		QImage image = GUIHelpers::convertCxImageToQImage(textures[currentTexture].maskBitmap);
		QPixmap pixmap;
		pixmap.convertFromImage(image);
		maskView->setPixmap(pixmap);

		//update distribution
		valuesChanged();
	}
}


/****************************************************************************
** TextureGUI resetMaskClicked
**
** Is called, when the reset button in mask group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::resetMaskClicked()
{
	//create default file
	textures[currentTexture].maskBitmap.Create(256,256,24);
	textures[currentTexture].maskBitmap.Clear(0xff);

	//save this image in project dir
	textures[currentTexture].maskBitmap.Save(
		projectPath+"/textures/"+textures[currentTexture].name+"_mask.png",
		CXIMAGE_FORMAT_PNG);

	//show the preview of texture
	QPixmap pixmap;
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(textures[currentTexture].maskBitmap));
	maskView->setPixmap(pixmap);

	//update distribution
	valuesChanged();
}

/****************************************************************************
** TextureGUI importDetailClicked
**
** Is called, when the import button in detail map group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::importDetailClicked()
{
	CxImage detailMap;

	//show the file-dialog
	if (GUIHelpers::showLoadImageDialog("./detailmaps/",detailMap,this))
    {
		//mean luminance = 0.5
		detailMap.Light(127-detailMap.Mean());

		//convert image to grayscale
		detailMap.GrayScale();

		//save this image in project dir
		detailMap.SetJpegQuality(JPG_QUALITY); 
		detailMap.Save(projectPath+"/engine/detailmap.jpg",CXIMAGE_FORMAT_JPG);

		//show the preview of texture
		QPixmap pixmap;
		pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(detailMap));
		detailView->setPixmap(pixmap);
	}
}


/****************************************************************************
** TextureGUI resetDetailClicked
**
** Is called, when the reset button in detail map group is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::resetDetailClicked()
{
	//delete detail map file
	QFileInfo fileInfo(projectPath+"/engine/detailmap.jpg");

	if (fileInfo.isFile())
	{
		QDir path = fileInfo.dir();
		path.remove(fileInfo.fileName());
	}

	//load default detail map
	CxImage detailMap;
	detailMap.Load("./detailmaps/default.jpg",CXIMAGE_FORMAT_JPG);

	//show the preview of texture
	QPixmap pixmap;
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(detailMap));
	detailView->setPixmap(pixmap);
}

/****************************************************************************
** TextureGUI generateClicked
**
** Is called, when the generate button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::generateClicked()
{
	//reset the generatingProgress
	generatingProgress = 0;		
	progressBar->reset();

	//prepare the preview image
	textureResult = CxImage(hMapBitmap);
	textureResult.IncreaseBpp(24);

	//retrieve the current resolution
	int currentResolution;
	if (resolution->currentItem() == 0)
		currentResolution = 64;
	else if (resolution->currentItem() == 1)
		currentResolution = 128;
	else if (resolution->currentItem() == 2)
		currentResolution = 256;
	else if (resolution->currentItem() == 3)
		currentResolution = 512;
	else if (resolution->currentItem() == 4)
		currentResolution = 1024;

	generator.generate(
		pHeightMap,
		&generatingProgress,
		&textureResult,
		projectPath+"/engine/textures/",
		currentResolution,
		textures,
		texturesCount);

	//hide the generatebutton and show the cancelbutton
	generateButton->hide();
	cancelButton->show();

	//disable all tabs except the own
	enableTabs(false);

	resolutionLabel->setEnabled(false);
	resolution->setEnabled(false);
	textureList->setEnabled(false);
	addButton->setEnabled(false);
	removeButton->setEnabled(false);
	renameButton->setEnabled(false);
	upButton->setEnabled(false);
	downButton->setEnabled(false);
	heightSlider->setEnabled(false);
	slopeSlider->setEnabled(false);
	smoothnessSlider->setEnabled(false);
	textureGroup->setEnabled(false);
	maskGroup->setEnabled(false);
	exportButton->setEnabled(false);

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//start timer for updating the image and progressbar
	generatingTextureTimerID = startTimer(100);
}

/****************************************************************************
** TextureGUI cancelClicked
**
** Is called, when the cancel-Button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::cancelClicked()
{
	//stop the generating-thread
	generator.cancel();

	//delete timer
	killTimer(generatingTextureTimerID);
	generatingTextureTimerID = -1;

	//update the image
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(textureResult));

	//update the progressbar
	progressBar->setProgress(generatingProgress);

	//hide the cancelbutton and show the generatebutton
	cancelButton->hide();
	generateButton->show();

	//enable all tabs except the own
	enableTabs(true);

	resolutionLabel->setEnabled(true);
	resolution->setEnabled(true);
	topParent->menuBar->setEnabled(true);
	textureList->setEnabled(true);
	addButton->setEnabled(true);
	removeButton->setEnabled(true);
	renameButton->setEnabled(true);
	upButton->setEnabled(true);
	downButton->setEnabled(true);
	heightSlider->setEnabled(true);
	slopeSlider->setEnabled(true);
	smoothnessSlider->setEnabled(true);
	textureGroup->setEnabled(true);
	maskGroup->setEnabled(true);
	exportButton->setEnabled(true);

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();	
}

/****************************************************************************
** TextureGUI exportClicked
**
** called if export button is clicked
**
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::exportClicked()
{
	//open terrain texture export dialog
	TextureExportGUI dialog(this, "textureExportGUI", true, WStyle_Customize | WStyle_DialogBorder | WStyle_Title | WStyle_SysMenu | WStyle_ContextHelp,
		projectPath+"/engine/textures/", textureTilesPerSide,0);
	dialog.show();
}

/****************************************************************************
** TextureGUI textureSelected
**
** Is called, when a texture in the list was selected
**  
** Author: Dirk Plate
****************************************************************************/
void TextureGUI::textureSelected()
{
	//get index of selected item
	currentTexture = textureList->currentItem();

	if (currentTexture == -1) return;

	dontRecalculate = true;

	//set all gui elements first to uncritical values (bug fix)
	int lowestHeightTmp = textures[currentTexture].lowestHeight;
	int highestHeightTmp = textures[currentTexture].highestHeight;
	int flattestSlopeTmp = textures[currentTexture].flattestSlope;
	int steepestSlopeTmp = textures[currentTexture].steepestSlope;
	int smoothnessTmp = textures[currentTexture].smoothness;
	heightSlider->setValue(0,heightSlider->getMinValue());
	heightSlider->setValue(1,heightSlider->getMaxValue());
	slopeSlider->setValue(0,slopeSlider->getMinValue());
	slopeSlider->setValue(1,slopeSlider->getMaxValue());
	smoothnessSlider->setValue(0,smoothnessSlider->getMinValue());

	//set all gui elements to the new values
	heightSlider->setValue(0,lowestHeightTmp);
	heightSlider->setValue(1,highestHeightTmp);
	slopeSlider->setValue(0,flattestSlopeTmp);
	slopeSlider->setValue(1,steepestSlopeTmp);
	smoothnessSlider->setValue(0,smoothnessTmp);
	
	QPixmap pixmap;
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(textures[currentTexture].textureBitmap));
	textureView->setPixmap(pixmap);
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(textures[currentTexture].maskBitmap));
	maskView->setPixmap(pixmap);

	dontRecalculate = false;

	//generate the distribution
	createTextureDistribution();
}

/****************************************************************************
** TextureGUI valuesChanged
**
** Is called, when a value changed
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::valuesChanged()
{
	//save the properties of all sliders in texture data
	textures[currentTexture].lowestHeight = heightSlider->getValue(0);
	textures[currentTexture].highestHeight = heightSlider->getValue(1);
	textures[currentTexture].flattestSlope = slopeSlider->getValue(0);
	textures[currentTexture].steepestSlope = slopeSlider->getValue(1);
	textures[currentTexture].smoothness = smoothnessSlider->getValue(0);
	
	//generate the distribution
	if (!dontRecalculate)
		createTextureDistribution();
}


/****************************************************************************
** TextureGUI showEvent
**
** Is called, when the TextureGUI will be shown. 
** Load everything for this panel!
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::showEvent(QShowEvent *showEvent)
{
	//ignore spontaneous show events (come from iconified)
	if (showEvent->spontaneous())
		return;

	int currentResolution = 256;

	//get a pointer to the widget with the tab bar (we need this for disabling other tabs while generating)
	topParent =	(ScapeMakerDialog*)(parentWidget()->parentWidget()->parentWidget()->parentWidget());
	
	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//hide tools in bitmapnav
	bitmapNavContainer->setPenButtonVisible(false);
	bitmapNavContainer->setRubberButtonVisible(false);

	//prepare sliders
	heightSlider->setProperties(CoolSlider::LINEAR,tr("Height"),0,3000,"m",2);
	slopeSlider->setProperties(CoolSlider::DEGREE,tr("Slope"),0,90,"�",2);
	smoothnessSlider->setProperties(CoolSlider::LINEAR,tr("Smoothness"),0,100,"",1);

	//delete all old textures
	if (texturesCount > 0)
	{
		textureList->clear();
		delete [] textures;
		texturesCount = 0;
		currentTexture = -1;
	}

	//load all settings from text file 
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/texture.txt",MiniXML::READ))
	{
		OneTexture newTexture;
		char string[512];
		int value;

		if (xmlFile.readInteger("resolution",&value))
			currentResolution = value;

		if (xmlFile.startReadList("textures"))
		{
			int i=0;
			while (xmlFile.startReadListElement(i))
			{	
				initTexture(newTexture);

				if (xmlFile.readString("name",string,512))
					newTexture.name = string;

				if (xmlFile.readInteger("lowestHeight",&value))
					newTexture.lowestHeight = value;
				
				if (xmlFile.readInteger("highestHeight",&value))
					newTexture.highestHeight = value;

				if (xmlFile.readInteger("flattestSlope",&value))
					newTexture.flattestSlope = value;

				if (xmlFile.readInteger("steepestSlope",&value))
					newTexture.steepestSlope = value;

				if (xmlFile.readInteger("smoothness",&value))
					newTexture.smoothness = value;

				//load image from file					
				if (!newTexture.textureBitmap.Load(projectPath+"/textures/"+newTexture.name+".jpg"))
				{
					//if file not exist, create a new bitmap
					newTexture.textureBitmap.Create(256,256,24);
					newTexture.textureBitmap.Clear(0x00);
				}

				//load mask from file					
				if (!newTexture.maskBitmap.Load(projectPath+"/textures/"+newTexture.name+"_mask.png"))
				{
					//if file not exist, create a new bitmap
					newTexture.maskBitmap.Create(256,256,24);
					newTexture.maskBitmap.Clear(0xff);
				}

				addTexture(newTexture,false);

				xmlFile.endReadListElement();
				i++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}

	//set right resolution
	if (currentResolution == 64)
		resolution->setCurrentItem(0);
	else if (currentResolution == 128)
		resolution->setCurrentItem(1);
	else if (currentResolution == 256)
		resolution->setCurrentItem(2);
	else if (currentResolution == 512)
		resolution->setCurrentItem(3);
	else if (currentResolution == 1024)
		resolution->setCurrentItem(4);
	else resolution->setCurrentItem(2);


	//load the heightmap file from project
	if (!hMapBitmap.Load(projectPath+"/engine/heightmap.png"))
	{
		//if file not exist, create a new bitmap
		hMapBitmap.Create(256,256,24);
		//save the heightmap in project (we need a heightmap!)
		hMapBitmap.Save(projectPath+"/engine/heightmap.png",CXIMAGE_FORMAT_PNG);
	}

	//try to load user specific detail map
	CxImage detailMap;
	if (!detailMap.Load(projectPath+"/engine/detailmap.jpg",CXIMAGE_FORMAT_JPG))
	{
		//no user specific detail map -> use default one
		detailMap.Load("./detailmaps/default.jpg",CXIMAGE_FORMAT_JPG);
	}
	//show detail map
	QPixmap pixmap;
	pixmap.convertFromImage(GUIHelpers::convertCxImageToQImage(detailMap));
	detailView->setPixmap(pixmap);

	//get number of texture tiles
	textureTilesPerSide = hMapBitmap.GetWidth()/32;

	//create texturedistribution
	textureDistribution.Create(hMapBitmap.GetWidth(),hMapBitmap.GetHeight(),24);
	textureDistribution.AlphaCreate();
	textureDistribution.AlphaSetMax(255);

	//create heightmap class
	QString enginePath = projectPath+"/engine/";
	char *enginePath2 = new char[enginePath.length()+1];
	strcpy(enginePath2,enginePath.latin1());
	pHeightMap = new Heightmap(enginePath2,"heightmap.png");

	//show the heightmap in bitmapNav
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));

	//set export mode
	filterExpertFunctions();

	if (texturesCount == 0)
	{
		//hide all gui elements for textures
		hideTextureGUIElements(true);
	}
	else
	{
		//select the first texture
		textureList->setSelected(0,true);
	}
}

/****************************************************************************
** TextureGUI hideEvent
**
** Is called, when the TextureGUI will be hide. 
** Save everything for this panel!
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::hideEvent(QHideEvent *hideEvent)
{
	int currentResolution = 256;

	//retrieve current resolution
	if (resolution->currentItem() == 0)
		currentResolution = 64;
	else if (resolution->currentItem() == 1)
		currentResolution = 128;
	else if (resolution->currentItem() == 2)
		currentResolution = 256;
	else if (resolution->currentItem() == 3)
		currentResolution = 512;
	else if (resolution->currentItem() == 4)
		currentResolution = 1024;

	//save the settings to the text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/texture.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("resolution",currentResolution);

		if (xmlFile.startWriteList("textures"))
		{
			for (int i=0;i<texturesCount;i++)
			{
				if (xmlFile.startWriteListElement(i))
				{
					xmlFile.writeString("name",textures[i].name);
					xmlFile.writeInteger("lowestHeight",textures[i].lowestHeight);
					xmlFile.writeInteger("highestHeight",textures[i].highestHeight); 
					xmlFile.writeInteger("flattestSlope",textures[i].flattestSlope);
					xmlFile.writeInteger("steepestSlope",textures[i].steepestSlope);
					xmlFile.writeInteger("smoothness",textures[i].smoothness);

					xmlFile.endWriteListElement();
				}
			}
			xmlFile.endWriteList();
		}
		xmlFile.closeFile();
	}

	//ignore hide events with minimizing
	if (!topParent->isMinimized())
	{
		//delete heightmap-class
		if (pHeightMap != NULL) 
		{
			delete pHeightMap;
			pHeightMap = NULL;
		}
	}
}

/****************************************************************************
** TextureGUI addTexture
**
** adds a texture to intern and GUI list and return the index of the list
**  
** Author: Dirk Plate
****************************************************************************/

int TextureGUI::addTexture(OneTexture &values,bool toBegin)
{
	int i;
	int index;

	//add this texture to the list
	//make a new array (one bigger)
	OneTexture *newArray = new OneTexture[texturesCount+1];
	
	//copy all items
	for (i=0;i<texturesCount;i++)
	{
		if (toBegin) newArray[i+1] = textures[i];
		else newArray[i] = textures[i];
	}
	
	//insert the new one
	if (toBegin) index = 0;
	else index = texturesCount;

	newArray[index] = values;

	//delete the old list
	if (texturesCount > 0)
		delete [] textures;

	//link the new array to the old list
	textures = newArray;
	texturesCount++;

	//update the gui-list
	if (toBegin) textureList->insertItem(values.name,0);
	else textureList->insertItem(values.name,texturesCount-1);

	if (toBegin) return 0;
	else return texturesCount-1;
}

/****************************************************************************
** TextureGUI initTexture
**
** init a texture with default values
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::initTexture(OneTexture &texture)
{
	texture.lowestHeight=0;
	texture.highestHeight=3000;
	texture.flattestSlope=0;
	texture.steepestSlope=90;
	texture.smoothness=50;
}

/****************************************************************************
** TextureGUI hideTextureGUIElements
**
** hides (or shows) all gui elements, which belongs to textures
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::hideTextureGUIElements(bool hide)
{
	if (hide)
	{
		heightSlider->hide();
		slopeSlider->hide();
		smoothnessSlider->hide();
		textureGroup->hide();
		maskGroup->hide();
		generateButton->setEnabled(false);
	}
	else
	{
		heightSlider->show();
		slopeSlider->show();
		smoothnessSlider->show();
		textureGroup->show();
		if (loadedExpert)
			maskGroup->show();
		else maskGroup->hide();
		generateButton->setEnabled(true);
	}
}

/****************************************************************************
** TextureGUI createCurrentBitmap
**
** create the bitmap and put it in bitmapNav
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::createCurrentBitmap()
{
	//copy the heightmap as nice background
	CxImage currentBitmap(hMapBitmap);
	currentBitmap.IncreaseBpp(24);

	//add the distribution
	for(DWORD y=0;y<currentBitmap.GetHeight();y++)
		for (DWORD x=0;x<currentBitmap.GetWidth();x++)
	{
		//get the color on the background
		RGBQUAD background = currentBitmap.GetPixelColor(x,y);
			
		//get the color on the distribution
		RGBQUAD distribution = textureDistribution.GetPixelColor(x,y);
		
		//calculate factor
		float blendFactor = float(distribution.rgbReserved)/255.0f;
		float blendFactorInv = 1.0f-blendFactor;
		
		//calculate new color
		RGBQUAD newColor;
		newColor.rgbRed = blendFactor*distribution.rgbRed+blendFactorInv*background.rgbRed;
		newColor.rgbGreen = blendFactor*distribution.rgbGreen+blendFactorInv*background.rgbGreen;
		newColor.rgbBlue = blendFactor*distribution.rgbBlue+blendFactorInv*background.rgbBlue;
		
		//set new color
		currentBitmap.SetPixelColor(x,y,newColor);
	}

	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));
}

/****************************************************************************
** TextureGUI createTextureDistribution
**
** create distribution preview for current texture
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::createTextureDistribution()
{
	//delete old timer
	if (generatingDistributionTimer)
		killTimer(generatingDistributionTimerID);

	//disable tabs
	enableTabs(false);

	generator.generateDistributionPreview(pHeightMap,&textureDistribution,
		&(textures[currentTexture]));
	
	generatingDistributionTimerID = startTimer(100);
	generatingDistributionTimer = true;

}

/****************************************************************************
** TextureGUI timerEvent
**
** Is called, at timer event
**  
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::timerEvent(QTimerEvent *timerEvent)
{
	//only its our generatingTimer
	if (timerEvent->timerId() == generatingDistributionTimerID)
	{
		//generating done?
		if (!generator.running())
		{
			//delete timer
			killTimer(generatingDistributionTimerID);
			generatingDistributionTimerID = -1;
			generatingDistributionTimer = false;
			//create the current bitmap for bitmapNav
			createCurrentBitmap();

			//enable all tabs
			enableTabs(true);
		}
	}
	else if (timerEvent->timerId() == generatingTextureTimerID)
	{
		//update the image
		bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(textureResult));
		
		//update the progressbar
		progressBar->setProgress(generatingProgress);
		
		//generating done?
		if (!generator.running())
		{
			//save bitmap as preview in project path
			textureResult.SetJpegQuality(JPG_QUALITY); 
			textureResult.Save(projectPath+"/engine/minimap.jpg",CXIMAGE_FORMAT_JPG);

			//use cancelClicked for doing the work
			cancelClicked();
		}
	}
}

/****************************************************************************
** TextureGUI enableTabs
**
** en or disable the tabs
**
** Author: Dirk Plate
****************************************************************************/

void TextureGUI::enableTabs(bool enable)
{
	topParent->tabContainer->setTabEnabled(topParent->topografie, enable);
	topParent->tabContainer->setTabEnabled(topParent->objects, enable);
	topParent->tabContainer->setTabEnabled(topParent->clouds, enable);
	topParent->tabContainer->setTabEnabled(topParent->water, enable);
	topParent->tabContainer->setTabEnabled(topParent->enviroment, enable);
	topParent->tabContainer->setTabEnabled(topParent->preview, enable);
	topParent->menuBar->setEnabled(enable);
}

/****************************************************************************
** TextureGUI filterExpertFunctions
**
** Hides or show all sliders for expert or beginner mode
**  
** Author: Dirk Plate
****************************************************************************/
void TextureGUI::filterExpertFunctions()
{
	//load settings from file
	MiniXML xmlFile;
	loadedExpert = false;
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		bool bValue;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}	

	//set visibility for all functions
	if (!loadedExpert)
	{
		detailGroup->hide();
		maskGroup->hide();
		exportButton->hide();
	}
	else
	{
		detailGroup->show();
		maskGroup->show();
		exportButton->show();
	}
}