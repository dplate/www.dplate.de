/****************************************************************************
** TextureGUI
**
** the texture-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "textureguibase.h"
#include "texturegen.h"
#include "qinputdialog.h"
#include "qmessagebox.h"
#include "qlistbox.h"
#include "qfile.h"
#include "qtextstream.h"
#include "qslider.h"
#include "qlabel.h"
#include "qpixmap.h"
#include "qimage.h"	
#include "qfiledialog.h"
#include "qpushbutton.h"
#include "qprogressbar.h"
#include "../scapemakerdialog.h"
#include "qtabwidget.h"
#include "qcombo.h"
#include "../common/textureexportgui.h"
#include "../common/guihelpers.h"

class TextureGUI : public TextureGUIBase  
{
	Q_OBJECT

public:
	TextureGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setProjectPath(QString projectPathSet);

public slots:
    virtual void addClicked();
    virtual void downClicked();
    virtual void removeClicked();
	virtual void renameClicked();
    virtual void upClicked();
    virtual void importTextureClicked();
	virtual void importMaskClicked();
	virtual void resetMaskClicked();
	virtual void importDetailClicked();
	virtual void resetDetailClicked();
    virtual void generateClicked();
	virtual void cancelClicked();
	virtual void textureSelected();
	virtual void valuesChanged();
	virtual void exportClicked();

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);

private:
	void filterExpertFunctions();
	int addTexture(OneTexture &values, bool toBegin);
	void initTexture(OneTexture &texture);
	void hideTextureGUIElements(bool hide);
	void createCurrentBitmap();
	void createTextureDistribution();
	void enableTabs(bool enable);

	QString projectPath;			//the path to the project-directory
	ScapeMakerDialog *topParent;	//direct pointer to main window

	//a array of all textures with all attributes
	OneTexture *textures;
	int texturesCount;				//count of textures
	int currentTexture;				//index of the current selected texture
	int textureTilesPerSide;		//how many texture tiles to calculate
	
	CxImage hMapBitmap;				//the heightmap
	CxImage textureDistribution;	//the distribution of current texture
	CxImage textureResult;			//this bitmap will be shown in bitmapNav
	Heightmap *pHeightMap;			//the heightmapclass
	TextureGen generator;			//the texture-generator
	bool generatingDistributionTimer;   //distribution timer on or not
	int generatingDistributionTimerID;	//the id of the timer while generating the distribution
	int generatingTextureTimerID;		//the id of the timer while generating the texture
	int generatingProgress;			//the progress of generating
	bool dontRecalculate;			//is this flag set, the distribution wont recalculate

	bool loadedExpert;				//expert mode in config set

};
