/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\texture\textureguibase.ui'
**
** Created: Sun Feb 13 15:03:31 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "textureguibase.h"

#include <qcombobox.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qprogressbar.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
".#############...",
".#############...",
".#############...",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
".................",
".................",
"................."};

static const char* const image1_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
".................",
".................",
".................",
".................",
".................",
".#############...",
".#############...",
".#############...",
".................",
".................",
".................",
".................",
".................",
".................",
".................",
"................."};

static const char* const image2_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"..#########......",
"..##########.....",
"..###########....",
"..####...####....",
"..####...####....",
"..###########....",
"..##########.....",
"..#########......",
"..####..####.....",
"..####..####.....",
"..####...####....",
"..####...####....",
"..####...#####...",
".................",
".................",
"................."};

static const char* const image3_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
".......#.........",
"......###........",
".....#####.......",
"....#######......",
"...#########.....",
"..###########....",
"..###########....",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
".................",
".................",
"................."};

static const char* const image4_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
"......###........",
"..###########....",
"..###########....",
"...#########.....",
"....#######......",
".....#####.......",
"......###........",
".......#.........",
".................",
".................",
"................."};


/* 
 *  Constructs a TextureGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
TextureGUIBase::TextureGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    QPixmap image1( ( const char** ) image1_data );
    QPixmap image2( ( const char** ) image2_data );
    QPixmap image3( ( const char** ) image3_data );
    QPixmap image4( ( const char** ) image4_data );
    if ( !name )
	setName( "TextureGUIBase" );
    resize( 497, 467 ); 
    setCaption( tr( "TextureGUI" ) );
    QWhatsThis::add(  this, tr( "Here the textures of the landscape are defined and generated." ) );

    resolutionLabel = new QLabel( this, "resolutionLabel" );
    resolutionLabel->setGeometry( QRect( 10, 10, 60, 20 ) ); 
    resolutionLabel->setText( tr( "Resolution:" ) );

    textureGroup = new QGroupBox( this, "textureGroup" );
    textureGroup->setGeometry( QRect( 5, 270, 95, 150 ) ); 
    textureGroup->setTitle( tr( "Texture" ) );

    textureView = new QLabel( textureGroup, "textureView" );
    textureView->setGeometry( QRect( 15, 20, 65, 65 ) ); 
    textureView->setScaledContents( TRUE );
    QWhatsThis::add(  textureView, tr( "Shows a picture of the selected texture." ) );

    importTextureButton = new QPushButton( textureGroup, "importTextureButton" );
    importTextureButton->setGeometry( QRect( 10, 95, 75, 23 ) ); 
    importTextureButton->setText( tr( "Import" ) );
    importTextureButton->setFlat( FALSE );
    QToolTip::add(  importTextureButton, tr( "Import a texture" ) );
    QWhatsThis::add(  importTextureButton, tr( "Changes the picture for the selected texture." ) );

    maskGroup = new QGroupBox( this, "maskGroup" );
    maskGroup->setGeometry( QRect( 105, 270, 95, 150 ) ); 
    maskGroup->setTitle( tr( "Mask" ) );

    maskView = new QLabel( maskGroup, "maskView" );
    maskView->setGeometry( QRect( 15, 20, 65, 65 ) ); 
    maskView->setScaledContents( TRUE );
    QWhatsThis::add(  maskView, tr( "Shows a picture of the mask used to limit the distribution of the texture." ) );

    importMaskButton = new QPushButton( maskGroup, "importMaskButton" );
    importMaskButton->setGeometry( QRect( 10, 95, 75, 23 ) ); 
    importMaskButton->setText( tr( "Change" ) );
    importMaskButton->setFlat( FALSE );
    QToolTip::add(  importMaskButton, tr( "Changes a mask" ) );
    QWhatsThis::add(  importMaskButton, tr( "Changes the mask for the selected texture." ) );

    resetMaskButton = new QPushButton( maskGroup, "resetMaskButton" );
    resetMaskButton->setGeometry( QRect( 10, 120, 75, 23 ) ); 
    resetMaskButton->setText( tr( "Reset" ) );
    resetMaskButton->setFlat( FALSE );
    QToolTip::add(  resetMaskButton, tr( "Reset to default mask" ) );
    QWhatsThis::add(  resetMaskButton, tr( "Sets mask for the selected texture to default mask." ) );

    cancelButton = new QPushButton( this, "cancelButton" );
    cancelButton->setGeometry( QRect( 5, 430, 93, 23 ) ); 
    cancelButton->setText( tr( "Cancel" ) );
    cancelButton->setFlat( FALSE );
    QToolTip::add(  cancelButton, tr( "Cancel generating ground texture" ) );

    progressBar = new QProgressBar( this, "progressBar" );
    progressBar->setGeometry( QRect( 105, 430, 395, 21 ) ); 
    progressBar->setFrameShape( QProgressBar::Box );
    progressBar->setFrameShadow( QProgressBar::Sunken );
    progressBar->setCenterIndicator( TRUE );

    bitmapNavContainer = new BitmapNav( this, "bitmapNavContainer" );
    bitmapNavContainer->setGeometry( QRect( 210, 0, 290, 260 ) ); 
    QWhatsThis::add(  bitmapNavContainer, tr( "Red areas show the areas that match the settings for the selected texture." ) );

    textureList = new QListBox( this, "textureList" );
    textureList->setGeometry( QRect( 5, 145, 170, 120 ) ); 
    QWhatsThis::add(  textureList, tr( "A list of all textures used for this landscape. A click on the name of a texture selects it." ) );

    addButton = new QToolButton( this, "addButton" );
    addButton->setGeometry( QRect( 180, 145, 20, 20 ) ); 
    addButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, addButton->sizePolicy().hasHeightForWidth() ) );
    addButton->setText( tr( "" ) );
    addButton->setPixmap( image0 );
    addButton->setToggleButton( FALSE );
    addButton->setTextLabel( tr( "" ) );
    addButton->setToggleButton( FALSE );
    QToolTip::add(  addButton, tr( "Add texture" ) );
    QWhatsThis::add(  addButton, tr( "Adds a new ground texture. A image file must be selected and a name must be entered." ) );

    removeButton = new QToolButton( this, "removeButton" );
    removeButton->setGeometry( QRect( 180, 170, 20, 20 ) ); 
    QFont removeButton_font(  removeButton->font() );
    removeButton->setFont( removeButton_font ); 
    removeButton->setText( tr( "" ) );
    removeButton->setPixmap( image1 );
    removeButton->setToggleButton( FALSE );
    removeButton->setTextLabel( tr( "" ) );
    removeButton->setToggleButton( FALSE );
    QToolTip::add(  removeButton, tr( "Remove texture" ) );
    QWhatsThis::add(  removeButton, tr( "Deletes the selected texture." ) );

    renameButton = new QToolButton( this, "renameButton" );
    renameButton->setGeometry( QRect( 180, 195, 20, 20 ) ); 
    renameButton->setText( tr( "" ) );
    renameButton->setPixmap( image2 );
    renameButton->setToggleButton( FALSE );
    renameButton->setTextLabel( tr( "" ) );
    renameButton->setToggleButton( FALSE );
    QToolTip::add(  renameButton, tr( "Rename texture" ) );
    QWhatsThis::add(  renameButton, tr( "Allows changing the name of the selected texture." ) );

    upButton = new QToolButton( this, "upButton" );
    upButton->setGeometry( QRect( 180, 220, 20, 20 ) ); 
    upButton->setText( tr( "" ) );
    upButton->setPixmap( image3 );
    upButton->setToggleButton( FALSE );
    upButton->setTextLabel( tr( "" ) );
    upButton->setToggleButton( FALSE );
    QToolTip::add(  upButton, tr( "Move texture up" ) );
    QWhatsThis::add(  upButton, tr( "Moves the selected texture upwards. The texture at the top is rendered last, so it can cover other textures." ) );

    downButton = new QToolButton( this, "downButton" );
    downButton->setGeometry( QRect( 180, 245, 20, 20 ) ); 
    downButton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, downButton->sizePolicy().hasHeightForWidth() ) );
    downButton->setText( tr( "" ) );
    downButton->setPixmap( image4 );
    downButton->setToggleButton( FALSE );
    downButton->setTextLabel( tr( "" ) );
    downButton->setToggleButton( FALSE );
    QToolTip::add(  downButton, tr( "Move texture down" ) );
    QWhatsThis::add(  downButton, tr( "Moves the selected texture downwards." ) );

    smoothnessSlider = new CoolSlider( this, "smoothnessSlider" );
    smoothnessSlider->setGeometry( QRect( 210, 270, 140, 70 ) ); 
    QWhatsThis::add(  smoothnessSlider, tr( "Sets the width of the seam of the texture. A higher value results in smoother blendings between two textures." ) );

    heightSlider = new CoolSlider( this, "heightSlider" );
    heightSlider->setGeometry( QRect( 210, 350, 140, 70 ) ); 
    heightSlider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, heightSlider->sizePolicy().hasHeightForWidth() ) );
    QWhatsThis::add(  heightSlider, tr( "Sets the range of height in which the selected texture will occur. For snow a high value would be good, for example." ) );

    exportButton = new QPushButton( this, "exportButton" );
    exportButton->setGeometry( QRect( 400, 265, 95, 23 ) ); 
    exportButton->setText( tr( "Export texture" ) );
    exportButton->setFlat( FALSE );
    QToolTip::add(  exportButton, tr( "Export terrain texture" ) );
    QWhatsThis::add(  exportButton, tr( "Opens the texture export dialog. There the generated ground textures can be exported as a single image file." ) );

    slopeSlider = new CoolSlider( this, "slopeSlider" );
    slopeSlider->setGeometry( QRect( 360, 295, 140, 125 ) ); 
    QWhatsThis::add(  slopeSlider, tr( "Sets the range of slope in which the selected texture will occur. For snow a low value would be good, for example." ) );

    generateButton = new QPushButton( this, "generateButton" );
    generateButton->setGeometry( QRect( 5, 430, 93, 23 ) ); 
    generateButton->setText( tr( "Generate" ) );
    generateButton->setFlat( FALSE );
    QToolTip::add(  generateButton, tr( "Start generating ground texture" ) );
    QWhatsThis::add(  generateButton, tr( "Generates the texture for the landscape." ) );

    resolution = new QComboBox( FALSE, this, "resolution" );
    resolution->insertItem( tr( "64x64" ) );
    resolution->insertItem( tr( "128x128" ) );
    resolution->insertItem( tr( "256x256" ) );
    resolution->insertItem( tr( "512x512" ) );
    resolution->insertItem( tr( "1024x1024" ) );
    resolution->setGeometry( QRect( 80, 10, 100, 21 ) ); 
    QWhatsThis::add(  resolution, tr( "Defines the resolution of the generated texture. Higher values result in sharper textures but make for a longer generation process." ) );

    detailGroup = new QGroupBox( this, "detailGroup" );
    detailGroup->setGeometry( QRect( 5, 35, 195, 100 ) ); 
    detailGroup->setTitle( tr( "Detail Map" ) );

    importDetailButton = new QPushButton( detailGroup, "importDetailButton" );
    importDetailButton->setGeometry( QRect( 110, 15, 75, 23 ) ); 
    importDetailButton->setText( tr( "Import" ) );
    importDetailButton->setFlat( FALSE );
    QToolTip::add(  importDetailButton, tr( "Import a detail mask" ) );
    QWhatsThis::add(  importDetailButton, tr( "Changes the picture of the current detail map. The imported detail map will be converted to grayscale and lightness will be corrected." ) );

    resetDetailButton = new QPushButton( detailGroup, "resetDetailButton" );
    resetDetailButton->setGeometry( QRect( 110, 40, 75, 23 ) ); 
    resetDetailButton->setText( tr( "Reset" ) );
    resetDetailButton->setFlat( FALSE );
    QToolTip::add(  resetDetailButton, tr( "Reset to default detail mask" ) );
    QWhatsThis::add(  resetDetailButton, tr( "Sets the detail map to default." ) );

    detailView = new QLabel( detailGroup, "detailView" );
    detailView->setGeometry( QRect( 15, 20, 70, 70 ) ); 
    detailView->setScaledContents( TRUE );
    QWhatsThis::add(  detailView, tr( "Shows a picture of the current detail map. The detail map is overlayed on the whole landscape, so try and choose a structure which suits all ground types." ) );

    // signals and slots connections
    connect( addButton, SIGNAL( clicked() ), this, SLOT( addClicked() ) );
    connect( removeButton, SIGNAL( clicked() ), this, SLOT( removeClicked() ) );
    connect( upButton, SIGNAL( clicked() ), this, SLOT( upClicked() ) );
    connect( downButton, SIGNAL( clicked() ), this, SLOT( downClicked() ) );
    connect( generateButton, SIGNAL( clicked() ), this, SLOT( generateClicked() ) );
    connect( textureList, SIGNAL( selectionChanged() ), this, SLOT( textureSelected() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( slopeSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( smoothnessSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( renameButton, SIGNAL( clicked() ), this, SLOT( renameClicked() ) );
    connect( importTextureButton, SIGNAL( clicked() ), this, SLOT( importTextureClicked() ) );
    connect( importMaskButton, SIGNAL( clicked() ), this, SLOT( importMaskClicked() ) );
    connect( resetMaskButton, SIGNAL( clicked() ), this, SLOT( resetMaskClicked() ) );
    connect( heightSlider, SIGNAL( valuesChanged() ), this, SLOT( valuesChanged() ) );
    connect( exportButton, SIGNAL( clicked() ), this, SLOT( exportClicked() ) );
    connect( importDetailButton, SIGNAL( clicked() ), this, SLOT( importDetailClicked() ) );
    connect( resetDetailButton, SIGNAL( clicked() ), this, SLOT( resetDetailClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TextureGUIBase::~TextureGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool TextureGUIBase::event( QEvent* ev )
{
    bool ret = QWidget::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont removeButton_font(  removeButton->font() );
	removeButton->setFont( removeButton_font ); 
    }
    return ret;
}

void TextureGUIBase::addClicked()
{
    qWarning( "TextureGUIBase::addClicked(): Not implemented yet!" );
}

void TextureGUIBase::cancelClicked()
{
    qWarning( "TextureGUIBase::cancelClicked(): Not implemented yet!" );
}

void TextureGUIBase::downClicked()
{
    qWarning( "TextureGUIBase::downClicked(): Not implemented yet!" );
}

void TextureGUIBase::exportClicked()
{
    qWarning( "TextureGUIBase::exportClicked(): Not implemented yet!" );
}

void TextureGUIBase::generateClicked()
{
    qWarning( "TextureGUIBase::generateClicked(): Not implemented yet!" );
}

void TextureGUIBase::importDetailClicked()
{
    qWarning( "TextureGUIBase::importDetailClicked(): Not implemented yet!" );
}

void TextureGUIBase::importMaskClicked()
{
    qWarning( "TextureGUIBase::importMaskClicked(): Not implemented yet!" );
}

void TextureGUIBase::importTextureClicked()
{
    qWarning( "TextureGUIBase::importTextureClicked(): Not implemented yet!" );
}

void TextureGUIBase::resetDetailClicked()
{
    qWarning( "TextureGUIBase::resetDetailClicked(): Not implemented yet!" );
}

void TextureGUIBase::removeClicked()
{
    qWarning( "TextureGUIBase::removeClicked(): Not implemented yet!" );
}

void TextureGUIBase::renameClicked()
{
    qWarning( "TextureGUIBase::renameClicked(): Not implemented yet!" );
}

void TextureGUIBase::resetMaskClicked()
{
    qWarning( "TextureGUIBase::resetMaskClicked(): Not implemented yet!" );
}

void TextureGUIBase::textureSelected()
{
    qWarning( "TextureGUIBase::textureSelected(): Not implemented yet!" );
}

void TextureGUIBase::upClicked()
{
    qWarning( "TextureGUIBase::upClicked(): Not implemented yet!" );
}

void TextureGUIBase::valuesChanged()
{
    qWarning( "TextureGUIBase::valuesChanged(): Not implemented yet!" );
}

