/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\texture\textureguibase.ui'
**
** Created: Sun Feb 13 15:03:31 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef TEXTUREGUIBASE_H
#define TEXTUREGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class BitmapNav;
class CoolSlider;
class QComboBox;
class QGroupBox;
class QLabel;
class QListBox;
class QListBoxItem;
class QProgressBar;
class QPushButton;
class QToolButton;

class TextureGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    TextureGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~TextureGUIBase();

    QLabel* resolutionLabel;
    QGroupBox* textureGroup;
    QLabel* textureView;
    QPushButton* importTextureButton;
    QGroupBox* maskGroup;
    QLabel* maskView;
    QPushButton* importMaskButton;
    QPushButton* resetMaskButton;
    QPushButton* cancelButton;
    QProgressBar* progressBar;
    BitmapNav* bitmapNavContainer;
    QListBox* textureList;
    QToolButton* addButton;
    QToolButton* removeButton;
    QToolButton* renameButton;
    QToolButton* upButton;
    QToolButton* downButton;
    CoolSlider* smoothnessSlider;
    CoolSlider* heightSlider;
    QPushButton* exportButton;
    CoolSlider* slopeSlider;
    QPushButton* generateButton;
    QComboBox* resolution;
    QGroupBox* detailGroup;
    QPushButton* importDetailButton;
    QPushButton* resetDetailButton;
    QLabel* detailView;

public slots:
    virtual void addClicked();
    virtual void cancelClicked();
    virtual void downClicked();
    virtual void exportClicked();
    virtual void generateClicked();
    virtual void importDetailClicked();
    virtual void importMaskClicked();
    virtual void importTextureClicked();
    virtual void resetDetailClicked();
    virtual void removeClicked();
    virtual void renameClicked();
    virtual void resetMaskClicked();
    virtual void textureSelected();
    virtual void upClicked();
    virtual void valuesChanged();

protected:
    bool event( QEvent* );
};

#endif // TEXTUREGUIBASE_H
