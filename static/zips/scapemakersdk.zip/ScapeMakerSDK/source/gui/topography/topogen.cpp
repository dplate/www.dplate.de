/****************************************************************************
** TopoGen
**
** The topografie generator class
**
** Author: Dirk Plate
****************************************************************************/

#include "topogen.h"
#include "math.h"

/****************************************************************************
** TopoGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

TopoGen::TopoGen()
{
}

/****************************************************************************
** TopoGen generate
**
** starts the generation of the heightmap
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::generate(int *pProgressSet,CxImage *pHMapBitmapSet, int dropsSet, 
		int bottomSet, int middleSet, int topSet, int bottomBorderSet, int middleBorderSet, 
		int smoothnessSet, int roughnessSet)
{
	//save all settings intern
	pProgress = pProgressSet;
	pHMapBitmap = pHMapBitmapSet;
	drops = dropsSet;
	bottomRock = (float)bottomSet/100.0f;
	middleRock = (float)middleSet/100.0f;
	topRock = (float)topSet/100.0f;
	bottomRockBorder = (float)bottomBorderSet/100.0f;
	middleRockBorder = (float)middleBorderSet/100.0f;
	smoothness = smoothnessSet;
	roughness = (float)roughnessSet/10.0f;

	//init cancel-flag
	cancelFlag = false;

	//set some vars
	size = pHMapBitmap->GetWidth();
		
	//start the generate thread
	start();
}

/****************************************************************************
** TopoGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::cancel()
{
	//set flag true, so the thread will stop
	cancelFlag = true;
}

/****************************************************************************
** TopoGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::run()
{
	doGeneration();
}

/****************************************************************************
** TopoGen initMaps
**
** initialise the rockmap and heightmap
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::initMaps()
{
	int x,y;

	//create heightmap
	heightMap = new float*[size];
	for (x=0;x<size;x++) heightMap[x] = new float[size];

	//create dropmap
	dropMap = new int*[size];
	for (x=0;x<size;x++) dropMap[x] = new int[size];

	//init heightmap with values from existing heightmap
	for (y=0;y<size;y++)
		for (x=0;x<size;x++)
	{
		heightMap[x][y] = ((float)pHMapBitmap->GetPixelGray(x,y))/255.0f;
	}
}

/****************************************************************************
** TopoGen deleteMaps
**
** delete the rockmap and heightmap
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::deleteMaps()
{
	int x;

	//delete heightmap
	for (x=0;x<size;x++) delete [] heightMap[x];
	delete [] heightMap;

	//delete dropmap
	for (x=0;x<size;x++) delete [] dropMap[x];
	delete [] dropMap;
}

/****************************************************************************
** TopoGen makeBitmap
**
** copy the heightmap the hmapBitmap
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::makeBitmap()
{
	int x,y;
	int grayShade;
	RGBQUAD color;

	//write the gray-shades in the bitmap
	for (x=0;x<size;x++)
		for (y=0;y<size;y++)
	{
		//calculate the gray shade for bitmap (must be between 0 and 256)
		grayShade = heightMap[x][y]*255.0f;
		
		color.rgbRed = grayShade;
		color.rgbGreen = grayShade;
		color.rgbBlue = grayShade;
		pHMapBitmap->SetPixelColor(x,y,color);
	}
}

/****************************************************************************
** TopoGen rain
**
** guide a drop from sky to border
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::rain()
{
	int x, y, currentX, currentY, wayNr, lowestWayNr, lowestX, lowestY;
	
	//init dropMap
	for (x=0;x<size;x++)
		for (y=0;y<size;y++)
			dropMap[x][y] = 0;

	//find a random start position
	currentX = rand()%size;
	currentY = rand()%size;

	//repeat moving drop until max length reached or in a hole
	wayNr = 0;
	bool borderReached = false;
	do
	{
		wayNr++;
		//mark the position
		dropMap[currentX][currentY] = wayNr;
	}
	while ((wayNr < TOPOGEN_MAXLENGTH) && moveDrop(&currentX,&currentY,borderReached));

	//go the way backwards
	while(1)
	{
		//reached the begin of the way?
		if (dropMap[currentX][currentY] == 1) break;

		heightMap[currentX][currentY] -= 
			heightMap[currentX][currentY]*(1.0f/(calculateRock(currentX,currentY)*1000.0f));
		makeErosion(currentX,currentY);

		//take this pixel as next with the lowest wayNr
		lowestWayNr = dropMap[currentX][currentY];
		for (x=currentX-1;x<=currentX+1;x++)
			for (y=currentY-1;y<=currentY+1;y++)
		{
			//ignore the middle
			if ((x == currentX) && (y == currentY)) continue;

			//a new lowest found
			if ((dropMap[mod(x)][mod(y)] != 0) && (dropMap[mod(x)][mod(y)] < lowestWayNr))
			{
				lowestX = mod(x);
				lowestY = mod(y);
				lowestWayNr = dropMap[lowestX][lowestY];
			}
		}
		
		//move to the lowest found
		currentX = lowestX;
		currentY = lowestY;
	}
}

/****************************************************************************
** TopoGen moveDrop
**
** moves a drop on step
**
** Author: Dirk Plate
****************************************************************************/

bool TopoGen::moveDrop(int *pCurrentX, int *pCurrentY, bool &borderReached)
{
	int x,y,x2,y2;
	int lowestX,lowestY;
	float lowestValue;
	bool possibility[3][3];
	int possibilities;

	//look all pixels around to find the lowest point
	lowestValue = 2.0f;
	for (x2=0;x2<3;x2++)
		for (y2=0;y2<3;y2++)
			possibility[x2][y2] = false;
	possibilities = 0;
	for (x=(*pCurrentX)-1;x<=(*pCurrentX)+1;x++)
		for (y=(*pCurrentY)-1;y<=(*pCurrentY)+1;y++)
		{
			//border reached?
			if ((x < 0) || (x >= size) || (y < 0) || (y >= size))
				borderReached = true;

			//ignore the middle
			if ((x == *pCurrentX) && (y == *pCurrentY)) continue;
			//ignore points, where the drop already was
			if (dropMap[mod(x)][mod(y)]) continue;

			//save the lowest point
			if (heightMap[mod(x)][mod(y)] < lowestValue)
			{
				lowestX = mod(x);
				lowestY = mod(y);
				lowestValue = heightMap[mod(x)][mod(y)];

				//its better than all other possibilities... so delete them
				for (x2=0;x2<3;x2++)
					for (y2=0;y2<3;y2++)
						possibility[x2][y2] = false;
				possibilities = 1;
				possibility[x-((*pCurrentX)-1)][y-((*pCurrentY)-1)] = true;
			}
			else if (heightMap[mod(x)][mod(y)] == lowestValue)
			{
				//add this to the list of possible
				possibilities++;
				possibility[x-((*pCurrentX)-1)][y-((*pCurrentY)-1)] = true;
			}
		}

	//we are done?
	if (possibilities == 1)
	{
		//move to the lowest point
		*pCurrentX = lowestX;
		*pCurrentY = lowestY;
		return true;
	}
	//now the special cases
	else if (possibilities == 0) 
	{
		//a dead end and border reached
		if (borderReached)	
		{
			//we're done
			return false;
		}
		//a dead end and border not reached
		else
		{
			//move to one direction, until you found an unvisited point
			//take a random direction
			int direction = rand()%8;
			//calculate the deltaX and deltaY
			directionToDelta(direction,&x2,&y2);
			y = *pCurrentY;
			x = *pCurrentX;
			while(1)
			{
				//add the delta
				x+=x2;
				y+=y2;
				//good one
				if (!dropMap[mod(x)][mod(y)])
				{
					//take this point
					*pCurrentX = mod(x);
					*pCurrentY = mod(y);
					return true;
				}
			}
		}
	}
	else //more than one possible
	{
		//choose one of the possible
		while(1)
		{
			x2=rand()%3;
			y2=rand()%3;
			//its a good one?
			if (possibility[x2][y2])
			{
				//take this
				*pCurrentX = mod(x2+(*pCurrentX)-1);
				*pCurrentY = mod(y2+(*pCurrentY)-1);
				return true;
			}
		}
	}

	//its shouldn't end here...
	return false;
}

/****************************************************************************
** TopoGen makeErosion
**
** make the erosion around a pixel
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::makeErosion(int currentX, int currentY)
{
	float maxDiff, heightDiff;
	int x,y;

	//calculate the rock at the currentPosition
	maxDiff = calculateRock(currentX, currentY);
	maxDiff = (float(rand()%1000)/1000.0f)*(maxDiff*roughness)+(maxDiff*(1.0f-roughness));


	//erode all pixels around
	for (x=currentX-1;x<=currentX+1;x++)
		for (y=currentY-1;y<=currentY+1;y++)
	{
		//ignore the middle
		if ((x == currentX) && (y == currentY)) continue;

		int modX = mod(x);
		int modY = mod(y);

		//ignore the way
		if (dropMap[modX][modY] > 0) continue;
		
		heightDiff = heightMap[modX][modY]-heightMap[currentX][currentY];

		//if the height difference to high... put down the earth
		if (heightDiff > maxDiff)
		{
			heightMap[modX][modY] = heightMap[currentX][currentY]+maxDiff;
			//and erode again around this point
			makeErosion(modX,modY);			
		}
	}
}

/****************************************************************************
** TopoGen doGeneration
**
** do the real generation
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::doGeneration()
{
	int dropNr;

	//init all
	//initialise randomizer
	srand( (unsigned)time( NULL ) );
	initMaps();

	//lets rain
	for (dropNr=0;dropNr<drops;dropNr++) 
	{
		rain();

		if (dropNr%(drops/100) == 0) *pProgress += 1;

		//make the bitmap
		if (dropNr%10 == 0) makeBitmap();
		
		//cancel?
		if (cancelFlag) break;

		//sleep(1);
	}

	//smooth
	for (int i=0;i<smoothness;i++) smoothHeightMap();
	
	//make the bitmap
	makeBitmap();

	//delete all
	deleteMaps();

	//progress to 100%
	*pProgress = 100;
}

/****************************************************************************
** TopoGen calculateRock
**
** calculate the hardness of the rock at a specified point
**
** Author: Dirk Plate
****************************************************************************/

float TopoGen::calculateRock(int currentX, int currentY)
{
	if (heightMap[currentX][currentY] < bottomRockBorder) return bottomRock;
	else if (heightMap[currentX][currentY] < middleRockBorder) return middleRock;
	else return topRock;
}

/****************************************************************************
** TopoGen smoothHeighMap
**
** smooth the height map with a gaussian filter
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::smoothHeightMap()
{
	int x,y;
	float sum;

	//go through every pixel
	for (x=0;x<size;x++)
		for (y=0;y<size;y++)
	{
		//take all pixels around the current and itself
		sum = 0.0f;
		sum += heightMap[mod(x-1)][mod(y-1)];
		
		sum += 2*heightMap[x][mod(y-1)];
		
		sum += heightMap[mod(x+1)][mod(y-1)];
		
		sum += 2*heightMap[mod(x-1)][y];
		
		sum += 4*heightMap[x][y];

		sum += 2*heightMap[mod(x+1)][y];
		
		sum += heightMap[mod(x-1)][mod(y+1)];
		
		sum += 2*heightMap[x][mod(y+1)];
		
		sum += heightMap[mod(x+1)][mod(y+1)];
		
		//set the pixel on new value
		heightMap[x][y] = sum/16.0f;
	}
}

/****************************************************************************
** TopoGen mod
**
** special mod which handles negative numbers
**
** Author: Dirk Plate
****************************************************************************/

int TopoGen::mod(int src)
{
	if (src >= 0) return src%size;
	else 
	{
		while (src < 0) src += size;
		return src;
	}
}

/****************************************************************************
** TopoGen directionToDelta
**
** transforms a direction to a relative x and y
**
** Author: Dirk Plate
****************************************************************************/

void TopoGen::directionToDelta(int direction, int *pDeltaX, int *pDeltaY)
{
	switch(direction)
	{
	case 0:
		*pDeltaX = -1;
		*pDeltaY = -1;
		break;
	case 1:
		*pDeltaX = 0;
		*pDeltaY = -1;
		break;
	case 2:
		*pDeltaX = +1;
		*pDeltaY = -1;
		break;
	case 3:
		*pDeltaX = +1;
		*pDeltaY = 0;
		break;
	case 4:
		*pDeltaX = +1;
		*pDeltaY = +1;
		break;
	case 5:
		*pDeltaX = 0;
		*pDeltaY = +1;
		break;
	case 6:
		*pDeltaX = -1;
		*pDeltaY = +1;
		break;
	case 7:
		*pDeltaX = -1;
		*pDeltaY = 0;
		break;

	}
}