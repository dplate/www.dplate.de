/****************************************************************************
** TopoGen
**
** The topografie generator class
**
** Author: Dirk Plate
****************************************************************************/

#include <qthread.h>
#include <stdlib.h>
#include <time.h>
#include "ximage.h"

#define SMALLNUM 0.000001f
#define TOPOGEN_MAXLENGTH 10000

class TopoGen : public QThread
{
public:
	TopoGen(); 

	void generate(int *pProgressSet,CxImage *pHMapBitmapSet, int dropsSet, 
		int bottomSet, int middleSet, int topSet, int bottomBorderSet, int middleBorderSet, 
		int smoothnessSet, int roughnessSet);
	void cancel();

protected:
	virtual void run(); 

private:
	void initMaps();
	void deleteMaps();
	void doGeneration();
	void makeBitmap();
	void rain();
	bool moveDrop(int *pCurrentX,int *pCurrentY, bool &borderReached);
	void makeErosion(int currentX, int currentY);
	float calculateRock(int currentX, int currentY);
	void smoothHeightMap();

	int mod(int src);
	void directionToDelta(int direction, int *pDeltaX, int *pDeltaY);

	int *pProgress;
	bool cancelFlag;		//is true, if the generate-thread should stop

	CxImage *pHMapBitmap;	//the heightmap
	float **heightMap;		//a 2D-map about the height. 0=ground,1=heighest peak
	int **dropMap;			//a 2D-map with flags, where there drops already was
	int size;				//the size of the map (width)
	
	//rock firmness
	float bottomRock, middleRock, topRock;
	float bottomRockBorder, middleRockBorder;

	float roughness;		//the roughness of the hills
	int smoothness;			//the smoothness
	int drops;				//how many drops?
};
