/****************************************************************************
** TopografieGUI
**
** the topografie-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#include "topografiegui.h"
#include "../common/coolslider.h"

/****************************************************************************
** TopografieGUI Constructor
**
** initialise vars
**  
** Author: Dirk Plate
****************************************************************************/

TopografieGUI::TopografieGUI( QWidget* parent, const char* name, WFlags f )
	: TopografieGUIBase(parent, name, f)
{
	generatingProgress = 0;

	cancelButton->hide();	//hide the cancel button
}

/****************************************************************************
** TopografieGUI setProjectPath
**
** set the current project
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}

/****************************************************************************
** TopografieGUI generateClicked
**
** Is called, when the generate-Button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::generateClicked()
{
	generatingProgress = 0;		//reset the generatingProgress
	progressBar->reset();

	//User want to make a completely new map?
	if (!improveTerrain->isChecked())
	{
		//generate a new bitmap with the right size
		if (size->currentItem() == 0)
			hMapBitmap.Create(256,256,24);
		else if (size->currentItem() == 1)
			hMapBitmap.Create(512,512,24);
		else if (size->currentItem() == 2)
			hMapBitmap.Create(1024,1024,24);

		//and fill it with white
		hMapBitmap.Clear(0xff);

		//new generated height maps are tileable
		tileable = true;
	}
			
	generator.generate(&generatingProgress,&hMapBitmap,
		dropsSlider->getValue(0),
		bottomSlider->getValue(0),
		middleSlider->getValue(0),
		topSlider->getValue(0),
		borderSlider->getValue(0),
		borderSlider->getValue(1),
		smoothnessSlider->getValue(0),
		roughnessSlider->getValue(0));

	//hide the generate button and show the cancel button
	generateButton->hide();
	cancelButton->show();

	//disable all tabs except the own
	topParent->tabContainer->setTabEnabled(topParent->texture, false);
	topParent->tabContainer->setTabEnabled(topParent->clouds, false);
	topParent->tabContainer->setTabEnabled(topParent->water, false);
	topParent->tabContainer->setTabEnabled(topParent->enviroment, false);
	topParent->tabContainer->setTabEnabled(topParent->objects, false);
	topParent->tabContainer->setTabEnabled(topParent->preview, false);
	topParent->menuBar->setEnabled(false);
	size->setEnabled(false);
	improveTerrain->setEnabled(false);
	dropsSlider->setEnabled(false);
	smoothnessSlider->setEnabled(false);
	firmnessGroup->setEnabled(false);
	roughnessSlider->setEnabled(false);
	resetButton->setEnabled(false);
	importButton->setEnabled(false);
	exportButton->setEnabled(false);
	heightSlider->setEnabled(false);
	
	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//start timer for updating the image and progressbar
	generatingTimerID = startTimer(100);
}

/****************************************************************************
** TopografieGUI cancelClicked
**
** Is called, when the cancel-Button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::cancelClicked()
{
	//stop the generating-thread
	generator.cancel();

	//delete timer
	killTimer(generatingTimerID);

	//update the image
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));

	//save the heightmap in project
	hMapBitmap.Save(projectPath+"/engine/heightmap.png",CXIMAGE_FORMAT_PNG);
	hMapBitmap.Save(projectPath+"/engine/heightmap_tmp.png",CXIMAGE_FORMAT_PNG);

	//update the progressbar
	progressBar->setProgress(generatingProgress);

	//hide the cancelbutton and show the generatebutton
	cancelButton->hide();
	generateButton->show();

	//enable all tabs except the own
	topParent->tabContainer->setTabEnabled(topParent->texture, true);
	topParent->tabContainer->setTabEnabled(topParent->clouds, true);
	topParent->tabContainer->setTabEnabled(topParent->water, true);
	topParent->tabContainer->setTabEnabled(topParent->enviroment, true);
	topParent->tabContainer->setTabEnabled(topParent->objects, true);
	topParent->tabContainer->setTabEnabled(topParent->preview, true);
	topParent->menuBar->setEnabled(true);
	//enable size only, if improve terrain check box is not checked
	if ( !improveTerrain->isChecked() )
		size->setEnabled(true);
	improveTerrain->setEnabled(true);
	dropsSlider->setEnabled(true);
	smoothnessSlider->setEnabled(true);
	firmnessGroup->setEnabled(true);
	roughnessSlider->setEnabled(true);
	resetButton->setEnabled(true);
	importButton->setEnabled(true);
	exportButton->setEnabled(true);
	heightSlider->setEnabled(true);
	
	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();	
}

/****************************************************************************
** TopografieGUI resetValues
**
** reset all values to default
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::resetValues()
{
	//init size (first item = 256x256)
	size->setCurrentItem(0);
	//init improve terrain checkbox
	improveTerrain->setChecked( false );
	//init number of drops
	dropsSlider->setValue(0,3000);
	//init firmness
	borderSlider->setValue(0,33);
	borderSlider->setValue(1,66);
	bottomSlider->setValue(0,5);
	middleSlider->setValue(0,6);
	topSlider->setValue(0,5);
	//init roughness
	roughnessSlider->setValue(0,5);
	//init smoothness
	smoothnessSlider->setValue(0,2);
	//init height
	heightSlider->setValue(0,0);
	heightSlider->setValue(1,1000);
}

/****************************************************************************
** TopografieGUI exportClicked
**
** Is called, when the export-button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::exportClicked()
{
	GUIHelpers::showSaveImageDialog("heightmap",hMapBitmap,this);
}

/****************************************************************************
** TopografieGUI exportClicked
**
** Is called, when the import-button is clicked
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::importClicked()
{
	//show the file-dialog
	if (GUIHelpers::showLoadImageDialog(QString::null, hMapBitmap, this))
	{
		//convert to gray scale 
		hMapBitmap.GrayScale();
		
		//convert the image to standard size
		if ((hMapBitmap.GetWidth() < 512) || (hMapBitmap.GetHeight() < 512))
			hMapBitmap.Resample(256,256,0);
		else if ((hMapBitmap.GetWidth() < 1024) || (hMapBitmap.GetHeight() < 1024))
			hMapBitmap.Resample(512,512,0);
		else hMapBitmap.Resample(1024,1024,0);

		//show the height map in bitmapNav
		bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));
	
		//ask if tileable or not
		switch( QMessageBox::information(this, tr("ScapeMaker"),
										 tr("Is the heightmap tileable?\n"
										 "(If you're not sure, please click 'No')"),
										 "Yes", "No", NULL,	1, 1 ))
		{
		case 0: 
			tileable = true;
			break;
		case 1: 
			tileable = false;
			break;
		default:
			tileable = false;
		}
		
		//save the heightmap in project
		hMapBitmap.Save(projectPath+"/engine/heightmap.png",CXIMAGE_FORMAT_PNG);
		hMapBitmap.Save(projectPath+"/engine/heightmap_tmp.png",CXIMAGE_FORMAT_PNG);	
	}
}

/****************************************************************************
** TopografieGUI showEvent
**
** Is called, when the TopografieGUI will be shown. 
** Load everything for this panel!
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::showEvent(QShowEvent *showEvent)
{
	//ignore spontaneous show events (come from iconified)
	if (showEvent->spontaneous())
		return;

	//get a pointer to the widget with the tab bar (we need this for disabling other tabs while generating)
	topParent =	(ScapeMakerDialog*)(parentWidget()->parentWidget()->parentWidget()->parentWidget());

	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//hide tools in bitmapnav
	bitmapNavContainer->setPenButtonVisible(false);
	bitmapNavContainer->setRubberButtonVisible(false);

	//set the properties of the sliders
	dropsSlider->setProperties(CoolSlider::LINEAR,tr("Drops"),100,10000,"",1);
	roughnessSlider->setProperties(CoolSlider::LINEAR,tr("Roughness"),1,10,"",1);
	smoothnessSlider->setProperties(CoolSlider::LINEAR,tr("Smoothness"),0,20,"",1);
	borderSlider->setProperties(CoolSlider::LINEAR,tr("Middle layer height"),0,100,"%",2);
	bottomSlider->setProperties(CoolSlider::LINEAR,tr("Bottom"),1,10,"",1);
	middleSlider->setProperties(CoolSlider::LINEAR,tr("Middle"),1,10,"",1);
	topSlider->setProperties(CoolSlider::LINEAR,tr("Top"),1,10,"",1);
	heightSlider->setProperties(CoolSlider::LINEAR,tr("Height"),0,3000,"m",2);

	//reset the generation-values
	resetValues();

	//load all settings from text file 
	int value;
	bool bValue;
	MiniXML xmlFile;
	tileable = true;
	if (xmlFile.openFile(projectPath+"/topografie.txt",MiniXML::READ))
	{
		if (xmlFile.readInteger("size",&value))
			size->setCurrentItem(value);

		if (xmlFile.readBoolean("improveTerrain",&bValue))
			improveTerrain->setChecked(bValue);

		if (xmlFile.readInteger("drops",&value))
			dropsSlider->setValue(0,value);

		if (xmlFile.readInteger("bottom",&value))
			bottomSlider->setValue(0,value);

		if (xmlFile.readInteger("middle",&value))
			middleSlider->setValue(0,value);
		
		if (xmlFile.readInteger("top",&value))
			topSlider->setValue(0,value);
		
		if (xmlFile.readInteger("bottomBorder",&value))
			borderSlider->setValue(0,value);
		
		if (xmlFile.readInteger("middleBorder",&value))
			borderSlider->setValue(1,value);
		
		if (xmlFile.readInteger("smoothness",&value))
			smoothnessSlider->setValue(0,value);
		
		if (xmlFile.readInteger("roughness",&value))
			roughnessSlider->setValue(0,value);

		if (xmlFile.readInteger("lowestHeight",&value))
			heightSlider->setValue(0,value);

		if (xmlFile.readInteger("highestHeight",&value))
			heightSlider->setValue(1,value);

		if (xmlFile.readBoolean("tileable",&bValue))
			tileable = bValue;
		
		xmlFile.closeFile();
	}

	//load the existing file from project
	if (!hMapBitmap.Load(projectPath+"/engine/heightmap_tmp.png"))
	{
		//if temporary not exist, load original
		if (!hMapBitmap.Load(projectPath+"/engine/heightmap.png"))
		{
			//if file not exist, create a new bitmap
			if (size->currentItem() == 0)
				hMapBitmap.Create(256,256,24);
			else if (size->currentItem() == 1)
				hMapBitmap.Create(512,512,24);
			else if (size->currentItem() == 2)
				hMapBitmap.Create(1024,1024,24);
			
			hMapBitmap.Clear(0xff);
		}
	}

	//show the heightmap in bitmapNav
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));

	//set export mode
	filterExpertFunctions();
}

/****************************************************************************
** TopografieGUI hideEvent
**
** Is called, when the TopografieGUI will be hide. 
** Save everything for this panel!
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::hideEvent(QHideEvent *hideEvent)
{
	//save the settings to the text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/topografie.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("size",size->currentItem());
		xmlFile.writeInteger("improveTerrain",improveTerrain->isChecked());
		xmlFile.writeInteger("drops",dropsSlider->getValue(0));
		xmlFile.writeInteger("bottom",bottomSlider->getValue(0));
		xmlFile.writeInteger("middle",middleSlider->getValue(0));
		xmlFile.writeInteger("top",topSlider->getValue(0));
		xmlFile.writeInteger("bottomBorder",borderSlider->getValue(0));
		xmlFile.writeInteger("middleBorder",borderSlider->getValue(1));
		xmlFile.writeInteger("roughness",roughnessSlider->getValue(0));
		xmlFile.writeInteger("smoothness",smoothnessSlider->getValue(0));
		xmlFile.writeInteger("lowestHeight",heightSlider->getValue(0));
		xmlFile.writeInteger("highestHeight",heightSlider->getValue(1));
		xmlFile.writeBoolean("tileable",tileable);
	
		xmlFile.closeFile();
	}

	//save the properties of the heightmap in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/heightmap.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("lowestHeight",heightSlider->getValue(0));
		xmlFile.writeInteger("highestHeight",heightSlider->getValue(1));
		xmlFile.writeBoolean("tileable",tileable);

		xmlFile.closeFile();
	}
}

/****************************************************************************
** TopografieGUI timerEvent
**
** Is called, at timer event
**  
** Author: Dirk Plate
****************************************************************************/

void TopografieGUI::timerEvent(QTimerEvent *timerEvent)
{
	//only its our generatingTimer
	if (timerEvent->timerId() == generatingTimerID)
	{
		//update the image
		bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));
		
		//update the progress bar
		progressBar->setProgress(generatingProgress);
		
		//generating done?
		if (!generator.running())
		{
			//use cancelClicked for doing the work
			cancelClicked();
		}
	}
}

/****************************************************************************
** TopografieGUI filterExpertFunctions
**
** Hides or show all sliders for expert or beginner mode
**  
** Author: Dirk Plate
****************************************************************************/
void TopografieGUI::filterExpertFunctions()
{
	//load settings from file
	MiniXML xmlFile;
	bool loadedExpert = false;
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		bool bValue;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}	

	//set visibility for all functions
	if (!loadedExpert)
	{
		improveTerrain->hide();
		firmnessGroup->hide();
		importButton->hide();
		exportButton->hide();
	}
	else
	{
		improveTerrain->show();
		firmnessGroup->show();
		importButton->show();
		exportButton->show();
	}
}
