/****************************************************************************
** TopografieGUI
**
** the topografie-tab window
** 
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "topografieguibase.h"
#include "topogen.h"
#include "../common/bitmapnav.h"
#include "qprogressbar.h"
#include "qpushbutton.h"
#include "../scapemakerdialog.h"
#include "qtabwidget.h"
#include "qslider.h"
#include "qcombo.h"
#include "qfile.h"
#include "qtextstream.h"
#include "qfiledialog.h"
#include "qgroupbox.h"
#include "../../common/minixml.h"
#include "../common/guihelpers.h"

class TopografieGUI : public TopografieGUIBase  
{
	Q_OBJECT

public:
	TopografieGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setProjectPath(QString projectPathSet);

public slots:
    virtual void cancelClicked();
    virtual void exportClicked();
    virtual void generateClicked();
    virtual void importClicked();
    virtual void resetValues();

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);

private:
	void filterExpertFunctions();

	QString projectPath;	//the path to the project-directory
	ScapeMakerDialog *topParent; //direct pointer to main window
	
	TopoGen generator;		//the topografie-generator
	CxImage hMapBitmap;		//the generated heightmap
	int generatingTimerID;	//the id of the timer while generating
	int generatingProgress;	//how much progress has the generating (0-100)

	bool tileable;			//current heightmap is tileable

};
