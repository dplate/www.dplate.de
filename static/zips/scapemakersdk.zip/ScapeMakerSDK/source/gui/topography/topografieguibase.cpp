/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\topography\topografieguibase.ui'
**
** Created: Sun Feb 13 15:03:30 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "topografieguibase.h"

#include <qcheckbox.h>
#include <qcombobox.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qprogressbar.h>
#include <qpushbutton.h>
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a TopografieGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
TopografieGUIBase::TopografieGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "TopografieGUIBase" );
    resize( 479, 472 ); 
    setCaption( tr( "TopografieGUI" ) );
    QWhatsThis::add(  this, tr( "Creates the heighmap of the landscape." ) );

    randomTerrainGroup = new QGroupBox( this, "randomTerrainGroup" );
    randomTerrainGroup->setGeometry( QRect( 0, 0, 201, 461 ) ); 
    randomTerrainGroup->setTitle( tr( "Random terrain" ) );

    progressBar = new QProgressBar( randomTerrainGroup, "progressBar" );
    progressBar->setGeometry( QRect( 110, 430, 80, 21 ) ); 
    progressBar->setFrameShape( QProgressBar::Box );
    progressBar->setFrameShadow( QProgressBar::Sunken );
    progressBar->setCenterIndicator( TRUE );

    cancelButton = new QPushButton( randomTerrainGroup, "cancelButton" );
    cancelButton->setGeometry( QRect( 10, 430, 93, 23 ) ); 
    cancelButton->setCaption( tr( "" ) );
    cancelButton->setText( tr( "Cancel" ) );
    cancelButton->setFlat( FALSE );
    QToolTip::add(  cancelButton, tr( "Cancel generating topography" ) );

    firmnessGroup = new QGroupBox( randomTerrainGroup, "firmnessGroup" );
    firmnessGroup->setGeometry( QRect( 10, 240, 180, 150 ) ); 
    firmnessGroup->setTitle( tr( "Firmness of rocks" ) );

    borderSlider = new CoolSlider( firmnessGroup, "borderSlider" );
    borderSlider->setGeometry( QRect( 10, 20, 160, 55 ) ); 
    QWhatsThis::add(  borderSlider, tr( "Defines the height of the middle layer." ) );

    bottomSlider = new CoolSlider( firmnessGroup, "bottomSlider" );
    bottomSlider->setGeometry( QRect( 10, 80, 50, 60 ) ); 
    QWhatsThis::add(  bottomSlider, tr( "Sets the firmness of the bottom layer. A low value causes soft stone, on which erosion has a big effect, and so soft slopes. Accordingly, a low value creates steep slopes." ) );

    middleSlider = new CoolSlider( firmnessGroup, "middleSlider" );
    middleSlider->setGeometry( QRect( 65, 80, 50, 60 ) ); 
    QWhatsThis::add(  middleSlider, tr( "Sets the firmness of the middle layer. A low value causes soft stone, on which erosion has a big effect, and so soft slopes. Accordingly, a low value creates steep slopes." ) );

    topSlider = new CoolSlider( firmnessGroup, "topSlider" );
    topSlider->setGeometry( QRect( 120, 80, 50, 60 ) ); 
    QWhatsThis::add(  topSlider, tr( "Sets the firmness of the top layer. A low value causes soft stone, on which erosion has a big effect, and so soft slopes. Accordingly, a low value creates steep slopes." ) );

    sizeLabel = new QLabel( randomTerrainGroup, "sizeLabel" );
    sizeLabel->setGeometry( QRect( 10, 20, 53, 20 ) ); 
    sizeLabel->setText( tr( "Size:" ) );

    size = new QComboBox( FALSE, randomTerrainGroup, "size" );
    size->insertItem( tr( "256x256" ) );
    size->insertItem( tr( "512x512" ) );
    size->insertItem( tr( "1024x1024" ) );
    size->setGeometry( QRect( 91, 20, 100, 21 ) ); 
    QWhatsThis::add(  size, tr( "Defines the size of the heightmap." ) );

    improveTerrain = new QCheckBox( randomTerrainGroup, "improveTerrain" );
    improveTerrain->setGeometry( QRect( 10, 45, 170, 20 ) ); 
    improveTerrain->setText( tr( "Improve current terrain" ) );
    QWhatsThis::add(  improveTerrain, tr( "The newly generated heightmap uses the current heightmap as a basis. Use this to improve your heightmaps by adding new valleys." ) );

    dropsSlider = new CoolSlider( randomTerrainGroup, "dropsSlider" );
    dropsSlider->setGeometry( QRect( 10, 80, 180, 70 ) ); 
    QWhatsThis::add(  dropsSlider, tr( "Sets the number of water tips that are used for the generation of the landscape. Each water tip flows its own way to the border of the landscape and by doing that it causes erosion. More drops result in clearer valleys." ) );

    smoothnessSlider = new CoolSlider( randomTerrainGroup, "smoothnessSlider" );
    smoothnessSlider->setGeometry( QRect( 10, 160, 85, 70 ) ); 
    QWhatsThis::add(  smoothnessSlider, tr( "A higher value makes the value smoother, independently from the other values." ) );

    roughnessSlider = new CoolSlider( randomTerrainGroup, "roughnessSlider" );
    roughnessSlider->setGeometry( QRect( 105, 160, 85, 70 ) ); 
    QWhatsThis::add(  roughnessSlider, tr( "Controls the regularity of the slopes. Low values produce similarly steep slopes, high values result in irregular, rough slopes." ) );

    resetButton = new QPushButton( randomTerrainGroup, "resetButton" );
    resetButton->setGeometry( QRect( 100, 400, 93, 23 ) ); 
    resetButton->setText( tr( "Reset values" ) );
    QToolTip::add(  resetButton, tr( "Reset all values to default" ) );
    QWhatsThis::add(  resetButton, tr( "Resets all settings to the their standard values." ) );

    generateButton = new QPushButton( randomTerrainGroup, "generateButton" );
    generateButton->setGeometry( QRect( 10, 430, 93, 23 ) ); 
    generateButton->setText( tr( "Generate" ) );
    generateButton->setFlat( FALSE );
    QToolTip::add(  generateButton, tr( "Start generating topography" ) );
    QWhatsThis::add(  generateButton, tr( "Generates the heightmap." ) );

    bitmapNavContainer = new BitmapNav( this, "bitmapNavContainer" );
    bitmapNavContainer->setGeometry( QRect( 210, 0, 290, 260 ) ); 
    QWhatsThis::add(  bitmapNavContainer, tr( "Shows the heightmap. Every height is represented by a colour, where bright areas represent a mountain, dark areas a valley." ) );

    importButton = new QPushButton( this, "importButton" );
    importButton->setGeometry( QRect( 300, 270, 93, 23 ) ); 
    importButton->setText( tr( "Import" ) );
    importButton->setFlat( FALSE );
    QToolTip::add(  importButton, tr( "Import a heightmap" ) );
    QWhatsThis::add(  importButton, tr( "Imports a heightmap from a file. Automatically scales it to the right size and transports it to grey." ) );

    heightSlider = new CoolSlider( this, "heightSlider" );
    heightSlider->setGeometry( QRect( 210, 300, 280, 160 ) ); 
    QWhatsThis::add(  heightSlider, tr( "Sets the height of the landscape. The left slider defines the height of the black pixels, the right one defines the height of the white pixels. All other colors are between them." ) );

    exportButton = new QPushButton( this, "exportButton" );
    exportButton->setGeometry( QRect( 400, 270, 93, 23 ) ); 
    exportButton->setText( tr( "Export" ) );
    exportButton->setFlat( FALSE );
    QToolTip::add(  exportButton, tr( "Export the heightmap" ) );
    QWhatsThis::add(  exportButton, tr( "Exports the heightmap as an image file." ) );

    // signals and slots connections
    connect( generateButton, SIGNAL( clicked() ), this, SLOT( generateClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( resetButton, SIGNAL( clicked() ), this, SLOT( resetValues() ) );
    connect( exportButton, SIGNAL( clicked() ), this, SLOT( exportClicked() ) );
    connect( importButton, SIGNAL( clicked() ), this, SLOT( importClicked() ) );
    connect( improveTerrain, SIGNAL( toggled(bool) ), size, SLOT( setDisabled(bool) ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TopografieGUIBase::~TopografieGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

void TopografieGUIBase::cancelClicked()
{
    qWarning( "TopografieGUIBase::cancelClicked(): Not implemented yet!" );
}

void TopografieGUIBase::exportClicked()
{
    qWarning( "TopografieGUIBase::exportClicked(): Not implemented yet!" );
}

void TopografieGUIBase::generateClicked()
{
    qWarning( "TopografieGUIBase::generateClicked(): Not implemented yet!" );
}

void TopografieGUIBase::importClicked()
{
    qWarning( "TopografieGUIBase::importClicked(): Not implemented yet!" );
}

void TopografieGUIBase::resetValues()
{
    qWarning( "TopografieGUIBase::resetValues(): Not implemented yet!" );
}

