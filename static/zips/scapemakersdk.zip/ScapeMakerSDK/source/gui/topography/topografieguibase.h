/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\topography\topografieguibase.ui'
**
** Created: Sun Feb 13 15:03:30 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef TOPOGRAFIEGUIBASE_H
#define TOPOGRAFIEGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class BitmapNav;
class CoolSlider;
class QCheckBox;
class QComboBox;
class QGroupBox;
class QLabel;
class QProgressBar;
class QPushButton;

class TopografieGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    TopografieGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~TopografieGUIBase();

    QGroupBox* randomTerrainGroup;
    QProgressBar* progressBar;
    QPushButton* cancelButton;
    QGroupBox* firmnessGroup;
    CoolSlider* borderSlider;
    CoolSlider* bottomSlider;
    CoolSlider* middleSlider;
    CoolSlider* topSlider;
    QLabel* sizeLabel;
    QComboBox* size;
    QCheckBox* improveTerrain;
    CoolSlider* dropsSlider;
    CoolSlider* smoothnessSlider;
    CoolSlider* roughnessSlider;
    QPushButton* resetButton;
    QPushButton* generateButton;
    BitmapNav* bitmapNavContainer;
    QPushButton* importButton;
    CoolSlider* heightSlider;
    QPushButton* exportButton;

public slots:
    virtual void cancelClicked();
    virtual void exportClicked();
    virtual void generateClicked();
    virtual void importClicked();
    virtual void resetValues();

};

#endif // TOPOGRAFIEGUIBASE_H
