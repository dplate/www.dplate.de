/****************************************************************************
** RiversGen
**
** The rivers generator class
**
** Author: Dirk Plate
****************************************************************************/

#include "riversgen.h"
#include <qimage.h>
#include "../../engine/common/enginehelpers.h"
#include "../../common/minixml.h"

/****************************************************************************
** RiversGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

RiversGen::RiversGen()
{
	preview = false;
}

RiversGen::~RiversGen()
{

}

/****************************************************************************
** RiversGen generatePreview
**
** starts the generation of rivers preview
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::generatePreview(Heightmap *pHeightmapSet, CxImage *pPreviewBitmapSet,
								OneSource *pParameterSet, int countSet, int highlightSet)
{
	//stop a old thread
	cancel();

	//save all settings intern
	pHeightmap = pHeightmapSet;
	pPreviewBitmap = pPreviewBitmapSet;
	pParameter = pParameterSet;
	count = countSet;
	highlight = highlightSet;

	//this is only the  preview
	preview = true;

	//start the generate thread
	start();
}

/****************************************************************************
** RiversGen generate
**
** starts the generation of rivers 
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::generate(Heightmap *pHeightmapSet, CxImage *pPreviewBitmapSet, QString enginePathSet,
						 OneSource *pParameterSet, int countSet)
{
	//stop a old thread
	cancel();

	//save all settings intern
	pHeightmap = pHeightmapSet;
	pPreviewBitmap = pPreviewBitmapSet;
	enginePath = enginePathSet;
	pParameter = pParameterSet;
	count = countSet;

	//this is not the preview
	preview = false;

	//start the generate thread
	start();
}

/****************************************************************************
** RiversGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::cancel()
{
	//set flag true, so the thread will stop
	if (running()) cancelFlag = true;
}

/****************************************************************************
** RiversGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::run()
{
	//init cancel-flag
	cancelFlag = false;

	if (preview) doPreview();
	else doGeneration();
}

/****************************************************************************
** RiversGen doPreview
**
** this is the real generation of the rivers preview
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::doPreview()
{
	int x,y;

	//delete old preview
	pPreviewBitmap->Clear(0x00);
	pPreviewBitmap->AlphaClear();
	
	//draw points on each source
	for (int i=0;i<count;i++)
	{
		//get right color
		RGBQUAD color;
		if (i==highlight) 
		{
			color.rgbRed = 255;
			color.rgbGreen = 0;
			color.rgbBlue = 0;
			color.rgbReserved = 255;
		}
		else 
		{
			color.rgbRed = 0;
			color.rgbGreen = 0;
			color.rgbBlue = 255;
			color.rgbReserved = 255;
		}

		//get source position
		x = pParameter[i].sourceX;
		y = pParameter[i].sourceY;

		//paint a cross
		if (x > 0) pPreviewBitmap->SetPixelColor(x-1,y,color,true);
		if (y > 0) pPreviewBitmap->SetPixelColor(x,y-1,color,true);
		pPreviewBitmap->SetPixelColor(x,y,color,true);
		if (x < pPreviewBitmap->GetWidth()-1) pPreviewBitmap->SetPixelColor(x+1,y,color,true);
		if (y < pPreviewBitmap->GetHeight()-1) pPreviewBitmap->SetPixelColor(x,y+1,color,true);
	}
}


/****************************************************************************
** RiversGen doGeneration
**
** this is the real generation of the rivers
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::doGeneration()
{
	int size = pPreviewBitmap->GetWidth();
	int x,y,i;
	int checkX,checkY;
	RGBQUAD color;

	//reset source vars
	for (i=0;i<count;i++)
	{
		pParameter[i].sourceFactor = 1.0;
	}

	//create array to hold water elements for terrain points
	pWaterElements = new WaterElement*[size];
	for (x=0;x<size;x++)
	{
		pWaterElements[x] = new WaterElement[size];
		for (y=0;y<size;y++)
		{
			pWaterElements[x][y].amount = 0.0;
			pWaterElements[x][y].meanAmount = 0.0f;
			pWaterElements[x][y].stream = D3DXVECTOR2(0.0f,0.0f);
			pWaterElements[x][y].source = false;
			pWaterElements[x][y].border = false;
			pWaterElements[x][y].textureCoordinateSet = false;
			pWaterElements[x][y].tu = 0.0f;
			pWaterElements[x][y].tv = 0.0f;
			pWaterElements[x][y].erosion = 0.0f;
			pWaterElements[x][y].orgGroundHeight = pHeightmap->getHeightInMeters(x,y);
		}
	}

	do
	{
		//check cancel flag
		if (cancelFlag)
			break;

		//add water to all source
		for (i=0;i<count;i++)
		{
			int sX = pParameter[i].sourceX;
			int sY = pParameter[i].sourceY;

			pWaterElements[sX][sY].amount += 
				pParameter[i].sourceFactor*pParameter[i].waterAmountBegin;
			pWaterElements[sX][sY].meanAmount = 
				pWaterElements[sX][sY].meanAmount*
				(RIVERSGEN_MEANCOUNT-1.0f)/RIVERSGEN_MEANCOUNT+
				pWaterElements[sX][sY].amount*
				1.0f/RIVERSGEN_MEANCOUNT;
			pWaterElements[sX][sY].source = true;

			if (pParameter[i].sourceFactor*pParameter[i].waterAmountBegin > pParameter[i].waterAmountEnd)
				pParameter[i].sourceFactor *= 0.999;
		}
	
		//let all water elements flow down
		for (y=0;y<size;y++)
			for (x=0;x<size;x++)
		{
			//get current amount of water
			double currentAmount = pWaterElements[x][y].amount;

			//no water... go on
			if (currentAmount <= SMALL_NUM)
			{
				//delete pixel
				color.rgbRed = 0;
				color.rgbGreen = 0;
				color.rgbBlue = 0;
				color.rgbReserved = 0;
				pPreviewBitmap->SetPixelColor(x,y,color,true);
				pWaterElements[x][y].meanAmount = 0.0f;
				continue;
			}
			//make pixel blue
			int lighter = 255-(currentAmount+double(pHeightmap->getHeight(x,y)));
			
			if (lighter < 0) lighter = 0;
			if (lighter > 255) lighter = 255;
			color.rgbRed = lighter;
			color.rgbGreen = lighter;
			color.rgbBlue = 255;
			color.rgbReserved = 255;
			pPreviewBitmap->SetPixelColor(x,y,color,true);
			
			//reset water amount
			double currentFullHeight = double(pHeightmap->getHeightInMeters(x,y))+currentAmount;
			pWaterElements[x][y].amount = 0.0;

			//build a list with affected elements
			std::list<double> affected;
			for (checkY = y-1; checkY <= y+1; checkY++)
				for (checkX = x-1; checkX <= x+1; checkX++)
			{
				double fullHeight;

				//diagonal flow is only legal in one direction (considers polygons of terrain)
				if (!isFlowLegal(x, y, checkX, checkY))
					continue;

				//fields outside have same height as center
				if ((checkX < 0) || (checkY < 0) ||
					(checkX >= size) || (checkY >= size))
					fullHeight = double(pHeightmap->getHeightInMeters(x,y));
				else
				{
					//calculate complete height
					fullHeight = double(pHeightmap->getHeightInMeters(checkX,checkY))+
				                 pWaterElements[checkX][checkY].amount;
				}

				//ignore fields with higher height
				if (fullHeight >= currentFullHeight)
					continue;

				//put full height in list
				affected.push_back(fullHeight);
			}

			//if only one (the center)
			if (affected.size() <= 1)
			{
				pWaterElements[x][y].amount = currentAmount;
				pWaterElements[x][y].stream = D3DXVECTOR2(0.0f,0.0f);
			}
			//more than one?
			else
			{
				//reset variable for current stream
				D3DXVECTOR2 currentStream(0.0f,0.0f);

				//sort this list
				affected.sort();

				//go through all elements and distribute water from center
				std::list<double>::iterator currentAffected = affected.begin();
				int affectedCount = 1;
				double newWaterLevel = 0.0;
				while (currentAffected != affected.end())
				{
					//get next element
					std::list<double>::iterator nextAffected = currentAffected;
					nextAffected++;
					//next element exists?
					if (nextAffected != affected.end())
					{
						//calculate difference to next higher element
						double difference = *nextAffected - *currentAffected;
						//calculate water amount to full up fill all
						double neededWater = difference*affectedCount;
						//enough water?
						if (neededWater < currentAmount)
						{
							//fill up
							currentAmount -= neededWater;
							//go to next element
							affectedCount++;
							currentAffected++;
							continue;
						}
					}
					//if up to here... fill up rest of water 
					double rest = currentAmount/double(affectedCount);
					newWaterLevel = *currentAffected+rest;
					break;
				}

				//fill up all elements around to this new water level
				for (checkY = y-1; checkY <= y+1; checkY++)
					for (checkX = x-1; checkX <= x+1; checkX++)
				{
					//diagonal flow is only legal in one direction (considers polygons of terrain)
					if (!isFlowLegal(x, y, checkX, checkY))
						continue;

					//ignore fields outside
					if ((checkX < 0) || (checkY < 0) ||
						(checkX >= size) || (checkY >= size))
						continue;

					//calculate complete height
					double fullHeight = double(pHeightmap->getHeightInMeters(checkX,checkY))+
									   pWaterElements[checkX][checkY].amount;

					//fill up
					if (fullHeight < newWaterLevel)
					{
						double streamAmount = newWaterLevel-fullHeight;
						
						//ignore to small amounts
						if (streamAmount > SMALL_NUM)
						{
							//add to stream value of current element
							if (checkX < x) 
							{
								if (checkY < y)
								{
									currentStream.x -= streamAmount/2;
									currentStream.y -= streamAmount/2;
								}
								else if (checkY == y)
									currentStream.x -= streamAmount;
								else if (checkY > y)
								{
									currentStream.x -= streamAmount/2;
									currentStream.y += streamAmount/2;
								}
							}
							else if (checkX == x)
							{
								if (checkY < y)
									currentStream.y -= streamAmount;
								else if (checkY > y)
									currentStream.y += streamAmount;
							}
							else if (checkX > x) 
							{
								if (checkY < y)
								{
									currentStream.x += streamAmount/2;
									currentStream.y -= streamAmount/2;
								}
								else if (checkY == y)
									currentStream.x += streamAmount;
								else if (checkY > y)
								{
									currentStream.x += streamAmount/2;
									currentStream.y += streamAmount/2;
								}
							}

							//really move water
							pWaterElements[checkX][checkY].amount += streamAmount;
							pWaterElements[checkX][checkY].meanAmount =
								(pWaterElements[checkX][checkY].meanAmount*(RIVERSGEN_MEANCOUNT-1.0f)+
								 pWaterElements[checkX][checkY].amount)/RIVERSGEN_MEANCOUNT;
						}
					}
				}
				//calculate mean stream about last frames
				pWaterElements[x][y].stream = (pWaterElements[x][y].stream*(RIVERSGEN_MEANCOUNT-1.0f)+
											   currentStream)/RIVERSGEN_MEANCOUNT;

				//make erosion of ground
				double erosionAmount = D3DXVec2Length(&currentStream)*RIVERSGEN_EROSIONSTEP;
				if ((pWaterElements[x][y].erosion + erosionAmount) < RIVERSGEN_MAXEROSION)
				{
					pWaterElements[x][y].erosion += erosionAmount;
					double newGroundHeight = pWaterElements[x][y].orgGroundHeight-pWaterElements[x][y].erosion;
					if (newGroundHeight > pHeightmap->getMinHeightInMeters())
						pHeightmap->setHeightInMeters(x,y,newGroundHeight);
				}
			}
		}
	}
	while(1);

	//flatten sources
	smoothSources();

	//fix ugly shores
	repairShore();

	//clean up
	removeErrors();

	//add border
	addBorder();

	//calculate texture coordinates
	calculateTextureCoordinates();

	//save
	saveIt();

	//delete array of water elements
	for (x=0;x<size;x++)
		SAFE_DELETE_ARRAY(pWaterElements[x]);
	SAFE_DELETE_ARRAY(pWaterElements);
}

/****************************************************************************
** RiversGen smoothSources
**
** flatten the sources
**
** Author: Dirk Plate
****************************************************************************/
void RiversGen::smoothSources()
{
	int size = pPreviewBitmap->GetWidth();

	//go through all sources
	for (int i=0;i<count;i++)
	{
		//get position of source
		int x = pParameter[i].sourceX;
		int y = pParameter[i].sourceY;

		//get amount of water of all elements around
		double meanAmount = 0.0f;
		int neighboursCount = 0;

		for (int nY=y-1;nY<=y+1;nY++)
			for (int nX=x-1;nX<=x+1;nX++)
		{
			//ignore fields outside
			if ((nX < 0) || (nY < 0) ||	(nX >= size) || (nY >= size))
				continue;

			//get current amount of water
			double currentAmount = pWaterElements[nX][nY].meanAmount;

			//no water... go on
			if (currentAmount <= SMALL_NUM)
				continue;
		
			//add to mean amount
			meanAmount += currentAmount;
			neighboursCount++;
		}
		meanAmount /= neighboursCount;

		//set amount of source to mean amount
		pWaterElements[x][y].meanAmount = meanAmount;
		pWaterElements[x][y].amount = meanAmount;
	}
}

/****************************************************************************
** RiversGen repairShore
**
** repair shore elements
**
** Author: Dirk Plate
****************************************************************************/
void RiversGen::repairShore()
{
	int size = pPreviewBitmap->GetWidth();

	//go through all elements
	for (int dY=0;dY<size;dY++)
		for (int dX=0;dX<size;dX++)
	{
		//get current amount of water
		double dAmount = pWaterElements[dX][dY].meanAmount;

		//no water... go on
		if (dAmount <= SMALL_NUM)
			continue;

		//get ground height
		double dGround = pHeightmap->getHeightInMeters(dX,dY);

		//get coordinates of elements around
		//      B----A
		//      |   /|
		//      | /  |
		// E----D----C
		// |   /|
		// | /  |
		// G----F
		int aX = dX+1; int aY = dY-1;
		int bX = dX;   int bY = dY-1;
		int cX = dX+1; int cY = dY;
		int eX = dX-1; int eY = dY;
		int fX = dX;   int fY = dY+1;
		int gX = dX-1; int gY = dY+1;

/*		// A----B
		// |\   |
		// |  \ |
		// C----D----E
		//      |\   |
		//      |  \ |
		//      F----G
		int aX = dX-1; int aY = dY-1;
		int bX = dX;   int bY = dY-1;
		int cX = dX-1; int cY = dY;
		int eX = dX+1; int eY = dY;
		int fX = dX;   int fY = dY+1;
		int gX = dX+1; int gY = dY+1;*/

		//top quad has critical shore?
		double newTopDGround;
		bool newTopDGroundSet = false;
		if ((aX < size) && (aY >= 0) && 
			(pWaterElements[aX][aY].meanAmount <=  SMALL_NUM) &&
			(pWaterElements[bX][bY].meanAmount >   SMALL_NUM) &&
			(pWaterElements[cX][cY].meanAmount >   SMALL_NUM))
		{
			//get ground heights of elements
			double aGround = pHeightmap->getHeightInMeters(aX,aY);
			double bGround = pHeightmap->getHeightInMeters(bX,bY);
			double cGround = pHeightmap->getHeightInMeters(cX,cY);

			//calculate new ground height for element
			newTopDGround = dGround+((cGround+bGround)/2.0-aGround);
			newTopDGroundSet = true;
		}
		//bottom quad has critical shore?
		double newBottomDGround;
		bool newBottomDGroundSet = false;
		if ((gX >= 0) && (gY < size) && 
			(pWaterElements[gX][gY].meanAmount <=  SMALL_NUM) &&
			(pWaterElements[eX][eY].meanAmount >   SMALL_NUM) &&
			(pWaterElements[fX][fY].meanAmount >   SMALL_NUM))
		{
			//get ground heights of elements
			double gGround = pHeightmap->getHeightInMeters(gX,gY);
			double eGround = pHeightmap->getHeightInMeters(eX,eY);
			double fGround = pHeightmap->getHeightInMeters(fX,fY);

			//calculate new ground height for element
			newBottomDGround = dGround+((eGround+fGround)/2.0-gGround);
			newBottomDGroundSet = true;
		}
		
		//calculate new ground height
		double newDGround;
		if (newTopDGroundSet && newBottomDGroundSet)
			newDGround = (newTopDGround+newBottomDGround)/2.0f;
		else if (newTopDGroundSet)
			newDGround = newTopDGround;
		else if (newBottomDGroundSet)
			newDGround = newBottomDGround;
		else continue;
		if (newDGround > dGround) newDGround = dGround;

		//set heightmap to new height
		if (newDGround > pHeightmap->getMinHeightInMeters())
			pHeightmap->setHeightInMeters(dX,dY,newDGround);

		//set water amount to same level as before
		pWaterElements[dX][dY].meanAmount = (dGround+dAmount)-pHeightmap->getHeightInMeters(dX,dY);
		pWaterElements[dX][dY].amount = pWaterElements[dX][dY].meanAmount;
	}
}

/****************************************************************************
** RiversGen removeErrors
**
** removes illegal river elements 
**
** Author: Dirk Plate
****************************************************************************/
void RiversGen::removeErrors()
{
	int x,y,checkX,checkY;
	int size = pPreviewBitmap->GetWidth();
	RGBQUAD color;

	//removes illegal river element (elements with no contact to a source)
	groups.clear();

	//repeatly going to all element
	while(1)
	{
		//set all groups to no changes
		std::list<OneRiverGroup>::iterator groupI = groups.begin();
		while(groupI != groups.end())
		{
			groupI->newElements = false;
			groupI++;
		}

		for (y=0;y<size;y++)
			for (x=0;x<size;x++)
		{
			//get current amount of water
			double currentAmount = pWaterElements[x][y].meanAmount;

			//no water... go on
			if (currentAmount <= RIVERSGEN_MINWATERAMOUNT)
			{
				//ignore pixel
				continue;
			}

			//get own group id
			long currentGroupId = y*size+x;

			//get group iterator
			std::list<OneRiverGroup>::iterator currentGroup = groups.begin();
			while(currentGroup != groups.end())
			{
				if (currentGroup->ids.find(currentGroupId) != currentGroup->ids.end())
					break;
				currentGroup++;
			}

			//find best other group around
			std::list<OneRiverGroup>::iterator bestGroup = currentGroup;
			for (checkY = y-1; checkY <= y+1; checkY++)
				for (checkX = x-1; checkX <= x+1; checkX++)
			{
				//diagonal flow is only legal in one direction (considers polygons of terrain)
				if (!isFlowLegal(x, y, checkX, checkY))
					continue;

				//ignore own element
				if ((checkX == x) && (checkY == y))
					continue;
				//ignore fields outside
				if ((checkX < 0) || (checkY < 0) ||
					(checkX >= size) || (checkY >= size))
					continue;
				//low elements are not grouped
				if (pWaterElements[checkX][checkY].meanAmount <= RIVERSGEN_MINWATERAMOUNT)
					continue;
				
				//get group iterator
				long checkGroupId = checkY*size+checkX;
				std::list<OneRiverGroup>::iterator checkGroup = groups.begin();
				while(checkGroup != groups.end())
				{
					if (checkGroup->ids.find(checkGroupId) != checkGroup->ids.end())
						break;
					checkGroup++;
				}
				//no group
				if (checkGroup == groups.end())
					continue;
				
				//already in same group
				if (checkGroup == bestGroup)
					continue;
			
				//take other group if own has no group
				if (bestGroup == groups.end())
				{
					bestGroup = checkGroup;
					continue;
				}

				//if other group has contact to source
				if (checkGroup->sourceContact)
				{
					//if own has also contact to source 
					if (bestGroup->sourceContact)
					{
						//take group with more elements
						if (checkGroup->elementCount > bestGroup->elementCount)
							bestGroup = checkGroup;
						continue;
					}
					//take group with contact
					else
					{
						bestGroup = checkGroup;
						continue;
					}
				}
				//the other has no no contact
				else
				{
					//both has no contact... take group with more elements
					if (!bestGroup->sourceContact)
						if (checkGroup->elementCount > bestGroup->elementCount)
							bestGroup = checkGroup;
					continue;
				}
			}
			//no group assigned?
			if (bestGroup == groups.end())
			{
				//create new group
				std::list<OneRiverGroup>::iterator newGroup = groups.insert(groups.end());
				newGroup->elementCount = 1;
				newGroup->newElements = true;
				if (pWaterElements[x][y].source)
				{
					newGroup->sourceContact = true;
					for (int i=0;i<count;i++)
					{
						if ((x == pParameter[i].sourceX) &&
							(y == pParameter[i].sourceY))
						{
							newGroup->sourceID = i;
							break;
						}
					}
				}
				else newGroup->sourceContact = false;
				newGroup->ids.insert(currentGroupId);
				currentGroup = newGroup;

				//qDebug( "New group created: %d", currentGroupId);
			}
			//a group changed
			else if (bestGroup != currentGroup)
			{
				//own has no group?
				if (currentGroup == groups.end())
				{
					//qDebug( "Adding %d to group", currentGroupId);

					//merge group to best group
					bestGroup->elementCount++;
					bestGroup->newElements = true;
					if (!bestGroup->sourceContact && pWaterElements[x][y].source)
					{
						bestGroup->sourceContact = true;
						for (int i=0;i<count;i++)
						{
							if ((x == pParameter[i].sourceX) &&
								(y == pParameter[i].sourceY))
							{
								bestGroup->sourceID = i;
								break;
							}
						}
					}
					bestGroup->ids.insert(currentGroupId);
					currentGroup = bestGroup;
				}
				//own has a group
				else
				{
					//qDebug( "Merging groups");

					//merge group to best group
					bestGroup->elementCount += currentGroup->elementCount;
					bestGroup->newElements = true;
					if (!bestGroup->sourceContact && currentGroup->sourceContact)
					{
						bestGroup->sourceContact = true;
						bestGroup->sourceID = currentGroup->sourceID;
					}
					std::set<long>::iterator copyId = currentGroup->ids.begin();
					while (copyId != currentGroup->ids.end())
					{
						bestGroup->ids.insert(*copyId);
						copyId++;
					}

					//delete old group
					groups.erase(currentGroup);
					currentGroup = bestGroup;
				}
			}
			//else qDebug( "No group changes");
		}

		//nothing changed... break
		groupI = groups.begin();
		while(groupI != groups.end())
		{
			if (groupI->newElements) 
				break;
			groupI++;
		}
		if (groupI == groups.end())
			break;
	}

	//remove all elements of a group with no contact
	for (y=0;y<size;y++)
		for (x=0;x<size;x++)
	{
		//get current amount of water
		double currentAmount = pWaterElements[x][y].meanAmount;

		//no water... go on
		if (currentAmount <= RIVERSGEN_MINWATERAMOUNT)
		{
			//delete pixel
			pWaterElements[x][y].amount = 0.0f;
			pWaterElements[x][y].meanAmount = 0.0f;
			color.rgbRed = 0;
			color.rgbGreen = 0;
			color.rgbBlue = 0;
			color.rgbReserved = 0;
			pPreviewBitmap->SetPixelColor(x,y,color,true);
			continue;
		}
		
		//get own group id
		long currentGroupId = y*size+x;

		//get group iterator
		std::list<OneRiverGroup>::iterator currentGroup = groups.begin();
		int groupNo = 0;
		while(currentGroup != groups.end())
		{
			if (currentGroup->ids.find(currentGroupId) != currentGroup->ids.end())
				break;
			currentGroup++;
			groupNo++;
		}
		
		//if no group or group has no source contact... delete element
		if ((currentGroup == groups.end()) ||
			(!currentGroup->sourceContact))
		{
			pWaterElements[x][y].amount = 0.0f;
			pWaterElements[x][y].meanAmount = 0.0f;
			color.rgbRed = 0;
			color.rgbGreen = 0;
			color.rgbBlue = 0;
			color.rgbReserved = 0;
			pPreviewBitmap->SetPixelColor(x,y,color,true);
			continue;
		}
	}
}

/****************************************************************************
** RiversGen addBorder
**
** add a border to rivers
**
** Author: Dirk Plate
****************************************************************************/
void RiversGen::addBorder()
{
	int x,y;
	int size = pPreviewBitmap->GetWidth();

	//enhance with border water elements
	for (y=0;y<size;y++)
		for (x=0;x<size;x++)
	{
		//no water... go on
		if (pWaterElements[x][y].meanAmount <= SMALL_NUM)
			continue;
		
		//ignore border elements (they don't need another border)
		if (pWaterElements[x][y].border)
			continue;

		//get group id of element
		long currentGroupId = y*size+x;

		//get group iterator
		std::list<OneRiverGroup>::iterator currentGroup = groups.begin();
		while(currentGroup != groups.end())
		{
			if (currentGroup->ids.find(currentGroupId) != currentGroup->ids.end())
				break;
			currentGroup++;
		}
		if (currentGroup == groups.end())
			currentGroup = groups.begin();

		//create border elements around
		for (int checkY = y-1; checkY <= y+1; checkY++)
			for (int checkX = x-1; checkX <= x+1; checkX++)
		{
			//don't need a border in top/right and bottom/left
			if (((checkY == y+1) && (checkX == x+1)) ||
				((checkY == y-1) && (checkX == x-1)))
				continue;

			//check border of terrain
			if ((checkX < 0) || (checkX >= size) ||
				(checkY < 0) || (checkY >= size))
				continue;

			//ignore elements, where already water is
			if (pWaterElements[checkX][checkY].meanAmount > SMALL_NUM)
				continue;

			//add element
			pWaterElements[checkX][checkY].meanAmount = 10.0f;
			pWaterElements[checkX][checkY].amount = 10.0f;
			pWaterElements[checkX][checkY].border = true;
			
			//calculate mean stream
			pWaterElements[checkX][checkY].stream = pWaterElements[x][y].stream;
			int meanCount = 1;
			for (int checkY2 = checkY-1; checkY2 <= checkY+1; checkY2++)
				for (int checkX2 = checkX-1; checkX2 <= checkX+1; checkX2++)
			{
				//don't get values in top/right and bottom/left
				/*if (((checkY2 == checkY+1) && (checkX2 == checkX+1)) ||
					((checkY2 == checkY-1) && (checkX2 == checkX-1)))
					continue;*/

				//check border of terrain
				if ((checkX2 < 0) || (checkX2 >= size) ||
					(checkY2 < 0) || (checkY2 >= size))
					continue;

				//ignore own element
				if ((checkX2 == x) && (checkY2 == y))
					continue;

				//ignore parent element
				if ((checkX2 == checkX) && (checkY2 == checkY))
					continue;

				//only elements, with water and not border
				if ((pWaterElements[checkX2][checkY2].meanAmount > SMALL_NUM) &&
					(!pWaterElements[checkX2][checkY2].border))
				{
					//add to mean stream
					pWaterElements[checkX][checkY].stream += pWaterElements[checkX2][checkY2].stream;
					meanCount++;
				}
			}
		
			//calculate mean stream
			pWaterElements[checkX][checkY].stream /= meanCount;

			//add id to group
			long newGroupId = checkY*size+checkX;
			currentGroup->ids.insert(newGroupId);
		}
	}
}

/****************************************************************************
** RiversGen calculateTextureCoordinates
**
** calculate texture coordinates for all elements		
**
** Author: Dirk Plate
****************************************************************************/
void RiversGen::calculateTextureCoordinates()
{
	int x,y;
	int size = pPreviewBitmap->GetWidth();

	//all sources of all groups begin with texturecoordinate 0
	std::list<OneRiverGroup>::iterator currentGroup = groups.begin();
	while(currentGroup != groups.end())
	{
		if (currentGroup->sourceContact)
		{
			x = pParameter[currentGroup->sourceID].sourceX;
			y = pParameter[currentGroup->sourceID].sourceY;
			pWaterElements[x][y].textureCoordinateSet = true;
			pWaterElements[x][y].tu = 0.0f;
			pWaterElements[x][y].tv = 0.0f;
		}
		currentGroup++;
	}

	//repeat until all elements have a texture coordinate
	bool textureCoordinateAdded;
	do
	{
		textureCoordinateAdded = false;

		//check all elements
		for (y=0;y<size;y++)
			for (x=0;x<size;x++)
		{
			//no water... go on
			if (pWaterElements[x][y].meanAmount <= SMALL_NUM)
				continue;
			
			//ignore element with wave time
			if (pWaterElements[x][y].textureCoordinateSet)
				continue;

			//get texture coordinates from all elements around
			int textureCoordinateCount = 0;
			float newTV = 0.0f;
			float newTU = 0.0f;
			float meanTV = 0.0f;
			float meanTU = 0.0f;
			int checkY, checkX;
			for (checkY = y-1; checkY <= y+1; checkY++)
				for (checkX = x-1; checkX <= x+1; checkX++)
			{
				//diagonal flow is only legal in one direction (considers polygons of terrain)
				if (!isFlowLegal(x, y, checkX, checkY))
					continue;

				//ignore own element
				if ((checkX == x) && (checkY == y))
					continue;

				//ignore fields outside
				if ((checkX < 0) || (checkY < 0) ||
					(checkX >= size) || (checkY >= size))
					continue;

				//use only elements with a texture coordinate
				if (!pWaterElements[checkX][checkY].textureCoordinateSet)
					continue;

				//don't use border elements
				if (pWaterElements[checkX][checkY].border)
					continue;
			
				//normalize stream vector
				D3DXVECTOR2 normStream;
				if ((pWaterElements[checkX][checkY].stream.x == 0.0f) &&
					(pWaterElements[checkX][checkY].stream.y == 0.0f))
					normStream = D3DXVECTOR2(1.0f,0.0f);
				else
					D3DXVec2Normalize(&normStream, &pWaterElements[checkX][checkY].stream);

				//calculate current u texture coordinate
				float currentTU;

				//left/top?
				if ((checkX<x) && (checkY<y))
					currentTU = (normStream.y-normStream.x);
				//top?
				else if ((checkX==x) && (checkY<y))
					currentTU = -normStream.x;
				//right/top?
				else if ((checkX>x) && (checkY<y))
					currentTU = (-normStream.y-normStream.x);
				//left?
				else if ((checkX<x) && (checkY==y))
					currentTU = normStream.y;
				//right?
				else if ((checkX>x) && (checkY==y))
					currentTU = -normStream.y;
				//left/bottom?
				else if ((checkX<x) && (checkY>y))
					currentTU = (normStream.y+normStream.x);
				//bottom?
				else if ((checkX==x) && (checkY>y))
					currentTU = normStream.x;
				//right/bottom?
				else if ((checkX>x) && (checkY>y))
					currentTU = (-normStream.y+normStream.x);
				
				newTU += currentTU/RIVERSGEN_TEXTURESCALE;
				meanTU += pWaterElements[checkX][checkY].tu;

				//calculate current v texture coordinate
				float currentTV;

				//left/top?
				if ((checkX<x) && (checkY<y))
					currentTV = (-normStream.x-normStream.y);
				//top?
				else if ((checkX==x) && (checkY<y))
					currentTV = -normStream.y;
				//right/top?
				else if ((checkX>x) && (checkY<y))
					currentTV = (normStream.x-normStream.y);
				//left?
				else if ((checkX<x) && (checkY==y))
					currentTV = -normStream.x;
				//right?
				else if ((checkX>x) && (checkY==y))
					currentTV = normStream.x;
				//left/bottom?
				else if ((checkX<x) && (checkY>y))
					currentTV = (-normStream.x+normStream.y);
				//bottom?
				else if ((checkX==x) && (checkY>y))
					currentTV = normStream.y;
				//right/bottom?
				else if ((checkX>x) && (checkY>y))
					currentTV = (normStream.x+normStream.y);
				
				newTV += currentTV/RIVERSGEN_TEXTURESCALE;
				meanTV += pWaterElements[checkX][checkY].tv;

				textureCoordinateCount++;

				
				float textureCoordinateLength = sqrtf(currentTU*currentTU+currentTV*currentTV);
				float coordinateLength = sqrtf((checkX-x)*(checkX-x)+(checkY-y)*(checkY-y));
				float difference = coordinateLength-textureCoordinateLength;
				
				if (difference > SMALL_NUM)
				{
					qDebug(QString("checkDiff: %1/%1").arg(checkX-x).arg(checkY-y));
					qDebug(QString("normStream: %1/%1").arg(normStream.x).arg(normStream.y));
					qDebug(QString("textureCoordinate: %1/%1").arg(currentTU).arg(currentTV));
					qDebug(QString("textureCoordinateLength: %1").arg(textureCoordinateLength));
					qDebug(QString("coordinateLength: %1").arg(coordinateLength));
					qDebug(QString("difference: %1\n").arg(difference));
				}
			}

			//no texture coordinate around... continue
			if (textureCoordinateCount == 0)
				continue;

			//calculate mean texture coordinate
			meanTU /= textureCoordinateCount;
			meanTV /= textureCoordinateCount;
			newTU /= textureCoordinateCount;
			newTV /= textureCoordinateCount;

			pWaterElements[x][y].tu = meanTU+newTU;
			pWaterElements[x][y].tv = meanTV+newTV;
			pWaterElements[x][y].textureCoordinateSet = true;

			/*float tmpU = pWaterElements[x][y].tu-int(pWaterElements[x][y].tu);
			float tmpV = pWaterElements[x][y].tv-int(pWaterElements[x][y].tv);

			previewBitmap.setPixel(x,y,qRgba(testStream.x*255.0f,testStream.y*255.0f,0,255));*/

			//something changes ... don't stop
			textureCoordinateAdded = true;
		}
	}
	while(textureCoordinateAdded);

}

/****************************************************************************
** RiversGen saveIt
**
** saves the results
**
** Author: Dirk Plate
****************************************************************************/
void RiversGen::saveIt()
{
	int x,y;
	int size = pPreviewBitmap->GetWidth();

	//save elements in txt
	MiniXML xmlFile;
	int no=0;
	if (xmlFile.openFile(enginePath+"/rivers.txt",MiniXML::WRITE))
	{
		if (xmlFile.startWriteList("rivers"))
		{
			//write all elements
			for (y=0;y<size;y++)
				for (x=0;x<size;x++)
			{
				if (pWaterElements[x][y].meanAmount > SMALL_NUM)
				{
					//get own group id
					long currentGroupId = y*size+x;

					//get group iterator
					std::list<OneRiverGroup>::iterator currentGroup = groups.begin();
					while(currentGroup != groups.end())
					{
						if (currentGroup->ids.find(currentGroupId) != currentGroup->ids.end())
							break;
						currentGroup++;
					}
					if (currentGroup == groups.end())
						currentGroup = groups.begin();

					if (xmlFile.startWriteListElement(no))
					{
						//save all relevant items
						xmlFile.writeInteger("x",x);
						xmlFile.writeInteger("y",y);
						xmlFile.writeFloat("amount",pWaterElements[x][y].meanAmount);
						xmlFile.writeFloat("streamStrength",
							D3DXVec2Length(&pWaterElements[x][y].stream)/50.0f*
							pParameter[currentGroup->sourceID].streamSpeed);
						xmlFile.writeFloat("tu",pWaterElements[x][y].tu);
						xmlFile.writeFloat("tv",pWaterElements[x][y].tv);
						xmlFile.writeBoolean("border",pWaterElements[x][y].border);
						
						xmlFile.endWriteListElement();
					}
					no++;
				}
			}
			xmlFile.endWriteList();
		}

		xmlFile.closeFile();
	}
}

/****************************************************************************
** RiversGen switchCoordinateOffset
**
** switch coordinate offsets
**
** Author: Dirk Plate
****************************************************************************/

void RiversGen::switchCoordinateOffset(int &xOffset, int &yOffset)
{
	if ((yOffset == 0) && (xOffset == 0))
	{
		yOffset=0;
		xOffset=2;
	}
	else if ((yOffset == 0) && (xOffset == 2))
	{
		yOffset=2;
		xOffset=0;
	}
	else if ((yOffset == 2) && (xOffset == 0))
	{
		yOffset=2;
		xOffset=2;
	}
	else if ((yOffset == 2) && (xOffset == 2))
	{
		yOffset=1;
		xOffset=0;
	}
	else if ((yOffset == 1) && (xOffset == 0))
	{
		yOffset=1;
		xOffset=2;
	}
	else if ((yOffset == 1) && (xOffset == 2))
	{
		yOffset=3;
		xOffset=0;
	}
	else if ((yOffset == 3) && (xOffset == 0))
	{
		yOffset=3;
		xOffset=2;
	}
	else if ((yOffset == 3) && (xOffset == 2))
	{
		yOffset=1;
		xOffset=1;
	}
	else if ((yOffset == 1) && (xOffset == 1))
	{
		yOffset=1;
		xOffset=3;
	}
	else if ((yOffset == 1) && (xOffset == 3))
	{
		yOffset=3;
		xOffset=1;
	}
	else if ((yOffset == 3) && (xOffset == 1))
	{
		yOffset=3;
		xOffset=3;
	}
	else if ((yOffset == 3) && (xOffset == 3))
	{
		yOffset=0;
		xOffset=1;
	}
	else if ((yOffset == 0) && (xOffset == 1))
	{
		yOffset=0;
		xOffset=3;
	}
	else if ((yOffset == 0) && (xOffset == 3))
	{
		yOffset=2;
		xOffset=1;
	}
	else if ((yOffset == 2) && (xOffset == 1))
	{
		yOffset=2;
		xOffset=3;
	}
	else if ((yOffset == 2) && (xOffset == 3))
	{
		yOffset=0;
		xOffset=0;
	}
}

/****************************************************************************
** RiversGen isFlowLegal
**
** check, if a flow is legal
**
** Author: Dirk Plate
****************************************************************************/
bool RiversGen::isFlowLegal(int xMiddle, int yMiddle, int xNeighbour, int yNeighbour)
{
	int size = pPreviewBitmap->GetWidth();
	
	//diagonal flow is only legal in one direction (considers polygons of terrain)
	if (((yNeighbour == yMiddle+1) && (xNeighbour == xMiddle+1)) ||
		((yNeighbour == yMiddle-1) && (xNeighbour == xMiddle-1)))
	{
		//it can be legal, if fields around have water
		if ((xMiddle    >= 0) && (xMiddle    < size) &&
			(yNeighbour >= 0) && (yNeighbour < size) &&
			(xNeighbour >= 0) && (xNeighbour < size) &&
			(yMiddle    >= 0) && (yMiddle    < size))
		{
			if ((pWaterElements[xMiddle][yNeighbour].amount > SMALL_NUM) ||
				(pWaterElements[xNeighbour][yMiddle].amount > SMALL_NUM))
				return true;
		}
	}
	else return true;
	
	return false;
}
