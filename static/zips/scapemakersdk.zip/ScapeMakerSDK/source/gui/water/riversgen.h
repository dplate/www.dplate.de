/****************************************************************************
** RiversGen
**
** The rivers generator class
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#ifndef RIVERSGEN_H
#define RIVERSGEN_H

#define RIVERSGEN_TEXTURESCALE 5.0f
#define RIVERSGEN_MEANCOUNT 10.0f
#define RIVERSGEN_MAXEROSION 10.0f
#define RIVERSGEN_EROSIONSTEP 0.01f
#define RIVERSGEN_MINWATERAMOUNT 0.1f

#include <qthread.h>
#include <stdlib.h>
#include "../../engine/terrain/heightmap.h"
#include "ximage.h"
#include <set>
#include <list>

//all attributes of one source
struct OneSource
{
	//the name of source
	QString name;

	//the position of source
	int sourceX;
	int sourceY;

	//the water amount of source (begin and end)
	int waterAmountBegin;
	int waterAmountEnd;
	double sourceFactor;

	//the strength factor for stream
	int streamSpeed;
};

//struct with information of groups
struct OneRiverGroup
{
	//list of all id includes in this group
	std::set<long> ids;

	//contact to a source?
	bool sourceContact;

	//if source contact... which source?
	int sourceID;

	//count of elements in this group
	long elementCount;

	//new elements in last round?
	bool newElements;
};

class RiversGen : public QThread
{
public:
	struct WaterElement
	{
		double		amount;		//amount of water (same unit as height)
		double		maxAmount;  //maximum amount in last generation round
		double		meanAmount; //mean amount in last x generation rounds
		D3DXVECTOR2 stream;		//direction and strength of stream
		bool		textureCoordinateSet; //texture coordinates are already set
		float		tu;			//the u texture coordinate
		float		tv;			//the v texture coordinate
		bool		source;		//source element or not
		bool		border;		//border element or not
		double		erosion;	//erosion at this coordinate
		double		orgGroundHeight; //original ground height
	};

	RiversGen();
	~RiversGen();

	void generatePreview(Heightmap *pHeightMapSet, CxImage *pPreviewBitmapSet,
		OneSource *pParameterSet, int countSet, int highlightSet);

	void generate(Heightmap *pHeightMapSet, CxImage *pPreviewBitmapSet, QString enginePathSet,
		OneSource *pParameterSet, int countSet);

	void cancel();

protected:
	virtual void run();

private:
	void doGeneration();		//the real generation of the rivers
	void doPreview();			//the real generation of the rivers-preview

	void smoothSources();		//flatten the sources
	void repairShore();			//repair shore elements
	void removeErrors();		//finish generation of rivers
	void addBorder();			//add the border of rivers
	void calculateTextureCoordinates();	//calculate texture coordinates for all elements		
	void saveIt();				//save the rivers

	void switchCoordinateOffset(int &xOffset, int&yOffset);	//switch coordinate offsets
	bool isFlowLegal(int xMiddle, int yMiddle, int xNeighbour, int yNeighbour);

	Heightmap *pHeightmap;		//pointer to heightmap class

	bool cancelFlag;

	CxImage *pPreviewBitmap;	//the generated shadow-preview
	bool preview;				//making the shadow preview or the real shadow on texture?

	QString enginePath;			//path to engine directory to save results

	OneSource *pParameter;		//all parameters of current sources
	int count;					//count of source
	int highlight;				//the source, which will be highlighted

	//array to hold water elements for terrain points
	WaterElement **pWaterElements;

	//list with all groups
	std::list<OneRiverGroup> groups;
};

#endif