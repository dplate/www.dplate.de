/****************************************************************************
** SeaGen
**
** The texture generator class
**
** Author: Dirk Plate
****************************************************************************/

#include "seagen.h"

/****************************************************************************
** SeaGen Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

SeaGen::SeaGen()
{
	preview = false;
}

SeaGen::~SeaGen()
{

}

/****************************************************************************
** SeaGen generatePreview
**
** starts the generation of sea preview
**
** Author: Dirk Plate
****************************************************************************/

void SeaGen::generatePreview(Heightmap *pHeightmapSet, CxImage *pPreviewBitmapSet, 
							 float seaHeightSet, int seaTransparencySet, DWORD seaColorSet)
{
	//stop a old thread
	cancel();

	//save all settings intern
	pHeightmap = pHeightmapSet;
	pPreviewBitmap = pPreviewBitmapSet;
	seaHeight = seaHeightSet;
	seaTransparency = seaTransparencySet;
	seaColor = seaColorSet;

	//this is only the  preview
	preview = true;

	//start the generate thread
	start();
}

/****************************************************************************
** SeaGen cancel
**
** stops the generate thread
**
** Author: Dirk Plate
****************************************************************************/

void SeaGen::cancel()
{
	//set flag true, so the thread will stop
	if (running()) cancelFlag = true;
}

/****************************************************************************
** SeaGen run
**
** this method is called, when the thread was started
**
** Author: Dirk Plate
****************************************************************************/

void SeaGen::run()
{
	//init cancel-flag
	cancelFlag = false;

	if (preview) doPreview();
}

/****************************************************************************
** SeaGen doPreview
**
** this is the real generation of the sea preview
**
** Author: Dirk Plate
****************************************************************************/

void SeaGen::doPreview()
{
	int heightMapX,heightMapY;
	int size = pPreviewBitmap->GetWidth();
	RGBQUAD color;
	
	//calculate the right transparency factor
	float transparencyFactor = float((100-seaTransparency)*5.0f/PIXELWIDTH)/100.0f;

	for (heightMapY=0;heightMapY<size;heightMapY++)
		for (heightMapX=0;heightMapX<size;heightMapX++)
	{
		if (cancelFlag) return;

		//set this pixel in the shadow preview bitmap
		float terrainHeight = pHeightmap->getHeightInMeters(heightMapX,heightMapY);
		if (terrainHeight < seaHeight)
		{
			float waterDeep = seaHeight - terrainHeight;
			if (waterDeep < 0.0f) waterDeep = 0.0f;
			//convert deep to an alpha value (more deepness... fewer transparency)
			waterDeep = 1.0f-atanf(transparencyFactor * waterDeep) * 2.0f / D3DX_PI;
			//calculate alpha value
			float alpha = 255.0f-(255.0f*waterDeep*0.75f);

			color.rgbRed = 0;
			color.rgbGreen = 0;
			color.rgbBlue = 200;
			color.rgbReserved = alpha;
			pPreviewBitmap->SetPixelColor(heightMapX,heightMapY,color,true);
		}
		else
		{
			color.rgbRed = 0;
			color.rgbGreen = 0;
			color.rgbBlue = 0;
			color.rgbReserved = 0;
			pPreviewBitmap->SetPixelColor(heightMapX,heightMapY,color,true);
		}
		
	}
}

