/****************************************************************************
** SeaGen
**
** The shadow generator class
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include <qthread.h>
#include <stdlib.h>
#include <time.h>
#include "../../engine/terrain/heightmap.h"
#include "ximage.h"

class SeaGen : public QThread
{
public:
	SeaGen();
	~SeaGen();

	void generatePreview(Heightmap *pHeightMapSet, CxImage *pPreviewBitmapSet, 
		float seaHeightSet,int seaTransparencySet,DWORD seaColorSet);
	void cancel();

protected:
	virtual void run();

private:
	void doPreview();			//the real generation of the sea-preview

	Heightmap *pHeightmap;		//pointer to heightmap class

	bool cancelFlag;
	float seaHeight;
	int seaTransparency;
	DWORD seaColor;

	CxImage *pPreviewBitmap;	//the generated sea-preview
	bool preview;				//making the sea preview or the real sea?
};
