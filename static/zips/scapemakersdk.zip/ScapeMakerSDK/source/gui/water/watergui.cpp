/****************************************************************************
** WaterGUI
**
** the sea-tab window
**
** Author: Dirk Plate
****************************************************************************/

#include "watergui.h"
#include "../../engine/water/riversmap.h"
#include "../../engine/common/enginehelpers.h"

/****************************************************************************
** WaterGUI Constructor
**
** initialise vars
**
** Author: Dirk Plate
****************************************************************************/

WaterGUI::WaterGUI( QWidget* parent, const char* name, WFlags f )
	: WaterGUIBase(parent, name, f)
{
	connect( bitmapNavContainer, SIGNAL(positionWithPenClicked(QPoint)), this, SLOT(newSource(QPoint)));
	connect( bitmapNavContainer, SIGNAL(positionWithRubberClicked(QPoint)), this, SLOT(deleteSource(QPoint)));

	generatingSeaPreviewTimer = false;
	generatingSeaPreviewTimerID = -1;

	generatingRiversPreviewTimer = false;
	generatingRiversPreviewTimerID = -1;

	generatingRiversTimerID = -1;

	dontRecalculate = false;

	pHeightMap = NULL;
	pSources = NULL;
	sourcesCount = 0;
}

/****************************************************************************
** WaterGUI showEvent
**
** Is called, when the WaterGUI will be shown.
** Load everything for this panel!
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::showEvent(QShowEvent *showEvent)
{
	//ignore spontaneous show events (come from iconified)
	if (showEvent->spontaneous())
		return;

	//get a pointer to the widget with the tab bar (we need this for disabling other tabs while generating)
	topParent =	(ScapeMakerDialog*)(parentWidget()->parentWidget()->parentWidget()->parentWidget());

	//repair directory tree
	GUIHelpers::createLandscapeDirectories(this,projectPath,false);

	//show tool in bitmapnav
	bitmapNavContainer->setPenButtonVisible(true);
	bitmapNavContainer->setRubberButtonVisible(true);

	//set all help texts
	penHelpLabel->show();
	generateHelpLabel->hide();

	//prepare sliders
	heightSlider->setProperties(CoolSlider::LINEAR,tr("Height"),0,3000,"m",1);
	speedSlider->setProperties(CoolSlider::LINEAR,tr("Speed"),0,100,"m/s",1);
	reflectionSlider->setProperties(CoolSlider::LINEAR,tr("Reflection"),0,100,"%",1);
	transparencySlider->setProperties(CoolSlider::LINEAR,tr("Transparency"),5,95,"%",1);
	waterAmountSlider->setProperties(CoolSlider::LINEAR,tr("Water amount"),0,100,"",2);
	streamSpeedSlider->setProperties(CoolSlider::LINEAR,tr("Stream speed"),0,100,"",1);

	//dont recalculate during initialising
	dontRecalculate = true;

	//set default values for sliders first
	heightSlider->setValue(0,0);
	speedSlider->setValue(0,20);
	reflectionSlider->setValue(0,50);
	transparencySlider->setValue(0,50);
	waterAmountSlider->setValue(0,20);
	waterAmountSlider->setValue(1,40);
	streamSpeedSlider->setValue(0,50);
	color.setRgb(100,100,100);

	//load the heightmap file from project
	if (!hMapBitmap.Load(projectPath+"/engine/heightmap_tmp.png"))
	{
		//if temporary not exist, load original
		if (!hMapBitmap.Load(projectPath+"/engine/heightmap.png"))
		{
			//if file not exist, create a new bitmap
			hMapBitmap.Create(256,256,24);
			//save the heightmap in project (we need a heightmap!)
			hMapBitmap.Save(projectPath+"/engine/heightmap.png",CXIMAGE_FORMAT_PNG);
		}
		//save original
		hMapBitmap.Save(projectPath+"/engine/heightmap_tmp.png",CXIMAGE_FORMAT_PNG);
	}

	//load all water settings from text file
	int r, g, b;
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/water.txt",MiniXML::READ))
	{
		int value;
		char buffer[256];

		//load common water settings
		if (xmlFile.readInteger("reflection",&value))
			reflectionSlider->setValue(0,value);

		if (xmlFile.readInteger("transparency",&value))
			transparencySlider->setValue(0,value);

		if (xmlFile.readString("wavesTexture",buffer, 256))
			wavesTextureLabel->setText(buffer);

		if (xmlFile.readInteger("rColor",&value))
			r = value;
		if (xmlFile.readInteger("gColor",&value))
			g = value;
		if (xmlFile.readInteger("bColor",&value))
			b = value;
		color.setRgb(r, g, b);

		//load settings of sea
		if (xmlFile.readInteger("seaHeight",&value))
			heightSlider->setValue(0,value);

		if (xmlFile.readInteger("seaSpeed",&value))
			speedSlider->setValue(0,value);

		//load settings of rivers
		if (xmlFile.startReadList("sources"))
		{
			int i=0;
			while (xmlFile.startReadListElement(i))
			{	
				//read name
				QString name=tr("Source");
				if (xmlFile.readString("name",buffer,256))
					name = buffer;

				//read position
				QPoint position(0,0);
				if (xmlFile.readInteger("positionX",&value))
					position.setX(value);
				if (xmlFile.readInteger("positionY",&value))
					position.setY(value);

				//read water amounts
				int waterAmountBegin = 5;
				if (xmlFile.readInteger("waterAmountBegin",&value))
					waterAmountBegin = value;
				int waterAmountEnd = 5;
				if (xmlFile.readInteger("waterAmountEnd",&value))
					waterAmountEnd = value;

				//read stream speed
				int streamSpeed = 50;
				if (xmlFile.readInteger("streamSpeed",&value))
					streamSpeed = value;

				addSource(name, position, waterAmountBegin, waterAmountEnd, streamSpeed);
				
				xmlFile.endReadListElement();
				i++;
			}
			xmlFile.endReadList();
		}

		xmlFile.closeFile();
	}

	// set the color button
	fillColorButton(colorButton,color.rgb());

	//set source list to first item
	rebuildSourceList();
	//mark new element in list
	if (sourcesCount > 0) sourceList->setSelected(0,true);
	else sourceSelected();

	//create heightmap class
	QString enginePath = projectPath+"/engine/";
	char *enginePath2 = new char[enginePath.length()+1];
	strcpy(enginePath2,enginePath.latin1());
	pHeightMap = new Heightmap(enginePath2,"heightmap_tmp.png");
	delete [] enginePath2;

	//create preview bitmaps
	seaPreviewBitmap.Create(hMapBitmap.GetWidth(), hMapBitmap.GetHeight(),24);
	seaPreviewBitmap.AlphaCreate();
	riversPreviewBitmap.Create(hMapBitmap.GetWidth(), hMapBitmap.GetHeight(),24);
	riversPreviewBitmap.AlphaCreate();

	//show the heightmap in bitmapNav
	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(hMapBitmap));

	//hide cancelbutton
	cancelButton->hide();
	generateButton->show();

	//set expert mode
	filterExpertFunctions();

	//create first sea preview
	createSeaPreview();

	//now recalculate again
	dontRecalculate = false;

	//create first first river preview
	createRiversPreview();
}

/****************************************************************************
** WaterGUI hideEvent
**
** Is called, when the WaterGUI will be hide.
** Save everything for this panel!
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::hideEvent(QHideEvent *hideEvent)
{
	//save the settings to the text file
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/water.txt",MiniXML::WRITE))
	{
		//save common water setting
		xmlFile.writeInteger("reflection",reflectionSlider->getValue(0));
		xmlFile.writeInteger("transparency",transparencySlider->getValue(0));
		xmlFile.writeString("wavesTexture",wavesTextureLabel->text());
		xmlFile.writeInteger("rColor",color.red());
		xmlFile.writeInteger("gColor",color.green());
		xmlFile.writeInteger("bColor",color.blue());

		//save sea settings
		xmlFile.writeInteger("seaHeight",heightSlider->getValue(0));
		xmlFile.writeInteger("seaSpeed",speedSlider->getValue(0));

		//save rivers settings
		if (xmlFile.startWriteList("sources"))
		{
			for (int i=0;i<sourcesCount;i++)
			{
				if (xmlFile.startWriteListElement(i))
				{
					xmlFile.writeString("name",pSources[i].name);
					xmlFile.writeInteger("positionX",pSources[i].sourceX);
					xmlFile.writeInteger("positionY",pSources[i].sourceY);
					xmlFile.writeInteger("waterAmountBegin",pSources[i].waterAmountBegin);
					xmlFile.writeInteger("waterAmountEnd",pSources[i].waterAmountEnd);
					xmlFile.writeInteger("streamSpeed",pSources[i].streamSpeed);

					xmlFile.endWriteListElement();
				}
			}
			xmlFile.endWriteList();
		}

		xmlFile.closeFile();
	}

	//save common properties of the water in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/water.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("reflection",reflectionSlider->getValue(0));
		xmlFile.writeInteger("transparency",transparencySlider->getValue(0));
		xmlFile.writeInteger("rColor",color.red());
		xmlFile.writeInteger("gColor",color.green());
		xmlFile.writeInteger("bColor",color.blue());

		xmlFile.closeFile();
	}

	//save the properties of the sea in engine-directory
	if (xmlFile.openFile(projectPath+"/engine/sea.txt",MiniXML::WRITE))
	{
		xmlFile.writeInteger("height",heightSlider->getValue(0));
		xmlFile.writeInteger("speed",speedSlider->getValue(0));

		xmlFile.closeFile();
	}

	//ignore hide events with minimizing
	if (!topParent->isMinimized())
	{
		//delete heightmap-class
		SAFE_DELETE(pHeightMap);

		//delete sources
		SAFE_DELETE_ARRAY(pSources);
		sourcesCount = 0;
	}
}


/****************************************************************************
** WaterGUI setProjectPath
**
** set the current project
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::setProjectPath(QString projectPathSet)
{
	projectPath = projectPathSet;
}

/****************************************************************************
** WaterGUI seaValuesChanged
**
** Is called, when a value of the sea changed
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::seaValuesChanged()
{
	//generate the distribution
	if (!dontRecalculate)
		createSeaPreview();
}

/****************************************************************************
** WaterGUI riversValuesChanged
**
** Is called, when a value of the rivers changed
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::riversValuesChanged()
{
	//retrieve active river
	int currentSource = sourceList->currentItem();
	if (currentSource < 0)
		return;
	if (currentSource >= sourcesCount)
		return;

	//save settings from sliders in intern structure
	pSources[currentSource].waterAmountEnd = waterAmountSlider->getValue(0);
	pSources[currentSource].waterAmountBegin = waterAmountSlider->getValue(1);
	pSources[currentSource].streamSpeed = streamSpeedSlider->getValue(0);
}

/****************************************************************************
** WaterGUI createCurrentBitmap
**
** create the bitmap and put it in bitmapNav
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::createCurrentBitmap()
{
	//copy the heightmap as nice background
	CxImage currentBitmap(hMapBitmap);
	currentBitmap.IncreaseBpp(24);

	//add the distributions
	for(DWORD y=0;y<currentBitmap.GetHeight();y++)
		for (DWORD x=0;x<currentBitmap.GetWidth();x++)
	{
		//get the color on the background
		RGBQUAD newColor = currentBitmap.GetPixelColor(x,y);
			
		//get the color on the sea distribution
		RGBQUAD distribution = seaPreviewBitmap.GetPixelColor(x,y);
		
		//calculate factor
		float blendFactor = float(distribution.rgbReserved)/255.0f;
		float blendFactorInv = 1.0f-blendFactor;
		
		//calculate new color
		newColor.rgbRed = blendFactor*distribution.rgbRed+blendFactorInv*newColor.rgbRed;
		newColor.rgbGreen = blendFactor*distribution.rgbGreen+blendFactorInv*newColor.rgbGreen;
		newColor.rgbBlue = blendFactor*distribution.rgbBlue+blendFactorInv*newColor.rgbBlue;

		//get the color on the river distribution
		distribution = riversPreviewBitmap.GetPixelColor(x,y);

		//calculate factor
		blendFactor = float(distribution.rgbReserved)/255.0f;
		blendFactorInv = 1.0f-blendFactor;
		
		//calculate new color
		newColor.rgbRed = blendFactor*distribution.rgbRed+blendFactorInv*newColor.rgbRed;
		newColor.rgbGreen = blendFactor*distribution.rgbGreen+blendFactorInv*newColor.rgbGreen;
		newColor.rgbBlue = blendFactor*distribution.rgbBlue+blendFactorInv*newColor.rgbBlue;
		
		//set new color
		currentBitmap.SetPixelColor(x,y,newColor);
	}


	bitmapNavContainer->setBitmap(GUIHelpers::convertCxImageToQImage(currentBitmap));
}

/****************************************************************************
** WaterGUI createSeaPreview
**
** create sea preview
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::createSeaPreview()
{
	//delete old timer
	if (generatingSeaPreviewTimer)
		killTimer(generatingSeaPreviewTimerID);

	//disable tabs
	enableTabs(false);

	seaGenerator.generatePreview(pHeightMap,&seaPreviewBitmap,
		heightSlider->getValue(0),
		transparencySlider->getValue(0),
		color.pixel());

	generatingSeaPreviewTimerID = startTimer(100);
	generatingSeaPreviewTimer = true;
}

/****************************************************************************
** WaterGUI createRiversPreview
**
** create rivers preview
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::createRiversPreview()
{
	//delete old timer
	if (generatingRiversPreviewTimer)
		killTimer(generatingRiversPreviewTimer);

	//disable tabs
	enableTabs(false);

	//retrieve active river
	int currentSource = sourceList->currentItem();
	if (currentSource < 0)
		currentSource = 0;

	riversGenerator.generatePreview(pHeightMap, &riversPreviewBitmap,
		pSources, sourcesCount, currentSource);

	generatingRiversPreviewTimer = true;
	generatingRiversPreviewTimerID = startTimer(100);
}

/****************************************************************************
** WaterGUI timerEvent
**
** Is called, at timer event
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::timerEvent(QTimerEvent *timerEvent)
{
	//if sea preview timer
	if (timerEvent->timerId() == generatingSeaPreviewTimerID)
	{
		//generating done?
		if (!seaGenerator.running())
		{
			//delete timer
			killTimer(generatingSeaPreviewTimerID);
			generatingSeaPreviewTimerID = -1;
			generatingSeaPreviewTimer = false;
			//create the current bitmap for bitmapNav
			createCurrentBitmap();

			//enable tabs
			enableTabs(true);
		}
	}
	//if rivers preview timer
	else if (timerEvent->timerId() == generatingRiversPreviewTimerID)
	{
		//generating done?
		if (!riversGenerator.running())
		{
			//delete timer
			killTimer(generatingRiversPreviewTimerID);
			generatingRiversPreviewTimerID = -1;
			generatingRiversPreviewTimer = false;
			//create the current bitmap for bitmapNav
			createCurrentBitmap();

			//enable tabs
			enableTabs(true);

			//workaround! DONT DELETE!
			sourceList->hide();
			sourceList->show();
		}
	}
	//if real river generation
	else if (timerEvent->timerId() == generatingRiversTimerID)
	{
		//update the image
		createCurrentBitmap();

		//generating done?
		if (!riversGenerator.running())
		{
			//use cancelClicked for doing the work
			cancelClicked();
		}
	}

}

/****************************************************************************
** WaterGUI colorClicked
**
** called when the color button is clicked -> show color dialog
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::colorClicked()
{
	QColor newColor = QColorDialog::getColor(color,this,tr("ScapeMaker"));
	if (newColor.isValid())
	{
		color = newColor;
		fillColorButton(colorButton,color.rgb());
		seaValuesChanged();
	}
}

/****************************************************************************
** WaterGUI importClicked
**
** Is called, when the import button in waves group is clicked
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::importClicked()
{
	//show the file-dialog
	QString fileName = QFileDialog::getOpenFileName("./wavetextures", "Normalmaps (*.dds)", this);

	if (!fileName.isNull())
    {
		//copy file to engine
		//create both files
		QFile source(fileName);
		QFile destination(projectPath+"/engine/waves.dds");
		//copy from source to destination
		GUIHelpers::copyFile(source, destination);

		//update wave texture label
		QFileInfo fileInfo(source);
		wavesTextureLabel->setText(fileInfo.baseName());
	}
}

/****************************************************************************
** WaterGUI resetClicked
**
** Is called, when the reset button in waves group is clicked
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::resetClicked()
{
	//delete waves file
	QFileInfo fileInfo(projectPath+"/engine/waves.dds");

	if (fileInfo.isFile())
	{
		QDir path = fileInfo.dir();
		path.remove(fileInfo.fileName());
	}

	//update waves texture label
	wavesTextureLabel->setText(tr("-default-"));
}

/****************************************************************************
** WaterGUI exportMaskClicked
**
** Is called, when the export mask button clicked
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::exportMaskClicked()
{
	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//create water mask
	CxImage waterMask(hMapBitmap.GetWidth(),hMapBitmap.GetHeight(),24);
	waterMask.Clear(0xFF);

	//load rivers
	RiversMap riversMap(waterMask.GetWidth());
	MiniXML xmlFile;
	if (xmlFile.openFile(projectPath+"/engine/rivers.txt", MiniXML::READ))
	{
		if (xmlFile.startReadList("rivers"))
		{
			int no=0;
			while (xmlFile.startReadListElement(no))
			{
				int value;
				int x = 0;
				int y = 0;
				bool bValue;
				bool border = false;

				if (xmlFile.readInteger("x", &value))
					x = value;
				if (xmlFile.readInteger("y", &value))
					y = value;
				if (xmlFile.readBoolean("border", &bValue))
					border = bValue;

				//get element
				RiversMap::OneWaterElement *pElement;
				if (riversMap.getElement(x,y,&pElement))
				{
					pElement->used = true;
					pElement->border = bValue;
				}

				xmlFile.endReadListElement();
				no++;
			}
			xmlFile.endReadList();
		}
		xmlFile.closeFile();
	}
	
	//set pixels of sea and rivers
	int seaHeight = heightSlider->getValue(0);
	for (int y=0;y<waterMask.GetHeight();y++)
		for (int x=0;x<waterMask.GetWidth();x++)
	{
		//find minimum terrain height around this mask pixel
		if ((pHeightMap->getHeightInMeters(x,y) < seaHeight) ||
			(pHeightMap->getHeightInMeters(x+1,y) < seaHeight) ||
			(pHeightMap->getHeightInMeters(x,y+1) < seaHeight) ||
			(pHeightMap->getHeightInMeters(x+1,y+1) < seaHeight))
		{
			 waterMask.SetPixelColor(x,y,0);
		}
		//river?
		else if ((riversMap.isUsed(x,y) && !riversMap.isBorder(x,y)) ||
		         (riversMap.isUsed(x+1,y) && !riversMap.isBorder(x+1,y)) ||
		         (riversMap.isUsed(x,y+1) && !riversMap.isBorder(x,y+1)) ||
		         (riversMap.isUsed(x+1,y+1) && !riversMap.isBorder(x+1,y+1)))
		{
			waterMask.SetPixelColor(x,y,0);
		}
	}

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();	

	//save it
	GUIHelpers::showSaveImageDialog("watermask",waterMask,this);
}

/****************************************************************************
** WaterGUI fillColorButton
**
** fill a color button with the specified color
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::fillColorButton(QButton *button, QRgb color)
{
	QPixmap backBuffer(button->size());
	QPainter painter(&backBuffer);

	//draw
	painter.setBrush(color);
	painter.fillRect(button->rect(),painter.brush());

	//set backbuffer
	button->setPixmap(backBuffer);
}

/****************************************************************************
** WaterGUI addSource
**
** add a source to source list
**  
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::addSource(QString name, QPoint position, int waterAmountBegin, int waterAmountEnd, int streamSpeed)
{
	//check if a good position
	if ((position.x() < 0) ||
		(position.x() >= hMapBitmap.GetWidth()-1) ||
		(position.y() < 0) ||
		(position.y() >= hMapBitmap.GetHeight()-1))
		return;

	//add to river list
	//make a new list one bigger
	OneSource *pTempList = new OneSource[sourcesCount+1];
	//copy all elements
	for (int i=0;i<sourcesCount;i++)
		pTempList[i] = pSources[i];
	//add new element
	pTempList[sourcesCount].name = name;
	pTempList[sourcesCount].sourceX = position.x();
	pTempList[sourcesCount].sourceY = position.y();
	pTempList[sourcesCount].waterAmountBegin = waterAmountBegin;
	pTempList[sourcesCount].waterAmountEnd = waterAmountEnd;
	pTempList[sourcesCount].streamSpeed = streamSpeed;
	//delete old list
	SAFE_DELETE_ARRAY(pSources);
	//copy pointer
	pSources = pTempList;
	//add riversCount
	sourcesCount++;
}

/****************************************************************************
** WaterGUI newSource
**
** Is called, the user clicked a position with pen
**  
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::newSource(QPoint position)
{
	//transform position (y flip)
	position.setY(hMapBitmap.GetHeight()-1-position.y());

	//only one source per position
	for (int i=0;i<sourcesCount;i++)
		if ((pSources[i].sourceX == position.x()) &&
			(pSources[i].sourceY == position.y()))
			return;

	//add source to source list
	addSource(tr("Source"),position);

	//rebuild list
	rebuildSourceList();

	//mark new element in list
	sourceList->setSelected(sourcesCount-1,true);

	//recalculate river preview
	createRiversPreview();
}

/****************************************************************************
** WaterGUI deleteSource
**
** Is called, the user clicked a position with rubber
**  
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::deleteSource(QPoint position)
{
	//transform position (y flip)
	position.setY(hMapBitmap.GetHeight()-1-position.y());

	//find nearest river source (because user cant click exactly one pixel)
	float bestDistance = (float)INT_MAX;
	int bestPosition = -1;
	for (int i=0; i<sourcesCount; i++)
	{
		float diffX = pSources[i].sourceX - position.x();
		float diffY = pSources[i].sourceY - position.y();
		float distance = sqrtf(diffX*diffX+diffY*diffY);
		if (distance < bestDistance)
		{
			bestDistance = distance;
			bestPosition = i;
		}
	}
	//no position found? -> do nothing
	if (bestPosition < 0)
		return;

	//position to far away
	if (bestDistance > 10.0f)
		return;

	//create new array one smaller
	if (sourcesCount > 1)
	{
		OneSource *pTempList = new OneSource[sourcesCount-1];
		//copy all elements, except the deleted
		for (int i=0, j=0;i<sourcesCount;i++)
		{
			if (i != bestPosition)
			{
				pTempList[j] = pSources[i];
				j++;
			}
		}
		//delete old list
		SAFE_DELETE_ARRAY(pSources);
		//copy pointer
		pSources = pTempList;
	}
	else pSources = NULL;

	//decrement sources
	sourcesCount--;

	//rebuild list
	rebuildSourceList();

	//mark first element in list
	if (sourcesCount > 0)
		sourceList->setSelected(0,true);
	else
	{
		//no rivers... hide sliders
		waterAmountSlider->hide();
		streamSpeedSlider->hide();

		//delete rivers in txt
		MiniXML xmlFile;
		if (xmlFile.openFile(projectPath+"/engine/rivers.txt",MiniXML::WRITE))
		{
			if (xmlFile.startWriteList("rivers"))
				xmlFile.endWriteList();
			xmlFile.closeFile();
		}

	}

	//recalculate river preview
	createRiversPreview();
}

/****************************************************************************
** WaterGUI removeClicked
**
** Is called, the user clicked a the remove button to erase a source
**  
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::removeClicked()
{
	//nothing selected?
	int currentSource = sourceList->currentItem();
	if (currentSource < 0)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select a source in the list first!"));
		return;
	}
	
	//call deleteSource to remove source
	deleteSource(QPoint(pSources[currentSource].sourceX,hMapBitmap.GetHeight()-1-pSources[currentSource].sourceY));
}

/****************************************************************************
** WaterGUI renameClicked
**
** called when the rename button is clicked -> rename a source
**  
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::renameClicked()
{
	int index = sourceList->currentItem();

	//clicked an item?
	if (index == -1)
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("Please select a source in the list first!"));
		return;
	}

	//get the selected text
	QString toRename = sourceList->currentText();

	//ask the user for new name
	bool ok = FALSE;
	QString newName = QInputDialog::getText(tr("ScapeMaker"),tr("New name of source?"), toRename, &ok, this );

	//the user cancel the dialog
	if (!ok) return;

	//no name written?
	if (newName.isNull() || newName.isEmpty())
	{
		QMessageBox::information(this, tr("ScapeMaker"),tr("You must enter a name!"));
		return;
	}

	//rename name in list
	sourceList->changeItem(newName,index);

	//rename object
	pSources[index].name = newName;
}

/****************************************************************************
** WaterGUI sourceSelected
**
** an item in source list clicked
**
** Author: Dirk Plate
****************************************************************************/
void WaterGUI::sourceSelected()
{
	//nothing selected?
	int currentSource = sourceList->currentItem();
	if (currentSource < 0)
	{
		//hide all sliders
		waterAmountSlider->hide();
		streamSpeedSlider->hide();
	}
	else
	{
		//and set to right values
		int newWaterAmountEnd = pSources[currentSource].waterAmountEnd;
		int newWaterAmountBegin = pSources[currentSource].waterAmountBegin;
		int newStreamSpeed = pSources[currentSource].streamSpeed;
		waterAmountSlider->setValue(0,newWaterAmountEnd);
		waterAmountSlider->setValue(1,newWaterAmountBegin);
		streamSpeedSlider->setValue(0,newStreamSpeed);

		//show all sliders
		waterAmountSlider->show();
		streamSpeedSlider->show();
	}

	//recalculate river preview
	createRiversPreview();
}

/****************************************************************************
** WaterGUI generateClicked
**
** generates the rivers
**
** Author: Dirk Plate
****************************************************************************/
void WaterGUI::generateClicked()
{
	riversGenerator.generate(
		pHeightMap,
		&riversPreviewBitmap,
		projectPath+"/engine/",
		pSources,
		sourcesCount);

	//hide the generatebutton and show the cancelbutton
	generateButton->hide();
	cancelButton->show();

	//disable all tabs except the own
	enableTabs(false);

	colorLabel->setEnabled(false);
	colorButton->setEnabled(false);
	exportButton->setEnabled(false);
	reflectionSlider->setEnabled(false);
	transparencySlider->setEnabled(false);
	wavesGroup->setEnabled(false);
	seaGroup->setEnabled(false);
	sourceList->setEnabled(false);
	removeButton->setEnabled(false);
	renameButton->setEnabled(false);
	waterAmountSlider->setEnabled(false);
	streamSpeedSlider->setEnabled(false);
	bitmapNavContainer->setPenButtonEnable(false);
	bitmapNavContainer->setRubberButtonEnable(false);

	//show other help text
	penHelpLabel->hide();
	generateHelpLabel->show();

	//change the mouse-cursor to waiting
	QApplication::setOverrideCursor(Qt::waitCursor);

	//start timer for updating the image
	generatingRiversTimerID = startTimer(500);
}

/****************************************************************************
** WaterGUI cancelClicked
**
** stop generating rivers
**
** Author: Dirk Plate
****************************************************************************/
void WaterGUI::cancelClicked()
{
	//stop the generating-thread
	riversGenerator.cancel();

	//give the generator time to stop
	while(riversGenerator.running())
	{
		Sleep(100);
	}

	//delete timer
	killTimer(generatingRiversTimerID);
	generatingRiversTimerID = -1;

	//update the image
	createCurrentBitmap();

	//save new version of heightmap
	QString filePath = projectPath+"/engine/heightmap.png";
	char *filePath2 = new char[filePath.length()+1];
	strcpy(filePath2,filePath.latin1());
	pHeightMap->save(filePath2);
	delete [] filePath2;

	//hide the cancelbutton and show the generatebutton
	cancelButton->hide();
	generateButton->show();

	//enable all tabs except the own
	enableTabs(true);

	colorLabel->setEnabled(true);
	colorButton->setEnabled(true);
	exportButton->setEnabled(true);
	reflectionSlider->setEnabled(true);
	transparencySlider->setEnabled(true);
	wavesGroup->setEnabled(true);
	seaGroup->setEnabled(true);	
	sourceList->setEnabled(true);
	removeButton->setEnabled(true);
	renameButton->setEnabled(true);
	waterAmountSlider->setEnabled(true);
	streamSpeedSlider->setEnabled(true);
	bitmapNavContainer->setPenButtonEnable(true);
	bitmapNavContainer->setRubberButtonEnable(true);

	//show other help text
	penHelpLabel->show();
	generateHelpLabel->hide();

	//restore old mouse-cursor
	QApplication::restoreOverrideCursor();	
}

/****************************************************************************
** WaterGUI rebuildSourceList
**
** rebuild the river list
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::rebuildSourceList()
{
	//clear old list
	sourceList->clear();

	//put all rivers in list
	for (int i=0;i<sourcesCount;i++)
	{
		sourceList->insertItem(pSources[i].name);
	}
}

/****************************************************************************
** WaterGUI enableTabs
**
** en or disable the tabs
**
** Author: Dirk Plate
****************************************************************************/

void WaterGUI::enableTabs(bool enable)
{
	topParent->tabContainer->setTabEnabled(topParent->topografie, enable);
	topParent->tabContainer->setTabEnabled(topParent->texture, enable);
	topParent->tabContainer->setTabEnabled(topParent->objects, enable);
	topParent->tabContainer->setTabEnabled(topParent->clouds, enable);
	topParent->tabContainer->setTabEnabled(topParent->enviroment, enable);
	topParent->tabContainer->setTabEnabled(topParent->preview, enable);
	topParent->menuBar->setEnabled(enable);
}

/****************************************************************************
** WaterGUI filterExpertFunctions
**
** Hides or show all sliders for expert or beginner mode
**  
** Author: Dirk Plate
****************************************************************************/
void WaterGUI::filterExpertFunctions()
{
	//load settings from file
	MiniXML xmlFile;
	bool loadedExpert = false;
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		bool bValue;

		//load expert mode
		if (xmlFile.readBoolean("expert", &bValue))
			loadedExpert = bValue;
			
		//close xml file
		xmlFile.closeFile();
	}	

	//set visibility for all functions
	if (!loadedExpert)
	{
		exportButton->hide();
		wavesGroup->hide();
		riversGroup->hide();
		bitmapNavContainer->setPenButtonVisible(false);
		bitmapNavContainer->setRubberButtonVisible(false);
	}
	else
	{
		exportButton->show();
		wavesGroup->show();
		riversGroup->show();
		bitmapNavContainer->setPenButtonVisible(true);
		bitmapNavContainer->setRubberButtonVisible(true);
	}
}