/****************************************************************************
** WaterGUI
**
** the water-tab window
**
** Author: Dirk Plate
****************************************************************************/

#pragma warning(disable:4786)

#include "waterguibase.h"
#include "../common/coolslider.h"
#include "../scapemakerdialog.h"
#include "../../common/minixml.h"
#include "../common/bitmapnav.h"
#include "qpushbutton.h"
#include "seagen.h"
#include "riversgen.h"
#include "../../engine/terrain/heightmap.h"
#include "qtabwidget.h"
#include "qgroupbox.h"
#include "qcolordialog.h"
#include "qfiledialog.h"
#include "../common/guihelpers.h"
#include "qlistbox.h"

class WaterGUI : public WaterGUIBase
{
	Q_OBJECT

public:
	WaterGUI(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	void setProjectPath(QString projectPathSet);

public slots:
	virtual void seaValuesChanged();
	virtual void riversValuesChanged();
	virtual void colorClicked();
	virtual void importClicked();
	virtual void removeClicked();
	virtual void renameClicked();
	virtual void resetClicked();
	virtual void exportMaskClicked();
	virtual void newSource(QPoint);
	virtual void deleteSource(QPoint);
	virtual void generateClicked();
	virtual void cancelClicked();
	virtual void sourceSelected();

protected:
	void showEvent(QShowEvent *showEvent);
	void hideEvent(QHideEvent *hideEvent);
	void timerEvent(QTimerEvent *timerEvent);

private:
	void filterExpertFunctions();
	void createCurrentBitmap();
	void createSeaPreview();
	void createRiversPreview();
	void fillColorButton(QButton *button, QRgb color);//fill a color button with the specified color
	void enableTabs(bool enable);	//en or disable the tabs
	void rebuildSourceList();		//rebuild current rivers list
	void addSource(QString name, QPoint position, int waterAmountBegin = 40, int waterAmountEnd = 20, int streamSpeed = 50);

	QString projectPath;			//the path to the project-directory
	ScapeMakerDialog *topParent;	//direct pointer to main window

	CxImage hMapBitmap;				//the heightmap
	CxImage seaPreviewBitmap;		//the preview of the sea with current settings
	CxImage riversPreviewBitmap;	//the preview of the rivers with current settings

	bool dontRecalculate;			//is this flag set, the shadow preview wont recalculate
	SeaGen seaGenerator;			//the sea-generator
	RiversGen riversGenerator;		//the rivers-generator
	Heightmap *pHeightMap;			//the heightmap class

	bool generatingSeaPreviewTimer;	//sea preview timer on or not
	int generatingSeaPreviewTimerID;//the id of the timer while generating the sea preview

	bool generatingRiversPreviewTimer;	//rivers preview timer on or not
	int generatingRiversPreviewTimerID;	//the id of the timer while generating the rivers preview

	int generatingRiversTimerID;		//the id of the timer while generating the rivers

	QColor color;					// color for the sea

	OneSource *pSources;			//a array with all set source
	int sourcesCount;				//count of sources
};
