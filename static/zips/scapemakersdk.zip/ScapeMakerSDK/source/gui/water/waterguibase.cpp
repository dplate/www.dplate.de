/****************************************************************************
** Form implementation generated from reading ui file '.\source\gui\water\waterguibase.ui'
**
** Created: Sun Feb 13 15:03:28 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "waterguibase.h"

#include <qgroupbox.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include "../common/bitmapnav.h"
#include "../common/coolslider.h"
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

static const char* const image0_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
".................",
".................",
".................",
".................",
".................",
".#############...",
".#############...",
".#############...",
".................",
".................",
".................",
".................",
".................",
".................",
".................",
"................."};

static const char* const image1_data[] = { 
"17 17 2 1",
". c None",
"# c #000000",
".................",
"..#########......",
"..##########.....",
"..###########....",
"..####...####....",
"..####...####....",
"..###########....",
"..##########.....",
"..#########......",
"..####..####.....",
"..####..####.....",
"..####...####....",
"..####...####....",
"..####...#####...",
".................",
".................",
"................."};


/* 
 *  Constructs a WaterGUIBase which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 */
WaterGUIBase::WaterGUIBase( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    QPixmap image1( ( const char** ) image1_data );
    if ( !name )
	setName( "WaterGUIBase" );
    resize( 484, 477 ); 
    setCaption( tr( "WaterGUI" ) );
    QWhatsThis::add(  this, tr( "Here, all settings for the sea are defined." ) );

    seaGroup = new QGroupBox( this, "seaGroup" );
    seaGroup->setGeometry( QRect( 0, 265, 200, 190 ) ); 
    seaGroup->setTitle( tr( "Sea" ) );

    heightSlider = new CoolSlider( seaGroup, "heightSlider" );
    heightSlider->setGeometry( QRect( 10, 100, 180, 80 ) ); 
    QWhatsThis::add(  heightSlider, tr( "Sets the height of the sea level. 0 deactivates the sea." ) );

    speedSlider = new CoolSlider( seaGroup, "speedSlider" );
    speedSlider->setGeometry( QRect( 10, 15, 180, 80 ) ); 
    QWhatsThis::add(  speedSlider, tr( "Defines the speed of the waves." ) );

    wavesGroup = new QGroupBox( this, "wavesGroup" );
    wavesGroup->setGeometry( QRect( 0, 185, 200, 75 ) ); 
    wavesGroup->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, wavesGroup->sizePolicy().hasHeightForWidth() ) );
    wavesGroup->setTitle( tr( "Waves" ) );
    wavesGroup->setAlignment( int( QGroupBox::AlignLeft ) );

    wavesTextureLabel = new QLabel( wavesGroup, "wavesTextureLabel" );
    wavesTextureLabel->setGeometry( QRect( 10, 20, 90, 16 ) ); 
    wavesTextureLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)1, wavesTextureLabel->sizePolicy().hasHeightForWidth() ) );
    wavesTextureLabel->setText( tr( "-default-" ) );
    wavesTextureLabel->setScaledContents( FALSE );
    wavesTextureLabel->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    importButton = new QPushButton( wavesGroup, "importButton" );
    importButton->setGeometry( QRect( 110, 15, 80, 23 ) ); 
    importButton->setText( tr( "Import" ) );
    importButton->setFlat( FALSE );
    QToolTip::add(  importButton, tr( "Import a waves texture" ) );
    QWhatsThis::add(  importButton, tr( "Sets another wave texture. A wave texture is not a normal textur, but a so called normal map. A normal map does not contain information about colour, but about the structure of the surface." ) );

    resetButton = new QPushButton( wavesGroup, "resetButton" );
    resetButton->setGeometry( QRect( 110, 40, 80, 23 ) ); 
    resetButton->setText( tr( "Reset" ) );
    resetButton->setFlat( FALSE );
    QToolTip::add(  resetButton, tr( "Reset to default waves texture" ) );
    QWhatsThis::add(  resetButton, tr( "Sets the default wave texture." ) );

    riversGroup = new QGroupBox( this, "riversGroup" );
    riversGroup->setGeometry( QRect( 210, 265, 281, 190 ) ); 
    riversGroup->setTitle( tr( "Rivers" ) );

    cancelButton = new QPushButton( riversGroup, "cancelButton" );
    cancelButton->setGeometry( QRect( 10, 160, 80, 23 ) ); 
    cancelButton->setText( tr( "Stop" ) );
    cancelButton->setFlat( FALSE );
    QToolTip::add(  cancelButton, tr( "Stop generating rivers" ) );

    penHelpLabel = new QLabel( riversGroup, "penHelpLabel" );
    penHelpLabel->setEnabled( TRUE );
    penHelpLabel->setGeometry( QRect( 101, 155, 175, 31 ) ); 
    penHelpLabel->setText( tr( "Use pen tool to set new sources." ) );
    penHelpLabel->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );

    generateHelpLabel = new QLabel( riversGroup, "generateHelpLabel" );
    generateHelpLabel->setEnabled( TRUE );
    generateHelpLabel->setGeometry( QRect( 100, 155, 175, 31 ) ); 
    generateHelpLabel->setText( tr( "Stop generation, if results suit your imagination." ) );
    generateHelpLabel->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter | QLabel::AlignLeft ) );

    sourceList = new QListBox( riversGroup, "sourceList" );
    sourceList->setGeometry( QRect( 10, 20, 80, 130 ) ); 
    QWhatsThis::add(  sourceList, tr( "List of all set sources." ) );

    removeButton = new QToolButton( riversGroup, "removeButton" );
    removeButton->setGeometry( QRect( 95, 20, 20, 20 ) ); 
    removeButton->setText( tr( "" ) );
    removeButton->setPixmap( image0 );
    QToolTip::add(  removeButton, tr( "Remove a source" ) );
    QWhatsThis::add(  removeButton, tr( "Removes the selected source from the list." ) );

    renameButton = new QToolButton( riversGroup, "renameButton" );
    renameButton->setGeometry( QRect( 95, 45, 20, 20 ) ); 
    renameButton->setText( tr( "" ) );
    renameButton->setPixmap( image1 );
    QToolTip::add(  renameButton, tr( "Rename a source" ) );
    QWhatsThis::add(  renameButton, tr( "Sets a new name for the current selected source." ) );

    waterAmountSlider = new CoolSlider( riversGroup, "waterAmountSlider" );
    waterAmountSlider->setGeometry( QRect( 125, 15, 150, 65 ) ); 
    QWhatsThis::add(  waterAmountSlider, tr( "Sets the amount of water the current selected source delivers. The right slider sets the amount of water at beginning of generation. Later it goes to the amount of the left slider." ) );

    streamSpeedSlider = new CoolSlider( riversGroup, "streamSpeedSlider" );
    streamSpeedSlider->setGeometry( QRect( 125, 85, 150, 65 ) ); 
    QWhatsThis::add(  streamSpeedSlider, tr( "Sets the amount of stream for the current selected source. A higher value will create more steamy and white rivers." ) );

    generateButton = new QPushButton( riversGroup, "generateButton" );
    generateButton->setGeometry( QRect( 10, 160, 80, 23 ) ); 
    generateButton->setText( tr( "Generate" ) );
    generateButton->setFlat( FALSE );
    QToolTip::add(  generateButton, tr( "Generate rivers" ) );
    QWhatsThis::add(  generateButton, tr( "Starts the generation of rivers. This generation has no end, so you'll have to stop it manually." ) );

    colorLabel = new QLabel( this, "colorLabel" );
    colorLabel->setGeometry( QRect( 5, 10, 35, 16 ) ); 
    colorLabel->setText( tr( "Color:" ) );
    colorLabel->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    reflectionSlider = new CoolSlider( this, "reflectionSlider" );
    reflectionSlider->setGeometry( QRect( 5, 110, 195, 70 ) ); 
    QWhatsThis::add(  reflectionSlider, tr( "Defines the reflectivity of the water in %." ) );

    transparencySlider = new CoolSlider( this, "transparencySlider" );
    transparencySlider->setGeometry( QRect( 5, 35, 195, 70 ) ); 
    QWhatsThis::add(  transparencySlider, tr( "Sets the transparency of the sea, that is up to which deepness the ground gleams through." ) );

    colorButton = new QPushButton( this, "colorButton" );
    colorButton->setGeometry( QRect( 40, 5, 60, 25 ) ); 
    QPalette pal;
    QColorGroup cg;
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, QColor( 243, 243, 243) );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setActive( cg );
    cg.setColor( QColorGroup::Foreground, black );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, black );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setInactive( cg );
    cg.setColor( QColorGroup::Foreground, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Button, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Light, white );
    cg.setColor( QColorGroup::Midlight, white );
    cg.setColor( QColorGroup::Dark, QColor( 115, 115, 115) );
    cg.setColor( QColorGroup::Mid, QColor( 154, 154, 154) );
    cg.setColor( QColorGroup::Text, black );
    cg.setColor( QColorGroup::BrightText, QColor( 222, 222, 222) );
    cg.setColor( QColorGroup::ButtonText, QColor( 128, 128, 128) );
    cg.setColor( QColorGroup::Base, white );
    cg.setColor( QColorGroup::Background, QColor( 231, 231, 231) );
    cg.setColor( QColorGroup::Shadow, black );
    cg.setColor( QColorGroup::Highlight, QColor( 76, 107, 156) );
    cg.setColor( QColorGroup::HighlightedText, black );
    pal.setDisabled( cg );
    colorButton->setPalette( pal );
    colorButton->setText( tr( "" ) );
    colorButton->setFlat( TRUE );
    QToolTip::add(  colorButton, tr( "Color of water" ) );
    QWhatsThis::add(  colorButton, tr( "Shows the waters color. Click on the color to change it." ) );

    exportButton = new QPushButton( this, "exportButton" );
    exportButton->setGeometry( QRect( 105, 5, 95, 23 ) ); 
    exportButton->setText( tr( "Export mask" ) );
    QToolTip::add(  exportButton, tr( "Export a mask of water" ) );
    QWhatsThis::add(  exportButton, tr( "Exports a mask of all water elements. Can be used to mask out terrain objects." ) );

    bitmapNavContainer = new BitmapNav( this, "bitmapNavContainer" );
    bitmapNavContainer->setGeometry( QRect( 210, 0, 290, 260 ) ); 
    QWhatsThis::add(  bitmapNavContainer, tr( "Shows a preview of the distribution of water." ) );

    // signals and slots connections
    connect( colorButton, SIGNAL( clicked() ), this, SLOT( colorClicked() ) );
    connect( transparencySlider, SIGNAL( valuesChanged() ), this, SLOT( seaValuesChanged() ) );
    connect( speedSlider, SIGNAL( valuesChanged() ), this, SLOT( seaValuesChanged() ) );
    connect( importButton, SIGNAL( clicked() ), this, SLOT( importClicked() ) );
    connect( resetButton, SIGNAL( clicked() ), this, SLOT( resetClicked() ) );
    connect( heightSlider, SIGNAL( valuesChanged() ), this, SLOT( seaValuesChanged() ) );
    connect( generateButton, SIGNAL( clicked() ), this, SLOT( generateClicked() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelClicked() ) );
    connect( sourceList, SIGNAL( selectionChanged() ), this, SLOT( sourceSelected() ) );
    connect( waterAmountSlider, SIGNAL( valuesChanged() ), this, SLOT( riversValuesChanged() ) );
    connect( streamSpeedSlider, SIGNAL( valuesChanged() ), this, SLOT( riversValuesChanged() ) );
    connect( removeButton, SIGNAL( clicked() ), this, SLOT( removeClicked() ) );
    connect( renameButton, SIGNAL( clicked() ), this, SLOT( renameClicked() ) );
    connect( exportButton, SIGNAL( clicked() ), this, SLOT( exportMaskClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
WaterGUIBase::~WaterGUIBase()
{
    // no need to delete child widgets, Qt does it all for us
}

void WaterGUIBase::cancelClicked()
{
    qWarning( "WaterGUIBase::cancelClicked(): Not implemented yet!" );
}

void WaterGUIBase::colorClicked()
{
    qWarning( "WaterGUIBase::colorClicked(): Not implemented yet!" );
}

void WaterGUIBase::generateClicked()
{
    qWarning( "WaterGUIBase::generateClicked(): Not implemented yet!" );
}

void WaterGUIBase::importClicked()
{
    qWarning( "WaterGUIBase::importClicked(): Not implemented yet!" );
}

void WaterGUIBase::exportMaskClicked()
{
    qWarning( "WaterGUIBase::exportMaskClicked(): Not implemented yet!" );
}

void WaterGUIBase::removeClicked()
{
    qWarning( "WaterGUIBase::removeClicked(): Not implemented yet!" );
}

void WaterGUIBase::renameClicked()
{
    qWarning( "WaterGUIBase::renameClicked(): Not implemented yet!" );
}

void WaterGUIBase::resetClicked()
{
    qWarning( "WaterGUIBase::resetClicked(): Not implemented yet!" );
}

void WaterGUIBase::riversValuesChanged()
{
    qWarning( "WaterGUIBase::riversValuesChanged(): Not implemented yet!" );
}

void WaterGUIBase::seaValuesChanged()
{
    qWarning( "WaterGUIBase::seaValuesChanged(): Not implemented yet!" );
}

void WaterGUIBase::sourceSelected()
{
    qWarning( "WaterGUIBase::sourceSelected(): Not implemented yet!" );
}

