/****************************************************************************
** Form interface generated from reading ui file '.\source\gui\water\waterguibase.ui'
**
** Created: Sun Feb 13 15:03:28 2005
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef WATERGUIBASE_H
#define WATERGUIBASE_H

#include <qvariant.h>
#include <qwidget.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class BitmapNav;
class CoolSlider;
class QGroupBox;
class QLabel;
class QListBox;
class QListBoxItem;
class QPushButton;
class QToolButton;

class WaterGUIBase : public QWidget
{ 
    Q_OBJECT

public:
    WaterGUIBase( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~WaterGUIBase();

    QGroupBox* seaGroup;
    CoolSlider* heightSlider;
    CoolSlider* speedSlider;
    QGroupBox* wavesGroup;
    QLabel* wavesTextureLabel;
    QPushButton* importButton;
    QPushButton* resetButton;
    QGroupBox* riversGroup;
    QPushButton* cancelButton;
    QLabel* penHelpLabel;
    QLabel* generateHelpLabel;
    QListBox* sourceList;
    QToolButton* removeButton;
    QToolButton* renameButton;
    CoolSlider* waterAmountSlider;
    CoolSlider* streamSpeedSlider;
    QPushButton* generateButton;
    QLabel* colorLabel;
    CoolSlider* reflectionSlider;
    CoolSlider* transparencySlider;
    QPushButton* colorButton;
    QPushButton* exportButton;
    BitmapNav* bitmapNavContainer;

public slots:
    virtual void cancelClicked();
    virtual void colorClicked();
    virtual void generateClicked();
    virtual void importClicked();
    virtual void exportMaskClicked();
    virtual void removeClicked();
    virtual void renameClicked();
    virtual void resetClicked();
    virtual void riversValuesChanged();
    virtual void seaValuesChanged();
    virtual void sourceSelected();

};

#endif // WATERGUIBASE_H
