#include <qapplication.h>
#include <qdialog.h>
#include <qfileinfo.h>
#include "./gui/scapemakerdialog.h"
#include "./engine/logger/logger.h"
#include "./engine/common/enginehelpers.h"

int main( int argc, char** argv )
{
	logger = new Logger("scapemaker.log");

	//init enginehelpers functions
	EngineHelpers::initInterpolationStrengths(1000);
	
	QApplication app( argc, argv );

	//check right directx version
	LPDIRECT3D9 pD3D = NULL;
	pD3D = Direct3DCreate9(D3D_SDK_VERSION);
	if (pD3D == NULL)
	{
		QMessageBox::information(0, "ScapeMaker","ScapeMaker needs DirectX 9.0c or better!\nPlease install it and try again.");
		return 0;
	}
	SAFE_RELEASE(pD3D);

	//check if there is a config.txt
	QFileInfo fileInfo1("./enginefiles/config.txt");
	QFileInfo fileInfo2("./guifiles/config.txt");
	if (!fileInfo1.exists() || fileInfo1.isDir() || 
		!fileInfo2.exists() || fileInfo2.isDir() )
	{
		//show config dialog
		ConfigGUI dialog(0,"configGUI", true, Qt::WStyle_Customize | Qt::WStyle_DialogBorder | Qt::WStyle_Title | Qt::WStyle_SysMenu | Qt::WStyle_ContextHelp);
		dialog.show();
		//if user canceled the dialog -> quit (we need a config file)
		if (dialog.isCanceledDialog())
		{
			//qApp->quit();
			return 0;
		}
	}

	//read language from config file
	MiniXML xmlFile;
	QString language = "en";
	if (xmlFile.openFile("./guifiles/config.txt",MiniXML::Modus::READ))
	{
		//load language
		int iValue;
		if (xmlFile.readInteger("language", &iValue))
		{
			switch (iValue)
			{
			case 0:
				language = "en";
				break;
			case 1:
				language = "de";
				break;
			default:
				language = "en";
				break;
			}
		}
			
		//close xml file
		xmlFile.closeFile();
	}

	//set language
	QTranslator germanTranslator(0);
	if (germanTranslator.load("scapemaker_"+language+".qm",".") )
		app.installTranslator(&germanTranslator);

	ScapeMakerDialog dialog(0, "scapeMakerDialog", true, Qt::WStyle_Customize | Qt::WStyle_DialogBorder | Qt::WStyle_Title | Qt::WStyle_SysMenu | Qt::WStyle_ContextHelp);
	app.setMainWidget(&dialog);

	//parameter from command line?
	if (argc == 2) dialog.setAutoStartProject(argv[1],0);
	else if (argc == 3) dialog.setAutoStartProject(argv[1],atoi(argv[2]));
	
	dialog.exec();

	delete logger;

	//deinit enginehelpers functions
	EngineHelpers::deInitInterpolationStrengths();

	return 0;
}

