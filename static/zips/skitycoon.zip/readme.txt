Ski Tycoon v0.5


Thank you for testing Ski Tycoon v0.5!
Please recognize that this program is not a complete game. We interrupted the development of this game because we didn't have enough time and motivation to complete it. We hope you have fun playing this game. :)


Some more Infos here:

Ski Tycoon is a 3D-game where you can build a ski resort. In this version you can build slopes, aerial-ropeways and restaurants.

System-Requirements:
Directx8.0 (www.microsoft.com/directx)
3D-Graphiccard (better than a tnt2 or equal)
Mouse
Windows9x, 2000 or XP
64 MB RAM
50 MB harddisc-space

Manual:
Move the mouse to scroll around.
Press the middle mouse button to rotate the camera.
Use the mouse wheel to zoom in or out.
Click on a button at the top of the screen and then on the landscape to construct slopes, restaurants or lifts. Click with the right button on the half transparent construction to buy it. If the construction is violett, the construction is illegal and you must change or cancel it. A construction could be invalid because of intersection with other slopes/lifts/restaurants or because a lift is too steep or to low. Insert supports in a lift-construction by left-clicking on the trail. Move your mouse up/down to set the height of the support and click left again to fix the support. Then, right click on the construction and choose Build Lift. Insert a curve in a slope by left-clicking on the slope-construction and move the mouse to move the new edge. Then left click and move the mouse to set the width of the slope. Again left click to fix the edge. Then, right click on the construction and choose Build Slope.
Click on 'Insert beginner/advanced/expert' to insert some people in your ski-resort. Beginner won't ski on red or black slopes! Advanced won't ski on black slopes! Expert use all sorts of slopes!

Credits:
Matthias Buchetics (Programming and 2D-art)
   www.matthias-buchetics.com
Dirk Plate (Programming and 3D-models)
   www.dplate.de
Jan Goepfert (Testing)
David Novak (concept GUI)