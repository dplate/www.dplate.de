//Clock.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;

public class Clock extends Component
	implements Runnable
{
	Image clockPic;
	Rectangle pos;
	long startTime;
	long lastTime;
	Point middlePos;
	int length;
	boolean done;
	Thread timeThread;
	float aktDegree;

	public Clock()
	{
		startTime = -1L;
		lastTime = 0L;
		clockPic = Helps.loadImage("clock.gif", this);
		pos = new Rectangle(150, 30, clockPic.getWidth(this), clockPic.getHeight(this));
		middlePos = new Point((pos.x + pos.width / 2) - 1, (pos.y + pos.height / 2) - 1);
		length = pos.width / 2 - 10;
	}

	public void run()
	{
		for(Thread thread = Thread.currentThread(); timeThread == thread;)
		{
			Helps.wait(Const.fpsTime);
			long l = java.lang.System.currentTimeMillis();
			if(l < lastTime)
			{
				done = true;
				timeThread = null;
			}
			lastTime = l;
			long l1 = Const.maxTime - (l - startTime);
			aktDegree = (2.0F * Const.pi * l1) / Const.maxTime;
			if(l1 <= 0L)
			{
				done = true;
				timeThread = null;
			}
		}

	}

	public void start()
	{
		startTime = java.lang.System.currentTimeMillis();
		lastTime = 0L;
		done = false;
		timeThread = new java.lang.Thread(this);
		timeThread.start();
	}

	public void display(java.awt.Graphics g)
	{
		g.drawImage(clockPic, pos.x, pos.y, this);
		g.setColor(java.awt.Color.blue);
		g.drawLine(middlePos.x, middlePos.y, middlePos.x + (int)(length * java.lang.Math.sin(aktDegree)), middlePos.y - (int)(length * java.lang.Math.cos(aktDegree)));
	}
}
