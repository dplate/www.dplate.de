//Const.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.Font;

public class Const extends Object
{
	static float pi = 3.141593F;
	static int maxX = 400;
	static int maxY = 300;
	static int korrX = 3;
	static int korrY = 22;
	static int fpsTime = 50;
	static int strapYPos = 150;
	static int maxLetters = 10;
	static int anzLetters = 6;
	static int maxImprints = 50;
	static int stampWidth = 15;
	static int scoreAnz = 5;
	static long maxTime = 0x15f90L;
	static String startGame = new java.lang.String("start new game");
	static Font schrift = new java.awt.Font("TimesRoman", 0, 14);
	static Font startGameFont = new java.awt.Font("TimesRoman", 0, 25);
}
