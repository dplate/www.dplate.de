//Game.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;
import java.awt.event.*;

public class Game extends Frame
	implements Runnable,KeyListener,MouseListener,MouseMotionListener
{
	Image offscreenImage;
	Graphics offscreen;
	Thread gameThread;
	Image backPic;
	Pad gamePad;
	Score gameScore;
	Clock gameClock;
	Lamp gameLamp;
	Strap gameStrap;
	boolean mouseButtonDown;
	Rectangle startGamePos;
	final int statusInit = 0;
	final int statusPlay = 1;
	final int statusEnd = 2;
	int status;

	public Game()
	{
		super("Stamp");
		gamePad = new Pad();
		gameScore = new Score();
		gameClock = new Clock();
		gameLamp = new Lamp();
		gameStrap = new Strap(gameLamp);
		mouseButtonDown = false;
		setSize(Const.maxX, Const.maxY);
		setResizable(false);
		setVisible(true);
		WindowAdapter windowadapter = new WindowAdapter()
		{
			public void windowClosing(WindowEvent windowevent)
			{
				gameThread = null;
				if(Gameapplet.applet == null)
				{
					System.exit(0);
				}
				Gameapplet.applet.stop();
			}
		};
		setCursor(new Cursor(1));
		addWindowListener(windowadapter);
		addKeyListener(this);
		addMouseListener(this);
		addMouseMotionListener(this);
		offscreenImage = createImage(getSize().width, getSize().height);
		offscreen = offscreenImage.getGraphics();
		backPic = Helps.loadImage("table.jpg", this);
		FontMetrics fontmetrics = getFontMetrics(Const.startGameFont);
		startGamePos = new Rectangle(140, 50, fontmetrics.stringWidth(Const.startGame), fontmetrics.getHeight());
		status = 2;
		gameThread = new Thread(this);
		gameThread.start();
	}

	protected void finalize()
		throws java.lang.Throwable
	{
		stopThreads();
		super.finalize();
	}

	public void stopThreads()
	{
		gameThread = null;
		if(gameStrap != null)
		{
			gameStrap.strapThread = null;
		}
		if(gameLamp != null)
		{
			gameLamp.greenThread = null;
		}
		if(gameClock != null)
		{
			gameClock.timeThread = null;
		}
	}

	public void run()
	{
		for(Thread thread = Thread.currentThread(); gameThread == thread;)
		{
			Helps.wait(Const.fpsTime);
			switch(status)
			{
			default:
				break;

			case 0:
				gameStrap.init();
				gameScore.init();
				gameClock.start();
				Thestamp.color = 3;
				status = 1;
				break;

			case 1:
				if(gameClock.done)
				{
					status = 2;
					gameStrap.strapThread = null;
					if(gameScore != null)
					{
						//gameScore.submit();
					}
				}
				repaint();
				break;

			case 2:
				repaint();
				break;

			}
		}

	}

	public void update(Graphics g)
	{
		paint(g);
	}

	public void paint(Graphics g)
	{
		if(gameThread == null)
		{
			return;
		}
		offscreen.drawImage(backPic, 0, 0, this);
		gameScore.display(offscreen);
		gameStrap.display(offscreen);
		gamePad.display(offscreen);
		gameLamp.display(offscreen);
		if(status == 1)
		{
			gameClock.display(offscreen);
		}
		if(status == 2)
		{
			offscreen.setFont(Const.startGameFont);
			offscreen.setColor(Color.cyan);
			offscreen.drawString(Const.startGame, startGamePos.x, startGamePos.y + startGamePos.height / 2);
		}
		g.drawImage(offscreenImage, 0, 0, this);
	}

	public void keyPressed(java.awt.event.KeyEvent keyevent)
	{
		if(status == 1)
		{
			if(keyevent.getKeyCode() == 38)
			{
				gameStrap.changeSpeed(1);
			}
			if(keyevent.getKeyCode() == 40)
			{
				gameStrap.changeSpeed(-1);
			}
		}
	}

	public void keyReleased(KeyEvent keyevent)
	{
	}

	public void keyTyped(KeyEvent keyevent)
	{
	}

	public void mouseClicked(MouseEvent mouseevent)
	{
		if(status == 2 && startGamePos.contains(mouseevent.getX(), mouseevent.getY()))
		{
			status = 0;
		}
	}

	public void mouseEntered(MouseEvent mouseevent)
	{
	}

	public void mouseExited(MouseEvent mouseevent)
	{
		mouseButtonDown = false;
	}

	public void mousePressed(MouseEvent mouseevent)
	{
		if(status == 1 && !mouseButtonDown)
		{
			mouseButtonDown = true;
			gameStrap.checkMouse();
			gamePad.checkMouse();
		}
	}

	public void mouseReleased(MouseEvent mouseevent)
	{
		mouseButtonDown = false;
	}

	public void mouseDragged(MouseEvent mouseevent)
	{
		Thestamp.checkMouse(mouseevent.getX() - Thestamp.pos.width / 2, mouseevent.getY() - Thestamp.pos.height / 2);
	}

	public void mouseMoved(MouseEvent mouseevent)
	{
		Thestamp.checkMouse(mouseevent.getX() - Thestamp.pos.width / 2, mouseevent.getY() - Thestamp.pos.height / 2);
	}

	public static void main(String args[])
	{
		Game game = new Game();
	}
}
