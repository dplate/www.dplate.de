//Gameapplet.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.applet.Applet;
import java.awt.Window;

public class Gameapplet extends Applet
{

	public Gameapplet()
	{
	}

	public void init()
	{
		Gameapplet.applet = this;
		appGame = new Game();
	}

	public void stop()
	{
		if(appGame != null)
		{
			appGame.stopThreads();
			appGame.dispose();
		}
		appGame = null;
	}

	Game appGame;
	static Gameapplet applet;
}
