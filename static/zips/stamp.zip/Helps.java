//Helps.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.applet.Applet;
import java.awt.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

public class Helps extends Object
{

	public Helps()
	{
	}

	static Image loadImage(String s, Component component)
	{
		Image image = null;
		try
		{
			if(Gameapplet.applet == null)
			{
				image = Toolkit.getDefaultToolkit().getImage(s);
			}
			else
			{
				image = Gameapplet.applet.getImage(Gameapplet.applet.getCodeBase(), s);
			}
			MediaTracker mediatracker = new MediaTracker(component);
			mediatracker.addImage(image, 0);
			mediatracker.waitForAll();
		}
		catch(InterruptedException interruptedexception)
		{
			System.out.println(interruptedexception);
		}
		return image;
	}

	static void wait(int i)
	{
		try
		{
			Thread.sleep(i);
		}
		catch(InterruptedException interruptedexception)
		{
			System.out.println(interruptedexception);
		}
	}

	static DataInput loadFile(String s)
	{
		Object obj = null;
		Object obj1 = null;
		if(Gameapplet.applet == null)
		{
			try
			{
				obj1 = new FileInputStream(s);
			}
			catch(IOException ioexception)
			{
				System.out.println(ioexception);
			}
		}
		else
		{
			try
			{
				URL url = new URL(Gameapplet.applet.getCodeBase() + s);
				try
				{
					obj1 = url.openStream();
				}
				catch(IOException ioexception1)
				{
					System.out.println(ioexception1);
				}
			}
			catch(MalformedURLException malformedurlexception)
			{
				System.out.println(malformedurlexception);
			}
		}
		return new DataInputStream(new BufferedInputStream(((InputStream) (obj1))));
	}
}
