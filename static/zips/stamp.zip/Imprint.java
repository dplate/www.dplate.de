//Imprint.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;

public class Imprint extends Object
{
	Image imprintPic;
	Rectangle pos;

	public Imprint(Image image, int i, int j, Component component)
	{
		imprintPic = image;
		pos = new Rectangle(i, j, image.getWidth(component), image.getHeight(component));
	}

	public void display(Graphics g, Component component)
	{
		g.drawImage(imprintPic, pos.x, pos.y, component);
	}
}
