//Lamp.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;

public class Lamp extends Component
	implements Runnable
{
	Thread greenThread;
	Image redPic;
	Image greenPic;
	Rectangle lampPos;
	boolean green;

	public Lamp()
	{
		redPic = Helps.loadImage("lampred.gif", this);
		greenPic = Helps.loadImage("lampgreen.gif", this);
		lampPos = new Rectangle(260, 80, redPic.getWidth(this), redPic.getHeight(this));
	}

	public void setToGreen()
	{
		greenThread = null;
		green = true;
		greenThread = new Thread(this);
		greenThread.start();
	}

	public void run()
	{
		for(Thread thread = Thread.currentThread(); greenThread == thread; greenThread = null)
		{
			Helps.wait(250);
			green = false;
		}

	}

	public void display(Graphics g)
	{
		if(green)
		{
			g.drawImage(greenPic, lampPos.x, lampPos.y, this);
		}
		else
		{
			g.drawImage(redPic, lampPos.x, lampPos.y, this);
		}
	}
}
