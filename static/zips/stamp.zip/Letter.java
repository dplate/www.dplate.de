//Letter.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;

public class Letter extends Object
{
	Image letterPic;
	Rectangle stampRect;
	Rectangle letterRect;
	boolean stamped;
	Lamp lamp;

	public Letter(Image aimage[], Component component, Lamp lamp1)
	{
		lamp = lamp1;
		int i = (int)(Math.random() * Const.anzLetters);
		switch(i)
		{
		case 0:
			stampRect = new Rectangle(44, 2, 15, 14);
			break;

		case 1:
			stampRect = new Rectangle(75, 2, 16, 13);
			break;

		case 2:
			stampRect = new Rectangle(68, 2, 21, 17);
			break;

		case 3:
			stampRect = new Rectangle(40, 10, 13, 10);
			break;

		case 4:
			stampRect = new Rectangle(60, 4, 25, 21);
			break;

		case 5:
			stampRect = new Rectangle(43, 1, 16, 15);
			break;

		}
		letterPic = aimage[i];
		letterRect = new Rectangle(Const.maxX, Strap.strapPos.y + (int)(Math.random() * (Strap.strapPos.height - letterPic.getHeight(component))), letterPic.getWidth(component), letterPic.getHeight(component));
		stamped = false;
	}

	public void checkMouse()
	{
		Rectangle rectangle = new Rectangle(stampRect);
		rectangle.translate(letterRect.x, letterRect.y);
		if(rectangle.intersects(Thestamp.pos) && !stamped)
		{
			stamped = true;
			Score.addScore(1);
			lamp.setToGreen();
		}
	}

	public void display(Graphics g, Component component)
	{
		g.drawImage(letterPic, letterRect.x, letterRect.y, component);
	}
}
