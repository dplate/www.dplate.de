//Pad.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;

public class Pad extends Component
{
	Image padPic;
	Rectangle padPos;
	Rectangle padInPos;

	public Pad()
	{
		padPic = Helps.loadImage("pad.gif", this);
		padPos = new Rectangle(Const.maxX - 80, 40, padPic.getWidth(this), padPic.getHeight(this));
		padInPos = new Rectangle(padPos.x + 3, padPos.y + 41, 59, 41);
	}

	public void checkMouse()
	{
		if(Thestamp.pos.intersects(padInPos))
		{
			Thestamp.color = 3;
		}
	}

	public void display(Graphics g)
	{
		g.drawImage(padPic, padPos.x, padPos.y, this);
	}
}
