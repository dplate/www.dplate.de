//Score.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;

public class Score extends Object
{
	String name[];
	static int points[];
	Point pos;
	static int yourPoints;
	static int yourPos;

	static
	{
		Score.points = new int[Const.scoreAnz];
	}

	public Score()
	{
		name = new String[Const.scoreAnz];
		pos = new Point(10, 40);
		init();
	}

	public void init()
	{
		java.io.DataInput datainput = Helps.loadFile("high.score");
		for(int i = 0; i < Const.scoreAnz; i++)
		{
			try
			{
				name[i] = datainput.readLine();
				Score.points[i] = Integer.parseInt(datainput.readLine());
			}
			catch(java.io.IOException ioexception)
			{
				System.out.println(ioexception);
			}
		}

		Score.yourPoints = 0;
		Score.yourPos = 5;
	}

	public static void addScore(int i)
	{
		Score.yourPoints += i;
		if(Score.yourPoints < 0)
		{
			Score.yourPoints = 0;
		}
		for(; Score.yourPos != 0 && Score.yourPoints > Score.points[Score.yourPos - 1]; Score.yourPos--) { }
		for(; Score.yourPos != 5 && Score.yourPoints < Score.points[Score.yourPos]; Score.yourPos++) { }
	}

	public void submit()
	{
		URL url = null;
		Calendar calendar = Calendar.getInstance();
		if(Score.yourPos >= 5)
		{
			return;
		}
		if(Gameapplet.applet != null)
		{
			int i = calendar.get(5) * 2 + (calendar.get(2) + 1) * 3 + calendar.get(1) * 4 + Score.yourPoints * 5;
			int j = (int)(Math.random() * 10D);
			i *= j;
			try
			{
				url = new URL("mailto:dP-Software@gmx.de?subject=" + String.valueOf(j) + String.valueOf(i) + String.valueOf((int)(Math.random() * 10D)) + " &body=Herzlichen Glueckwunsch. Du hast eine der 5 besten Punktzahlen erreicht.%0A" + "Fuelle einfach noch die Felder hier unter diesem Text aus (nicht die Betreffzeile aendern)%0A" + "und schicke die Mail ab.%0A" + "%0A" + "Name:%0A" + "Email:%0A" + "Spitzname:%0A" + "Punktzahl:");
			}
			catch(MalformedURLException malformedurlexception)
			{
				System.out.println(malformedurlexception);
			}
			Gameapplet.applet.getAppletContext().showDocument(url, "_blank");
		}
	}

	public void display(Graphics g)
	{
		g.setFont(Const.schrift);
		for(int i = 0; i < Const.scoreAnz; i++)
		{
			int j;
			if(i < Score.yourPos)
			{
				j = i;
			}
			else
			{
				j = i + 1;
			}
			if(i == Score.yourPos)
			{
				g.setColor(Color.yellow);
				g.drawString("Your Score", pos.x, pos.y + i * 15);
				g.drawString(String.valueOf(Score.yourPoints), pos.x + 100, pos.y + i * 15);
			}
			g.setColor(Color.white);
			g.drawString(name[i], pos.x, pos.y + j * 15);
			g.drawString(String.valueOf(Score.points[i]), pos.x + 100, pos.y + j * 15);
		}

		if(Score.yourPos == Const.scoreAnz)
		{
			g.setColor(Color.yellow);
			g.drawString("Your Score", pos.x, pos.y + Const.scoreAnz * 15);
			g.drawString(String.valueOf(Score.yourPoints), pos.x + 100, pos.y + Const.scoreAnz * 15);
		}
	}
}
