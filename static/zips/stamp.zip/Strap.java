//Strap.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.*;

public class Strap extends Component
	implements Runnable
{
	Thread strapThread;
	Image strapPic;
	Image allLetters[];
	Image allImprints[];
	int speed;
	static Rectangle strapPos;
	Letter strapLetter[];
	Imprint strapImprint[];
	Lamp lamp;

	public Strap(Lamp lamp1)
	{
		allLetters = new Image[Const.anzLetters];
		allImprints = new Image[3];
		strapLetter = new Letter[Const.maxLetters];
		strapImprint = new Imprint[Const.maxImprints];
		lamp = lamp1;
		strapPic = Helps.loadImage("strap.gif", this);
		Strap.strapPos = new Rectangle(0, Const.strapYPos, strapPic.getWidth(this), strapPic.getHeight(this));
		allLetters[0] = Helps.loadImage("letter0.gif", this);
		allLetters[1] = Helps.loadImage("letter1.gif", this);
		allLetters[2] = Helps.loadImage("letter2.gif", this);
		allLetters[3] = Helps.loadImage("letter3.gif", this);
		allLetters[4] = Helps.loadImage("letter4.gif", this);
		allLetters[5] = Helps.loadImage("letter5.gif", this);
		allImprints[0] = Helps.loadImage("imprint0.gif", this);
		allImprints[1] = Helps.loadImage("imprint1.gif", this);
		allImprints[2] = Helps.loadImage("imprint2.gif", this);
	}

	protected void finalize()
		throws Throwable
	{
		strapThread = null;
		super.finalize();
	}

	public void init()
	{
		speed = 3;
		Strap.strapPos.x = 0;
		for(int i = 0; i < Const.maxLetters; i++)
		{
			strapLetter[i] = null;
		}

		for(int j = 0; j < Const.maxImprints; j++)
		{
			strapImprint[j] = null;
		}

		strapThread = new Thread(this);
		strapThread.start();
	}

	public void run()
	{
		for(Thread thread = Thread.currentThread(); strapThread == thread;)
		{
			int i = -1;
			int j = 0;
			int k = -1;
			Helps.wait(Const.fpsTime);
			Strap.strapPos.x -= speed;
			if(Strap.strapPos.x < -Strap.strapPos.width)
			{
				Strap.strapPos.x += Strap.strapPos.width;
			}
			for(int l = 0; l < Const.maxLetters; l++)
			{
				if(strapLetter[l] == null)
				{
					if(i == -1)
					{
						i = l;
					}
				}
				else
				{
					strapLetter[l].letterRect.x -= speed;
					if(strapLetter[l].letterRect.x > j)
					{
						j = strapLetter[l].letterRect.x;
						k = l;
					}
					if(strapLetter[l].letterRect.x + strapLetter[l].letterRect.width < 0)
					{
						if(!strapLetter[l].stamped)
						{
							Score.addScore(-5);
						}
						strapLetter[l] = null;
					}
				}
			}

			if(k == -1)
			{
				strapLetter[0] = new Letter(allLetters, this, lamp);
			}
			else
			if(j < Strap.strapPos.width - strapLetter[k].letterRect.width - 5 && i != -1)
			{
				strapLetter[i] = new Letter(allLetters, this, lamp);
			}
			for(int i1 = 0; i1 < Const.maxImprints; i1++)
			{
				if(strapImprint[i1] != null)
				{
					strapImprint[i1].pos.x -= speed;
					if(strapImprint[i1].pos.x + strapImprint[i1].pos.width < 0)
					{
						strapImprint[i1] = null;
					}
				}
			}

		}

	}

	public void changeSpeed(int i)
	{
		speed += i;
		if(speed < 0)
		{
			speed = 0;
		}
	}

	public void checkMouse()
	{
		Rectangle rectangle = new Rectangle(Strap.strapPos);
		rectangle.setBounds(rectangle.x, rectangle.y, 2 * rectangle.width, rectangle.height);
		if(rectangle.intersects(Thestamp.pos) && Thestamp.decreaseColor())
		{
			for(int i = 0; i < Const.maxImprints; i++)
			{
				if(strapImprint[i] != null)
				{
					continue;
				}
				strapImprint[i] = new Imprint(allImprints[2 - Thestamp.color], Thestamp.pos.x, Thestamp.pos.y, this);
				for(int j = 0; j < Const.maxLetters; j++)
				{
					if(strapLetter[j] != null)
					{
						strapLetter[j].checkMouse();
					}
				}

				break;
			}

		}
	}

	public void display(Graphics g)
	{
		g.drawImage(strapPic, Strap.strapPos.x, Strap.strapPos.y, this);
		g.drawImage(strapPic, Strap.strapPos.x + Strap.strapPos.width, Strap.strapPos.y, this);
		for(int i = 0; i < Const.maxLetters; i++)
		{
			if(strapLetter[i] != null)
			{
				strapLetter[i].display(g, this);
			}
		}

		for(int j = 0; j < Const.maxImprints; j++)
		{
			if(strapImprint[j] != null)
			{
				strapImprint[j].display(g, this);
			}
		}

	}
}
