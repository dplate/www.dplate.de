//Thestamp.java
//part of the game 'stamp'
//programmed by dP-Software in 2001
//dP-Software@gmx.de

import java.awt.Rectangle;

public class Thestamp extends Object
{
	static Rectangle pos;
	static int color;

	static
	{
		Thestamp.pos = new Rectangle(0, 0, Const.stampWidth, Const.stampWidth);
	}

	public Thestamp()
	{
	}

	static boolean decreaseColor()
	{
		Thestamp.color--;
		if(Thestamp.color < 0)
		{
			Thestamp.color = 0;
			return false;
		}
		else
		{
			return true;
		}
	}

	public static void checkMouse(int i, int j)
	{
		Thestamp.pos.setLocation(i, j);
	}
}
