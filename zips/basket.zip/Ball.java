import java.awt.*;
import java.math.*;

public class Ball extends Component
{
	Kollision kollWaende;
	PunkteTafel punkte;
	Image ballBild;
	Image schattenBild;
	float g = (float)/*9.81*/15;			//Erdanziehungskraft
	float m = (float)0.2;			//die Masse des Ball
	float t = (float)0.2;			//Wieviel Zeit vergeht w�hrend eines frames
	float deformationsFaktor = (float)0.7; //Wieviel Energie wird beim Aufprall vernichtet
	float reibungsFaktor = (float)0.9;		//Wieviel Energie wird durch den Luftwiederstand verbraucht
	int   maxX;						//die Bildschirmbreite
	int   boden;					//Wo ist der Boden
	boolean isKoll;					//Gabs bei dem Wurf schon eine Kollision? (um 3er rauszubekommen)

	float posX;						//die linke obere Ecke des Balls
	float posY;
	float vX;						//der Geschwindigkeitsvektor des Balls
	float vY;

	public Ball(GameApplet setApplet,Kollision newWaende, int setMaxX, PunkteTafel newPunkte, int setBoden)
	{
		maxX = setMaxX;
		kollWaende = newWaende;
		punkte = newPunkte;
		boden = setBoden;
		try
		{
			if (setApplet == null)
			{
				ballBild = Toolkit.getDefaultToolkit().getImage("ball.gif");
				schattenBild = Toolkit.getDefaultToolkit().getImage("schatten.gif");
			}
			else
			{
				ballBild = setApplet.getImage(setApplet.getCodeBase(),"ball.gif");
				schattenBild = setApplet.getImage(setApplet.getCodeBase(),"schatten.gif");
			}

			MediaTracker tracker = new MediaTracker(this);
			// Bild zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.addImage(ballBild, 0);
			tracker.addImage(schattenBild, 0);
			tracker.waitForAll();
		}
		catch(java.lang.InterruptedException ie)
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes");
		}
	}

	public void init()
	{
		posX = (float)80;
		posY = (float)280;
		vX = (float)0;
		vY = (float)0;
		isKoll = false;
	}

	public void push(float winkel, float staerke)
	{
		vX = staerke * (float)Math.cos(winkel);
		vY = -staerke * (float)Math.sin(winkel);
	}

	public boolean reCalc()
	{
		float newAX;	//der neue Beschleunigungsvektor
		float newAY;
		float newVX;	//der neue Geschwindigkeitsvektor
		float newVY;
		float newPX;	//die neue Position
		float newPY;
		float [] sPunkt = new float[2]; //der eventuelle Schnittpunkt
		float [] wandDiff = new float[2]; //die Wand mit der kollidiert
		float drittel = ballBild.getWidth(this)/3;	//ein Drittel eine Seitenl�nge des Balls
		float seite = ballBild.getWidth(this);	//die Seitenl�nge

		boolean koll = false; //true, wenn es eine Kollision gab

		//Erdanziehungskraft
		newAX = 0;
		newAY = g;

		//neuen Geschwindigkeitsvektor ausrechnen
		newVX = newAX*t;
		newVY = newAY*t;

		//zu altem Geschwindigkeitsvektor dazuaddieren
		vX += newVX*reibungsFaktor;
		vY += newVY*reibungsFaktor;

		//neue Position ausrechnen
		newPX = posX + vX*t;
		newPY = posY + vY*t;

		//Kollsion? (nehme einen achteckigen Ball an)
		if ((kollWaende.checkKollision(newPX+drittel,newPY,
									  newPX+2*drittel,newPY,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX+2*drittel,newPY,
									  newPX+seite,newPY+drittel,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX+seite,newPY+drittel,
									  newPX+seite,newPY+2*drittel,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX+seite,newPY+2*drittel,
									  newPX+2*drittel,newPY+seite,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX+2*drittel,newPY+seite,
									  newPX+drittel,newPY+seite,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX+drittel,newPY+seite,
									  newPX,newPY+2*drittel,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX,newPY+2*drittel,
									  newPX,newPY+drittel,
									  sPunkt,wandDiff,false)) ||
			(kollWaende.checkKollision(newPX,newPY+drittel,
									  newPX+drittel,newPY,
									  sPunkt,wandDiff,false)))
		{
			float alpha,beta,beta1, vBetrag;

			//Spiegelvektor errechnen
			alpha = (float)Math.atan2(-wandDiff[1],wandDiff[0]);
			beta  = (float)Math.atan2(-vY,vX);
			beta1 = 2*alpha-beta;
			vBetrag = (float)Math.sqrt(vX*vX+vY*vY);

			//Ball anstossen
			vX = (float)Math.cos(beta1)*vBetrag * deformationsFaktor;
			vY = -(float)Math.sin(beta1)*vBetrag * deformationsFaktor;

			koll = true;
			//System.out.println("Kollision: "+ String.valueOf((int)vX) + ", " + String.valueOf((int)vY));
		}
		else
		{
			posX = newPX;
			posY = newPY;
		}

		//Ein Korb?
		if (kollWaende.checkKollision(posX+seite/2,posY+seite/2,
									posX+seite/2-vX,posY+seite/2-vY,
									sPunkt,wandDiff,true))
		{
			if (isKoll) punkte.newPunkte(2);	//Punkte z�hlen
			else punkte.newPunkte(3);
			return false;
		}

		if (koll) isKoll = true;

		/*if (koll) System.out.println("Kollision");
		System.out.println(String.valueOf((int)Math.sqrt(vX*vX+vY*vY)));
		if (posY < boden/2) System.out.println("Hoch genug "+ (int)posY);
*/
		if ((koll) && (Math.sqrt(vX*vX+vY*vY) <= 6)) //bei Stillstand des Balls
		{
			if (posY < 150)
			{
				posY -=5;//Bl�de Bugbeseitigungsma�nahme
				posX -=5;
				vX 	= -5;
				vY = 5;
			}
			else return false;
		}
		if ((posX < 0) || (posX > maxX)) return false;	//Wenn au�erhalb des Bildschirms
		return true;		//alles roger
	}

	public void display(Graphics screen)
	{
		screen.drawImage(schattenBild, (int)posX, boden-12, this);
		screen.drawImage(ballBild, (int)posX, (int)posY, this);

		float drittel = ballBild.getWidth(this)/3;	//ein Drittel eine Seitenl�nge des Balls
		float seite = ballBild.getWidth(this);	//die Seitenl�nge

	/*	screen.drawLine((int)(posX+drittel),(int)posY,(int)(posX+2*drittel),(int)posY);
		screen.drawLine((int)(posX+2*drittel),(int)posY, (int)(posX+seite),(int)(posY+drittel));
		screen.drawLine((int)(posX+seite),(int)(posY+drittel),(int)(posX+seite),(int)(posY+2*drittel));
		screen.drawLine((int)(posX+seite),(int)(posY+2*drittel),(int)(posX+2*drittel),(int)(posY+seite));
		screen.drawLine((int)(posX+2*drittel),(int)(posY+seite),(int)(posX+drittel),(int)(posY+seite));
		screen.drawLine((int)(posX+drittel),(int)(posY+seite),(int)posX,(int)(posY+2*drittel));
		screen.drawLine((int)posX,(int)(posY+2*drittel),(int)posX,(int)(posY+drittel));
		screen.drawLine((int)posX,(int)(posY+drittel), (int)(posX+drittel),(int)posY);*/
	}
}