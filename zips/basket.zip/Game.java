import java.awt.*;
import java.awt.event.*;

public class Game extends Frame implements Runnable
{
	//Spielzust�nde
	final int szIntro 	= 0;	//In dem Zustand wird das Intro angezeigt
	final int szInit 	= 1;	//In dem Zustand wird alles wieder in den Ursprungszustand gesetzt
	final int szWinkel 	= 2;	//ver�ndert den Winkel des Kraftpfeils und wartet auf Aktion des Spielers
	final int szLaenge 	= 3; 	//ver�ndert die Laenge des Kraftpfeils und wartet auf Aktion des Spielers
	final int szWurf 	= 4;	//l�sst den Ball fliegen
	final int szFly		= 5; 	//die Flugphase und stellt das Ergebnis fest
	final int szWaitFly = 6;	//wartet bis Spieler Taste dr�ckt zum Neubeginn
	int spielZustand = 0;		//Dies ist der aktuelle Spielzustand

	Kollision waende = new Kollision();
	Ball basketBall;
	Pfeil kraftPfeil = new Pfeil();
	PunkteTafel punkte = new PunkteTafel();
	Intro introObject;
	Image offscreenImage;	//F�r die doppelte Pufferung
	Graphics offscreen;
	final int maxX = 640;	//Fensterbreite
	final int maxY = 480;	//Fensterh�he
	Image backBild;
	Image frontBild;

	float aktLaenge;		//welche L�nge und Winkel ist gerade eingestellt
	float aktWinkel;

	Thread gameThread;
	GameApplet applet = null;	//wenn als applet gestartet, dann ist hier der Pointer drin

    public Game(GameApplet setApplet)
    {
		super("The Ultimative Basketball Game");

		applet = setApplet;		//Falls ein Applet, dann haben wir jetzt ein Pointer darauf
		setSize(maxX,maxY);		//Fenster auf die richtige Gr��e bringen
		setResizable(false);	//Fenster soll nicht in der Gr��e ver�nderbar sein
		setVisible(true);		//Fenster anzeigen

		WindowListener l = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) //Wenn das Fenster geschlossen wird
			{
				gameThread = null;					//Den Thread schliessen
				if (applet == null)	System.exit(0); //Wenn kein Applet, dann einfach raus
				applet.stop();						//sonst die Stop-Routine vom Applet aufrufen
			}
		};
		addWindowListener(l);	//Den Listener zum Fenster hinzuf�gen

	    Keysteuerung steuer = new Keysteuerung();	//Die Tastenabfrage aktivieren

        offscreenImage = createImage(getSize().width,getSize().height);	//Ein imagin�res Bild im Speicher erstellen
		offscreen = offscreenImage.getGraphics();	//Den Handle von dem Bild offscreen hinzuf�gen

		//die Bilder laden
		try
		{
			if (applet == null)		//Wenns kein Applet ist
			{
				backBild = Toolkit.getDefaultToolkit().getImage("back.gif");
				frontBild = Toolkit.getDefaultToolkit().getImage("front.gif");
			}
			else		//wenn Applet, dann besonders laden
			{
				backBild = applet.getImage(applet.getCodeBase(),"back.gif");
				frontBild = applet.getImage(applet.getCodeBase(),"front.gif");
			}

			MediaTracker tracker = new MediaTracker(this);
			// Bild zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.addImage(backBild, 0);
			tracker.addImage(frontBild, 0);
			tracker.waitForAll();
		}
		catch(java.lang.InterruptedException ie)
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes");
		}

		//einstellungen f�r Spiel vornehmen
		waende.insertLine(0,452,maxX,452,false);		//den Boden
		waende.insertLine(571,80,571,208,false);		//Holzwand hinter Korb
		waende.insertLine(571,80,573,83,false);			//oben auf Holzwand
		waende.insertLine(517,178,512,176,false);		//Stange beim Korb
		waende.insertLine(512,176,520,219,false);		//Netz vorderseite
		waende.insertLine(571,176,562,219,false);		//Netz hinterseite
		waende.insertLine(525,190,560,190,true); 		//die Korblinie

		basketBall = new Ball(applet,waende,maxX,punkte,452);		//Der Ball
		introObject = new Intro(applet);

		gameThread = new Thread(this);
		gameThread.start();
	}

    public Thread getGameThread()
    {
		return gameThread;
	}

	public void run()		//wird von thread.start aufgerufen
    {
		Thread thisThread = Thread.currentThread();
		while(gameThread == thisThread)		//ist das aktuelle Thread noch vorhanden?
		{
			try
			{
				Thread.sleep(50);
			}
			catch(InterruptedException ie)
			{
				System.out.println("Irgendein Sleep Fehler");
			}

			switch (spielZustand)		//je nach Spielzustand unterschiedliche Sachen machen
			{
			case szIntro:
				introObject.reCalc();
				break;
			case szInit:				//alles initialisieren (was sich im Spiel ver�ndert)
				basketBall.init();
				kraftPfeil.init();
				punkte.init();
				spielZustand++;
				break;
			case szWinkel:
				aktWinkel = kraftPfeil.calcWinkel();
				break;
			case szLaenge:
				aktLaenge = kraftPfeil.calcLaenge();
				break;
			case szWurf:
				basketBall.push(aktWinkel,aktLaenge*((float)2/3));
				spielZustand++;
				break;
			case szFly:
				if (!basketBall.reCalc()) spielZustand++;
				break;
			case szWaitFly:
				basketBall.reCalc();
				break;
			}
			repaint();
		}
	}

	public void update(Graphics screen)
	{
		paint(screen);		//Bildschirm nicht l�schen, sondern einfach wieder Paint
	}

    public void paint(Graphics screen)
	{
		if (basketBall == null) return;

		//Hintergrundbild �bermalen
		offscreen.drawImage(backBild, 0, 0, this);

		if (spielZustand != szIntro)
		{
			kraftPfeil.display(offscreen);
			punkte.display(offscreen);
			basketBall.display(offscreen);
		}

		//Vordergrundkullissen
		offscreen.drawImage(frontBild, 509, 52, this);

		//Intro Einblendung anzeigen
		if (spielZustand == szIntro) introObject.display(offscreen);

		//testzeichnungen
		//waende.display(offscreen);

		screen.drawImage(offscreenImage, 0, 0, this); //offscreen auf screen malen
	}

	public class Keysteuerung implements KeyListener
	{
	    public Keysteuerung()
	    {
	      	addKeyListener(this);
	    }

	    public void keyPressed(KeyEvent event)
	    {
	    	if (event.getKeyCode() == KeyEvent.VK_SPACE)
	    	{
				if ((spielZustand == szWinkel) || (spielZustand == szLaenge) ||
				    (spielZustand == szIntro)) spielZustand++;
				else if (spielZustand == szWaitFly) spielZustand = szInit;	//neu beginnen
			}
	    }

	    public void keyReleased(KeyEvent event)
		{
		}

		public void keyTyped(KeyEvent event)
		{
		}
	}

	public static void main(String[] args)		//Hauptprogramm
	{
		Game frame = new Game(null);
	}
}
