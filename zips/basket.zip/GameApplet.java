public class GameApplet extends java.applet.Applet
{
	Game appGame;
	Thread refThread;

	public void init()
	{
		appGame  = new Game(this);		//Ein Objekt der hauptklasse des Spiels machen
	}

	public void stop()
	{
		refThread = appGame.getGameThread();
		refThread = null;		//Thread l�schen
		appGame.dispose();		//Fenster schliessen
	}
}