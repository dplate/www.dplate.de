import java.awt.*;
import java.math.*;
import java.awt.Font;

public class Intro extends Component
{
	final float pi = (float)3.1415926535897932384626433832795; //pi: was hast du gedacht, was das sein soll?

	Image textBild;		//Das Introbild
	float breite;	//Die Ausma�e des Bild in der Originalgr��e
	float hoehe;
	float winkel;	//Wie ist der PerspektivenWinkel

	public Intro(GameApplet setApplet)
	{
		try
		{
			if (setApplet == null) textBild = Toolkit.getDefaultToolkit().getImage("intro.gif");
			else textBild = setApplet.getImage(setApplet.getCodeBase(),"intro.gif");

			MediaTracker tracker = new MediaTracker(this);
			// Bild zum Mediatracker hinzuf�gen (der verfolgt den Ladezustand)
			tracker.addImage(textBild, 0);
			tracker.waitForAll();
		}
		catch(java.lang.InterruptedException ie)
		{
			System.out.println("Irgendein Fehler beim Laden des Bildes");
		}
		winkel = 0;
		breite = textBild.getWidth(this);	//Breite und H�he des Bildes speichern
		hoehe = textBild.getHeight(this);
	}

	public void reCalc()
	{
		winkel += pi/250;
		if (winkel > (pi/2)) winkel = pi/2;	//Wenns gerade ist, dann stehen bleiben
	}

	public void display(Graphics screen)
	{
		float newHoehe = hoehe*(float)Math.sin(winkel);

		screen.drawImage(textBild, 170, 140+(int)(hoehe-newHoehe)/2,(int)breite,(int)newHoehe, this); //Speicherbild auf screen malen
	}
}