import java.awt.*;

public class Kollision extends Component
{
	int maxLines = 50;
	int[] lineX1 = new int[maxLines];	//Punkt 1 der Line
	int[] lineY1 = new int[maxLines];
	int[] lineX2 = new int[maxLines];	//Punkt 2 der Line
	int[] lineY2 = new int[maxLines];
	boolean[] korb = new boolean[maxLines];	//wird bei dieser Line ein Punkt gewertet
	int anzLines = 0;

	public Kollision()
	{

	}

	public void insertLine(int newX1, int newY1, int newX2, int newY2, boolean newKorb)
	{
		//neue Line hinzuf�gen
		lineX1[anzLines] = newX1;
		lineY1[anzLines] = newY1;
		lineX2[anzLines] = newX2;
		lineY2[anzLines] = newY2;
		korb[anzLines] = newKorb;
		anzLines++;
	}

	public boolean checkKollision(float checkX1, float checkY1, float checkX2, float checkY2,
								float [] koll,float [] wandDiff, boolean checkKorb)
	{
		int i;
		float g2a,g2b,g1a,g1b;
		float mauerDiffX,mauerDiffY,posDiffX,posDiffY,sPunktX = 0,sPunktY = 0;
		boolean check = true;
		boolean kollision = false;
		int anzKoll = 0;	//Wieviele Kollisionen
		float kollDiffY = 0;

		koll[0] = -1;
		koll[1] = -1;

		for (i=0;i<anzLines;i++)
		{
			if ((checkKorb) && (!korb[i])) continue; 	//wenns keine Korbgerade ist, aber die Korbgerade gefragt ist
			if ((!checkKorb) && (korb[i])) continue;

			check = true;

			posDiffX = checkX2-checkX1;
			posDiffY = checkY2-checkY1;
			mauerDiffX = lineX2[i]-lineX1[i];
			mauerDiffY = lineY2[i]-lineY1[i];

			//Steigung errechnen
			if (posDiffX == 0) g1a = 10000;
			else g1a = posDiffY/posDiffX;
			if (mauerDiffX == 0) g2a = 10000;
			else g2a = mauerDiffY/mauerDiffX;

			//Achsenabschnitt berechnen
			g1b = checkY1-checkX1*g1a;
			g2b = lineY1[i]-lineX1[i]*g2a;

			//Schnittpunkt berechnen
			if (g1a >= 10000)				//Sonderf�lle bei senkrechten Geraden
			{
				sPunktX = checkX2;
				sPunktY = sPunktX*g2a+g2b;
			}
			else if (g2a >= 10000)
			{
				sPunktX = lineX2[i];
				sPunktY = sPunktX*g1a+g1b;
			}
			else if (g2a == g1a)			//beide Geraden sind parallel
			{
				koll[0] = -1;
				koll[1] = -1;
				check = false;
			}
			else							//normale F�lle
			{
				sPunktX = (g1b-g2b)/(g2a-g1a);
				sPunktY = (sPunktX*g1a)+g1b;
			}
			if (check)
			{
				//Ist Schnittpunkt innerhalb der Grenzen?
				if (((sPunktX >= checkX1-0.1) && (sPunktX <= checkX2+0.1)) ||
					((sPunktX <= checkX1+0.1) && (sPunktX >= checkX2-0.1)))
				{
					if (((sPunktY >= checkY1-0.1) && (sPunktY <= checkY2+0.1)) ||
						((sPunktY <= checkY1+0.1) && (sPunktY >= checkY2-0.1)))
					{
						if (((sPunktX >= lineX1[i]-0.1) && (sPunktX <= lineX2[i]+0.1)) ||
							((sPunktX <= lineX1[i]+0.1) && (sPunktX >= lineX2[i]-0.1)))
						{
							if (((sPunktY >= lineY1[i]-0.1) && (sPunktY <= lineY2[i]+0.1)) ||
								((sPunktY <= lineY1[i]+0.1) && (sPunktY >= lineY2[i]-0.1)))
							{
								koll[0] = sPunktX;
								koll[1] = sPunktY;
								kollision = true;

								kollDiffY = (kollDiffY*(float)anzKoll+(mauerDiffY/mauerDiffX))/
												((float)anzKoll+1);
								anzKoll++;
							}
						}
					}
				}
			}
		}
		wandDiff[0] = 1;	//nur f�r die R�ckgabe
		wandDiff[1] = kollDiffY;
		return kollision;
	}

	public void display(Graphics screen)
	{
		int i;

		Color farbe = new Color(255,255,255);
		screen.setColor(farbe);
		for (i=0;i<anzLines;i++) screen.drawLine(lineX1[i],lineY1[i],lineX2[i],lineY2[i]);
	}
}