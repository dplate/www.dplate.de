import java.awt.*;
import java.math.*;

public class Pfeil extends Component
{
	float pi = (float)3.1415926535897932384626433832795; //pi: was hast du gedacht, was das sein soll?

	int wPosX = 100;		//Die Position der Wurzel des Pfeils
	int wPosY = 300;

	float winkel;
	boolean winkelRichtung;	//in welche Richtung bewegt sich im Moment der Winkel
	float laenge;			//L�nge des Pfeils
	boolean laengeRichtung;	//in welche Richtung bewegt sich im Moment die L�nge

	public Pfeil()
	{

	}

	public void init()
	{
		winkel = pi/4;
		winkelRichtung = true;
		laenge = (float)90;
		laengeRichtung = true;
	}

	public float calcWinkel()
	{
		if (winkelRichtung) winkel += pi/40;
		else winkel -= pi/40;

		if (winkel > pi/2) winkelRichtung = false;		//Damit das Schwenken wendet
		else if (winkel < 0) winkelRichtung = true;
		return winkel;
	}

	public float calcLaenge()
	{
		if (laengeRichtung) laenge += 4;
		else laenge -= 4;

		if (laenge > 180) laengeRichtung = false;		//Damit das Schwenken wendet
		else if (laenge < 90) laengeRichtung = true;

		return laenge;
	}

	public void display(Graphics screen)
	{
		Color farbe = new Color(0,200,50);
		screen.setColor(farbe);

		screen.drawLine(wPosX,wPosY,
			wPosX+(int)(laenge * Math.cos(winkel)),
			wPosY-(int)(laenge * Math.sin(winkel)));
		screen.drawLine(wPosX+(int)(laenge * Math.cos(winkel)),
					wPosY-(int)(laenge * Math.sin(winkel)),
					wPosX+(int)((laenge*9/10) * Math.cos(winkel+pi/40)),
					wPosY-(int)((laenge*9/10) * Math.sin(winkel+pi/40)));
		screen.drawLine(wPosX+(int)(laenge * Math.cos(winkel)),
					wPosY-(int)(laenge * Math.sin(winkel)),
					wPosX+(int)((laenge*9/10) * Math.cos(winkel-pi/40)),
					wPosY-(int)((laenge*9/10) * Math.sin(winkel-pi/40)));
	}
}