import java.awt.*;
import java.awt.Font;

public class PunkteTafel extends Component
{
	int lastPunkte = 0;		//Wieviele Punkte mit dem letzten Wurf (2 oder 3)
	int gesamtPunkte = 0;	//Wieviele Punkte insgesamt
	boolean schonPunkte = false;	//gabs bei dem Wurf schon Punkte?

	public PunkteTafel()
	{

	}

	public void init()
	{
		lastPunkte = 0;
		schonPunkte = false;
	}

	public void newPunkte(int anz)
	{
		if (schonPunkte) return;
		schonPunkte = true;
		lastPunkte = anz;
		gesamtPunkte += anz;
	}

	public void display(Graphics screen)
	{
		Color farbe = new Color(255,255,255);
		Font f = new Font("TimesRoman", Font.PLAIN, 36);
		screen.setColor(farbe);
		screen.setFont(f);
    	screen.drawString(String.valueOf((int)lastPunkte), 142, 78);
    	screen.drawString(String.valueOf((int)gesamtPunkte), 100, 120);
	}
}