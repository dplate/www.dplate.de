"The Ultimative Basketball Game"
von dP-Software


Starten des Spiels:

Es gibt bei Java zwei M�glichkeiten, entweder das Spiel als Applet zu starten oder als Programm.

Als Applet (nicht optimal):
Mit dem "Netscape Navigator", dem "Microsoft Internet Explorer" oder dem "Applet-Viewer" die Datei "index.htm" laden. Dann sollte das Spiel automatisch laden.

Als Programm (optimal):
Daf�r muss Java auf dem Rechner installiert sein. Das Spiel kann dann mit diesem Befehl in der DOS-Eingabeauforderung im Spielverzeichnis gestartet werden: "java Game" (Gro�- und Kleinschreibung beachten)


Anleitung:

Gespielt wird nur mit der Spacetaste. Wenn der gr�ne Pfeil hin- und herschwenkt, einfach beim gew�nschten Winkel Space dr�cken. Danach f�ngt der Pfeil an sich in der L�nge zu ver�ndern. Die L�nge entspricht der St�rke des Wurfs. Hier wieder bei der richtigen Stelle die Space-Taste dr�cken.
Ziel ist es, m�glichst viele K�rbe zu werfen. Ein Korb, bei dem der Ball zuvor das Brett oder den Ring ber�hrt hat, gibt 2 Punkte. Ohne die Ber�hrungen 3 (sehr schwer).
Beendet wird das Spiel einfach durch Schliessen des Fensters.


Anmerkungen:

Die *.java Dateien im Spielverzeichnis sind nicht zum Spielen notwendig. Sie enthalten f�r Interessierte den Quellcode des Spiels.
Auf �lteren Browsern kann es sein, dass das Spiel nicht startet, da diese noch nicht vollst�ndig Java unterst�tzt haben.
Unter dem "Internet Explorer 4.0" und dem "Netscape Navigator 4.0" l�uft es fehlerfrei, allerdings reagieren die Tasten beim Navigator etwas sp�t, so dass das Spielen etwas schwieriger wird. Da die Javaunterst�tzung der Browser nicht optimal ist, ruckelt das Spiel auch etwas, wenn es als Applet gestartet wird.


Bekannte Bugs:

Manchmal bleibt der Ball auf dem Ring des Korbes h�ngen. Dann einfach Space dr�cken und neu werfen.


Werbung:

Noch mehr gratis Spiele von dP-Software gibt es unter: http://dP-Software.home.pages.de/
Bei Fragen Email an mich: dP-Software@gmx.de


Dirk Plate 
am 22.11.2000